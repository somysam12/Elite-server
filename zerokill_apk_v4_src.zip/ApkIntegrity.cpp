// ApkIntegrity.cpp — ZeroKill v4 APK tamper detection
// All path/tag string literals are encrypted at compile-time by Hikari -enable-strcry
// Decoy char-array is NOT a string literal — strcry ignores it, stays visible as bait
// Hash stored XOR'd across split key halves; decode function obfuscated with BCF+CFF

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <string>
#include <vector>
#include <android/log.h>
#include <zlib.h>
#include <openssl/sha.h>

// Strip log in release — no tag strings leak
#define ZL(fmt,...) ((void)0)
#define ZE(fmt,...) ((void)0)

// ══════════════════════════════════════════════════════════════════════════
//  DECOY — visible bait for crackers
//  char-array initializer: Hikari strcry does NOT encrypt these.
//  Patching or NOPing this function has ZERO effect on the real check.
// ══════════════════════════════════════════════════════════════════════════
[[maybe_unused]] static volatile char g_DecoyPkg[] = {
    'c','o','m','.','z','e','r','o','k','i','l','l','\0'
};
[[maybe_unused]] static volatile char g_DecoyCheck[] = {
    'a','p','k','_','i','n','t','e','g','r','i','t','y','_','c','h','e','c','k','\0'
};
[[maybe_unused]] static volatile char g_DecoyResult[] = {
    'i','n','t','e','g','r','i','t','y','_','o','k','\0'
};

// Cracker will likely NOP/patch this — never called from CheckApkIntegrity()
[[maybe_unused, gnu::noinline]]
static bool _DecoyVerify(const char* s) {
    volatile bool r = (strcmp(s, (const char*)g_DecoyPkg) == 0);
    return r;
}

// ══════════════════════════════════════════════════════════════════════════
//  OBFUSCATED HASH STORAGE
//  kK1+kK2 = 32-byte XOR key (split so no contiguous 32-byte block in binary)
//  kEX[i]  = SHA256[i] ^ key[i]   — patched by build_v4.sh
// ══════════════════════════════════════════════════════════════════════════
static const uint8_t kK1[16] = {
    0xA3,0x7F,0xC2,0x11,0xE8,0x55,0x3D,0x90,
    0x1B,0xA6,0x4E,0xF7,0x82,0x29,0x6C,0xD4
};
static const uint8_t kK2[16] = {
    0x5A,0x38,0x71,0xBC,0x0E,0x93,0xF4,0x27,
    0x68,0xAB,0x1D,0x56,0xE3,0x9F,0x40,0xCC
};

static const uint8_t kEX[32] = {
                    // BEGIN_HASH_PLACEHOLDER
    0xDC,0x23,0x38,0xE4,0x30,0x48,0x06,0xED,
    0x5C,0xDC,0x48,0x5F,0x29,0xE5,0xE0,0xF5,
    0x0C,0xAE,0x55,0x1C,0x79,0x8C,0x25,0x63,
    0x8C,0x63,0xB4,0x66,0xE5,0xCB,0xA2,0x87
    // END_HASH_PLACEHOLDER
};

// ── Decode expected hash ──────────────────────────────────────────────────
__attribute__((noinline, annotate("bcf"), annotate("cff"), annotate("vmobf")))
static void _Decode(uint8_t out[32]) {
    volatile uint8_t k[32];
    for (int i = 0; i < 16; i++) k[i]    = kK1[i];
    for (int i = 0; i < 16; i++) k[16+i] = kK2[i];
    for (int i = 0; i < 32; i++) out[i]  = kEX[i] ^ k[i];
    volatile uint8_t sink = 0;
    for (int i = 0; i < 32; i++) sink ^= k[i];
    (void)sink;
}

// ══════════════════════════════════════════════════════════════════════════
//  ZIP STRUCTURES
// ══════════════════════════════════════════════════════════════════════════
#pragma pack(push,1)
struct ZipEOCD {
    uint32_t sig; uint16_t dn,sd,ne,te; uint32_t cs,co; uint16_t cl;
};
struct ZipCD {
    uint32_t sig; uint16_t vm,vn,fl,mt,mtime,mdate;
    uint32_t crc,csz,usz; uint16_t nl,xl,cl,ds,ia; uint32_t ea,loff;
};
struct ZipLH {
    uint32_t sig; uint16_t vn,fl,mt,mtime,mdate;
    uint32_t crc,csz,usz; uint16_t nl,xl;
};
#pragma pack(pop)

// ── Hash one entry (store/deflate) ────────────────────────────────────────
static bool _HashEntry(SHA256_CTX* ctx, FILE* f, long off,
                        uint32_t csz, uint32_t usz, uint16_t meth) {
    if (fseek(f, off, SEEK_SET)) return false;
    if (meth == 0) {
        uint8_t buf[8192]; uint32_t r = csz;
        while (r > 0) {
            uint32_t n = r < sizeof(buf) ? r : sizeof(buf);
            size_t g = fread(buf,1,n,f); if (!g) return false;
            SHA256_Update(ctx,buf,g); r -= (uint32_t)g;
        }
        return true;
    }
    if (meth == 8) {
        z_stream zs{}; if (inflateInit2(&zs,-15)!=Z_OK) return false;
        uint8_t ib[8192],ob[8192]; uint32_t ri=csz; bool ok=true;
        while (true) {
            if (!zs.avail_in && ri) {
                uint32_t n=ri<sizeof(ib)?ri:(uint32_t)sizeof(ib);
                size_t g=fread(ib,1,n,f); if(!g){ok=false;break;}
                zs.next_in=ib; zs.avail_in=(uInt)g; ri-=(uint32_t)g;
            }
            zs.next_out=ob; zs.avail_out=sizeof(ob);
            int r=inflate(&zs,Z_NO_FLUSH);
            uint32_t p=(uint32_t)(sizeof(ob)-zs.avail_out);
            if (p) SHA256_Update(ctx,ob,p);
            if (r==Z_STREAM_END) break;
            if (r!=Z_OK&&r!=Z_BUF_ERROR){ok=false;break;}
            if (!zs.avail_in&&!ri) break;
        }
        inflateEnd(&zs); return ok;
    }
    return false;
}

// ── Compute hash (all entries except lib/) ────────────────────────────────
// "lib/" is a plain string literal here — Hikari strcry encrypts it at compile time
__attribute__((noinline, annotate("bcf"), annotate("cff")))
static bool _Hash(const char* path, uint8_t out[32]) {
    FILE* f = fopen(path,"rb"); if (!f) return false;
    fseek(f,0,SEEK_END); long fsz=ftell(f);
    ZipEOCD eocd{}; bool found=false;
    long hi = fsz-(long)sizeof(ZipEOCD);
    long lo = hi-65535; if(lo<0)lo=0;
    for (long p=hi;p>=lo;p--) {
        fseek(f,p,SEEK_SET); uint32_t s=0; fread(&s,4,1,f);
        if (s==0x06054b50){fseek(f,p,SEEK_SET);fread(&eocd,sizeof(eocd),1,f);found=true;break;}
    }
    if (!found){fclose(f);return false;}
    fseek(f,eocd.co,SEEK_SET);
    std::vector<uint8_t> cd(eocd.cs);
    if (fread(cd.data(),1,eocd.cs,f)!=eocd.cs){fclose(f);return false;}
    SHA256_CTX ctx; SHA256_Init(&ctx);

    // All plain string literals — Hikari strcry AES-encrypts them at compile time
    // Skip: lib/ (changes per build), classes (FrozenFire re-encrypts every build),
    //        META-INF/ (signature files change on every re-sign)

    size_t pos=0;
    for (int i=0;i<eocd.te&&pos+sizeof(ZipCD)<=eocd.cs;i++) {
        const ZipCD* e=reinterpret_cast<const ZipCD*>(cd.data()+pos);
        if (e->sig!=0x02014b50) break;
        size_t es=sizeof(ZipCD)+e->nl+e->xl+e->cl;
        if (pos+es>eocd.cs) break;
        const char* nm=reinterpret_cast<const char*>(cd.data()+pos+sizeof(ZipCD));
        // "lib/"=4, "classes"=7, "META-INF/"=9
        // "assets/ff_core.bin"=18, "assets/dexopt/"=14 — FrozenFire regenerates these
        bool skip=(e->nl>=(uint16_t)4 && memcmp(nm,"lib/",4)==0)
               || (e->nl>=(uint16_t)7 && memcmp(nm,"classes",7)==0)
               || (e->nl>=(uint16_t)9 && memcmp(nm,"META-INF/",9)==0)
               || (e->nl==(uint16_t)18 && memcmp(nm,"assets/ff_core.bin",18)==0)
               || (e->nl>=(uint16_t)14 && memcmp(nm,"assets/dexopt/",14)==0);
        if (!skip&&e->csz>0) {
            ZipLH lh{}; fseek(f,e->loff,SEEK_SET); fread(&lh,sizeof(lh),1,f);
            if (lh.sig==0x04034b50) {
                long doff=e->loff+(long)sizeof(ZipLH)+lh.nl+lh.xl;
                _HashEntry(&ctx,f,doff,e->csz,e->usz,e->mt);
            }
        }
        pos+=es;
    }
    SHA256_Final(out,&ctx); fclose(f); return true;
}

// ── Find APK path ─────────────────────────────────────────────────────────
// All strings here are plain literals — Hikari strcry AES-encrypts every one
__attribute__((noinline))
static std::string _FindApk() {
    FILE* f=fopen("/proc/self/maps","r"); if(!f) return "";
    char line[512]; std::string res;
    while (fgets(line,sizeof(line),f)) {
        if (!strstr(line,".apk")) continue;
        if (!strstr(line,"com.zerokill")&&!strstr(line,"com.bgmi")) continue;
        char* sl=strchr(line,'/'); if(!sl) continue;
        char* en=sl;
        while(*en&&*en!='\n'&&*en!='\r'&&*en!=' '&&*en!='(') en++;
        *en='\0'; res=sl; break;
    }
    fclose(f); return res;
}

// ══════════════════════════════════════════════════════════════════════════
//  PUBLIC ENTRY
// ══════════════════════════════════════════════════════════════════════════
__attribute__((noinline, annotate("bcf"), annotate("cff"), annotate("vmobf")))
void CheckApkIntegrity() {
    std::string apk = _FindApk();
    if (apk.empty()) { abort(); }

    uint8_t computed[32]{};
    if (!_Hash(apk.c_str(), computed)) { abort(); }

    uint8_t expected[32]{};
    _Decode(expected);

    volatile uint32_t diff = 0;
    for (int i = 0; i < 32; i++)
        diff |= (uint32_t)(computed[i] ^ expected[i]);

    if (diff != 0) {
        // SIGSEGV — looks like a real crash, not a detection abort
        volatile int* p = nullptr;
        *p = 0;
        __builtin_unreachable();
    }
}
