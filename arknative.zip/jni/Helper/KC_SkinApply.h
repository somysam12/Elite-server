// ═══════════════════════════════════════════════════════════════════════════
// KC_SkinApply.h — writes selected outfit + fixed default accessories to config.ini
// Lua reads this and applies on game thread (crash-free). Gun skins handled
// separately by the VERIFIED C++ method (GunSkin.cpp maps).
// ═══════════════════════════════════════════════════════════════════════════
#pragma once
#include "KC_SkinData.h"
#include "KC_VehicleData.h"   // g_KCVehicleEnabled
#include <cstdio>
#include <cstring>
#include <sys/stat.h>

// ── Lua skin config (runtime, read by Lua each frame) ───────────────────
// Shared with the loader/license config + Lua-written keys → preserved on write.
#define KC_SKIN_CONFIG "/storage/emulated/0/Android/Skins.ini"

// ── Persistent save file (internal app storage — no STORAGE permission) ─
// Uses com.king.cheats internal dir, always writable by the app process.
#define KC_SAVED_SKINS_PATH "/data/data/com.king.cheats/files/kc_saved_skins.ini"

// ── Max guns we support saving (matches g_KCGunSelIdx array size) ───────
#define KC_MAX_GUN_SAVE 50

// ─────────────────────────────────────────────────────────────────────────
static void KC_WriteSkinConfig() {
    // DISABLED: outfit + all accessories are now managed entirely by the lobby
    // wardrobe (kc_WritePrefs writes OUTFIT/HELMET/BACKPACK/PARACHUTE/GLIDER),
    // and in-match defaults come from the static skin maps. This function used to
    // write SHIRT/PARACHUTE/BACKPACK1/HELMET1 defaults which CLOBBERED the user's
    // lobby selections (esp. the shared PARACHUTE key). Making it a no-op removes
    // that conflict so lobby selections persist and apply correctly.
    return;

    int outfit = (g_KCOutfitIdx > 0 && g_KCOutfitIdx < (int)(sizeof(g_KCOutfits)/sizeof(g_KCOutfits[0])))
                 ? g_KCOutfits[g_KCOutfitIdx].code : 0;
    int backpack  = g_KCSkinEnabled ? KC_DEFAULT_BACKPACK  : 0;
    int parachute = g_KCSkinEnabled ? KC_DEFAULT_PARACHUTE : 0;
    int helmet    = g_KCSkinEnabled ? KC_DEFAULT_HELMET    : 0;
    if (!g_KCSkinEnabled) outfit = 0;

    // Read existing file to preserve Lua-written keys (GUN_xxx, OUTFIT, license, etc.)
    // so rewriting the skin keys never clobbers the shared Skinsini.
    struct { char key[64]; char val[64]; } rows[512];
    int nrows = 0;
    FILE* fr = fopen(KC_SKIN_CONFIG, "r");
    if (fr) {
        char line[128];
        while (fgets(line, sizeof(line), fr) && nrows < 512) {
            char k[64] = {}, v[64] = {};
            if (sscanf(line, "%63[^=]=%63s", k, v) != 2) continue;
            if (strcmp(k,"SHIRT")==0 || strcmp(k,"PARACHUTE")==0 ||
                strcmp(k,"BACKPACK1")==0 || strcmp(k,"HELMET1")==0) continue;
            memcpy(rows[nrows].key, k, 64);
            memcpy(rows[nrows].val, v, 64);
            nrows++;
        }
        fclose(fr);
    }

    FILE* f = fopen(KC_SKIN_CONFIG, "w");
    if (!f) return;
    fprintf(f, "SHIRT=%d\n", outfit);
    fprintf(f, "PARACHUTE=%d\n", parachute);
    fprintf(f, "BACKPACK1=%d\n", backpack);
    fprintf(f, "HELMET1=%d\n", helmet);
    for (int i = 0; i < nrows; i++)
        fprintf(f, "%s=%s\n", rows[i].key, rows[i].val);
    fclose(f);
}

static void KC_ApplySkins() {
    static int lastO=-1; static bool lastE=false;
    if (g_KCOutfitIdx!=lastO || g_KCSkinEnabled!=lastE) {
        lastO=g_KCOutfitIdx; lastE=g_KCSkinEnabled;
        KC_WriteSkinConfig();
    }
}

// ── Save currently applied skins to persistent internal storage ──────────
// Called when user taps "Save Applied Skins" button in Misc tab.
// Safe: uses fopen/fclose only — no memory allocs, no game-thread access.
static bool KC_SaveAppliedSkins() {
    // Ensure internal files dir exists (usually created by Android, but mkdir just in case)
    // We use mkdir silently — failure is fine if dir already exists
    mkdir("/data/data/com.king.cheats",       0755);
    mkdir("/data/data/com.king.cheats/files", 0755);

    FILE* f = fopen(KC_SAVED_SKINS_PATH, "w");
    if (!f) return false;

    // Global toggles
    fprintf(f, "SKINS_ENABLED=%d\n",   (int)g_KCSkinEnabled);
    fprintf(f, "VEHICLE_ENABLED=%d\n", (int)g_KCVehicleEnabled);
    fprintf(f, "OUTFIT_IDX=%d\n",       g_KCOutfitIdx);

    // Gun selections — save count first so loader can validate
    int gunCount = (int)g_KCGunDB.size();
    if (gunCount > KC_MAX_GUN_SAVE) gunCount = KC_MAX_GUN_SAVE;
    fprintf(f, "GUN_COUNT=%d\n", gunCount);
    for (int i = 0; i < gunCount; i++) {
        fprintf(f, "GUN_%d=%d\n", i, g_KCGunSelIdx[i]);
    }

    fclose(f);
    return true;
}

// ── Load saved skins on launch and restore selections ────────────────────
// Call AFTER KC_InitGunDB() so g_KCGunDB is populated.
// Safe: validates all indices before applying — no out-of-bounds possible.
static void KC_LoadSavedSkins() {
    FILE* f = fopen(KC_SAVED_SKINS_PATH, "r");
    if (!f) return;   // no save file yet — first launch, do nothing

    char line[128];
    int  skinsEnabled   = -1;
    int  vehicleEnabled = -1;
    int  outfitIdx      = -1;
    int  gunCount       = 0;
    int  tempGuns[KC_MAX_GUN_SAVE];
    memset(tempGuns, 0, sizeof(tempGuns));
    bool gunCountRead = false;

    while (fgets(line, sizeof(line), f)) {
        int val = 0;
        char key[64] = {};
        // Parse "KEY=VALUE\n"
        if (sscanf(line, "%63[^=]=%d", key, &val) != 2) continue;

        if      (strcmp(key, "SKINS_ENABLED")   == 0) skinsEnabled   = val;
        else if (strcmp(key, "VEHICLE_ENABLED")  == 0) vehicleEnabled = val;
        else if (strcmp(key, "OUTFIT_IDX")       == 0) outfitIdx      = val;
        else if (strcmp(key, "GUN_COUNT")        == 0) {
            gunCount = val;
            if (gunCount < 0) gunCount = 0;
            if (gunCount > KC_MAX_GUN_SAVE) gunCount = KC_MAX_GUN_SAVE;
            gunCountRead = true;
        }
        else if (key[0] == 'G' && key[1] == 'U' && key[2] == 'N' && key[3] == '_') {
            // GUN_N=idx
            int gIdx = 0;
            if (sscanf(key + 4, "%d", &gIdx) == 1) {
                if (gIdx >= 0 && gIdx < KC_MAX_GUN_SAVE) {
                    tempGuns[gIdx] = val;
                }
            }
        }
    }
    fclose(f);

    // ── Apply globals (with bounds checks) ──────────────────────────────
    if (skinsEnabled   >= 0) g_KCSkinEnabled   = (skinsEnabled   != 0);
    if (vehicleEnabled >= 0) g_KCVehicleEnabled = (vehicleEnabled != 0);

    // Outfit index: validate against array size
    int maxOutfit = (int)(sizeof(g_KCOutfits) / sizeof(g_KCOutfits[0]));
    if (outfitIdx >= 0 && outfitIdx < maxOutfit) {
        g_KCOutfitIdx = outfitIdx;
    }

    // ── Apply gun indices (validate against DB size) ──────────────────
    if (gunCountRead) {
        int dbSize = (int)g_KCGunDB.size();
        int applyCount = gunCount;
        if (applyCount > dbSize) applyCount = dbSize;   // never exceed actual DB
        for (int i = 0; i < applyCount; i++) {
            int maxSkins = (int)g_KCGunDB[i].skins.size();
            if (tempGuns[i] >= 0 && tempGuns[i] < maxSkins) {
                g_KCGunSelIdx[i] = tempGuns[i];
            } else {
                g_KCGunSelIdx[i] = 0;  // fallback to default if invalid
            }
        }
    }

    // Trigger Lua skin config write so outfit is applied immediately
    KC_WriteSkinConfig();
}
