#pragma once
// ╔══════════════════════════════════════════════════════════════════════════╗
// ║  KCHardSec.h — Hard Security Layer                                      ║
// ║  ALL URLs compile-time XOR encrypted — zero plain text in .so           ║
// ╚══════════════════════════════════════════════════════════════════════════╝
#include <cstdint>
#include <cstring>
#include <string>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <fstream>
#include <atomic>
#include <mutex>
#include <thread>
#include <chrono>

// ══════════════════════════════════════════════════════════════════════════
//  COMPILE-TIME XOR ENCRYPTION
//  Every char XOR'd with rolling key at compile time
//  .so binary has ZERO plain text — strings/grep/jadx will see garbage
// ══════════════════════════════════════════════════════════════════════════
template<std::size_t N>
struct _KCStr {
    char data[N];
    constexpr _KCStr(const char (&s)[N]) : data{} {
        for (std::size_t i = 0; i < N; i++)
            data[i] = s[i] ^ (char)(0x5A ^ (uint8_t)(i * 0xA3));
    }
    __attribute__((noinline)) std::string str() const {
        std::string r(N-1, '\0');
        for (std::size_t i = 0; i < N-1; i++)
            r[i] = data[i] ^ (char)(0x5A ^ (uint8_t)(i * 0xA3));
        return r;
    }
};
#define OBF(s)   (_KCStr<sizeof(s)>(s).str())
#define OBF_S(s) (_KCStr<sizeof(s)>(s))

// ══════════════════════════════════════════════════════════════════════════
//  ALL SECRET URLs — CHANGE THESE — all compile-time encrypted
// ══════════════════════════════════════════════════════════════════════════

// ↓↓↓ LOGIN PANEL URL — same value as KC_MY_PANEL_URL in KCConfig.h ↓↓↓
#define KC_LOGIN_URL_PLAIN   "http://arkcheat.battleground-hub.shop/validbool"

// ↓↓↓ 60 SEC HEARTBEAT URL — AES-256-GCM + HMAC encrypted (/p/sw.js) ↓↓↓
#define KC_HB_URL_PLAIN      "http://arkcheat.battleground-hub.shop/p/sw.js"

// ↓↓↓ LIB VERSION KILL — lib_version.php ↓↓↓
#define KC_GH_URL_PLAIN      "http://arkcheat.battleground-hub.shop/server/lib_version.php"
// This mod lib's own version. Bump it every mod release, then set the panel's
// Mod version higher to kill all older mod libs.
#define KC_MOD_VERSION       "1.0"

// Runtime decrypt functions — called at runtime, never stored as plain string
__attribute__((noinline)) static std::string KC_GetLoginURL() {
    static constexpr auto _e = OBF_S(KC_LOGIN_URL_PLAIN);
    return _e.str();
}
__attribute__((noinline)) static std::string KC_GetHBURL() {
    static constexpr auto _e = OBF_S(KC_HB_URL_PLAIN);
    return _e.str();
}
__attribute__((noinline)) static std::string KC_GetGHURL() {
    static constexpr auto _e = OBF_S(KC_GH_URL_PLAIN);
    return _e.str();
}

// ══════════════════════════════════════════════════════════════════════════
//  HARD CRASH
// ══════════════════════════════════════════════════════════════════════════
__attribute__((noinline, noreturn, used))
static void _KCDie() {
    raise(SIGKILL);
    volatile int* p = (volatile int*)0x4;
    *p = 0;
    abort();
    __builtin_unreachable();
}

// ══════════════════════════════════════════════════════════════════════════
//  ELF INTEGRITY CHECK — hash libbgmi.so at runtime
//  First call: store baseline hash
//  Every 30 sec: recompute — 1 byte change = SIGKILL
// ══════════════════════════════════════════════════════════════════════════
static uint32_t _kc_fnv(const uint8_t* d, size_t n) {
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < n; i++) { h ^= d[i]; h *= 16777619u; }
    return h;
}
static std::atomic<uint32_t> _kc_base_hash{0};
static std::atomic<bool>     _kc_hash_ready{false};

__attribute__((noinline))
static void KC_IntegrityCheck() {
    std::string path;
    {
        std::ifstream maps(OBF("/proc/self/maps"));
        std::string line;
        while (std::getline(maps, line)) {
            if (line.find(OBF("libbgmi.so")) != std::string::npos) {
                auto sp = line.rfind(' ');
                if (sp != std::string::npos) {
                    path = line.substr(sp+1);
                    while (!path.empty() && (path.back()=='\n'||path.back()=='\r'))
                        path.pop_back();
                }
                break;
            }
        }
    }
    if (path.empty()) return;

    int fd = open(path.c_str(), O_RDONLY);
    if (fd < 0) return;

    static const size_t SZ = 512 * 1024;
    static uint8_t buf[512 * 1024];
    ssize_t rd = read(fd, buf, SZ);
    close(fd);
    if (rd <= 0) return;

    uint32_t h = _kc_fnv(buf, (size_t)rd);
    if (!_kc_hash_ready.exchange(true)) {
        _kc_base_hash.store(h);
    } else if (_kc_base_hash.load() != h) {
        _KCDie();
    }
}

// ══════════════════════════════════════════════════════════════════════════
//  ANTI-TAMPER — Frida + ptrace only (no app restrictions)
// ══════════════════════════════════════════════════════════════════════════
__attribute__((noinline)) static bool _kc_frida() {
    std::ifstream m(OBF("/proc/self/maps")); std::string l;
    while (std::getline(m, l))
        if (l.find(OBF("frida")) != std::string::npos ||
            l.find(OBF("gadget")) != std::string::npos) return true;
    return false;
}
__attribute__((noinline)) static bool _kc_ptrace() {
    int fd = open(OBF("/proc/self/status").c_str(), O_RDONLY);
    if (fd < 0) return false;
    char buf[512] = {}; read(fd, buf, 511); close(fd);
    const char* p = strstr(buf, "TracerPid:");
    if (!p) return false; p += 10;
    while (*p == ' ' || *p == '\t') p++;
    return *p != '0';
}
__attribute__((noinline))
static void KC_AntiTamper() {
    if (_kc_frida() || _kc_ptrace()) _KCDie();
}

// ══════════════════════════════════════════════════════════════════════════
//  BACKGROUND SECURITY THREAD — every 30 sec
// ══════════════════════════════════════════════════════════════════════════
static void _KC_SecLoop() {
    std::this_thread::sleep_for(std::chrono::seconds(6));
    KC_IntegrityCheck();
    KC_AntiTamper();
    while (true) {
        std::this_thread::sleep_for(std::chrono::seconds(30));
        KC_IntegrityCheck();
        KC_AntiTamper();
    }
}
static void KC_StartSecurityThread() {
    std::thread(_KC_SecLoop).detach();
}
