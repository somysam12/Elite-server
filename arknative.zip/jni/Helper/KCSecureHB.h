#pragma once
// ╔══════════════════════════════════════════════════════════════════════════╗
// ║  KCSecureHB.h — AES-256-GCM + HMAC login/heartbeat (protocol v4)          ║
// ║                                                                          ║
// ║  WIRE FORMAT (nothing readable on the wire OR in the binary):             ║
// ║   Request : p1 = base64url( nonce[12] | tag[16] | AES-256-GCM(json) )     ║
// ║             p2 = HMAC_SHA256(p1)      p3 = plaintext build marker          ║
// ║   Response: base64url( nonce[12] | tag[16] | AES-256-GCM(json) ) . HMAC    ║
// ║                                                                          ║
// ║  WHY THIS IS SAFE END-TO-END:                                             ║
// ║   • Confidentiality → AES-256-GCM (payload encrypted) + TLS on top.       ║
// ║     The JSON is NEVER plaintext on the wire or in server logs.            ║
// ║   • Authenticity    → TWO independent proofs a fake server can't fake:    ║
// ║       (1) the GCM auth-tag  (2) the outer HMAC. Both need the secret keys.║
// ║     Repoint the /validbool URL to an attacker server → it has neither key ║
// ║     → tag fails AND HMAC fails → we return -1 → login STAYS false. The     ║
// ║     "valid" verdict is decided ONLY by the real server. (bValid in the    ║
// ║     lib is set from (q==7) — it is never a hardcoded true; see Login.h.)   ║
// ║                                                                          ║
// ║  KEYS ARE HIDDEN (canary-safe): the AES + HMAC keys are stored XOR-masked ║
// ║   as byte arrays and un-masked only in registers at use time, then wiped. ║
// ║   `strings`/grep/jadx on the .so reveal NO readable key.                  ║
// ║                                                                          ║
// ║  FALLBACK SWITCH: if AES ever misbehaves on a device, set HB_USE_AES 0,   ║
// ║   rebuild → instant return to the proven v3 HMAC-only path. The PANEL      ║
// ║   auto-detects either format and replies in kind, so no server change is  ║
// ║   ever needed to flip this.                                               ║
// ╚══════════════════════════════════════════════════════════════════════════╝
#include <string>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <curl/curl.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/rand.h>

// ── 1 = AES-256-GCM + HMAC (encrypted). 0 = v3 HMAC-only (base64url, no AES).
//    Flip to 0 + clean rebuild is the guaranteed escape hatch; panel handles both.
#define HB_USE_AES 1

// Plaintext build marker — sent OUTSIDE any crypto as POST field p3 so the panel
// can log it and PROVE this exact source got compiled + deployed.
// vb_debug.log will show:  build=KCBUILD_V4_AESGCM
#define HB_BUILD_MARKER "KCBUILD_V4_AESGCM"

// Response field mask — MUST equal secrets.php HB_XKEY1. The panel sends the key
// expiry as  x = expiry_unix ^ HB_XKEY1 . This is only an obfuscation mask (NOT a
// secret key), so it may live in the clear. XOR it back to recover the expiry.
#define HB_XKEY1 0xB7E15163ULL

// Last key-expiry (unix seconds) recovered from the most recent beat.
//   -1 = unknown / not received   ·   0 = lifetime (no expiry)   ·   >0 = expiry ts
static long long g_KC_ExpUnix = -1;

// ── XOR-masked secrets (NOT visible to `strings`) ───────────────────────────
// unmask(b,i) = b ^ _KC_PAD[i % 8]. Generated + round-trip-verified offline.
static const unsigned char _KC_PAD[8] =
    { 0x5A, 0x3C, 0x91, 0x7E, 0xB2, 0x08, 0xE5, 0x4D };
// AES-256 key (32 bytes) == secrets.php HB_AES_KEY, masked.
static const unsigned char _KC_AK[32] = {
    0x06,0x01,0x0E,0x54,0x39,0x16,0xA9,0x2D,0x23,0xEE,0x62,0xDA,
    0x07,0xCE,0x02,0xB5,0x53,0x26,0xBA,0x42,0xFF,0x56,0x8A,0x3D,
    0xDB,0xAE,0x32,0xCA,0x77,0xDE,0x02,0xB5 };
// HMAC key (31 bytes) == secrets.php HB_HMAC_KEY, masked.
static const unsigned char _KC_HK[31] = {
    0x02,0x05,0xFA,0x32,0x80,0x65,0xB4,0x7A,0x2C,0x6E,0xA5,0x10,
    0xF0,0x39,0x80,0x14,0x69,0x4C,0xC5,0x46,0xC5,0x5B,0xD0,0x38,
    0x10,0x0A,0xF5,0x3F,0x82,0x6B,0xA3 };

__attribute__((noinline))
static void _kc_unmask(const unsigned char* m, size_t n, unsigned char* out) {
    for (size_t i = 0; i < n; i++) out[i] = m[i] ^ _KC_PAD[i & 7];
}

// base64url (RFC 4648, no padding) — matches PHP strtr('+/','-_') + rtrim('=').
// Handles arbitrary binary (AES output), verified against reference base64 for
// all 256 byte values. NOTE: 6-bit step (bits -= 6) — the earlier -= 8 was a bug.
static const char* _KC_B64 =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
static std::string _kc_b64url_enc(const unsigned char* d, size_t n) {
    std::string o; int val = 0, bits = -6;
    for (size_t i = 0; i < n; i++) {
        val = (val << 8) + d[i]; bits += 8;
        while (bits >= 0) { o += _KC_B64[(val >> bits) & 0x3F]; bits -= 6; }
    }
    if (bits > -6) o += _KC_B64[((val << 8) >> (bits + 8)) & 0x3F];
    return o;
}
static std::string _kc_b64url_dec(const std::string& in) {
    int T[256]; memset(T, -1, sizeof(T));
    for (int i = 0; i < 64; i++) T[(unsigned char)_KC_B64[i]] = i;
    std::string o; int val = 0, bits = -8;
    for (unsigned char c : in) {
        if (T[c] == -1) break;
        val = (val << 6) + T[c]; bits += 6;
        if (bits >= 0) { o += char((val >> bits) & 0xFF); bits -= 8; }
    }
    return o;
}

// HMAC-SHA256(data, HB_HMAC_KEY) → lowercase hex. Key un-masked in a local buffer.
static std::string _kc_hmac_hex(const std::string& data) {
    unsigned char hk[31]; _kc_unmask(_KC_HK, 31, hk);
    unsigned char mac[32]; unsigned int l = 0;
    HMAC(EVP_sha256(), hk, (int)sizeof(hk),
         (const unsigned char*)data.data(), data.size(), mac, &l);
    memset(hk, 0, sizeof(hk));
    static const char* h = "0123456789abcdef";
    std::string o;
    for (unsigned i = 0; i < l; i++) { o += h[mac[i] >> 4]; o += h[mac[i] & 0xF]; }
    return o;
}
static bool _kc_hmac_eq(const std::string& a, const std::string& b) {
    if (a.size() != b.size()) return false;
    unsigned char diff = 0;
    for (size_t i = 0; i < a.size(); i++) diff |= (unsigned char)(a[i] ^ b[i]);
    return diff == 0;
}

// ── AES-256-GCM ──────────────────────────────────────────────────────────────
// Frame layout matches PHP hb_aes_encrypt EXACTLY:  nonce[12] | tag[16] | ct
// (12-byte nonce, 16-byte tag, empty AAD). Returns base64url(frame).
static bool _kc_aes_enc(const std::string& plain, std::string& out_b64) {
    unsigned char key[32]; _kc_unmask(_KC_AK, 32, key);
    unsigned char nonce[12], tag[16];
    bool ok = false;
    if (RAND_bytes(nonce, 12) == 1) {
        EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
        if (ctx) {
            std::string ct; ct.resize(plain.size() ? plain.size() : 1);
            int len = 0, tot = 0;
            do {
                if (EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) != 1) break;
                if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, 12, NULL) != 1) break;
                if (EVP_EncryptInit_ex(ctx, NULL, NULL, key, nonce) != 1) break;
                if (!plain.empty()) {
                    if (EVP_EncryptUpdate(ctx, (unsigned char*)&ct[0], &len,
                            (const unsigned char*)plain.data(), (int)plain.size()) != 1) break;
                    tot = len;
                }
                if (EVP_EncryptFinal_ex(ctx, (unsigned char*)&ct[0] + tot, &len) != 1) break;
                tot += len;
                if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, 16, tag) != 1) break;
                std::string frame;
                frame.reserve(12 + 16 + tot);
                frame.append((const char*)nonce, 12);
                frame.append((const char*)tag, 16);
                frame.append(ct.data(), tot);
                out_b64 = _kc_b64url_enc((const unsigned char*)frame.data(), frame.size());
                ok = true;
            } while (0);
            EVP_CIPHER_CTX_free(ctx);
        }
    }
    memset(key, 0, sizeof(key));
    return ok;
}
// Decrypt base64url(nonce|tag|ct). Returns false if the tag fails (fake server).
static bool _kc_aes_dec(const std::string& b64, std::string& out_plain) {
    std::string raw = _kc_b64url_dec(b64);
    if (raw.size() < 28) return false;                 // 12 nonce + 16 tag
    unsigned char key[32]; _kc_unmask(_KC_AK, 32, key);
    const unsigned char* nonce = (const unsigned char*)raw.data();
    unsigned char tag[16]; memcpy(tag, raw.data() + 12, 16);
    const unsigned char* ct = (const unsigned char*)raw.data() + 28;
    int ctlen = (int)raw.size() - 28;
    bool ok = false;
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (ctx) {
        std::string pt; pt.resize(ctlen > 0 ? ctlen : 1);
        int len = 0, tot = 0;
        do {
            if (EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) != 1) break;
            if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, 12, NULL) != 1) break;
            if (EVP_DecryptInit_ex(ctx, NULL, NULL, key, nonce) != 1) break;
            if (ctlen > 0) {
                if (EVP_DecryptUpdate(ctx, (unsigned char*)&pt[0], &len, ct, ctlen) != 1) break;
                tot = len;
            }
            if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, 16, tag) != 1) break;
            if (EVP_DecryptFinal_ex(ctx, (unsigned char*)&pt[0] + tot, &len) != 1) break; // tag check
            tot += len; pt.resize(tot);
            out_plain.swap(pt);
            ok = true;
        } while (0);
        EVP_CIPHER_CTX_free(ctx);
    }
    memset(key, 0, sizeof(key));
    return ok;
}

// Encode the request payload per the active protocol.
static bool _kc_pack(const std::string& js, std::string& p1) {
#if HB_USE_AES
    return _kc_aes_enc(js, p1);
#else
    p1 = _kc_b64url_enc((const unsigned char*)js.data(), js.size());
    return true;
#endif
}
// Decode the response body per the active protocol.
static bool _kc_unpack(const std::string& body, std::string& plain) {
#if HB_USE_AES
    return _kc_aes_dec(body, plain);
#else
    plain = _kc_b64url_dec(body);
    return !plain.empty();
#endif
}

static size_t _kc_hb_wr(char* p, size_t s, size_t n, void* u) {
    ((std::string*)u)->append(p, s * n); return s * n;
}

// One authenticated beat to the panel (login or heartbeat).
// Returns: 7=OK · 1=soft(maintenance) · 2=blocked/expired · -1=network/forgery.
static int KC_SecureBeat(const std::string& hbUrl, const std::string& key,
                         const std::string& dev, const std::string& pkg) {
    g_KC_ExpUnix = -1;                       // reset; set only on a verified reply
    time_t t = time(0);
    char js[768];
    snprintf(js, sizeof(js),
        "{\"k\":\"%s\",\"d\":\"%s\",\"t\":%ld,\"pkg\":\"%s\",\"libs\":\"\",\"bh\":\"\",\"v\":\"%s\"}",
        key.c_str(), dev.c_str(), (long)t, pkg.c_str(), HB_BUILD_MARKER);

    std::string p1;
    if (!_kc_pack(std::string(js), p1)) { memset(js, 0, sizeof(js)); return -1; }
    memset(js, 0, sizeof(js));               // wipe plaintext JSON from stack
    std::string p2 = _kc_hmac_hex(p1);
    std::string post = "p1=" + p1 + "&p2=" + p2 + "&p3=" + std::string(HB_BUILD_MARKER);

    std::string resp;
    CURL* c = curl_easy_init(); if (!c) return -1;
    curl_easy_setopt(c, CURLOPT_URL, hbUrl.c_str());
    curl_easy_setopt(c, CURLOPT_POSTFIELDS, post.c_str());
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, _kc_hb_wr);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, &resp);
    curl_easy_setopt(c, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(c, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(c, CURLOPT_TIMEOUT, 12L);
    curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, 1L);
    CURLcode rc = curl_easy_perform(c);
    curl_easy_cleanup(c);
    if (rc != CURLE_OK || resp.empty()) return -1;

    // Trim any trailing whitespace a webserver/CDN might append.
    while (!resp.empty() && (resp.back()=='\n' || resp.back()=='\r' ||
           resp.back()==' ' || resp.back()=='\t')) resp.pop_back();

    // Response = "base64url(nonce|tag|ct) . hmachex". Verify HMAC, then decrypt.
    // A fake server fails the HMAC (no key) AND the GCM tag (no key) → q stays -1.
    int q = -1;
    size_t dot = resp.rfind('.');
    if (dot != std::string::npos && dot > 0 && dot + 1 < resp.size()) {
        std::string body = resp.substr(0, dot);
        std::string sig  = resp.substr(dot + 1);
        if (_kc_hmac_eq(_kc_hmac_hex(body), sig)) {
            std::string plain;
            if (_kc_unpack(body, plain)) {
                size_t pos = plain.find("\"q\":");
                if (pos != std::string::npos) q = atoi(plain.c_str() + pos + 4);
                // Recover key expiry: x = expiry_unix ^ HB_XKEY1 (0 = lifetime).
                size_t xp = plain.find("\"x\":");
                if (xp != std::string::npos) {
                    long long xval = atoll(plain.c_str() + xp + 4);
                    g_KC_ExpUnix = xval ^ (long long)HB_XKEY1;
                }
                std::fill(plain.begin(), plain.end(), '\0');
            }
        }
    }
    std::fill(resp.begin(), resp.end(), '\0');
    return q;   // -1 if signature/tag invalid (patched URL / fake server)
}
