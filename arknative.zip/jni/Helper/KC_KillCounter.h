// ═══════════════════════════════════════════════════════════════════════════
// KC_KillCounter.h — Per-gun kill counter (adapted from the proven reference)
//
// Behaviour (as requested): the FIRST kill with a gun turns its per-gun counter
// ON; after that, whenever that gun is held (even after switching to another
// weapon and back), its counter shows for the rest of the match.
//
// Design:
//   • CheckNeedMainKillCounterUI (weapon equip) → DIRECTLY calls
//     UpdateMainKillCounterUI(true) which ShowUI's + sets the number → shows on
//     equip, not only after a kill.
//   • A light change-detected refresh (CheckAndRefreshKillUI) runs on a ticker;
//     it only touches the widget when the count actually changed → no freeze.
//   • Kill count persists to /storage/emulated/0/Android/KillCount.dat.
// ═══════════════════════════════════════════════════════════════════════════
#pragma once

static const char* kc_kill_counter_script = R"lua(

_G.killCountInfo    = _G.killCountInfo    or {}
_G.lastDisplayedKills = _G.lastDisplayedKills or {}
_G.lastFileContent  = ""

function _G.GetKillCounterPath()
    return "/storage/emulated/0/Android/KillCount.dat"
end
_G.ActiveKillCounterPath = nil

local function saveKillCountToFile()
    if not _G.ActiveKillCounterPath then _G.ActiveKillCounterPath = _G.GetKillCounterPath() end
    local file = io.open(_G.ActiveKillCounterPath, 'w+')
    if not file then return end
    local content = '{\n'
    for weaponID, count in pairs(_G.killCountInfo) do
        content = content .. string.format('    [%d] = %d,\n', weaponID, count)
    end
    content = content .. '}'
    file:write(content); file:close()
    _G.lastFileContent = content
end

function _G.loadKillCountFromFile()
    if not _G.ActiveKillCounterPath then _G.ActiveKillCounterPath = _G.GetKillCounterPath() end
    local file = io.open(_G.ActiveKillCounterPath, 'r')
    if file then
        local content = file:read('*a'); file:close()
        _G.lastFileContent = content
        if content ~= '' then
            content = content:gsub('\239\187\191', ''):gsub('^%s+', '')
            local tempTable = {}
            for weaponID, count in content:gmatch('%[(%d+)%]%s*=%s*(%d+)') do
                tempTable[tonumber(weaponID)] = tonumber(count)
            end
            if next(tempTable) then _G.killCountInfo = tempTable end
        end
    end
end

function _G.getKills(weaponID)
    return weaponID and _G.killCountInfo[weaponID] or 0
end

-- ── addKill: increment + persist + show the counter ──────────────────────────
function _G.addKill(weaponID, count)
    if not weaponID or not count then return end
    _G.killCountInfo[weaponID] = (_G.killCountInfo[weaponID] or 0) + count
    pcall(saveKillCountToFile)
    local PC = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
    if PC then
        local uCharacter = PC:GetPlayerCharacterSafety()
        if uCharacter then
            local currweapon = uCharacter:GetCurrentWeapon()
            if currweapon then
                local SkinID = slua.IndexReference(currweapon.synData:Get(7), "defineID").TypeSpecificID
                if _G.OurkillCountSystem then
                    _G.OurkillCountSystem:UpdateMainKillCounterUI(true, weaponID, SkinID)
                end
            end
        end
    end
end

-- ══════════════════════════════════════════════════════════════════════════════
-- Kill detection — SKillInfo.FileItem
-- ══════════════════════════════════════════════════════════════════════════════
pcall(function()
    local SKillInfo = require("GameLua.Mod.BaseMod.Client.KillInfoTips.KillInfo")
    local ECharacterHealthStatus = import("ECharacterHealthStatus")
    local MM = require("client.module_framework.ModuleManager")
    local O_FileItem = SKillInfo.__inner_impl.FileItem

    SKillInfo.__inner_impl.FileItem = function(self, DamageRecordData)
        if not self or not DamageRecordData then return O_FileItem(self, DamageRecordData) end
        local LogicKillCounter = MM.GetModule(MM.CommonModuleConfig.LogicKillCounter)
        if not LogicKillCounter then return O_FileItem(self, DamageRecordData) end
        local uCharacter = slua_GameFrontendHUD and
                           slua_GameFrontendHUD:GetPlayerController() and
                           slua_GameFrontendHUD:GetPlayerController():GetPlayerCharacterSafety()
        if not uCharacter or not slua.isValid(uCharacter) then return O_FileItem(self, DamageRecordData) end

        local SelfName = uCharacter:GetPlayerNameSafety()
        if DamageRecordData.Causer == SelfName then
            local currWeapon = uCharacter:GetCurrentWeapon()
            if currWeapon and slua.isValid(currWeapon) then
                local DefineID = currWeapon:GetItemDefineID() and currWeapon:GetItemDefineID().TypeSpecificID or 0
                if DefineID ~= 0 then
                    local ExpandData = slua.LuaArchiverDecode(LuaStateWrapper, DamageRecordData.ExpandDataContent) or {}
                    local SupportKillCounter = LogicKillCounter:GetBaseKillCounterIdByWeaponId(DefineID)
                    if SupportKillCounter and
                       DamageRecordData.ResultHealthStatus == ECharacterHealthStatus.FinishedLastBreath then
                        ExpandData.KillCounterItemId = DefineID
                        ExpandData.KillCounterNum = (ExpandData.KillCounterNum or 0) + 1
                        _G.addKill(DefineID, 1)
                    end
                    local synData = currWeapon.synData
                    if synData and slua.isValid(synData) then
                        local weaponDefineID = slua.IndexReference(synData:Get(7), "defineID")
                        if weaponDefineID and slua.isValid(weaponDefineID) then
                            DamageRecordData.CauserWeaponAvatarID = weaponDefineID.TypeSpecificID
                        end
                    end
                    DamageRecordData.ExpandDataContent = slua.LuaArchiverEncode(LuaStateWrapper, ExpandData)
                end
            end
        end
        O_FileItem(self, DamageRecordData)
    end
end)

-- ══════════════════════════════════════════════════════════════════════════════
-- UI hooks
-- ══════════════════════════════════════════════════════════════════════════════
pcall(function()
    local MyMainKillCounter   = require("GameLua.Mod.BaseMod.Client.KillCounter.MainKillCounter")
    local MyKillCountSubSystem= require("GameLua.Mod.BaseMod.Client.KillCounter.KillCounterUISubsystem")
    local MyMainWeaponKillCounter = require("GameLua.Mod.BaseMod.Client.KillCounter.MainWeaponKillCounter")
    local SlotBase            = require("GameLua.Mod.BaseMod.Client.MainControlUI.SwitchWeaponSlotMode2")

    _G.OurkillCountSystem = MyKillCountSubSystem.__inner_impl

    -- Main counter refresh: keep OUR number on it
    MyMainKillCounter.__inner_impl.OnRefreshUI = function(self, _, _, UID)
        pcall(function()
            local MM = require("client.module_framework.ModuleManager")
            local LogicKillCounter = MM.GetModule(MM.CommonModuleConfig.LogicKillCounter)
            local uCharacter = slua_GameFrontendHUD:GetPlayerController():GetPlayerCharacterSafety()
            if not uCharacter then return end
            local currweapon = uCharacter:GetCurrentWeapon()
            if currweapon then
                local DefineID = currweapon:GetItemDefineID().TypeSpecificID
                local avatarID = slua.IndexReference(currweapon.synData:Get(7), "defineID").TypeSpecificID
                local cid = LogicKillCounter:GetEquipedKillCounterId(6114302174, avatarID)
                if not cid or cid == 0 then cid = LogicKillCounter:GetBaseKillCounterIdByWeaponId(DefineID) end
                self.KillCounterItem:SetKillCounterItemShowWithNum(cid, _G.getKills(DefineID), avatarID)
            end
        end)
    end

    -- Injected skins are always "supported"
    MyKillCountSubSystem.__inner_impl.CheckSupportKCUI = function(self) return true end

    -- Weapon EQUIP → show the counter (this is the on-equip trigger)
    MyKillCountSubSystem.__inner_impl.CheckNeedMainKillCounterUI = function(self, Weapon, PlayerID)
        pcall(function()
            local uCharacter = slua_GameFrontendHUD:GetPlayerController():GetPlayerCharacterSafety()
            if not uCharacter then return end
            local currweapon = uCharacter:GetCurrentWeapon()
            if currweapon then
                local DefineID = currweapon:GetItemDefineID().TypeSpecificID
                self:UpdateMainKillCounterUI(true, DefineID,
                    slua.IndexReference(currweapon.synData:Get(7), "defineID").TypeSpecificID)
            end
        end)
    end

    -- The main show/hide + number logic
    local o_UpdateMainKillCounterUI = MyKillCountSubSystem.__inner_impl.UpdateMainKillCounterUI
    MyKillCountSubSystem.__inner_impl.UpdateMainKillCounterUI = function(self, bShow, WeaponID, AvatarID)
        pcall(function()
            o_UpdateMainKillCounterUI(self, bShow, WeaponID, AvatarID)
            local UIManager = require("client.slua_ui_framework.manager")
            local MainKillCounter = UIManager.GetUI(UIManager.UI_Config_InGame.MainKillCounter)
            local uCharacter = slua_GameFrontendHUD:GetPlayerController():GetPlayerCharacterSafety()
            if not uCharacter then return end
            local currweapon = uCharacter:GetCurrentWeapon()

            if not bShow and MainKillCounter then
                UIManager.CloseUI(UIManager.UI_Config_InGame.MainKillCounter)
            elseif bShow and currweapon then
                local DefineID = currweapon:GetItemDefineID().TypeSpecificID
                local avatarID = slua.IndexReference(currweapon.synData:Get(7), "defineID").TypeSpecificID
                local MM = require("client.module_framework.ModuleManager")
                local LogicKillCounter = MM.GetModule(MM.CommonModuleConfig.LogicKillCounter)
                local SupportKillCounter = LogicKillCounter:GetBaseKillCounterIdByWeaponId(DefineID)
                if SupportKillCounter == nil and MainKillCounter then
                    UIManager.CloseUI(UIManager.UI_Config_InGame.MainKillCounter)
                elseif DefineID == avatarID and MainKillCounter then
                    UIManager.CloseUI(UIManager.UI_Config_InGame.MainKillCounter)
                else
                    local cid = LogicKillCounter:GetEquipedKillCounterId(6114302174, avatarID)
                    if not cid or cid == 0 then cid = SupportKillCounter end
                    if not MainKillCounter then
                        UIManager.ShowUI(UIManager.UI_Config_InGame.MainKillCounter, DefineID, avatarID)
                        MainKillCounter = UIManager.GetUI(UIManager.UI_Config_InGame.MainKillCounter)
                        if MainKillCounter then
                            MainKillCounter:SetKillCounterItemShowWithNum(cid, _G.getKills(DefineID), avatarID)
                        end
                    else
                        pcall(function() MainKillCounter:UpdateWeaponID(DefineID, avatarID) end)
                        MainKillCounter:SetKillCounterItemShowWithNum(cid, _G.getKills(DefineID), avatarID)
                    end
                end
            end
        end)
    end

    -- Weapon-slot panel counter
    MyMainWeaponKillCounter.__inner_impl.OnRefresh = function(self, SelfUID)
        pcall(function()
            local MM = require("client.module_framework.ModuleManager")
            local LogicKillCounter = MM.GetModule(MM.CommonModuleConfig.LogicKillCounter)
            local skinID = (self.WeaponIDOrAvatarID and self.WeaponIDOrAvatarID ~= self.WeaponID)
                           and self.WeaponIDOrAvatarID or self.WeaponID
            local cid = LogicKillCounter:GetBaseKillCounterIdByWeaponId(self.WeaponID)
            self.KillCounterItem:SetKillCounterItemShowWithNum(cid, _G.getKills(self.WeaponID), skinID)
        end)
    end

    -- KC icon in the weapon-switch slot
    local o_CheckShowKCIcon = SlotBase.__inner_impl.CheckShowKCIcon
    SlotBase.__inner_impl.CheckShowKCIcon = function(self)
        pcall(function()
            if o_CheckShowKCIcon then o_CheckShowKCIcon(self) end
            local ESlateVisibility = import("ESlateVisibility")
            local MM = require("client.module_framework.ModuleManager")
            local LogicKillCounter = MM.GetModule(MM.CommonModuleConfig.LogicKillCounter)
            local CurWeapon = self:GetCurrentWeapon()
            if not slua.isValid(CurWeapon) then
                self.KillCounterImg:SetVisibility(ESlateVisibility.Collapsed)
                return
            end
            local WeaponID = CurWeapon:GetWeaponID()
            if LogicKillCounter:GetBaseKillCounterIdByWeaponId(WeaponID) then
                self.KillCounterImg:SetVisibility(ESlateVisibility.SelfHitTestInvisible)
            end
        end)
    end
end)

-- ══════════════════════════════════════════════════════════════════════════════
-- Light change-detected refresh (keeps the shown number in sync; only touches
-- the widget when the count actually changed → no per-frame widget work).
-- ══════════════════════════════════════════════════════════════════════════════
function _G.CheckAndRefreshKillUI()
    pcall(function()
        local PC = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
        if not PC then return end
        local uCharacter = PC:GetPlayerCharacterSafety()
        if not uCharacter then return end
        local currweapon = uCharacter:GetCurrentWeapon()
        if not currweapon then return end
        local DefineID = currweapon:GetItemDefineID().TypeSpecificID
        if DefineID == 0 then return end
        local realKills = _G.getKills(DefineID)
        local lastShown = _G.lastDisplayedKills[DefineID] or -1
        if realKills ~= lastShown then
            local UIManager = require("client.slua_ui_framework.manager")
            local MainKillCounter = UIManager.GetUI(UIManager.UI_Config_InGame.MainKillCounter)
            if MainKillCounter and slua.isValid(MainKillCounter) then
                local avatarID = slua.IndexReference(currweapon.synData:Get(7), "defineID").TypeSpecificID
                local MM = require("client.module_framework.ModuleManager")
                local LogicKillCounter = MM.GetModule(MM.CommonModuleConfig.LogicKillCounter)
                local cid = LogicKillCounter:GetEquipedKillCounterId(6114302174, avatarID)
                if not cid or cid == 0 then cid = LogicKillCounter:GetBaseKillCounterIdByWeaponId(DefineID) end
                MainKillCounter:SetKillCounterItemShowWithNum(cid, realKills, avatarID)
                _G.lastDisplayedKills[DefineID] = realKills
            end
        end
    end)
end

-- ── Load persisted counts + start the light refresh ticker ───────────────────
_G.loadKillCountFromFile()
pcall(function()
    local tk = require('common.time_ticker')
    if tk and tk.AddTimerLoop then
        tk.AddTimerLoop(0.1, _G.CheckAndRefreshKillUI, -1, 1)
    end
end)
print('[KCKills] Per-gun kill counter ready')

)lua";
