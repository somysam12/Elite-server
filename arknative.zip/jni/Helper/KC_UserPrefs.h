#pragma once
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <sys/stat.h>
#include "KC_SkinData.h"
#include "KC_GunMaps.h"

#define KC_PREFS_PATH_1  "/storage/emulated/0/Android/Skins.ini"
#define KC_PREFS_PATH_2  "/sdcard/Skins.ini"

static int  g_UserOutfitId        = 0;
static int  g_UserGunBodySkin[60] = {};
static int  g_UserHelmetSkin      = 0;  // user selected helmet skin
static int  g_UserBackpackSkin    = 0;  // user selected backpack skin
static int  g_UserParachuteSkin   = 0;  // user selected parachute skin
static int  g_UserGliderSkin      = 0;  // user selected glider skin
static int  g_UserMaskSkin        = 0;  // user selected mask/cover skin
static int  g_UserHeadgearSkin    = 0;  // user selected headgear/cover skin
static int  g_UserGlovesSkin      = 0;  // user selected gloves skin
// melee skins: [0]=Pan [1]=Machete [2]=Dagger [3]=Crowbar
static int  g_UserMeleeSkin[4]    = {};
static bool g_UserPrefsLoaded     = false;

static void KC_LoadUserPrefs() {
    const char* paths[] = { KC_PREFS_PATH_1, KC_PREFS_PATH_2, nullptr };
    FILE* f = nullptr;
    for (int i = 0; paths[i] && !f; i++) f = fopen(paths[i],"r");
    if (!f) return;
    char line[128];
    while (fgets(line, sizeof(line), f)) {
        char key[64]; int val = 0;
        if (sscanf(line, "%63[^=]=%d", key, &val) != 2) continue;
        if (strcmp(key, "OUTFIT") == 0) {
            g_UserOutfitId = val;
        } else if (strcmp(key, "HELMET") == 0) {
            g_UserHelmetSkin = val;
        } else if (strcmp(key, "BACKPACK") == 0) {
            g_UserBackpackSkin = val;
        } else if (strcmp(key, "PARACHUTE") == 0) {
            g_UserParachuteSkin = val;
        } else if (strcmp(key, "GLIDER") == 0) {
            g_UserGliderSkin = val;
        } else if (strcmp(key, "MASK") == 0) {
            g_UserMaskSkin = val;
        } else if (strcmp(key, "HEADGEAR") == 0) {
            g_UserHeadgearSkin = val;
        } else if (strcmp(key, "GLOVES") == 0) {
            g_UserGlovesSkin = val;
        } else if (strcmp(key, "MELEE_PAN") == 0) {
            g_UserMeleeSkin[0] = val;
        } else if (strcmp(key, "MELEE_MACHETE") == 0) {
            g_UserMeleeSkin[1] = val;
        } else if (strcmp(key, "MELEE_DAGGER") == 0) {
            g_UserMeleeSkin[2] = val;
        } else if (strcmp(key, "MELEE_CROWBAR") == 0) {
            g_UserMeleeSkin[3] = val;
        } else if (strncmp(key, "GUN_", 4) == 0) {
            int weaponID = atoi(key + 4);
            for (int gi = 0; gi < (int)g_KCGunDB.size() && gi < 60; gi++) {
                if (g_KCGunDB[gi].weaponID == weaponID) {
                    g_UserGunBodySkin[gi] = val;
                    break;
                }
            }
        }
    }
    fclose(f);
    g_UserPrefsLoaded = true;
}

static void KC_SyncModSkinsIDFromPrefs() {
    g_KillOutfitId = g_UserOutfitId;
    // ── Helmet — the wardrobe puts the DISPLAY base (BPID:0, invalid) in the
    // skin slot, so the game shows a default. The equippable per-level codes for
    // HELMETS are ALWAYS 1502-prefixed (verified: Inferno Rider base 1505000014
    // → Lv3 1502003014; Piercing Fang base 1502000408 → Lv3 1502003408).
    //   levelCode(N) = 1502000000 + N*1000 + (base % 1000)
    // We map the display base (any prefix) → the Lv3 code so findNewId replaces
    // the invalid slot value with a valid skin.
    if (g_UserHelmetSkin > 0) {
        int last3 = g_UserHelmetSkin % 1000;
        int lv3   = 1502000000 + 3000 + last3;
        Helmet[g_UserHelmetSkin]      = lv3;   // the exact base the user selected
        Helmet[1505000000 + last3]    = lv3;   // 1505-prefixed display base
        Helmet[1502000000 + last3]    = lv3;   // 1502-prefixed display base
        Helmet[lv3]                   = lv3;   // self-map so it stays
    }
    // ── Backpack — same idea, but backpack level codes keep the BASE prefix
    // (Godzilla 1501000061 → Lv3 1501003061). levelCode = prefix + N*1000 + last3.
    if (g_UserBackpackSkin > 0) {
        int prefix = (g_UserBackpackSkin / 1000000) * 1000000;   // 1501000000 / 1504000000
        int last3  = g_UserBackpackSkin % 1000;
        int lv3    = prefix + 3000 + last3;
        Bagpack[g_UserBackpackSkin] = lv3;
        Bagpack[lv3]                = lv3;      // self-map
    }
    // Update PARACHUTE map with user selection — remap every known default
    // parachute slot to the chosen skin, plus a self-map so it stays stable.
    if (g_UserParachuteSkin > 0) {
        for (auto& kv : Parachute) kv.second = g_UserParachuteSkin;
        Parachute[g_UserParachuteSkin] = g_UserParachuteSkin;
        // common default parachute base ids (so an unmapped default still applies)
        Parachute[703001] = g_UserParachuteSkin;
        Parachute[703002] = g_UserParachuteSkin;
    }
    // Update GLIDER map — cover BOTH glider id schemes (602xxx equippable incl.
    // Default Glider 602130, and the 4151xxx scheme) so whatever base id the
    // deployed glider uses gets remapped to the user's selection.
    if (g_UserGliderSkin > 0) {
        for (auto& kv : GliderSkin) kv.second = g_UserGliderSkin;
        GliderSkin[g_UserGliderSkin] = g_UserGliderSkin;
        GliderSkin[602130] = g_UserGliderSkin;   // Default Glider (602 scheme)
        GliderSkin[4151000] = g_UserGliderSkin;
        GliderSkin[4151140] = g_UserGliderSkin;
    }

    // Update melee skin maps from user prefs
    if (g_UserMeleeSkin[0] > 0) { PANSkinsID[108004]     = g_UserMeleeSkin[0]; }
    if (g_UserMeleeSkin[1] > 0) { MacheteSkinsID[108001]  = g_UserMeleeSkin[1]; }
    if (g_UserMeleeSkin[2] > 0) { DaggerSkinsID[108005]   = g_UserMeleeSkin[2]; }
    if (g_UserMeleeSkin[3] > 0) { CrowbarSkinsID[108002]  = g_UserMeleeSkin[3]; }

    // Update gun ModSkinsID using exact verified attachment codes from KC_GunMaps
    for (int gi = 0; gi < (int)g_KCGunDB.size() && gi < 60; gi++) {
        int bodyId = g_UserGunBodySkin[gi];
        if (bodyId <= 0) continue;
        int weaponId = g_KCGunDB[gi].weaponID;
        ModSkinsID[weaponId] = bodyId;
        for (int si = 0; si < (int)g_KCGunDB[gi].skins.size(); si++) {
            auto it = g_KCGunDB[gi].skins[si].map.find(weaponId);
            if (it != g_KCGunDB[gi].skins[si].map.end() && it->second == bodyId) {
                g_KCGunSelIdx[gi] = si;
                // Register EVERY attachment code of this skin so all slots apply.
                for (auto& kv : g_KCGunDB[gi].skins[si].map)
                    ModSkinsID[kv.first] = kv.second;
                break;
            }
        }
    }
}

static int KC_GetUserOutfitId() {
    if (g_UserOutfitId > 0) return g_UserOutfitId;
    int idx = g_KCOutfitIdx;
    int n = (int)(sizeof(g_KCOutfits)/sizeof(g_KCOutfits[0]));
    if (idx >= 0 && idx < n) return g_KCOutfits[idx].code;
    return 0;
}

static void KC_InitUserPrefs() {
    KC_InitGunDB();
    // NOTE: Skinsini is now SHARED with the loader/license config, so we must
    // NOT wipe it on startup (that would erase the license + persisted skins).
    // Skin keys are overwritten in place by KC_SkinApply's preserve-and-rewrite,
    // so lobby-applied skins persist across restarts until the file is deleted.
}
