#pragma once
#include <unordered_map>
#include <vector>
#include <string>

struct KCSkinMap {
    std::string name;
    std::unordered_map<int,int> map;
};
struct KCGunEntry {
    int weaponID;
    std::string gunName;
    std::vector<KCSkinMap> skins;
};
static std::vector<KCGunEntry> g_KCGunDB;
static int g_KCGunSelIdx[60] = {0};
static void KC_InitGunDB() {
    if (!g_KCGunDB.empty()) return;
    g_KCGunDB = {
        {101001, "AKM", {
            {"None", {}},
            {"Jack-o'-lantern", {
                {101001, 1101001116},
                {201009, 1010011107},  // Compensator
                {201010, 1010011106},  // Flash Hider
                {201011, 1010011108},  // Suppressor
                {203001, 1010011105},  // Red Dot Sight
                {203002, 1010011104},  // Holographic Sight
                {203003, 1010011103},  // 2x Scope
                {203004, 1010011102},  // 4x Scope
                {204011, 1010011109},  // Extended Mag
                {204013, 1010011112},  // Extended Quickdraw Mag
            }},
            {"Ghillie Dragon", {
                {101001, 1101001128},
                {201009, 1010011233},  // Compensator
                {201010, 1010011232},  // Flash Hider
                {201011, 1010011234},  // Suppressor
                {203001, 1010011226},  // Red Dot Sight
                {203002, 1010011225},  // Holographic Sight
                {203003, 1010011224},  // 2x Scope
                {203004, 1010011222},  // 4x Scope
                {203014, 1010011223},  // 3x Scope
                {204011, 1010011227},  // Extended Mag
                {204012, 1010011228},  // Quickdraw Mag
                {204013, 1010011229},  // Extended Quickdraw Mag
            }},
            {"Codebreaker", {
                {101001, 1101001154},
                {201009, 1010011488},  // Compensator
                {201010, 1010011487},  // Flash Hider
                {201011, 1010011489},  // Suppressor
                {203001, 1010011486},  // Red Dot Sight
                {203002, 1010011485},  // Holographic Sight
                {203003, 1010011484},  // 2x Scope
                {203004, 1010011482},  // 4x Scope
                {203014, 1010011483},  // 3x Scope
                {203015, 1010011497},  // 6x Scope
                {203100, 1010011498},  // Canted Sight
                {204011, 1010011490},  // Extended Mag
                {204012, 1010011493},  // Quickdraw Mag
                {204013, 1010011494},  // Extended Quickdraw Mag
            }},
            {"Wandering Tyrant", {
                {101001, 1101001174},
                {201009, 1010011668},  // Compensator
                {201010, 1010011667},  // Flash Hider
                {201011, 1010011669},  // Suppressor
                {203001, 1010011666},  // Red Dot Sight
                {203002, 1010011665},  // Holographic Sight
                {203003, 1010011664},  // 2x Scope
                {203004, 1010011662},  // 4x Scope
                {203014, 1010011663},  // 3x Scope
                {204011, 1010011670},  // Extended Mag
                {204012, 1010011673},  // Quickdraw Mag
                {204013, 1010011674},  // Extended Quickdraw Mag
            }},
            {"Starsea Admiral", {
                {101001, 1101001213},
                {201009, 1010012068},  // Compensator
                {201010, 1010012067},  // Flash Hider
                {201011, 1010012069},  // Suppressor
                {203001, 1010012066},  // Red Dot Sight
                {203002, 1010012065},  // Holographic Sight
                {203003, 1010012064},  // 2x Scope
                {203004, 1010012062},  // 4x Scope
                {203014, 1010012063},  // 3x Scope
                {203100, 1010012074},  // Canted Sight
                {204011, 1010012070},  // Extended Mag
                {204012, 1010012072},  // Quickdraw Mag
                {204013, 1010012073},  // Extended Quickdraw Mag
            }},
            {"Bunny Munchkin", {
                {101001, 1101001231},
                {201009, 1010012268},  // Compensator
                {201010, 1010012267},  // Flash Hider
                {201011, 1010012269},  // Suppressor
                {203001, 1010012266},  // Red Dot Sight
                {203002, 1010012265},  // Holographic Sight
                {203003, 1010012264},  // 2x Scope
                {203004, 1010012262},  // 4x Scope
                {203014, 1010012263},  // 3x Scope
                {203015, 1010012075},  // 6x Scope
                {203100, 1010012275},  // Canted Sight
                {204011, 1010012272},  // Extended Mag
                {204012, 1010012273},  // Quickdraw Mag
                {204013, 1010012274},  // Extended Quickdraw Mag
            }},
            {"Decisive Day", {
                {101001, 1101001242},
                {201009, 1010012358},  // Compensator
                {201010, 1010012357},  // Flash Hider
                {201011, 1010012359},  // Suppressor
                {203001, 1010012356},  // Red Dot Sight
                {203002, 1010012355},  // Holographic Sight
                {203003, 1010012354},  // 2x Scope
                {203004, 1010012352},  // 4x Scope
                {203014, 1010012353},  // 3x Scope
                {203015, 1010012276},  // 6x Scope
                {203100, 1010012365},  // Canted Sight
                {204011, 1010012362},  // Extended Mag
                {204012, 1010012363},  // Quickdraw Mag
                {204013, 1010012364},  // Extended Quickdraw Mag
            }},
            {"Lightshift Temple (Divine Moon)", {
                {101001, 1101001249},
                {201009, 1010012438},  // Compensator
                {201010, 1010012437},  // Flash Hider
                {201011, 1010012439},  // Suppressor
                {203001, 1010012436},  // Red Dot Sight
                {203002, 1010012435},  // Holographic Sight
                {203003, 1010012434},  // 2x Scope
                {203004, 1010012432},  // 4x Scope
                {203014, 1010012433},  // 3x Scope
                {203015, 1010012366},  // 6x Scope
                {203100, 1010012445},  // Canted Sight
                {204011, 1010012442},  // Extended Mag
                {204012, 1010012443},  // Quickdraw Mag
                {204013, 1010012444},  // Extended Quickdraw Mag
            }},
            {"Lightshift Temple (Gold Feather)", {
                {101001, 1101001256},
                {201009, 1010012589},  // Compensator
                {201010, 1010012588},  // Flash Hider
                {201011, 1010012590},  // Suppressor
                {203001, 1010012587},  // Red Dot Sight
                {203002, 1010012586},  // Holographic Sight
                {203003, 1010012585},  // 2x Scope
                {203004, 1010012583},  // 4x Scope
                {203014, 1010012584},  // 3x Scope
                {203015, 1010012582},  // 6x Scope
                {203100, 1010012595},  // Canted Sight
                {204011, 1010012592},  // Extended Mag
                {204012, 1010012593},  // Quickdraw Mag
                {204013, 1010012594},  // Extended Quickdraw Mag
            }},
            {"Sandspring Dominion", {
                {101001, 1101001265},
                {201009, 1010012699},  // Compensator
                {201010, 1010012698},  // Flash Hider
                {201011, 1010012700},  // Suppressor
                {203001, 1010012697},  // Red Dot Sight
                {203002, 1010012696},  // Holographic Sight
                {203003, 1010012695},  // 2x Scope
                {203004, 1010012693},  // 4x Scope
                {203014, 1010012694},  // 3x Scope
                {203015, 1010012692},  // 6x Scope
                {203100, 1010012705},  // Canted Sight
                {204011, 1010012702},  // Extended Mag
                {204012, 1010012703},  // Quickdraw Mag
                {204013, 1010012704},  // Extended Quickdraw Mag
            }},
            {"Pulsing Light", {
                {101001, 1101001276},
                {201009, 1010012699},  // Compensator
                {201010, 1010012698},  // Flash Hider
                {201011, 1010012700},  // Suppressor
                {203001, 1010012697},  // Red Dot Sight
                {203002, 1010012696},  // Holographic Sight
                {203003, 1010012695},  // 2x Scope
                {203004, 1010012693},  // 4x Scope
                {203014, 1010012694},  // 3x Scope
                {203015, 1010012692},  // 6x Scope
                {203100, 1010012705},  // Canted Sight
                {204011, 1010012702},  // Extended Mag
                {204012, 1010012703},  // Quickdraw Mag
                {204013, 1010012704},  // Extended Quickdraw Mag
            }},
        }},
        {101002, "M16A4", {
            {"None", {}},
            {"Blood & Bones", {
                {101002, 1101002029},
                {201009, 1010020250},  // Compensator
                {201010, 1010020249},  // Flash Hider
                {201011, 1010020255},  // Suppressor
                {202101, 1010020257},  // Tactical Stock
                {203001, 1010020240},  // Red Dot Sight
                {203002, 1010020239},  // Holographic Sight
                {203003, 1010020238},  // 2x Scope
                {203004, 1010020236},  // 4x Scope
                {203014, 1010020237},  // 3x Scope
                {203015, 1010020235},  // 6x Scope
                {203100, 1010020256},  // Canted Sight
                {204011, 1010020246},  // Extended Mag
                {204012, 1010020247},  // Quickdraw Mag
                {204013, 1010020248},  // Extended Quickdraw Mag
            }},
            {"Aurora Pulse", {
                {101002, 1101002056},
                {201010, 1010020519},  // Flash Hider
                {203001, 1010020510},  // Red Dot Sight
                {203002, 1010020509},  // Holographic Sight
                {203003, 1010020508},  // 2x Scope
                {203004, 1010020506},  // 4x Scope
                {203014, 1010020507},  // 3x Scope
                {203015, 1010020505},  // 6x Scope
                {204011, 1010020516},  // Extended Mag
                {204012, 1010020517},  // Quickdraw Mag
                {204013, 1010020518},  // Extended Quickdraw Mag
            }},
            {"Skeletal Core", {
                {101002, 1101002081},
                {201009, 1010020769},  // Compensator
                {201010, 1010020768},  // Flash Hider
                {201011, 1010020770},  // Suppressor
                {202101, 1010020775},  // Tactical Stock
                {203001, 1010020759},  // Red Dot Sight
                {203002, 1010020758},  // Holographic Sight
                {203003, 1010020757},  // 2x Scope
                {203004, 1010020755},  // 4x Scope
                {203014, 1010020756},  // 3x Scope
                {203015, 1010020776},  // 6x Scope
                {203100, 1010020777},  // Canted Sight
                {204011, 1010020760},  // Extended Mag
                {204012, 1010020766},  // Quickdraw Mag
                {204013, 1010020767},  // Extended Quickdraw Mag
            }},
        }},
        {101003, "SCAR-L", {
            {"None", {}},
            {"Enchanted Pumpkin", {
                {101003, 1101003070},
                {201009, 1010030653},  // Compensator
                {201010, 1010030654},  // Flash Hider
                {201011, 1010030655},  // Suppressor
                {202001, 1010030658},  // Vertical Foregrip
                {202002, 1010030656},  // Angled Foregrip
                {202004, 1010030662},  // Half Grip
                {202005, 1010030660},  // Light Grip
                {202006, 1010030657},  // Thumb Grip
                {203001, 1010030647},  // Red Dot Sight
                {203002, 1010030646},  // Holographic Sight
                {203003, 1010030645},  // 2x Scope
                {203004, 1010030643},  // 4x Scope
                {203014, 1010030644},  // 3x Scope
                {203015, 1010030642},  // 6x Scope
                {203100, 1010030663},  // Canted Sight
                {203101, 1010030659},  // Laser Sight
                {204011, 1010030648},  // Extended Mag
                {204012, 1010030649},  // Quickdraw Mag
                {204013, 1010030650},  // Extended Quickdraw Mag
            }},
            {"Operation Tomorrow", {
                {101003, 1101003080},
                {201009, 1010030753},  // Compensator
                {201010, 1010030754},  // Flash Hider
                {201011, 1010030755},  // Suppressor
                {202001, 1010030758},  // Vertical Foregrip
                {202002, 1010030756},  // Angled Foregrip
                {202004, 1010030762},  // Half Grip
                {202005, 1010030760},  // Light Grip
                {202006, 1010030757},  // Thumb Grip
                {203001, 1010030747},  // Red Dot Sight
                {203002, 1010030746},  // Holographic Sight
                {203003, 1010030745},  // 2x Scope
                {203004, 1010030743},  // 4x Scope
                {203014, 1010030744},  // 3x Scope
                {203015, 1010030742},  // 6x Scope
                {203100, 1010030763},  // Canted Sight
                {203101, 1010030759},  // Laser Sight
                {204011, 1010030748},  // Extended Mag
                {204012, 1010030749},  // Quickdraw Mag
                {204013, 1010030750},  // Extended Quickdraw Mag
            }},
            {"Drop the Bass", {
                {101003, 1101003099},
                {201009, 1010030944},  // Compensator
                {201010, 1010030943},  // Flash Hider
                {201011, 1010030945},  // Suppressor
                {202001, 1010030947},  // Vertical Foregrip
                {202002, 1010030946},  // Angled Foregrip
                {202004, 1010030949},  // Half Grip
                {202005, 1010030948},  // Light Grip
                {202006, 1010030952},  // Thumb Grip
                {203001, 1010030937},  // Red Dot Sight
                {203002, 1010030936},  // Holographic Sight
                {203003, 1010030935},  // 2x Scope
                {203004, 1010030933},  // 4x Scope
                {203014, 1010030934},  // 3x Scope
                {203015, 1010030932},  // 6x Scope
                {203100, 1010030955},  // Canted Sight
                {203101, 1010030953},  // Laser Sight
                {204011, 1010030938},  // Extended Mag
                {204012, 1010030939},  // Quickdraw Mag
                {204013, 1010030942},  // Extended Quickdraw Mag
            }},
            {"Hextech Crystal", {
                {101003, 1101003119},
                {201009, 1010031140},  // Compensator
                {201010, 1010031139},  // Flash Hider
                {201011, 1010031142},  // Suppressor
                {202001, 1010031144},  // Vertical Foregrip
                {202002, 1010031143},  // Angled Foregrip
                {202006, 1010031145},  // Thumb Grip
                {203001, 1010031136},  // Red Dot Sight
                {203002, 1010031135},  // Holographic Sight
                {203003, 1010031134},  // 2x Scope
                {203004, 1010031132},  // 4x Scope
                {203014, 1010031133},  // 3x Scope
                {204011, 1010031137},  // Extended Mag
                {204012, 1010031138},  // Quickdraw Mag
                {204013, 1010031146},  // Extended Quickdraw Mag
            }},
            {"Thorn of Malice", {
                {101003, 1101003146},
                {201009, 1010031230},  // Compensator
                {201010, 1010031229},  // Flash Hider
                {201011, 1010031237},  // Suppressor
                {202001, 1010031239},  // Vertical Foregrip
                {202002, 1010031238},  // Angled Foregrip
                {202006, 1010031240},  // Thumb Grip
                {203001, 1010031226},  // Red Dot Sight
                {203002, 1010031225},  // Holographic Sight
                {203003, 1010031224},  // 2x Scope
                {203004, 1010031222},  // 4x Scope
                {203014, 1010031223},  // 3x Scope
                {204011, 1010031227},  // Extended Mag
                {204012, 1010031228},  // Quickdraw Mag
                {204013, 1010031242},  // Extended Quickdraw Mag
            }},
            {"Bloodstained Nemesis", {
                {101003, 1101003167},
                {201009, 1010031610},  // Compensator
                {201010, 1010031609},  // Flash Hider
                {201011, 1010031613},  // Suppressor
                {202001, 1010031615},  // Vertical Foregrip
                {202002, 1010031614},  // Angled Foregrip
                {202004, 1010031622},  // Half Grip
                {202005, 1010031620},  // Light Grip
                {202006, 1010031616},  // Thumb Grip
                {203001, 1010031606},  // Red Dot Sight
                {203002, 1010031605},  // Holographic Sight
                {203003, 1010031604},  // 2x Scope
                {203004, 1010031602},  // 4x Scope
                {203014, 1010031603},  // 3x Scope
                {203015, 1010031618},  // 6x Scope
                {203100, 1010031623},  // Canted Sight
                {203101, 1010031619},  // Laser Sight
                {204011, 1010031607},  // Extended Mag
                {204012, 1010031608},  // Quickdraw Mag
                {204013, 1010031617},  // Extended Quickdraw Mag
            }},
            {"Folly's Clasp", {
                {101003, 1101003181},
                {201009, 1010031764},  // Compensator
                {201010, 1010031765},  // Flash Hider
                {201011, 1010031766},  // Suppressor
                {202001, 1010031769},  // Vertical Foregrip
                {202002, 1010031767},  // Angled Foregrip
                {202004, 1010031774},  // Half Grip
                {202005, 1010031773},  // Light Grip
                {202006, 1010031768},  // Thumb Grip
                {203001, 1010031757},  // Red Dot Sight
                {203002, 1010031756},  // Holographic Sight
                {203003, 1010031755},  // 2x Scope
                {203004, 1010031753},  // 4x Scope
                {203014, 1010031754},  // 3x Scope
                {203015, 1010031752},  // 6x Scope
                {203100, 1010031775},  // Canted Sight
                {203101, 1010031772},  // Laser Sight
                {204011, 1010031758},  // Extended Mag
                {204012, 1010031759},  // Quickdraw Mag
                {204013, 1010031763},  // Extended Quickdraw Mag
            }},
            {"Serene Lumina", {
                {101003, 1101003195},
                {201009, 1010031911},  // Compensator
                {201010, 1010031912},  // Flash Hider
                {201011, 1010031913},  // Suppressor
                {202001, 1010031916},  // Vertical Foregrip
                {202002, 1010031914},  // Angled Foregrip
                {202004, 1010031919},  // Half Grip
                {202005, 1010031918},  // Light Grip
                {202006, 1010031915},  // Thumb Grip
                {203001, 1010031906},  // Red Dot Sight
                {203002, 1010031905},  // Holographic Sight
                {203003, 1010031904},  // 2x Scope
                {203004, 1010031902},  // 4x Scope
                {203014, 1010031903},  // 3x Scope
                {203015, 1010031901},  // 6x Scope
                {203100, 1010031921},  // Canted Sight
                {203101, 1010031917},  // Laser Sight
                {204011, 1010031907},  // Extended Mag
                {204012, 1010031908},  // Quickdraw Mag
                {204013, 1010031909},  // Extended Quickdraw Mag
            }},
            {"Fantastical Realm", {
                {101003, 1101003208},
                {201009, 1010032033},  // Compensator
                {201010, 1010032034},  // Flash Hider
                {201011, 1010032045},  // Suppressor
                {202001, 1010032038},  // Vertical Foregrip
                {202002, 1010032036},  // Angled Foregrip
                {202004, 1010032043},  // Half Grip
                {202005, 1010032042},  // Light Grip
                {202006, 1010032037},  // Thumb Grip
                {203001, 1010032027},  // Red Dot Sight
                {203002, 1010032026},  // Holographic Sight
                {203003, 1010032025},  // 2x Scope
                {203004, 1010032023},  // 4x Scope
                {203014, 1010032024},  // 3x Scope
                {203015, 1010032022},  // 6x Scope
                {203100, 1010032044},  // Canted Sight
                {203101, 1010032039},  // Laser Sight
                {204011, 1010032028},  // Extended Mag
                {204012, 1010032029},  // Quickdraw Mag
                {204013, 1010032032},  // Extended Quickdraw Mag
            }},
            {"Phoenix Rising", {
                {101003, 1101003227},
                {201009, 1010032242},  // Compensator
                {201010, 1010032243},  // Flash Hider
                {201011, 1010032244},  // Suppressor
                {202001, 1010032247},  // Vertical Foregrip
                {202002, 1010032245},  // Angled Foregrip
                {202004, 1010032250},  // Half Grip
                {202005, 1010032249},  // Light Grip
                {202006, 1010032246},  // Thumb Grip
                {203001, 1010032207},  // Red Dot Sight
                {203002, 1010032206},  // Holographic Sight
                {203003, 1010032205},  // 2x Scope
                {203004, 1010032203},  // 4x Scope
                {203014, 1010032204},  // 3x Scope
                {203015, 1010032202},  // 6x Scope
                {203100, 1010032252},  // Canted Sight
                {203101, 1010032248},  // Laser Sight
                {204011, 1010032208},  // Extended Mag
                {204012, 1010032209},  // Quickdraw Mag
                {204013, 1010032210},  // Extended Quickdraw Mag
            }},
            {"Soulbound Prism", {
                {101003, 1101003219},
                {201009, 1010032222},  // Compensator
                {201010, 1010032223},  // Flash Hider
                {201011, 1010032224},  // Suppressor
                {202001, 1010032227},  // Vertical Foregrip
                {202002, 1010032225},  // Angled Foregrip
                {202004, 1010032230},  // Half Grip
                {202005, 1010032229},  // Light Grip
                {202006, 1010032226},  // Thumb Grip
                {203001, 1010032217},  // Red Dot Sight
                {203002, 1010032216},  // Holographic Sight
                {203003, 1010032215},  // 2x Scope
                {203004, 1010032213},  // 4x Scope
                {203014, 1010032214},  // 3x Scope
                {203015, 1010032212},  // 6x Scope
                {203100, 1010032232},  // Canted Sight
                {203101, 1010032228},  // Laser Sight
                {204011, 1010032218},  // Extended Mag
                {204012, 1010032219},  // Quickdraw Mag
                {204013, 1010032220},  // Extended Quickdraw Mag
            }},
        }},
        {101004, "M416", {
            {"None", {}},
            {"Glacier", {
                {101004, 1101004046},
                {201009, 1010040475},  // Compensator
                {201010, 1010040474},  // Flash Hider
                {201011, 1010040476},  // Suppressor
                {202001, 1010040479},  // Vertical Foregrip
                {202002, 1010040477},  // Angled Foregrip
                {202004, 1010040483},  // Half Grip
                {202005, 1010040482},  // Light Grip
                {202006, 1010040478},  // Thumb Grip
                {202101, 1010040480},  // Tactical Stock
                {205002, 1010040480},  // Tactical Stock (M416 game slot = 205002)
                {203001, 1010040470},  // Red Dot Sight
                {203002, 1010040469},  // Holographic Sight
                {203003, 1010040468},  // 2x Scope
                {203004, 1010040466},  // 4x Scope
                {203014, 1010040467},  // 3x Scope
                {203015, 1010040481},  // 6x Scope
                {203100, 1010040485},  // Canted Sight
                {203101, 1010040484},  // Laser Sight
                {204011, 1010040471},  // Extended Mag
                {204012, 1010040472},  // Quickdraw Mag
                {204013, 1010040473},  // Extended Quickdraw Mag
            }},
            {"The Fool", {
                {101004, 1101004062},
                {201009, 1010040577},  // Compensator
                {201010, 1010040578},  // Flash Hider
                {201011, 1010040579},  // Suppressor
                {202001, 1010040585},  // Vertical Foregrip
                {202002, 1010040580},  // Angled Foregrip
                {202004, 1010040588},  // Half Grip
                {202005, 1010040587},  // Light Grip
                {202006, 1010040584},  // Thumb Grip
                {202101, 1010040586},  // Tactical Stock
                {205002, 1010040586},  // Tactical Stock (M416 game slot = 205002)
                {203001, 1010040569},  // Red Dot Sight
                {203002, 1010040568},  // Holographic Sight
                {203003, 1010040567},  // 2x Scope
                {203004, 1010040565},  // 4x Scope
                {203014, 1010040566},  // 3x Scope
                {203015, 1010040564},  // 6x Scope
                {203100, 1010040590},  // Canted Sight
                {203101, 1010040589},  // Laser Sight
                {204011, 1010040570},  // Extended Mag
                {204012, 1010040575},  // Quickdraw Mag
                {204013, 1010040576},  // Extended Quickdraw Mag
            }},
            {"Call of the Wild", {
                {101004, 1101004098},
                {201009, 1010040926},  // Compensator
                {201010, 1010040924},  // Flash Hider
                {201011, 1010040925},  // Suppressor
                {202001, 1010040939},  // Vertical Foregrip
                {202002, 1010040945},  // Angled Foregrip
                {202006, 1010040944},  // Thumb Grip
                {202101, 1010040936},  // Tactical Stock
                {205002, 1010040936},  // Tactical Stock (M416 game slot = 205002)
                {203001, 1010040935},  // Red Dot Sight
                {203002, 1010040934},  // Holographic Sight
                {203003, 1010040929},  // 2x Scope
                {203004, 1010040927},  // 4x Scope
                {203014, 1010040928},  // 3x Scope
                {204011, 1010040937},  // Extended Mag
                {204013, 1010040938},  // Extended Quickdraw Mag
            }},
            {"TechnoCore", {
                {101004, 1101004138},
                {201009, 1010041137},  // Compensator
                {201010, 1010041136},  // Flash Hider
                {201011, 1010041138},  // Suppressor
                {202001, 1010041145},  // Vertical Foregrip
                {202002, 1010041139},  // Angled Foregrip
                {202006, 1010041144},  // Thumb Grip
                {202101, 1010041146},  // Tactical Stock
                {205002, 1010041146},  // Tactical Stock (M416 game slot = 205002)
                {203001, 1010041128},  // Red Dot Sight
                {203002, 1010041127},  // Holographic Sight
                {203003, 1010041126},  // 2x Scope
                {203004, 1010041124},  // 4x Scope
                {203014, 1010041125},  // 3x Scope
                {204011, 1010041129},  // Extended Mag
                {204012, 1010041134},  // Quickdraw Mag
                {204013, 1010041135},  // Extended Quickdraw Mag
            }},
            {"Imperial Splendor", {
                {101004, 1101004163},
                {201009, 1010041574},  // Compensator
                {201010, 1010041570},  // Flash Hider
                {201011, 1010041575},  // Suppressor
                {202001, 1010041578},  // Vertical Foregrip
                {202002, 1010041576},  // Angled Foregrip
                {202006, 1010041577},  // Thumb Grip
                {202101, 1010041579},  // Tactical Stock
                {205002, 1010041579},  // Tactical Stock (M416 game slot = 205002)
                {203001, 1010041566},  // Red Dot Sight
                {203002, 1010041565},  // Holographic Sight
                {203003, 1010041564},  // 2x Scope
                {203004, 1010041554},  // 4x Scope
                {203014, 1010041560},  // 3x Scope
                {204011, 1010041567},  // Extended Mag
                {204012, 1010041568},  // Quickdraw Mag
                {204013, 1010041569},  // Extended Quickdraw Mag
            }},
            {"Silver Guru", {
                {101004, 1101004201},
                {201009, 1010041957},  // Compensator
                {201010, 1010041956},  // Flash Hider
                {201011, 1010041958},  // Suppressor
                {202001, 1010041965},  // Vertical Foregrip
                {202002, 1010041959},  // Angled Foregrip
                {202006, 1010041960},  // Thumb Grip
                {202101, 1010041966},  // Tactical Stock
                {205002, 1010041966},  // Tactical Stock (M416 game slot = 205002)
                {203001, 1010041948},  // Red Dot Sight
                {203002, 1010041947},  // Holographic Sight
                {203003, 1010041946},  // 2x Scope
                {203004, 1010041944},  // 4x Scope
                {203014, 1010041945},  // 3x Scope
                {203015, 1010041967},  // 6x Scope
                {204011, 1010041949},  // Extended Mag
                {204012, 1010041950},  // Quickdraw Mag
                {204013, 1010041955},  // Extended Quickdraw Mag
            }},
            {"Tidal Embrace", {
                {101004, 1101004209},
                {201009, 1010042037},  // Compensator
                {201010, 1010042038},  // Flash Hider
                {201011, 1010042039},  // Suppressor
                {202001, 1010042046},  // Vertical Foregrip
                {202002, 1010042044},  // Angled Foregrip
                {202004, 1010042049},  // Half Grip
                {202005, 1010042048},  // Light Grip
                {202006, 1010042045},  // Thumb Grip
                {202101, 1010042047},  // Tactical Stock
                {205002, 1010042047},  // Tactical Stock (M416 game slot = 205002)
                {203001, 1010042029},  // Red Dot Sight
                {203002, 1010042028},  // Holographic Sight
                {203003, 1010042027},  // 2x Scope
                {203004, 1010042025},  // 4x Scope
                {203014, 1010042026},  // 3x Scope
                {203015, 1010042024},  // 6x Scope
                {203100, 1010042055},  // Canted Sight
                {203101, 1010042054},  // Laser Sight
                {204011, 1010042034},  // Extended Mag
                {204012, 1010042035},  // Quickdraw Mag
                {204013, 1010042036},  // Extended Quickdraw Mag
            }},
            {"Shinobi Kami", {
                {101004, 1101004218},
                {201009, 1010042127},  // Compensator
                {201010, 1010042128},  // Flash Hider
                {201011, 1010042129},  // Suppressor
                {202001, 1010042136},  // Vertical Foregrip
                {202002, 1010042134},  // Angled Foregrip
                {202004, 1010042139},  // Half Grip
                {202005, 1010042138},  // Light Grip
                {202006, 1010042135},  // Thumb Grip
                {202101, 1010042137},  // Tactical Stock
                {205002, 1010042137},  // Tactical Stock (M416 game slot = 205002)
                {203001, 1010042119},  // Red Dot Sight
                {203002, 1010042118},  // Holographic Sight
                {203003, 1010042117},  // 2x Scope
                {203004, 1010042115},  // 4x Scope
                {203014, 1010042116},  // 3x Scope
                {203015, 1010042114},  // 6x Scope
                {203100, 1010042145},  // Canted Sight
                {203101, 1010042144},  // Laser Sight
                {204011, 1010042124},  // Extended Mag
                {204012, 1010042125},  // Quickdraw Mag
                {204013, 1010042126},  // Extended Quickdraw Mag
            }},
            {"Sealed Nether", {
                {101004, 1101004226},
                {201009, 1010042237},  // Compensator
                {201010, 1010042238},  // Flash Hider
                {201011, 1010042239},  // Suppressor
                {202001, 1010042243},  // Vertical Foregrip
                {202002, 1010042241},  // Angled Foregrip
                {202004, 1010042246},  // Half Grip
                {202005, 1010042245},  // Light Grip
                {202006, 1010042242},  // Thumb Grip
                {202101, 1010042244},  // Tactical Stock
                {205002, 1010042244},  // Tactical Stock (M416 game slot = 205002)
                {203001, 1010042233},  // Red Dot Sight
                {203002, 1010042232},  // Holographic Sight
                {203003, 1010042231},  // 2x Scope
                {203004, 1010042218},  // 4x Scope
                {203014, 1010042219},  // 3x Scope
                {203015, 1010042217},  // 6x Scope
                {203100, 1010042248},  // Canted Sight
                {203101, 1010042247},  // Laser Sight
                {204011, 1010042234},  // Extended Mag
                {204012, 1010042235},  // Quickdraw Mag
                {204013, 1010042236},  // Extended Quickdraw Mag
            }},
            {"Roaring Immolation", {
                {101004, 1101004236},
                {201009, 1010042306},  // Compensator
                {201010, 1010042307},  // Flash Hider
                {201011, 1010042308},  // Suppressor
                {202001, 1010042314},  // Vertical Foregrip
                {202002, 1010042309},  // Angled Foregrip
                {202004, 1010042317},  // Half Grip
                {202005, 1010042316},  // Light Grip
                {202006, 1010042310},  // Thumb Grip
                {202101, 1010042315},  // Tactical Stock
                {205002, 1010042315},  // Tactical Stock (M416 game slot = 205002)
                {203001, 1010042299},  // Red Dot Sight
                {203002, 1010042298},  // Holographic Sight
                {203003, 1010042297},  // 2x Scope
                {203004, 1010042295},  // 4x Scope
                {203014, 1010042296},  // 3x Scope
                {203015, 1010042294},  // 6x Scope
                {203100, 1010042319},  // Canted Sight
                {203101, 1010042318},  // Laser Sight
                {204011, 1010042300},  // Extended Mag
                {204012, 1010042304},  // Quickdraw Mag
                {204013, 1010042305},  // Extended Quickdraw Mag
            }},
            {"Crimson Skyblade", {
                {101004, 1101004246},
                {201009, 1010042407},  // Compensator
                {201010, 1010042406},  // Flash Hider
                {201011, 1010042408},  // Suppressor
                {202001, 1010042414},  // Vertical Foregrip
                {202002, 1010042409},  // Angled Foregrip
                {202004, 1010042417},  // Half Grip
                {202005, 1010042416},  // Light Grip
                {202006, 1010042410},  // Thumb Grip
                {202101, 1010042415},  // Tactical Stock
                {205002, 1010042415},  // Tactical Stock (M416 game slot = 205002)
                {203001, 1010042399},  // Red Dot Sight
                {203002, 1010042398},  // Holographic Sight
                {203003, 1010042397},  // 2x Scope
                {203004, 1010042395},  // 4x Scope
                {203014, 1010042396},  // 3x Scope
                {203015, 1010042394},  // 6x Scope
                {203100, 1010042419},  // Canted Sight
                {203101, 1010042418},  // Laser Sight
                {204011, 1010042400},  // Extended Mag
                {204012, 1010042404},  // Quickdraw Mag
                {204013, 1010042405},  // Extended Quickdraw Mag
            }},
        }},
        {101005, "Groza", {
            {"None", {}},
            {"Ryomen Sukuna", {
                {101005, 1101005038},
                {201011, 1010050327},  // Suppressor
                {203001, 1010050326},  // Red Dot Sight
                {203002, 1010050325},  // Holographic Sight
                {203003, 1010050324},  // 2x Scope
                {203004, 1010050322},  // 4x Scope
                {203014, 1010050323},  // 3x Scope
                {203015, 1010050334},  // 6x Scope
                {204011, 1010050328},  // Extended Mag
                {204012, 1010050329},  // Quickdraw Mag
                {204013, 1010050330},  // Extended Quickdraw Mag
            }},
            {"River Styx", {
                {101005, 1101005052},
                {201011, 1010050467},  // Suppressor
                {203001, 1010050466},  // Red Dot Sight
                {203002, 1010050465},  // Holographic Sight
                {203003, 1010050464},  // 2x Scope
                {203004, 1010050462},  // 4x Scope
                {203014, 1010050463},  // 3x Scope
                {203015, 1010050473},  // 6x Scope
                {204011, 1010050468},  // Extended Mag
                {204012, 1010050469},  // Quickdraw Mag
                {204013, 1010050470},  // Extended Quickdraw Mag
            }},
            {"Burning Godzilla", {
                {101005, 1101005098},
                {201011, 1010050928},  // Suppressor
                {203001, 1010050927},  // Red Dot Sight
                {203002, 1010050926},  // Holographic Sight
                {203003, 1010050925},  // 2x Scope
                {203004, 1010050923},  // 4x Scope
                {203014, 1010050924},  // 3x Scope
                {203015, 1010050922},  // 6x Scope
                {204011, 1010050929},  // Extended Mag
                {204012, 1010050930},  // Quickdraw Mag
                {204013, 1010050932},  // Extended Quickdraw Mag
            }},
        }},
        {101006, "AUG", {
            {"None", {}},
            {"Forsaken Glace", {
                {101006, 1101006062},
                {201009, 1010060572},  // Compensator
                {201010, 1010060573},  // Flash Hider
                {201011, 1010060574},  // Suppressor
                {202001, 1010060583},  // Vertical Foregrip
                {202002, 1010060581},  // Angled Foregrip
                {202004, 1010060592},  // Half Grip
                {202005, 1010060591},  // Light Grip
                {202006, 1010060582},  // Thumb Grip
                {203001, 1010060562},  // Red Dot Sight
                {203002, 1010060561},  // Holographic Sight
                {203003, 1010060554},  // 2x Scope
                {203004, 1010060552},  // 4x Scope
                {203014, 1010060553},  // 3x Scope
                {203015, 1010060551},  // 6x Scope
                {203100, 1010060593},  // Canted Sight
                {203101, 1010060584},  // Laser Sight
                {204011, 1010060563},  // Extended Mag
                {204012, 1010060564},  // Quickdraw Mag
                {204013, 1010060571},  // Extended Quickdraw Mag
            }},
            {"Abyssal Howl", {
                {101006, 1101006075},
                {201009, 1010060701},  // Compensator
                {201010, 1010060702},  // Flash Hider
                {201011, 1010060703},  // Suppressor
                {202001, 1010060706},  // Vertical Foregrip
                {202002, 1010060704},  // Angled Foregrip
                {202004, 1010060709},  // Half Grip
                {202005, 1010060708},  // Light Grip
                {202006, 1010060705},  // Thumb Grip
                {203001, 1010060696},  // Red Dot Sight
                {203002, 1010060695},  // Holographic Sight
                {203003, 1010060694},  // 2x Scope
                {203004, 1010060692},  // 4x Scope
                {203014, 1010060693},  // 3x Scope
                {203015, 1010060691},  // 6x Scope
                {203100, 1010060711},  // Canted Sight
                {203101, 1010060707},  // Laser Sight
                {204011, 1010060697},  // Extended Mag
                {204012, 1010060698},  // Quickdraw Mag
                {204013, 1010060699},  // Extended Quickdraw Mag
            }},
            {"Nyxen Rose", {
                {101006, 1101006085},
                {201009, 1010060795},  // Compensator
                {201010, 1010060796},  // Flash Hider
                {201011, 1010060797},  // Suppressor
                {202001, 1010060800},  // Vertical Foregrip
                {202002, 1010060798},  // Angled Foregrip
                {202004, 1010060805},  // Half Grip
                {202005, 1010060804},  // Light Grip
                {202006, 1010060799},  // Thumb Grip
                {203001, 1010060788},  // Red Dot Sight
                {203002, 1010060787},  // Holographic Sight
                {203003, 1010060786},  // 2x Scope
                {203004, 1010060784},  // 4x Scope
                {203014, 1010060785},  // 3x Scope
                {203015, 1010060783},  // 6x Scope
                {203100, 1010060806},  // Canted Sight
                {203101, 1010060803},  // Laser Sight
                {204011, 1010060789},  // Extended Mag
                {204012, 1010060793},  // Quickdraw Mag
                {204013, 1010060794},  // Extended Quickdraw Mag
            }},
        }},
        {101007, "QBZ", {
            {"None", {}},
            {"Nether Phantom", {
                {101007, 1101007046},
                {201009, 1010070413},  // Compensator
                {201010, 1010070410},  // Flash Hider
                {201011, 1010070414},  // Suppressor
                {202001, 1010070417},  // Vertical Foregrip
                {202002, 1010070415},  // Angled Foregrip
                {202004, 1010070422},  // Half Grip
                {202005, 1010070420},  // Light Grip
                {202006, 1010070416},  // Thumb Grip
                {203001, 1010070406},  // Red Dot Sight
                {203002, 1010070405},  // Holographic Sight
                {203003, 1010070404},  // 2x Scope
                {203004, 1010070402},  // 4x Scope
                {203014, 1010070403},  // 3x Scope
                {203015, 1010070418},  // 6x Scope
                {203100, 1010070423},  // Canted Sight
                {203101, 1010070419},  // Laser Sight
                {204011, 1010070407},  // Extended Mag
                {204012, 1010070408},  // Quickdraw Mag
                {204013, 1010070409},  // Extended Quickdraw Mag
            }},
            {"Fatal Foil", {
                {101007, 1101007062},
                {201009, 1010070578},  // Compensator
                {201010, 1010070579},  // Flash Hider
                {201011, 1010070581},  // Suppressor
                {202001, 1010070584},  // Vertical Foregrip
                {202002, 1010070582},  // Angled Foregrip
                {202004, 1010070586},  // Half Grip
                {202005, 1010070585},  // Light Grip
                {202006, 1010070583},  // Thumb Grip
                {203001, 1010070574},  // Red Dot Sight
                {203002, 1010070573},  // Holographic Sight
                {203003, 1010070572},  // 2x Scope
                {203004, 1010070569},  // 4x Scope
                {203014, 1010070571},  // 3x Scope
                {203015, 1010070568},  // 6x Scope
                {203100, 1010070588},  // Canted Sight
                {203101, 1010070587},  // Laser Sight
                {204011, 1010070575},  // Extended Mag
                {204012, 1010070576},  // Quickdraw Mag
                {204013, 1010070577},  // Extended Quickdraw Mag
            }},
            {"Empyrean Charm", {
                {101007, 1101007071},
                {201009, 1010070662},  // Compensator
                {201010, 1010070663},  // Flash Hider
                {201011, 1010070664},  // Suppressor
                {202001, 1010070667},  // Vertical Foregrip
                {202002, 1010070665},  // Angled Foregrip
                {202004, 1010070669},  // Half Grip
                {202005, 1010070668},  // Light Grip
                {202006, 1010070666},  // Thumb Grip
                {203001, 1010070657},  // Red Dot Sight
                {203002, 1010070656},  // Holographic Sight
                {203003, 1010070655},  // 2x Scope
                {203004, 1010070653},  // 4x Scope
                {203014, 1010070654},  // 3x Scope
                {203015, 1010070652},  // 6x Scope
                {203100, 1010070672},  // Canted Sight
                {203101, 1010070670},  // Laser Sight
                {204011, 1010070658},  // Extended Mag
                {204012, 1010070659},  // Quickdraw Mag
                {204013, 1010070660},  // Extended Quickdraw Mag
            }},
        }},
        {101008, "M762", {
            {"None", {}},
            {"Concerto of Love", {
                {101008, 1101008051},
                {201009, 1010080464},  // Compensator
                {201010, 1010080463},  // Flash Hider
                {201011, 1010080465},  // Suppressor
                {202001, 1010080467},  // Vertical Foregrip
                {202002, 1010080466},  // Angled Foregrip
                {202004, 1010080469},  // Half Grip
                {202005, 1010080468},  // Light Grip
                {202006, 1010080472},  // Thumb Grip
                {203001, 1010080457},  // Red Dot Sight
                {203002, 1010080456},  // Holographic Sight
                {203003, 1010080455},  // 2x Scope
                {203004, 1010080453},  // 4x Scope
                {203014, 1010080454},  // 3x Scope
                {203015, 1010080452},  // 6x Scope
                {203100, 1010080475},  // Canted Sight
                {203101, 1010080473},  // Laser Sight
                {204011, 1010080458},  // Extended Mag
                {204012, 1010080459},  // Quickdraw Mag
                {204013, 1010080462},  // Extended Quickdraw Mag
            }},
            {"Deadly Precision", {
                {101008, 1101008061},
                {201009, 1010080564},  // Compensator
                {201010, 1010080563},  // Flash Hider
                {201011, 1010080565},  // Suppressor
                {202001, 1010080567},  // Vertical Foregrip
                {202002, 1010080566},  // Angled Foregrip
                {202006, 1010080572},  // Thumb Grip
                {203001, 1010080557},  // Red Dot Sight
                {203002, 1010080556},  // Holographic Sight
                {203003, 1010080555},  // 2x Scope
                {203004, 1010080553},  // 4x Scope
                {203014, 1010080554},  // 3x Scope
                {204011, 1010080558},  // Extended Mag
                {204012, 1010080559},  // Quickdraw Mag
                {204013, 1010080562},  // Extended Quickdraw Mag
            }},
            {"GACKT MOONSAGA", {
                {101008, 1101008070},
                {201009, 1010080612},  // Compensator
                {201010, 1010080609},  // Flash Hider
                {201011, 1010080613},  // Suppressor
                {202001, 1010080615},  // Vertical Foregrip
                {202002, 1010080614},  // Angled Foregrip
                {202006, 1010080616},  // Thumb Grip
                {203001, 1010080606},  // Red Dot Sight
                {203002, 1010080605},  // Holographic Sight
                {203003, 1010080604},  // 2x Scope
                {203004, 1010080602},  // 4x Scope
                {203014, 1010080603},  // 3x Scope
                {204011, 1010080607},  // Extended Mag
                {204012, 1010080608},  // Quickdraw Mag
                {204013, 1010080617},  // Extended Quickdraw Mag
            }},
            {"Stray Rebellion", {
                {101008, 1101008081},
                {201009, 1010080743},  // Compensator
                {201010, 1010080740},  // Flash Hider
                {201011, 1010080745},  // Suppressor
                {202001, 1010080747},  // Vertical Foregrip
                {202002, 1010080746},  // Angled Foregrip
                {202004, 1010080752},  // Half Grip
                {202005, 1010080750},  // Light Grip
                {202006, 1010080744},  // Thumb Grip
                {203001, 1010080736},  // Red Dot Sight
                {203002, 1010080735},  // Holographic Sight
                {203003, 1010080734},  // 2x Scope
                {203004, 1010080732},  // 4x Scope
                {203014, 1010080733},  // 3x Scope
                {203015, 1010080748},  // 6x Scope
                {203100, 1010080753},  // Canted Sight
                {203101, 1010080749},  // Laser Sight
                {204011, 1010080737},  // Extended Mag
                {204012, 1010080738},  // Quickdraw Mag
                {204013, 1010080739},  // Extended Quickdraw Mag
            }},
            {"Starcore", {
                {101008, 1101008104},
                {201009, 1010080982},  // Compensator
                {201010, 1010080980},  // Flash Hider
                {201011, 1010080984},  // Suppressor
                {202001, 1010080986},  // Vertical Foregrip
                {202002, 1010080985},  // Angled Foregrip
                {202004, 1010080987},  // Half Grip
                {202005, 1010080989},  // Light Grip
                {202006, 1010080983},  // Thumb Grip
                {203001, 1010080976},  // Red Dot Sight
                {203002, 1010080975},  // Holographic Sight
                {203003, 1010080974},  // 2x Scope
                {203004, 1010080972},  // 4x Scope
                {203014, 1010080973},  // 3x Scope
                {203015, 1010080992},  // 6x Scope
                {203100, 1010080988},  // Canted Sight
                {203101, 1010080993},  // Laser Sight
                {204011, 1010080977},  // Extended Mag
                {204012, 1010080978},  // Quickdraw Mag
                {204013, 1010080979},  // Extended Quickdraw Mag
            }},
            {"Messi Football Icon", {
                {101008, 1101008116},
                {201009, 1010081112},  // Compensator
                {201010, 1010081110},  // Flash Hider
                {201011, 1010081114},  // Suppressor
                {202001, 1010081116},  // Vertical Foregrip
                {202002, 1010081115},  // Angled Foregrip
                {202006, 1010081113},  // Thumb Grip
                {203001, 1010081106},  // Red Dot Sight
                {203002, 1010081105},  // Holographic Sight
                {203003, 1010081104},  // 2x Scope
                {203004, 1010081102},  // 4x Scope
                {203014, 1010081103},  // 3x Scope
                {204011, 1010081107},  // Extended Mag
                {204012, 1010081108},  // Quickdraw Mag
                {204013, 1010081109},  // Extended Quickdraw Mag
            }},
            {"Noctum Sunder", {
                {101008, 1101008126},
                {201009, 1010081225},  // Compensator
                {201010, 1010081210},  // Flash Hider
                {201011, 1010081226},  // Suppressor
                {202001, 1010081217},  // Vertical Foregrip
                {202002, 1010081216},  // Angled Foregrip
                {202004, 1010081220},  // Half Grip
                {202005, 1010081219},  // Light Grip
                {202006, 1010081214},  // Thumb Grip
                {202101, 1010081228},  // Tactical Stock
                {203001, 1010081206},  // Red Dot Sight
                {203002, 1010081205},  // Holographic Sight
                {203003, 1010081204},  // 2x Scope
                {203004, 1010081202},  // 4x Scope
                {203014, 1010081203},  // 3x Scope
                {203015, 1010081218},  // 6x Scope
                {203100, 1010081227},  // Canted Sight
                {203101, 1010081222},  // Laser Sight
                {204011, 1010081207},  // Extended Mag
                {204012, 1010081208},  // Quickdraw Mag
                {204013, 1010081209},  // Extended Quickdraw Mag
            }},
            {"Luminous Muse", {
                {101008, 1101008136},
                {201009, 1010081315},  // Compensator
                {201010, 1010081314},  // Flash Hider
                {201011, 1010081316},  // Suppressor
                {202001, 1010081318},  // Vertical Foregrip
                {202002, 1010081317},  // Angled Foregrip
                {202004, 1010081323},  // Half Grip
                {202005, 1010081322},  // Light Grip
                {202006, 1010081324},  // Thumb Grip
                {203001, 1010081307},  // Red Dot Sight
                {203002, 1010081306},  // Holographic Sight
                {203003, 1010081305},  // 2x Scope
                {203004, 1010081303},  // 4x Scope
                {203014, 1010081304},  // 3x Scope
                {203015, 1010081302},  // 6x Scope
                {203100, 1010081326},  // Canted Sight
                {203101, 1010081325},  // Laser Sight
                {204011, 1010081308},  // Extended Mag
                {204012, 1010081312},  // Quickdraw Mag
                {204013, 1010081313},  // Extended Quickdraw Mag
            }},
            {"Skeletal Carver", {
                {101008, 1101008146},
                {201009, 1010081402},  // Compensator
                {201010, 1010081401},  // Flash Hider
                {201011, 1010081403},  // Suppressor
                {202001, 1010081405},  // Vertical Foregrip
                {202002, 1010081404},  // Angled Foregrip
                {202004, 1010081407},  // Half Grip
                {202005, 1010081406},  // Light Grip
                {202006, 1010081408},  // Thumb Grip
                {203001, 1010081396},  // Red Dot Sight
                {203002, 1010081395},  // Holographic Sight
                {203003, 1010081394},  // 2x Scope
                {203004, 1010081392},  // 4x Scope
                {203014, 1010081393},  // 3x Scope
                {203015, 1010081391},  // 6x Scope
                {203100, 1010081411},  // Canted Sight
                {203101, 1010081409},  // Laser Sight
                {204011, 1010081397},  // Extended Mag
                {204012, 1010081398},  // Quickdraw Mag
                {204013, 1010081399},  // Extended Quickdraw Mag
            }},
            {"Platinum Skeleton", {
                {101008, 1101008154},
                {201009, 1010081532},  // Compensator
                {201010, 1010081531},  // Flash Hider
                {201011, 1010081533},  // Suppressor
                {202001, 1010081541},  // Vertical Foregrip
                {202002, 1010081534},  // Angled Foregrip
                {202004, 1010081543},  // Half Grip
                {202005, 1010081542},  // Light Grip
                {202006, 1010081544},  // Thumb Grip
                {203001, 1010081526},  // Red Dot Sight
                {203002, 1010081525},  // Holographic Sight
                {203003, 1010081524},  // 2x Scope
                {203004, 1010081522},  // 4x Scope
                {203014, 1010081523},  // 3x Scope
                {203015, 1010081521},  // 6x Scope
                {203100, 1010081546},  // Canted Sight
                {203101, 1010081545},  // Laser Sight
                {204011, 1010081527},  // Extended Mag
                {204012, 1010081528},  // Quickdraw Mag
                {204013, 1010081529},  // Extended Quickdraw Mag
            }},
            {"Soulspecter Shredder", {
                {101008, 1101008163},
                {201009, 1010081583},  // Compensator
                {201010, 1010081582},  // Flash Hider
                {201011, 1010081584},  // Suppressor
                {202001, 1010081586},  // Vertical Foregrip
                {202002, 1010081585},  // Angled Foregrip
                {202004, 1010081588},  // Half Grip
                {202005, 1010081587},  // Light Grip
                {202006, 1010081589},  // Thumb Grip
                {203001, 1010081577},  // Red Dot Sight
                {203002, 1010081576},  // Holographic Sight
                {203003, 1010081575},  // 2x Scope
                {203004, 1010081573},  // 4x Scope
                {203014, 1010081574},  // 3x Scope
                {203015, 1010081572},  // 6x Scope
                {203100, 1010081592},  // Canted Sight
                {203101, 1010081590},  // Laser Sight
                {204011, 1010081578},  // Extended Mag
                {204012, 1010081579},  // Quickdraw Mag
                {204013, 1010081580},  // Extended Quickdraw Mag
            }},
        }},
        {101012, "Honey Badger", {
            {"None", {}},
            {"Sacred Witherbloom", {
                {101012, 1101012033},
                {201009, 1010120285},  // Compensator
                {201010, 1010120284},  // Flash Hider
                {201011, 1010120286},  // Suppressor
                {203001, 1010120278},  // Red Dot Sight
                {203002, 1010120277},  // Holographic Sight
                {203003, 1010120276},  // 2x Scope
                {203004, 1010120274},  // 4x Scope
                {203014, 1010120275},  // 3x Scope
                {203015, 1010120273},  // 6x Scope
                {203100, 1010120287},  // Canted Sight
                {204011, 1010120279},  // Extended Mag
                {204012, 1010120280},  // Quickdraw Mag
                {204013, 1010120283},  // Extended Quickdraw Mag
            }},
        }},
        {101100, "FAMAS", {
            {"None", {}},
            {"Origin Lumen", {
                {101100, 1101100012},
                {201009, 1011000067},  // Compensator
                {201010, 1011000066},  // Flash Hider
                {201011, 1011000068},  // Suppressor
                {203001, 1011000058},  // Red Dot Sight
                {203002, 1011000057},  // Holographic Sight
                {203003, 1011000056},  // 2x Scope
                {203004, 1011000054},  // 4x Scope
                {203014, 1011000055},  // 3x Scope
                {203015, 1011000053},  // 6x Scope
                {203100, 1011000073},  // Canted Sight
            }},
        }},
        {101102, "ACE32", {
            {"None", {}},
            {"Beam Blast", {
                {101102, 1101102007},
                {201009, 1011010024},  // Compensator
                {201010, 1011010025},  // Flash Hider
                {201011, 1011010026},  // Suppressor
                {203001, 1011010018},  // Red Dot Sight
                {203002, 1011010017},  // Holographic Sight
                {203003, 1011010016},  // 2x Scope
                {203004, 1011010014},  // 4x Scope
                {203014, 1011010015},  // 3x Scope
                {203015, 1011010013},  // 6x Scope
                {203100, 1011010027},  // Canted Sight
                {204011, 1011010019},  // Extended Mag
                {204012, 1011010020},  // Quickdraw Mag
                {204013, 1011010023},  // Extended Quickdraw Mag
            }},
            {"Icicle Spike", {
                {101102, 1101102017},
                {201009, 1011020028},  // Compensator
                {201010, 1011020027},  // Flash Hider
                {201011, 1011020029},  // Suppressor
                {202001, 1011020036},  // Vertical Foregrip
                {202002, 1011020034},  // Angled Foregrip
                {202004, 1011020039},  // Half Grip
                {202005, 1011020038},  // Light Grip
                {202006, 1011020035},  // Thumb Grip
                {202101, 1011020037},  // Tactical Stock
                {203001, 1011020019},  // Red Dot Sight
                {203002, 1011020018},  // Holographic Sight
                {203003, 1011020017},  // 2x Scope
                {203004, 1011020015},  // 4x Scope
                {203014, 1011020016},  // 3x Scope
                {203015, 1011020014},  // 6x Scope
                {203100, 1011020045},  // Canted Sight
                {203101, 1011020044},  // Laser Sight
                {204011, 1011020024},  // Extended Mag
                {204012, 1011020025},  // Quickdraw Mag
                {204013, 1011020026},  // Extended Quickdraw Mag
            }},
            {"Mystic Kraken", {
                {101102, 1101102025},
                {201009, 1011020128},  // Compensator
                {201010, 1011020127},  // Flash Hider
                {201011, 1011020129},  // Suppressor
                {202001, 1011020136},  // Vertical Foregrip
                {202002, 1011020134},  // Angled Foregrip
                {202004, 1011020139},  // Half Grip
                {202005, 1011020138},  // Light Grip
                {202006, 1011020135},  // Thumb Grip
                {202101, 1011020137},  // Tactical Stock
                {203001, 1011020119},  // Red Dot Sight
                {203002, 1011020118},  // Holographic Sight
                {203003, 1011020117},  // 2x Scope
                {203004, 1011020115},  // 4x Scope
                {203014, 1011020116},  // 3x Scope
                {203015, 1011020114},  // 6x Scope
                {203100, 1011020145},  // Canted Sight
                {203101, 1011020144},  // Laser Sight
                {204011, 1011020124},  // Extended Mag
                {204012, 1011020125},  // Quickdraw Mag
                {204013, 1011020126},  // Extended Quickdraw Mag
            }},
            {"Papillon Kiss", {
                {101102, 1101102041},
                {201009, 1011020215},  // Compensator
                {201010, 1011020214},  // Flash Hider
                {201011, 1011020216},  // Suppressor
                {202001, 1011020219},  // Vertical Foregrip
                {202002, 1011020217},  // Angled Foregrip
                {202004, 1011020223},  // Half Grip
                {202005, 1011020222},  // Light Grip
                {202006, 1011020218},  // Thumb Grip
                {202101, 1011020221},  // Tactical Stock
                {203001, 1011020209},  // Red Dot Sight
                {203002, 1011020208},  // Holographic Sight
                {203003, 1011020207},  // 2x Scope
                {203004, 1011020205},  // 4x Scope
                {203014, 1011020206},  // 3x Scope
                {203015, 1011020204},  // 6x Scope
                {203100, 1011020225},  // Canted Sight
                {203101, 1011020224},  // Laser Sight
                {204011, 1011020211},  // Extended Mag
                {204012, 1011020212},  // Quickdraw Mag
                {204013, 1011020213},  // Extended Quickdraw Mag
            }},
            {"Butterfly Whispers", {
                {101102, 1101102049},
                {201009, 1011020357},  // Compensator
                {201010, 1011020356},  // Flash Hider
                {201011, 1011020358},  // Suppressor
                {202001, 1011020364},  // Vertical Foregrip
                {202002, 1011020359},  // Angled Foregrip
                {202004, 1011020367},  // Half Grip
                {202005, 1011020366},  // Light Grip
                {202006, 1011020360},  // Thumb Grip
                {202101, 1011020365},  // Tactical Stock
                {203001, 1011020349},  // Red Dot Sight
                {203002, 1011020348},  // Holographic Sight
                {203003, 1011020347},  // 2x Scope
                {203004, 1011020345},  // 4x Scope
                {203014, 1011020346},  // 3x Scope
                {203015, 1011020344},  // 6x Scope
                {203100, 1011020369},  // Canted Sight
                {203101, 1011020368},  // Laser Sight
                {204011, 1011020350},  // Extended Mag
                {204012, 1011020354},  // Quickdraw Mag
                {204013, 1011020355},  // Extended Quickdraw Mag
            }},
        }},
        {102001, "UZI", {
            {"None", {}},
            {"Glacier Hammer", {
                {102001, 1102001120},
                {201009, 1020011138},  // Compensator
                {201010, 1020011137},  // Flash Hider
                {201011, 1020011139},  // Suppressor
                {203001, 1020011133},  // Red Dot Sight
                {203002, 1020011132},  // Holographic Sight
                {204011, 1020011134},  // Extended Mag
                {204012, 1020011135},  // Quickdraw Mag
                {204013, 1020011136},  // Extended Quickdraw Mag
            }},
            {"Chained Inferno", {
                {102001, 1102001130},
                {201009, 1020011248},  // Compensator
                {201010, 1020011247},  // Flash Hider
                {201011, 1020011249},  // Suppressor
                {203001, 1020011243},  // Red Dot Sight
                {203002, 1020011242},  // Holographic Sight
                {204011, 1020011244},  // Extended Mag
                {204012, 1020011245},  // Quickdraw Mag
                {204013, 1020011246},  // Extended Quickdraw Mag
            }},
        }},
        {102002, "UMP45", {
            {"None", {}},
            {"Dragonfire", {
                {102002, 1102002043},
                {201009, 1020020374},  // Compensator
                {201010, 1020020372},  // Flash Hider
                {201011, 1020020373},  // Suppressor
                {202001, 1020020385},  // Vertical Foregrip
                {202002, 1020020387},  // Angled Foregrip
                {202006, 1020020386},  // Thumb Grip
                {203001, 1020020379},  // Red Dot Sight
                {203002, 1020020378},  // Holographic Sight
                {203003, 1020020377},  // 2x Scope
                {203004, 1020020375},  // 4x Scope
                {203014, 1020020376},  // 3x Scope
                {203015, 1020020388},  // 6x Scope
                {204011, 1020020380},  // Extended Mag
                {204012, 1020020383},  // Quickdraw Mag
                {204013, 1020020384},  // Extended Quickdraw Mag
            }},
            {"Outlawed Fantasy", {
                {102002, 1102002061},
                {201009, 1020020554},  // Compensator
                {201010, 1020020552},  // Flash Hider
                {201011, 1020020553},  // Suppressor
                {202001, 1020020565},  // Vertical Foregrip
                {202002, 1020020567},  // Angled Foregrip
                {202004, 1020020574},  // Half Grip
                {202005, 1020020573},  // Light Grip
                {202006, 1020020566},  // Thumb Grip
                {203001, 1020020559},  // Red Dot Sight
                {203002, 1020020558},  // Holographic Sight
                {203003, 1020020557},  // 2x Scope
                {203004, 1020020555},  // 4x Scope
                {203014, 1020020556},  // 3x Scope
                {203015, 1020020578},  // 6x Scope
                {203100, 1020020569},  // Canted Sight
                {203101, 1020020572},  // Laser Sight
                {204011, 1020020562},  // Extended Mag
                {204012, 1020020563},  // Quickdraw Mag
                {204013, 1020020564},  // Extended Quickdraw Mag
            }},
            {"Cryofrost Shard", {
                {102002, 1102002136},
                {201009, 1020021313},  // Compensator
                {201010, 1020021314},  // Flash Hider
                {201011, 1020021315},  // Suppressor
                {202001, 1020021318},  // Vertical Foregrip
                {202002, 1020021316},  // Angled Foregrip
                {202004, 1020021324},  // Half Grip
                {202005, 1020021323},  // Light Grip
                {202006, 1020021317},  // Thumb Grip
                {203001, 1020021307},  // Red Dot Sight
                {203002, 1020021306},  // Holographic Sight
                {203003, 1020021305},  // 2x Scope
                {203004, 1020021303},  // 4x Scope
                {203014, 1020021304},  // 3x Scope
                {203015, 1020021302},  // 6x Scope
                {203100, 1020021325},  // Canted Sight
                {203101, 1020021322},  // Laser Sight
                {204011, 1020021308},  // Extended Mag
                {204012, 1020021309},  // Quickdraw Mag
                {204013, 1020021312},  // Extended Quickdraw Mag
            }},
            {"Void Souleater", {
                {102002, 1102002424},
                {201009, 1020024192},  // Compensator
                {201010, 1020024193},  // Flash Hider
                {201011, 1020024194},  // Suppressor
                {202001, 1020024197},  // Vertical Foregrip
                {202002, 1020024195},  // Angled Foregrip
                {202004, 1020024200},  // Half Grip
                {202005, 1020024199},  // Light Grip
                {202006, 1020024196},  // Thumb Grip
                {203001, 1020024187},  // Red Dot Sight
                {203002, 1020024186},  // Holographic Sight
                {203003, 1020024185},  // 2x Scope
                {203004, 1020024183},  // 4x Scope
                {203014, 1020024184},  // 3x Scope
                {203015, 1020024182},  // 6x Scope
                {203100, 1020024202},  // Canted Sight
                {203101, 1020024198},  // Laser Sight
                {204011, 1020024188},  // Extended Mag
                {204012, 1020024189},  // Quickdraw Mag
                {204013, 1020024190},  // Extended Quickdraw Mag
            }},
        }},
        {102003, "Vector", {
            {"None", {}},
            {"Mecha Drake", {
                {102003, 1102003080},
                {201009, 1020030756},  // Compensator
                {201010, 1020030755},  // Flash Hider
                {201011, 1020030758},  // Suppressor
                {202001, 1020030760},  // Vertical Foregrip
                {202004, 1020030757},  // Half Grip
                {202005, 1020030759},  // Light Grip
                {202101, 1020030765},  // Tactical Stock
                {203001, 1020030748},  // Red Dot Sight
                {203002, 1020030747},  // Holographic Sight
                {203003, 1020030746},  // 2x Scope
                {203004, 1020030744},  // 4x Scope
                {203014, 1020030745},  // 3x Scope
                {203015, 1020030764},  // 6x Scope
                {204011, 1020030749},  // Extended Mag
                {204013, 1020030754},  // Extended Quickdraw Mag
            }},
            {"Absolute Zero", {
                {102003, 1102003100},
                {201009, 1020030957},  // Compensator
                {201010, 1020030956},  // Flash Hider
                {201011, 1020030958},  // Suppressor
                {202001, 1020030964},  // Vertical Foregrip
                {202004, 1020030959},  // Half Grip
                {202005, 1020030960},  // Light Grip
                {202101, 1020030967},  // Tactical Stock
                {203001, 1020030949},  // Red Dot Sight
                {203002, 1020030948},  // Holographic Sight
                {203003, 1020030947},  // 2x Scope
                {203004, 1020030945},  // 4x Scope
                {203014, 1020030946},  // 3x Scope
                {203015, 1020030944},  // 6x Scope
                {203100, 1020030966},  // Canted Sight
                {203101, 1020030965},  // Laser Sight
                {204011, 1020030950},  // Extended Mag
                {204012, 1020030954},  // Quickdraw Mag
                {204013, 1020030955},  // Extended Quickdraw Mag
            }},
        }},
        {102005, "Bizon", {
            {"None", {}},
            {"Spectral Byte", {
                {102005, 1102005064},
                {201009, 1020050589},  // Compensator
                {201010, 1020050588},  // Flash Hider
                {201011, 1020050590},  // Suppressor
                {203001, 1020050587},  // Red Dot Sight
                {203002, 1020050586},  // Holographic Sight
                {203003, 1020050585},  // 2x Scope
                {203004, 1020050583},  // 4x Scope
                {203014, 1020050584},  // 3x Scope
                {203015, 1020050582},  // 6x Scope
                {203100, 1020050592},  // Canted Sight
            }},
        }},
        {103002, "M24", {
            {"None", {}},
            {"Pharaoh's Might", {
                {103002, 1103002030},
                {201009, 1030020246},  // Compensator
                {201010, 1030020245},  // Flash Hider
                {201011, 1030020247},  // Suppressor
                {202102, 1030020248},  // Cheek Pad
                {203001, 1030020258},  // Red Dot Sight
                {203002, 1030020257},  // Holographic Sight
                {203003, 1030020256},  // 2x Scope
                {203004, 1030020244},  // 4x Scope
                {203014, 1030020255},  // 3x Scope
                {203015, 1030020243},  // 6x Scope
                {204011, 1030020249},  // Extended Mag
                {204012, 1030020252},  // Quickdraw Mag
                {204013, 1030020253},  // Extended Quickdraw Mag
            }},
            {"Circle of Life", {
                {103002, 1103002059},
                {201009, 1030020545},  // Compensator
                {201010, 1030020544},  // Flash Hider
                {201011, 1030020546},  // Suppressor
                {202102, 1030020547},  // Cheek Pad
                {203001, 1030020538},  // Red Dot Sight
                {203002, 1030020537},  // Holographic Sight
                {203003, 1030020536},  // 2x Scope
                {203004, 1030020534},  // 4x Scope
                {203014, 1030020535},  // 3x Scope
                {203015, 1030020533},  // 6x Scope
                {203100, 1030020548},  // Canted Sight
                {204011, 1030020539},  // Extended Mag
                {204012, 1030020542},  // Quickdraw Mag
                {204013, 1030020543},  // Extended Quickdraw Mag
            }},
            {"Cadence Maestro", {
                {103002, 1103002087},
                {201009, 1030020825},  // Compensator
                {201010, 1030020824},  // Flash Hider
                {201011, 1030020826},  // Suppressor
                {202102, 1030020827},  // Cheek Pad
                {203001, 1030020818},  // Red Dot Sight
                {203002, 1030020817},  // Holographic Sight
                {203003, 1030020816},  // 2x Scope
                {203004, 1030020814},  // 4x Scope
                {203014, 1030020815},  // 3x Scope
                {203015, 1030020813},  // 6x Scope
                {203100, 1030020828},  // Canted Sight
            }},
            {"Voidwave Trigger", {
                {103002, 1103002106},
                {201009, 1030021010},  // Compensator
                {201010, 1030021009},  // Flash Hider
                {201011, 1030021012},  // Suppressor
                {202102, 1030021013},  // Cheek Pad
                {203001, 1030021008},  // Red Dot Sight
                {203002, 1030021007},  // Holographic Sight
                {203003, 1030021006},  // 2x Scope
                {203004, 1030021004},  // 4x Scope
                {203014, 1030021005},  // 3x Scope
                {203015, 1030021003},  // 6x Scope
                {203100, 1030021017},  // Canted Sight
                {204011, 1030021014},  // Extended Mag
                {204012, 1030021015},  // Quickdraw Mag
                {204013, 1030021016},  // Extended Quickdraw Mag
            }},
            {"Nightshade Dawn", {
                {103002, 1103002113},
                {201009, 1030021080},  // Compensator
                {201010, 1030021079},  // Flash Hider
                {201011, 1030021082},  // Suppressor
                {202102, 1030021083},  // Cheek Pad
                {203001, 1030021078},  // Red Dot Sight
                {203002, 1030021077},  // Holographic Sight
                {203003, 1030021076},  // 2x Scope
                {203004, 1030021074},  // 4x Scope
                {203014, 1030021075},  // 3x Scope
                {203015, 1030021073},  // 6x Scope
                {203100, 1030021087},  // Canted Sight
                {204011, 1030021084},  // Extended Mag
                {204012, 1030021085},  // Quickdraw Mag
                {204013, 1030021086},  // Extended Quickdraw Mag
            }},
            {"Party Parcel", {
                {103002, 1105001034},
                {202101, 1050010292},  // Tactical Stock
                {203001, 1050010286},  // Red Dot Sight
                {203002, 1050010285},  // Holographic Sight
                {203003, 1050010284},  // 2x Scope
                {203004, 1050010282},  // 4x Scope
                {203014, 1050010283},  // 3x Scope
                {204011, 1050010287},  // Extended Mag
                {204013, 1050010289},  // Extended Quickdraw Mag
            }},
            {"Moondrop Eterna", {
                {103002, 1105001048},
                {202101, 1050010435},  // Tactical Stock
                {203001, 1050010427},  // Red Dot Sight
                {203002, 1050010426},  // Holographic Sight
                {203003, 1050010425},  // 2x Scope
                {203004, 1050010423},  // 4x Scope
                {203014, 1050010424},  // 3x Scope
                {204011, 1050010428},  // Extended Mag
                {204012, 1050010429},  // Quickdraw Mag
                {204013, 1050010434},  // Extended Quickdraw Mag
            }},
            {"Malus Majesty", {
                {103002, 1105001069},
                {202101, 1050010643},  // Tactical Stock
                {203001, 1050010637},  // Red Dot Sight
                {203002, 1050010636},  // Holographic Sight
                {203003, 1050010635},  // 2x Scope
                {203004, 1050010633},  // 4x Scope
                {203014, 1050010634},  // 3x Scope
                {203015, 1050010645},  // 6x Scope
                {203100, 1050010646},  // Canted Sight
                {204011, 1050010638},  // Extended Mag
                {204012, 1050010639},  // Quickdraw Mag
                {204013, 1050010640},  // Extended Quickdraw Mag
            }},
        }},
        {103003, "AWM", {
            {"None", {}},
            {"Mauve Avenger", {
                {103003, 1103003022},
                {201009, 1030030166},  // Compensator
                {201010, 1030030165},  // Flash Hider
                {201011, 1030030167},  // Suppressor
                {203004, 1030030164},  // 4x Scope
                {203015, 1030030163},  // 6x Scope
                {204011, 1030030169},  // Extended Mag
                {204012, 1030030172},  // Quickdraw Mag
                {204013, 1030030173},  // Extended Quickdraw Mag
            }},
            {"Field Commander", {
                {103003, 1103003030},
                {201009, 1030030257},  // Compensator
                {201010, 1030030256},  // Flash Hider
                {201011, 1030030258},  // Suppressor
                {202102, 1030030259},  // Cheek Pad
                {203001, 1030030248},  // Red Dot Sight
                {203002, 1030030247},  // Holographic Sight
                {203003, 1030030246},  // 2x Scope
                {203004, 1030030244},  // 4x Scope
                {203014, 1030030245},  // 3x Scope
                {203015, 1030030243},  // 6x Scope
                {203100, 1030030249},  // Canted Sight
                {204011, 1030030253},  // Extended Mag
                {204012, 1030030254},  // Quickdraw Mag
                {204013, 1030030255},  // Extended Quickdraw Mag
            }},
            {"Godzilla", {
                {103003, 1103003042},
                {201009, 1030030375},  // Compensator
                {201010, 1030030374},  // Flash Hider
                {201011, 1030030376},  // Suppressor
                {202102, 1030030377},  // Cheek Pad
                {203004, 1030030364},  // 4x Scope
                {203015, 1030030363},  // 6x Scope
                {204011, 1030030369},  // Extended Mag
                {204012, 1030030372},  // Quickdraw Mag
                {204013, 1030030373},  // Extended Quickdraw Mag
            }},
            {"Rainbow Drake", {
                {103003, 1103003051},
                {201009, 1030030459},  // Compensator
                {201010, 1030030458},  // Flash Hider
                {201011, 1030030460},  // Suppressor
                {202102, 1030030463},  // Cheek Pad
                {203004, 1030030454},  // 4x Scope
                {203015, 1030030453},  // 6x Scope
                {204011, 1030030455},  // Extended Mag
                {204012, 1030030456},  // Quickdraw Mag
                {204013, 1030030457},  // Extended Quickdraw Mag
            }},
            {"Flamewave", {
                {103003, 1103003062},
                {201009, 1030030569},  // Compensator
                {201010, 1030030568},  // Flash Hider
                {201011, 1030030570},  // Suppressor
                {202102, 1030030572},  // Cheek Pad
                {203004, 1030030564},  // 4x Scope
                {203015, 1030030563},  // 6x Scope
                {204011, 1030030565},  // Extended Mag
                {204012, 1030030566},  // Quickdraw Mag
                {204013, 1030030567},  // Extended Quickdraw Mag
            }},
            {"Valor's Requiem", {
                {103003, 1103003079},
                {201009, 1030030745},  // Compensator
                {201010, 1030030744},  // Flash Hider
                {201011, 1030030746},  // Suppressor
                {202102, 1030030747},  // Cheek Pad
                {203001, 1030030738},  // Red Dot Sight
                {203002, 1030030737},  // Holographic Sight
                {203003, 1030030736},  // 2x Scope
                {203004, 1030030734},  // 4x Scope
                {203014, 1030030735},  // 3x Scope
                {203015, 1030030733},  // 6x Scope
                {203100, 1030030739},  // Canted Sight
                {204011, 1030030740},  // Extended Mag
                {204012, 1030030742},  // Quickdraw Mag
                {204013, 1030030743},  // Extended Quickdraw Mag
            }},
            {"Serpengleam", {
                {103003, 1103003087},
                {201009, 1030030826},  // Compensator
                {201010, 1030030825},  // Flash Hider
                {201011, 1030030827},  // Suppressor
                {202102, 1030030828},  // Cheek Pad
                {203001, 1030030818},  // Red Dot Sight
                {203002, 1030030817},  // Holographic Sight
                {203003, 1030030816},  // 2x Scope
                {203004, 1030030814},  // 4x Scope
                {203014, 1030030815},  // 3x Scope
                {203015, 1030030813},  // 6x Scope
                {203100, 1030030819},  // Canted Sight
                {204011, 1030030822},  // Extended Mag
                {204012, 1030030823},  // Quickdraw Mag
                {204013, 1030030824},  // Extended Quickdraw Mag
            }},
        }},
        {103004, "SKS", {
            {"None", {}},
            {"Lady Carmine", {
                {103004, 1103004037},
                {201009, 1030040316},  // Compensator
                {201010, 1030040315},  // Flash Hider
                {201011, 1030040317},  // Suppressor
                {202001, 1030040327},  // Vertical Foregrip
                {202002, 1030040326},  // Angled Foregrip
                {202006, 1030040328},  // Thumb Grip
                {202102, 1030040329},  // Cheek Pad
                {203004, 1030040314},  // 4x Scope
                {203015, 1030040313},  // 6x Scope
                {204011, 1030040324},  // Extended Mag
            }},
        }},
        {103006, "Mini14", {
            {"None", {}},
            {"Icicle", {
                {103006, 1103006030},
                {201009, 1030060246},  // Compensator
                {201010, 1030060245},  // Flash Hider
                {201011, 1030060247},  // Suppressor
                {203004, 1030060244},  // 4x Scope
                {203015, 1030060243},  // 6x Scope
                {204011, 1030060253},  // Extended Mag
            }},
        }},
        {103007, "Mk14", {
            {"None", {}},
            {"Drakreign", {
                {103007, 1103007028},
                {202102, 1030070236},  // Cheek Pad
                {203001, 1030070218},  // Red Dot Sight
                {203002, 1030070217},  // Holographic Sight
                {203003, 1030070216},  // 2x Scope
                {203004, 1030070214},  // 4x Scope
                {203014, 1030070215},  // 3x Scope
                {203015, 1030070213},  // 6x Scope
                {203100, 1030070219},  // Canted Sight
                {204011, 1030070222},  // Extended Mag
            }},
        }},
        {103012, "AMR", {
            {"None", {}},
            {"Crimson Ephialtes", {
                {103012, 1103012010},
                {203001, 1030120038},  // Red Dot Sight
                {203002, 1030120037},  // Holographic Sight
                {203003, 1030120036},  // 2x Scope
                {203004, 1030120034},  // 4x Scope
                {203014, 1030120035},  // 3x Scope
                {203015, 1030120033},  // 6x Scope
            }},
            {"Scorching Blessing", {
                {103012, 1103012019},
                {203001, 1030120138},  // Red Dot Sight
                {203002, 1030120137},  // Holographic Sight
                {203003, 1030120136},  // 2x Scope
                {203004, 1030120134},  // 4x Scope
                {203014, 1030120135},  // 3x Scope
                {203015, 1030120133},  // 6x Scope
            }},
            {"Silent Departed", {
                {103012, 1103012031},
                {203001, 1030120258},  // Red Dot Sight
                {203002, 1030120257},  // Holographic Sight
                {203003, 1030120256},  // 2x Scope
                {203004, 1030120254},  // 4x Scope
                {203014, 1030120255},  // 3x Scope
                {203015, 1030120253},  // 6x Scope
            }},
            {"Pyrotechnic Chroma", {
                {103012, 1103012039},
                {203001, 1030120339},  // Red Dot Sight
                {203002, 1030120338},  // Holographic Sight
                {203003, 1030120337},  // 2x Scope
                {203004, 1030120335},  // 4x Scope
                {203014, 1030120336},  // 3x Scope
                {203015, 1030120334},  // 6x Scope
            }},
        }},
        {103102, "DSR", {
            {"None", {}},
            {"Hyperion Ship", {
                {103102, 1103102007},
                {201009, 1031020027},  // Compensator
                {201010, 1031020026},  // Flash Hider
                {201011, 1031020028},  // Suppressor
                {202102, 1031020029},  // Cheek Pad
                {203001, 1031020019},  // Red Dot Sight
                {203002, 1031020018},  // Holographic Sight
                {203003, 1031020017},  // 2x Scope
                {203004, 1031020015},  // 4x Scope
                {203014, 1031020016},  // 3x Scope
                {203015, 1031020014},  // 6x Scope
                {204011, 1031020023},  // Extended Mag
                {204012, 1031020024},  // Quickdraw Mag
                {204013, 1031020025},  // Extended Quickdraw Mag
            }},
        }},
        {105002, "DP-28", {
            {"None", {}},
            {"Bloodbane Parasite", {
                {105002, 1105002091},
                {203001, 1050020847},  // Red Dot Sight
                {203002, 1050020846},  // Holographic Sight
                {203003, 1050020845},  // 2x Scope
                {203004, 1050020843},  // 4x Scope
                {203014, 1050020844},  // 3x Scope
                {203015, 1050020842},  // 6x Scope
            }},
        }},
        {105010, "MG3", {
            {"None", {}},
            {"Sky Huntress", {
                {105010, 1105010019},
                {203001, 1050100144},  // Red Dot Sight
                {203002, 1050100143},  // Holographic Sight
                {203003, 1050100142},  // 2x Scope
                {203004, 1050100139},  // 4x Scope
                {203014, 1050100141},  // 3x Scope
                {203015, 1050100138},  // 6x Scope
            }},
        }},
        // ── P90 ──────────────────────────────────────────────────────────────
        {102105, "P90", {
            {"None", {}},
            // Body-only: P90 attachment slot item ID is unknown for this build and the
            // fabricated 292105 slot never applies. Bodies below are verified-correct.
            {"Devious Cybercat (Lv.7)", {
                {102105, 1102105012},
            }},
            {"Golden Talon (Lv.5)", {
                {102105, 1102105018},
            }},
            {"Golden Pegasus (Lv.7)", {
                {102105, 1102105028},
            }},
        }},
        // ── MP5K ─────────────────────────────────────────────────────────────
        {102007, "MP5K", {
            {"None", {}},
            {"Retro Pixel (Lv.3)", {
                {102007, 1102007022},   // Body (body-only: attachment slots unverified)
            }},
        }},
        // ── S686 ─────────────────────────────────────────────────────────────
        {104001, "S686", {
            {"None", {}},
            {"Lethal Venom (Lv.5)", {
                {104001, 1104001035},
            }},
        }},
        // ── S1897 ────────────────────────────────────────────────────────────
        {104002, "S1897", {
            {"None", {}},
            {"Twilight Hunt (Lv.5)", {
                {104002, 1104002022},
            }},
            {"Splendid Assault (Lv.3)", {
                {104002, 1104002049},
            }},
            {"Sakura Neko (Lv.1)", {
                {104002, 1104002051},
            }},
        }},
        // ── S12K ─────────────────────────────────────────────────────────────
        {104003, "S12K", {
            {"None", {}},
            {"GACKT (Lv.7)", {
                {104003, 1104003026},
                {291004, 1040030261},  // Mag
                {203008, 1040030262},  // Sight
                {205005, 1040030263},  // Stock
                {201001, 1040030261},  // Choke
                {204011, 1040030271},  // Extended Mag
                {203015, 1040030281},  // 6x Scope
            }},
            {"Atomic Trigger (Lv.5)", {
                {104003, 1104003037},
                {291004, 1040030371},  // Mag
                {203008, 1040030372},  // Sight
                {205005, 1040030373},  // Stock
                {201001, 1040030371},  // Choke
                {204011, 1040030381},  // Extended Mag
                {203015, 1040030391},  // 6x Scope
            }},
            {"Heartbeat Moment (Lv.5)", {
                {104003, 1104003046},
                {291004, 1040030461},  // Mag
                {203008, 1040030462},  // Sight
                {205005, 1040030463},  // Stock
                {201001, 1040030461},  // Choke
                {204011, 1040030471},  // Extended Mag
                {203015, 1040030481},  // 6x Scope
            }},
        }},
        // ── DBS ──────────────────────────────────────────────────────────────
        {104004, "DBS", {
            {"None", {}},
            {"Cosmic Beast (Lv.5)", {
                {104004, 1104004035},   // Body
                {203015, 1040040371},   // 6x Scope
            }},
            {"Panthera Prime (Lv.3)", {
                {104004, 1104004024},   // Body
                {201001, 1040040241},   // Choke
                {203008, 1040040242},   // Sight
                {205005, 1040040243},   // Stock
                {204011, 1040040251},   // Extended Mag
                {203015, 1040040261},   // 6x Scope
            }},
            {"Sandsinger (Lv.3)", {
                {104004, 1104004039},   // Body (no attachments in dump)
            }},
        }},
        // ── NS2000 ───────────────────────────────────────────────────────────
        {104102, "NS2000", {
            {"None", {}},
            {"Rustborn Strider (Lv.3)", {
                {104102, 1104102004},   // Body (body-only: attachment slots unverified)
            }},
        }},
    };
}
