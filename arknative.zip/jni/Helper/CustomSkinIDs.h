#pragma once
#include <map>
#include "GunSkinsAttachments.h"  // User-specified gun skins with attachments

// ═══════════════════════════════════════════════════════════════
//  UNIFIED SKIN SYSTEM - MERGED FROM BOTH SOURCES
//  ├─ Kill Effect, Deadbox, Hit Effect (AimBtSsAllFix)
//  ├─ XSuit, Backpack (AimBtSsAllFix)
//  ├─ Gun Skins + Attachments (User Specified)
//  └─ All integrated in ArkCheat_v3 source
// ═══════════════════════════════════════════════════════════════

// XSUIT/OUTFIT SKINS (NEW SET GLIT 4.4)
#define XSUIT_SET_ID        1407921
#define XSUIT_COVER_ID      1411103

// BACKPACK SKINS (Lv1, Lv2, Lv3)
#define BACKPACK_LV1_ID     1501001727
#define BACKPACK_LV2_ID     1501002727
#define BACKPACK_LV3_ID     1501003727

// NARUTO BACKPACK — NINJA SCROLL (Lv1, Lv2, Lv3)
#define NARUTO_BACKPACK_LV1 1501001742
#define NARUTO_BACKPACK_LV2 1501002742
#define NARUTO_BACKPACK_LV3 1501003742

// NARUTO HELMET — PAKKUN (Lv1, Lv2, Lv3)
#define NARUTO_HELMET_LV1   1502001508
#define NARUTO_HELMET_LV2   1502002508
#define NARUTO_HELMET_LV3   1502003508

// EFFECT SYSTEM - ACTIVE
#define ENABLE_KILL_EFFECT  true
#define ENABLE_HIT_EFFECT   true
#define ENABLE_DEADBOX_SKIN true
#define ENABLE_KILL_MSG     true   // kill feed skin hook

// OUTFIT & WEAPON SYSTEM - ACTIVE
#define ENABLE_OUTFIT_SKIN  true
#define ENABLE_BACKPACK_SKIN true
#define ENABLE_GUN_SKIN true
#define ENABLE_GUN_ATTACHMENTS true
#define ENABLE_VEHICLE_SKIN false

// GUN IDs REFERENCE
#define M416    101004
#define AKM     101001
#define M16A4   101002
#define SCARL   101003
#define GROZA   101005
#define AUG     101006
#define QBZ     101007
#define M762    101008
#define ACE32   101102
#define AWM     103003
#define M24     103002
#define KAR98K  103001
#define AMR     103012
#define MK14    103007
#define SKS     103004
#define SLR     103009
#define MINI14  103006
#define MK12    103100
#define DP28    105002
#define MG3     105010
#define M249    105001
#define UZI     102001
#define UMP45   102002
#define THOMPSON 102004
#define BIZON   102005
#define VSS     103005
#define P90     102105
