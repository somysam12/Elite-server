#pragma once
// ╔══════════════════════════════════════════════════════════════╗
// ║  KCConfig.h — APNA DETAILS YAHAN CHANGE KARO               ║
// ╚══════════════════════════════════════════════════════════════╝

// ── Loader APK Package Name ─────────────────────────────────

// ── Lic File written by the LOADER (read-only here) ─────────
// Loader writes: key\nserial\npkg  →  /storage/emulated/0/Android/ArkCheat.lic
// Path constructed via OBF() (compile-time XOR) in main.cpp.

// ── Panel URL (validbool endpoint) ──────────────────────────
#define KC_MY_PANEL_URL  "https://arkcheatadmin.battleground-hub.shop/validbool"
