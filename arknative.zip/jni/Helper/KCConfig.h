#pragma once
// ╔══════════════════════════════════════════════════════════════╗
// ║  KCConfig.h — APNA DETAILS YAHAN CHANGE KARO               ║
// ╚══════════════════════════════════════════════════════════════╝

// ── Loader APK Package Name ─────────────────────────────────

// ── Lic File written by the LOADER (read-only here) ─────────
// Loader writes: key\nserial\npkg  →  /storage/emulated/0/Android/ArkCheat.lic
// Path constructed at use site via OBFUSCATE to avoid plaintext in binary.

// ── Panel URL (validbool endpoint) ──────────────────────────
#define KC_MY_PANEL_URL  "http://arkcheat.battleground-hub.shop/validbool"
