#pragma once
// ╔══════════════════════════════════════════════════════════════╗
// ║  KCConfig.h — APNA DETAILS YAHAN CHANGE KARO               ║
// ╚══════════════════════════════════════════════════════════════╝

// ── Loader APK Package Name ─────────────────────────────────

// ── Lic File written by the LOADER (read-only here) ─────────
// Loader writes: key\nserial\npkg  →  /storage/emulated/0/Android/FpsBattle.lic
#define LIC_FILE_NAME  "ArkCheat.lic"
#define LIC_DIR        "/storage/emulated/0/Android/"

// ── Panel URL (validbool endpoint) ──────────────────────────
#define KC_MY_PANEL_URL  "http://arkcheat.battleground-hub.shop/validbool"
