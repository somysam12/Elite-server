// ═══════════════════════════════════════════════════════════════════════════
// KC_LuaInject.h — Lua injection (wardrobe, kill counter)
//
// Method (crash-safe, game-thread):
//   1. Hook luaL_loadbufferx → captures Lua state (KC_G_LuaState)
//   2. Hook lua_sub (ProcessEvent-equivalent) → inject from game thread
//      Twitter  : as soon as isLogin becomes true
//      Wardrobe : after 20 ProcessEvent calls + isLogin
//      Kill Ctr : after 35 calls
//
// Installation: A64HookFunction calls in main_thread() in main.cpp.
// ═══════════════════════════════════════════════════════════════════════════
#pragma once
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <ctime>
#include "KC_LuaScript.h"              // kc_wardrobe_script
#include "KC_TwitterLogin.h"           // kc_twitter_login_script
#include "KC_KillCounter.h"            // kc_kill_counter_script
#include "KC_WeaponAttach.h"           // kc_weapon_attach_script

// ── Captured state + flags ─────────────────────────────────────────────────
static int64_t  KC_G_LuaState              = 0;
static bool     KC_LuaInjected             = false;
static bool     KC_KillCounterInjected     = false;
static int      KC_ProcessEventCount       = 0;
static bool     KC_TwitterInjected         = false;
static bool     KC_WeaponAttachInjected    = false;

// ── Lua function pointers (set in main_thread after bValid) ───────────────
struct KC_LuaFns {
    int64_t (*loadBuffer)(int64_t, const char*, size_t, const char*, const char*);
    int64_t (*pcall)(int64_t, int, int, int);
};
static KC_LuaFns kc_lua = { nullptr, nullptr };

// ── Execute a Lua script on the captured state ────────────────────────────
static bool KC_ExecScript(int64_t state, const char* script, const char* chunkName) {
    if (!state || !kc_lua.loadBuffer || !kc_lua.pcall) return false;
    int r = kc_lua.loadBuffer(state, script, strlen(script), chunkName, "t");
    if (r != 0) return false;
    return kc_lua.pcall(state, 0, 0, 0) == 0;
}

static bool KC_ExecuteLua(int64_t state)          { return KC_ExecScript(state, kc_wardrobe_script,        "@kc_main"); }
static bool KC_ExecuteTwitter(int64_t state)      { return KC_ExecScript(state, kc_twitter_login_script,   "@kc_twitter"); }
static bool KC_ExecuteKillCounter(int64_t state)  { return KC_ExecScript(state, kc_kill_counter_script,    "@kc_kills"); }
static bool KC_ExecuteWeaponAttach(int64_t state) { return KC_ExecScript(state, kc_weapon_attach_script,   "@kc_weaponattach"); }

// ── Hook: luaL_loadbufferx — capture the Lua state ─────────────────────────
static int64_t (*KC_orig_loadbufferx)(int64_t, const char*, size_t,
                                      const char*, const char*) = nullptr;
static int64_t KC_hooked_loadbufferx(int64_t L, const char* buff, size_t sz,
                                     const char* name, const char* mode) {
    if (!KC_G_LuaState && L) KC_G_LuaState = L;
    return KC_orig_loadbufferx(L, buff, sz, name, mode);
}

// ── Hook: lua_sub (ProcessEvent-equivalent) — inject from game thread ──────
static void (*KC_orig_ProcessEvent)(void*, void*, void*) = nullptr;
static void KC_hooked_ProcessEvent(void* object, void* function, void* params) {
    if (KC_G_LuaState) ++KC_ProcessEventCount;

    // Twitter login: inject as soon as login becomes true (before login UI)
    if (!KC_TwitterInjected && KC_G_LuaState && isLogin) {
        KC_TwitterInjected = true;
        KC_ExecuteTwitter(KC_G_LuaState);
    }

    // Wardrobe skins: inject after 20 calls + login
    if (!KC_LuaInjected && KC_G_LuaState && isLogin && KC_ProcessEventCount >= 20) {
        KC_LuaInjected = true;
        KC_ExecuteLua(KC_G_LuaState);
    }

    // Per-gun kill counter: inject after wardrobe
    if (!KC_KillCounterInjected && KC_G_LuaState && isLogin && KC_ProcessEventCount >= 35) {
        KC_KillCounterInjected = true;
        KC_ExecuteKillCounter(KC_G_LuaState);
    }

    // Weapon attachment ownership: inject after kill counter
    if (!KC_WeaponAttachInjected && KC_G_LuaState && isLogin && KC_ProcessEventCount >= 45) {
        KC_WeaponAttachInjected = true;
        KC_ExecuteWeaponAttach(KC_G_LuaState);
    }

    KC_orig_ProcessEvent(object, function, params);
}
