#pragma once
#include <vector>
#include <string>

struct KCSkinItem { int code; const char* name; };

static const KCSkinItem g_KCOutfits[] = {
    {0, "None"},
    {1405132, "Forest Elf Set"},
    {1406469, "Golden Pharaoh X-Suit (7-Star)"},
    {1405870, "Blood Raven X-Suit (6-Star)"},
    {1407140, "Poseidon X-Suit (7-Star)"},
    {1407141, "Avalanche X-Suit (7-Star)"},
    {1407142, "Silvanus X-Suit (7-Star)"},
    {1407550, "Iridescence X-Suit (7-Star)"},
    {1406638, "Arcane Jester X-Suit (6-Star)"},
    {1406872, "Stygian Liege X-Suit (7-Star)"},
    {1406971, "Marmoris X-Suit (7-Star)"},
    {1407103, "Fiore X-Suit (7-Star)"},
    {1407219, "Ignis X-Suit (7-Star)"},
    {1407366, "Galadria X-Suit (7-Star)"},
    {1407512, "Anukhra X-Suit (7-Star)"},
    {1407906, "Chaosphage Set"},
    {1407916, "Castor Set"},
    {1407920, "Bloodfeather Spartan Set"},
    {1407757, "Cryonix Wraith Set (F)"},
    {1407789, "Cryonix Wraith Set (M)"},
    {1407990, "Verdant Druvaen X-Suit (7-Star)"},
    {1408038, "Pyre Druvaen X-Suit (7-Star)"},
    {1408045, "Frost Druvaen X-Suit (7-Star)"},
    {1400290, "Bloody Fangs Suit"},
    {1400292, "Bloodied Maid Suit"},
    {1400694, "Demon Hunter Set"},
    {1400782, "Glacier Set"},
    {1404283, "Golden Nights Set"},
    {1405038, "Dangerous Angel Set"},
    {1405041, "Roaring Dragon Set"},
    {1405042, "Dragon Hunter Set"},
    {1405052, "Golden Piglet Suit"},
    {1405102, "Golden Trigger Set"},
    {1405124, "Dragon's Wrath Set"},
    {1405319, "Blood Rain Set"},
    {1405326, "First Blood Set"},
    {1405340, "Angel Wings Set"},
    {1405412, "Blood Lotus Set"},
    {1405440, "Black Dragon Fighter Set"},
    {1405441, "Red Dragon Fighter Set"},
    {1405450, "Joker of Spades Set"},
    {1405478, "Joker of Clubs Set"},
    {1405514, "Golden Claw Set"},
    {1405518, "Golden Splendor Set"},
    {1405533, "Bloodthirsty Fiend Set"},
    {1405792, "Ghillie Dragon Set"},
    {1405866, "Golden Prince Set"},
    {1405941, "Languid Dragonfly Set"},
    {1405986, "Poseidon's Ironguard Set"},
    {1405987, "Poseidon's Herald Set"},
    {1405989, "PsyOp Samurai Set"},
    {1406060, "Bonds of Blood Set"},
    {1406068, "Demon Guise Set"},
    {1406201, "Celestial Ruler Set"},
    {1406341, "Baby Dragon Set"},
    {1406363, "Peerless Conqueror Set"},
    {1406370, "Trendy Samurai Set"},
    {1406432, "Phoenix Adarna Set"},
    {1406433, "Agent Phoenix Set"},
    {1406459, "Celestial Oracle Set"},
    {1406548, "Cake Demon Set"},
    {1406567, "Nebulous Conqueror Set"},
    {1406654, "Conquering Soul Set"},
    {1406656, "Bloody Noon Set"},
    {1406728, "Bruce Lee Kung Fu Soul Set"},
    {1406730, "Bruce Lee Dragon's Roar Set"},
    {1406754, "Mythical Monkey Set"},
    {1406791, "Dragonflame Berserker Set"},
    {1406805, "Windcrest Soul Set"},
    {1406824, "Bloodstained Nemesis Set"},
    {1406827, "Blood Rose Set"},
    {1406881, "Golden Reaper Set"},
    {1406882, "Golden Blessing Set (Female)"},
    {1406883, "Golden Blessing Set (Male)"},
    {1406902, "Glacier Squad Set"},
    {1406914, "Arcane Disciple Set"},
    {1406918, "Golden Paw Set"},
    {1406981, "Aurelian Dragon Set"},
    {1407041, "Sakura Samurai Set"},
    {1407078, "The Magician's Arcane Set"},
    {1407152, "Dragon Emperor Set"},
    {1407153, "Dragon Empress Set"},
    {1407155, "Inferno Valkyrie Set"},
    {1407156, "LINE FRIENDS Dragon BROWN Set"},
    {1407157, "LINE FRIENDS Dragon CONY Set"},
    {1407245, "Tira the Power of 9 Dragons Set"},
    {1407248, "Celestial Sentinel Set"},
    {1407263, "Wasteland Samurai Set"},
    {1407277, "Inferno Fiend Set"},
    {1407300, "Alluring Angel Set"},
    {1407316, "Bloodmoon Assassin Set"},
    {1407353, "Turf Conqueror Set"},
    {1407440, "Arctic Conqueror Set"},
    {1407442, "Arcane Mechanist Set"},
    {1407450, "Demon Lord Rimuru Set"},
    {1407462, "Dragontide Pulse Set"},
    {1407470, "Untamed Celestial Set"},
    {1407530, "Goldensands Noble Set"},
    {1407531, "Goldensands Priestess Set"},
};

// Fixed default skins (always applied, no dropdown)
static const int KC_DEFAULT_BACKPACK  = 1501003724;  // Dioscuri Backpack (Lv. 3)
static const int KC_DEFAULT_PARACHUTE = 1401842;     // Dioscuri Parachute
static const int KC_DEFAULT_HELMET    = 1502003497;  // Dioscuri Helmet (Lv. 3)

// Helmet selection list (Lv3 codes)
static const KCSkinItem g_KCHelmets[] = {
    {0,           "Default"},
    {1502003497,  "Dioscuri (Lv.3)"},
    {1502003499,  "Bloodfeather Spartan (Lv.3)"},
    {1502003014,  "Inferno Rider (Lv.3)"},
    {1502003023,  "Glacier (Lv.3)"},
    {1502003327,  "Magma Skull (Lv.3)"},
    {1502003408,  "Piercing Fang (Lv.3)"},
    {1502003410,  "Feral Ravager (Lv.3)"},
    {1502003439,  "Auric Reign (Lv.3)"},
};

// Backpack selection list (Lv3 codes)
static const KCSkinItem g_KCBackpacks[] = {
    {0,           "Default"},
    {1501003724,  "Dioscuri (Lv.3)"},
    {1501003051,  "The Fool (Lv.3)"},
    {1501003174,  "Pharaoh's Regalia (Lv.3)"},
    {1501003265,  "Poseidon (Lv.3)"},
    {1501003336,  "Alfheim Wonder (Lv.3)"},
    {1501003349,  "Lost Civilization (Lv.3)"},
    {1501003443,  "Luminous Galaxy (Lv.3)"},
    {1501003567,  "Ignis (Lv.3)"},
    {1501003581,  "Mercury Soldier (Lv.3)"},
    {1501003607,  "Vampiric Compulsion (Lv.3)"},
    {1501003664,  "Sinkeeper's Coffer (Lv.3)"},
    {1501003672,  "Stellarwing Flutter (Lv.3)"},
    {1501003677,  "Talisdrake Rift (Lv.3)"},
    {1501003688,  "Polar Prism (Lv.3)"},
    {1501003698,  "Well of Souls (Lv.3)"},
    {1501003699,  "Mystic Seal (Lv.3)"},
    {1501003133,  "Bloodthirsty Joker (Lv.3)"},
    {1501003637,  "Godzilla King of the Monsters (Lv.3)"},
    {1501003741,  "Sanctuary Traveler (Lv.3)"},
};

// Mask selection list
static const KCSkinItem g_KCMasks[] = {
    {0,        "None"},
    {1400168,  "Clown Mask"},
    {1403028,  "The Fool Mask"},
    {1403307,  "Fluorescent Jesterette Mask"},
    {1403318,  "Lethal Creepster Mask"},
    {1403498,  "Spectral Ranger Mask"},
    {1403660,  "Shinobi Spirit Mask"},
    {1403770,  "Tobi's Mask"},
    {1410072,  "Flamewraith Mask"},
    {1403745,  "Cryonix Wraith Mask"},
};

// Headgear / Cover selection list
static const KCSkinItem g_KCHeadgear[] = {
    {0,         "None"},
    {1402026,   "Traveler's Fedora"},
    {1402166,   "Sea Serpent Cover"},
    {1410138,   "Bramble Overlord Cover"},
    {1410647,   "The Lover's Grace Cover"},
    {1410923,   "The Hermit's Chrysalis Cover"},
    {1411097,   "Rose Requiem Cover"},
    {1411101,   "Pollux Cover"},
    {1411103,   "Aberrant Aphrodite Cover"},
    {1411130,   "Cybernetic Samurai Cover"},
    {1410695,   "CYCLE 7 Cover"},
    {1411162,   "Cryo King Hat"},
};

// Gloves selection list
static const KCSkinItem g_KCGloves[] = {
    {0,       "None"},
    {452001,  "Icy Gloves"},
    {452003,  "Quicksand Gloves"},
};

// Pan skin selection list (slot 108004)
static const KCSkinItem g_KCPanSkins[] = {
    {0,           "Default (Faerie Luster)"},
    {1108004283,  "Accolade - Pan (Lv.6)"},
    {1108004280,  "Accolade - Pan (Lv.3)"},
    {1108004290,  "Evangelion 10th Angel - Pan"},
    {1108004027,  "Glacier - Pan"},
    {1108004008,  "Olive Branch - Pan"},
    {1108004365,  "Faerie Luster - Pan (Lv.3)"},
};

// Machete skin selection list (slot 108001)
static const KCSkinItem g_KCMacheteSkins[] = {
    {0,           "Default (Kusanagi Blade Lv.3)"},
    {1108001107,  "Kusanagi Blade (Lv.3)"},
    {1108001104,  "Dioscuri - Machete"},
    {1108001103,  "Chain Handcuffs (Lv.3)"},
    {1108001087,  "Drakewing Edge - Pan"},
    {1108001081,  "Burning Godzilla Tomahawk (Lv.3)"},
};

// Dagger skin selection list (slot 108005)
static const KCSkinItem g_KCDaggerSkins[] = {
    {0,           "Default (Tundra Knight Lv.3)"},
    {1108005050,  "Tundra Knight - Dagger (Lv.3)"},
    {1108005052,  "Papillon Kiss - Dagger"},
};

// Crowbar / Trident skin selection list (slot 108002)
static const KCSkinItem g_KCCrowbarSkins[] = {
    {0,           "Default (Frost Graze)"},
    {1108002039,  "Frost Graze - Crowbar"},
    {1108002059,  "Tidal Fury - Trident (Lv.5)"},
    {1108002057,  "Tidal Fury - Trident (Lv.3)"},
    {1108002054,  "Tidal Fury - Trident (Lv.1)"},
};

static int  g_KCOutfitIdx   = 0;
static bool g_KCSkinEnabled = false;

// Indices for new skin selections
static int g_KCHelmetIdx   = 0;
static int g_KCBackpackIdx = 0;
static int g_KCMaskIdx     = 0;
static int g_KCHeadgearIdx = 0;
static int g_KCGlovesIdx   = 0;
static int g_KCPanIdx      = 0;
static int g_KCMacheteIdx  = 0;
static int g_KCDaggerIdx   = 0;
static int g_KCCrowbarIdx  = 0;