namespace Cheat {
    
uintptr_t libUE4Base;
uintptr_t libanogsBase;
uintptr_t libcBase;
uintptr_t libanortBase;
uintptr_t GName_Offest = 0;
uintptr_t GUObject_Offset = 0;
uintptr_t ActorArray_Offest = 0;
uintptr_t GNativeAndroidApp_Offset = 0;
uintptr_t anosdkrevsign;
uintptr_t recvparent;
uintptr_t bulletioctl;
uintptr_t bullethitinfo;
uintptr_t case10;
uintptr_t anosdk;
uintptr_t getreport;
uintptr_t getreport2;
uintptr_t getreport3;
uintptr_t getreport4;
uintptr_t fps120;
uintptr_t tssmanager;
uintptr_t msgboxext;
uintptr_t renderoffset;
uintptr_t line;
uintptr_t text;
uintptr_t fakedamage1;
uintptr_t shootevent;
uintptr_t launchbp;
uintptr_t crashfixer;

// Lua injection offsets (BGMI 4.6)
uintptr_t lua_loadbufferx;
uintptr_t lua_pcall;
uintptr_t lua_sub;        // ProcessEvent-equivalent trigger
uintptr_t lua_tostring;

// Kill message hook (BGMI 4.6)
uintptr_t KillMSG;

std::string Mode;
SDK::ASTExtraPlayerCharacter *localPlayer = 0;
SDK::ASTExtraPlayerController *localController = 0;



namespace Esp {
bool Line = false;
bool Skeleton = false;
bool Health = false;
bool Distance = false;
bool Name = false;
bool WeaponName = false;
bool ItemEsp = false;
bool LootBox = false;
bool PlayerWarning = false;
bool AimWarning = false;
bool Grenade = false;
bool Count = false;
bool Alert = false;

namespace Vehicle {
bool Name = false;
bool Health = false;
bool Fuel = false;
}

namespace World {
bool GrenadeWarn = false;
bool LootBox = false;
}
}
namespace Aimbot
{
bool Enable;
bool VisCheck;
bool IgnoreKnock;
bool IgnoreBot = false;
float Aimset = 30.0f;
float Range = 150.0f;
float Radius = 150.0f;
float AimingSpeed = 4.0f;
float Smoothness = 20.0f;
float RecoilCompression = 0.5f;
bool RecoilControl;
}

namespace BulletTrack
{
bool Enable;
bool Safe;
bool VisCheck;
bool IgnoreKnock;
float BulletRange = 90.0f;
float AimPos = 10.0f;
float Fov = 95.0f;
bool AutoFire = false;
bool IgnoreBot = false;
float hitAccuracy = 30.0f;
}

namespace Memory
{
bool MagicBullet = false;  // TCP-controlled toggle
bool HitEffect;
bool WideView;
bool InstantHit;
bool InstantFix;
}
}

float FOVsizea = 140.f;
float FOVSizea;
bool Expiry = true;

bool is_bgmi = false, is_pubgm = false;
const char *Gamepackage = nullptr;

// Skin system globals — used by GunSkin.cpp / KillMsg.cpp
bool GunSkin      = false;
bool VehicleSkin  = false;
static uintptr_t lastVehicle     = 0;
static int       lastSkinApplied = -1;



void *detect()
{
    char process_name[256] = {0};
    FILE *fp = fopen("/proc/self/cmdline", "r");
    if (fp)
    {
        fread(process_name, 1, sizeof(process_name) - 1, fp);
        fclose(fp);
    }

    if (strcmp(process_name, "com.pubg.imobile") == 0)
    {
        is_bgmi = true;
        Cheat::GName_Offest             = 0x89750B0;
        Cheat::GUObject_Offset          =  0xEB04D00;
        Cheat::ActorArray_Offest        = 0xA71EA80;
        Cheat::GNativeAndroidApp_Offset = 0xE8338A8;
        Cheat::msgboxext                = 0x87a095c; //not
        Cheat::renderoffset             = 0xA62830C;
        Cheat::line                     = 0xac24160; //not
        Cheat::text                     = 0xAC243F0;
        Cheat::fakedamage1              = 0x7FA12B0;
        Cheat::shootevent               = 0x6DAB6cc;
        Cheat::launchbp                 = 0x7486918;
        // Lua injection (4.6)
        Cheat::lua_loadbufferx          = 0xB51186C;
        Cheat::lua_pcall                = 0xB4ED430;
        Cheat::lua_sub                  = 0xC222534;
        Cheat::lua_tostring             = 0xB4EB850;
        // Kill message hook (4.6)
        Cheat::KillMSG                  = 0x6529184;

    }

    else if (strcmp(process_name, "com.tencent.ig") == 0)
    {
        is_pubgm = true;
        Cheat::GName_Offest    = 0x81db440;
        Cheat::GUObject_Offset   = 0xe788870;
        Cheat::ActorArray_Offest  = 0xa20682c;
        Cheat::GNativeAndroidApp_Offset = 0xe4d0980;
        Cheat::anosdkrevsign = 0xCA95480;
        Cheat::recvparent   = 0x72FB314;
        Cheat::bulletioctl  = 0x676FBB4;
        Cheat::bullethitinfo = 0x676E848;
        Cheat::anosdk       = 0xCA94EE0;
        Cheat::getreport  = 0x5CC03D4;
        Cheat::getreport2 = 0x72FA4BC;
        Cheat::getreport3 = 0x72FCBB0;
        Cheat::getreport4 = 0x72FCFCC;
        Cheat::fps120     = 0x62EB99C;
        Cheat::tssmanager = 0x72F9870;
        Cheat::case10       = 0x72FA848;
        Cheat::msgboxext    = 0x80003AC;
        Cheat::renderoffset = 0xa11405c;
        Cheat::line         = 0xA6EB70C;
        Cheat::text         = 0xA6EB99C;
        Cheat::fakedamage1 = 0x7941B84;
        Cheat::shootevent   = 0x680CFB4;
        Cheat::launchbp     = 0x6E81724; 
        Cheat::crashfixer = 0x25CB88;
    }

    else if (strcmp(process_name, "com.pubg.krmobile") == 0)
    {
        is_pubgm = true;
        Cheat::GName_Offest    = 0x81db440;
        Cheat::GUObject_Offset   = 0xe788870;
        Cheat::ActorArray_Offest  = 0xa20682c;
        Cheat::GNativeAndroidApp_Offset = 0xe4d0980;
        Cheat::anosdkrevsign = 0xCA95480;
        Cheat::recvparent   = 0x72FB314;
        Cheat::bulletioctl  = 0x676FBB4;
        Cheat::bullethitinfo = 0x676E848;
        Cheat::anosdk       = 0xCA94EE0;
        Cheat::getreport  = 0x5CC03D4;
        Cheat::getreport2 = 0x72FA4BC;
        Cheat::getreport3 = 0x72FCBB0;
        Cheat::getreport4 = 0x72FCFCC;
        Cheat::fps120     = 0x62EB99C;
        Cheat::tssmanager = 0x72F9870;
        Cheat::case10       = 0x72FA848;
        Cheat::msgboxext    = 0x80003AC;
        Cheat::renderoffset = 0xa11405c;
        Cheat::line         = 0xA6EB70C;
        Cheat::text         = 0xA6EB99C;
        Cheat::fakedamage1 = 0x7941B84;
        Cheat::shootevent   = 0x680CFB4;
        Cheat::launchbp     = 0x6E81724; 
        Cheat::crashfixer = 0x25CB88;
    }

    else if (strcmp(process_name, "com.vng.pubgmobile") == 0)
    {
       is_pubgm = true;
        Cheat::GName_Offest    = 0x81db440;
        Cheat::GUObject_Offset   = 0xe788870;
        Cheat::ActorArray_Offest  = 0xa20682c;
        Cheat::GNativeAndroidApp_Offset = 0xe4d0980;
        Cheat::anosdkrevsign = 0xCA95480;
        Cheat::recvparent   = 0x72FB314;
        Cheat::bulletioctl  = 0x676FBB4;
        Cheat::bullethitinfo = 0x676E848;
        Cheat::anosdk       = 0xCA94EE0;
        Cheat::getreport  = 0x5CC03D4;
        Cheat::getreport2 = 0x72FA4BC;
        Cheat::getreport3 = 0x72FCBB0;
        Cheat::getreport4 = 0x72FCFCC;
        Cheat::fps120     = 0x62EB99C;
        Cheat::tssmanager = 0x72F9870;
        Cheat::case10       = 0x72FA848;
        Cheat::msgboxext    = 0x80003AC;
        Cheat::renderoffset = 0xa11405c;
        Cheat::line         = 0xA6EB70C;
        Cheat::text         = 0xA6EB99C;
        Cheat::fakedamage1 = 0x7941B84;
        Cheat::shootevent   = 0x680CFB4;
        Cheat::launchbp     = 0x6E81724; 
        Cheat::crashfixer = 0x25CB88;
    }

    else if (strcmp(process_name, "com.rekoo.pubgm") == 0)
    {
        is_pubgm = true;
        Cheat::GName_Offest    = 0x81db440;
        Cheat::GUObject_Offset   = 0xe788870;
        Cheat::ActorArray_Offest  = 0xa20682c;
        Cheat::GNativeAndroidApp_Offset = 0xe4d0980;
        Cheat::anosdkrevsign = 0xCA95480;
        Cheat::recvparent   = 0x72FB314;
        Cheat::bulletioctl  = 0x676FBB4;
        Cheat::bullethitinfo = 0x676E848;
        Cheat::anosdk       = 0xCA94EE0;
        Cheat::getreport  = 0x5CC03D4;
        Cheat::getreport2 = 0x72FA4BC;
        Cheat::getreport3 = 0x72FCBB0;
        Cheat::getreport4 = 0x72FCFCC;
        Cheat::fps120     = 0x62EB99C;
        Cheat::tssmanager = 0x72F9870;
        Cheat::case10       = 0x72FA848;
        Cheat::msgboxext    = 0x80003AC;
        Cheat::renderoffset = 0xa11405c;
        Cheat::line         = 0xA6EB70C;
        Cheat::text         = 0xA6EB99C;
        Cheat::fakedamage1 = 0x7941B84;
        Cheat::shootevent   = 0x680CFB4;
        Cheat::launchbp     = 0x6E81724; 
        Cheat::crashfixer = 0x25CB88; 
    }

    return nullptr;
}






#define PI 3.14159265358979323846
#define RAD2DEG(x) ((float)(x) * (float)(180.f / PI))
#define IM_PI 3.14159265358979323846
#define RAD2DEG( x )  ( (float)(x) * (float)(180.f / IM_PI) )
#define DEG2RAD( x ) ( (float)(x) * (float)(IM_PI / 180.f) )
#define W2S(w, s) UGameplayStatics::ProjectWorldToScreen(Cheat::localController, w, true, s)
#define COLOR_IN FLinearColor(0, 0, 0, 0)
#define COLOR_OUTLINE FLinearColor(0.0f, 0.0f, 0.0f, 0.25f)
#define COLOR_BLACK FLinearColor(0, 0, 0, 1.f)
#define 深紫 FLinearColor(0.15f, 0.20f, 0.89f, 1.0f )
#define COLOR_THUNDEROP FLinearColor(0.0f, 0.0f, 0.0f, 0.0f)
#define COLOR_WHITE FLinearColor(1.f, 1.f, 1.f, 1.f)
#define COLOR_RED FLinearColor(1.f, 0, 0, 1.f)
#define COLOR_CAR FLinearColor(1.f, 0.5f, 1.f, 1.f)
#define COLOR_GREEN FLinearColor(0.0f, 1.0f, 0.0f, 1.0f)
#define COLOR_ORANGE FLinearColor(1.f, 0.4f, 0, 1.f)
#define COLOR_YELLOW FLinearColor(1.f, 1.f, 0, 1.f)
#define COLOR_LIME FLinearColor(0, 1.f, 0, 1.f)
#define COLOR_BLUE FLinearColor(0, 0, 1.f, 1.f)
#define COLOR_THISTLE FLinearColor(1.0f, 0.74f, 0.84f, 1.0f)
#define COLOR_PINK FLinearColor(1.0f, 0.75f, 0.8f, 1.0f)
#define TSL_FONT_DEFAULT_SIZE 20


using namespace SDK;
int screenWidth = -1, glWidth, screenHeight = -1, glHeight;
float density = -1;

FVector GetBoneLocationByName(ASTExtraPlayerCharacter *Actor, const char *BoneName) {
    return Actor->GetBonePos(BoneName, FVector());
}

// Login && SDK Implement
using json = nlohmann::json;
time_t rng = 0;
pthread_t t;
using namespace SDK;

struct sRegion {
    uintptr_t start, end;
};

std::vector<sRegion> trapRegions;
static UFont *tslFont = 0, *robotoTinyFont = 0;

void *LoadFont(void *) {
    while (!tslFont || !robotoTinyFont) {
        tslFont = UObject::FindObject<UFont>("Font Roboto.Roboto");
        robotoTinyFont = UObject::FindObject<UFont>("Font RobotoDistanceField.RobotoDistanceField");
        sleep(1);
    }
    return 0;
}


#include "Helper/Items.h"
#include "Helper/Login+functions.h"

FVector TargetPos = { };
bool isObjectInvalid(UObject *obj) {
    if (!Tools::IsPtrValid(obj)) {
        return true;
    }

    if (!Tools::IsPtrValid(obj->ClassPrivate)) {
        return true;
    }

    if (obj->InternalIndex <= 0) {
        return true;
    }

    if (obj->NamePrivate.ComparisonIndex <= 0) {
        return true;
    }

    if ((uintptr_t) (obj) % sizeof(uintptr_t) != 0x0 &&
            (uintptr_t) (obj) % sizeof(uintptr_t) != 0x4) {
        return true;
    }

    if (std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) {
    return ((uintptr_t) obj) >= region.start && ((uintptr_t) obj) <= region.end;
    }) ||
    std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) {
        return ((uintptr_t) obj->ClassPrivate) >= region.start &&
               ((uintptr_t) obj->ClassPrivate) <= region.end;
    })) {
        return true;
    }

    return false;
}


static UEngine *GEngine = 0;
UWorld *GetWorld()
{
    while (!GEngine)
    {
        GEngine = UObject::FindObject<UEngine>("UAEGameEngine Transient.UAEGameEngine_1");
        sleep(1);
    }
    if (GEngine)
    {
        auto ViewPort = GEngine->GameViewport;

        if (ViewPort)
        {
            return ViewPort->World;
        }
    }
    return 0;
}


TNameEntryArray *GetGNames() {
    return ((TNameEntryArray *(*)()) (Cheat::libUE4Base + Cheat::GName_Offest))();
}

std::vector<AActor *> GetActors() {
    auto World = GetWorld();
    if (!World)
        return std::vector<AActor *>();

    auto PersistentLevel = World->PersistentLevel;
    if (!PersistentLevel)
        return std::vector<AActor *>();

    struct GovnoArray {
        uintptr_t base;
        int32_t count;
        int32_t max;
    };
    static thread_local GovnoArray Actors{};

    Actors = *(((GovnoArray *(*)(uintptr_t)) (Cheat::libUE4Base + Cheat::ActorArray_Offest))(
                   reinterpret_cast<uintptr_t>(PersistentLevel)));

    if (Actors.count <= 0) {
        return {};
    }

    std::vector<AActor *> actors;
    for (int i = 0; i < Actors.count; i++) {
        auto Actor = *(uintptr_t *) (Actors.base + (i * sizeof(uintptr_t)));
        if (Actor) {
            actors.push_back(reinterpret_cast<AActor *const>(Actor));
        }
    }
    return actors;
}


template <class T>
void GetAllActors(std::vector<T *> &Actors)
{
    UGameplayStatics *gGameplayStatics = (UGameplayStatics *)gGameplayStatics->StaticClass();
    auto GWorld = GetWorld();
    if (GWorld)
    {
        TArray<AActor *> Actors2;
        gGameplayStatics->GetAllActorsOfClass((UObject *)GWorld, T::StaticClass(), &Actors2);
        for (int i = 0; i < Actors2.Num(); i++)
        {
            Actors.push_back((T *)Actors2[i]);
        }
    }
}

SDK::FVector SubtractVectors(SDK::FVector a, SDK::FVector b) {
    SDK::FVector result;
    result.X = a.X - b.X;
    result.Y = a.Y - b.Y;
    result.Z = a.Z - b.Z;
    return result;
}


SDK::FVector AddVectors(SDK::FVector a, SDK::FVector b) {
    SDK::FVector result;
    result.X = a.X + b.X;
    result.Y = a.Y + b.Y;
    result.Z = a.Z + b.Z;
    return result;
}


SDK::FVector MultiplyVectors(SDK::FVector a, SDK::FVector b) {
    SDK::FVector result;
    result.X = a.X * b.X;
    result.Y = a.Y * b.Y;
    result.Z = a.Z * b.Z;
    return result;
}


SDK::FVector DivideVectors(SDK::FVector a, SDK::FVector b) {
    SDK::FVector result;
    result.X = a.X / b.X;
    result.Y = a.Y / b.Y;
    result.Z = a.Z / b.Z;
    return result;
}


SDK::FVector MultiplyVectorFloat(SDK::FVector a, float scalar) {
    SDK::FVector result;
    result.X = a.X * scalar;
    result.Y = a.Y * scalar;
    result.Z = a.Z * scalar;
    return result;
}

FVector Minus_VectorVector(const FVector& A, const FVector& B)
{
    return FVector{A.X - B.X, A.Y - B.Y, A.Z - B.Z};
}


FVector Add_VectorVector(const FVector& A, const FVector& B)
{
    return FVector{A.X + B.X, A.Y + B.Y, A.Z + B.Z};
}

FVector Multiply_VectorFloat(const FVector& A, float Scalar)
{
    return FVector{A.X * Scalar, A.Y * Scalar, A.Z * Scalar};
}

FVector CalculateWeaponMuzzlePosition(const FVector& weaponLocation, const FRotator& weaponRotation, float weaponBodyLength) {

    float radPitch = weaponRotation.Pitch * (3.14159265358979323846 / 180.0f);
    float radYaw = weaponRotation.Yaw * (3.14159265358979323846 / 180.0f);


    float forwardX = std::cos(radPitch) * std::cos(radYaw);
    float forwardY = std::cos(radPitch) * std::sin(radYaw);
    float forwardZ = std::sin(radPitch);


    FVector muzzlePosition = {
        weaponLocation.X + forwardX * weaponBodyLength,
        weaponLocation.Y + forwardY * weaponBodyLength,
        weaponLocation.Z + forwardZ * weaponBodyLength
    };

    return muzzlePosition;
}


FRotator ClampAngles(FRotator inRot) {
    FRotator outRot = inRot;
    if (outRot.Pitch > 180)
        outRot.Pitch -= 360;
    if (outRot.Pitch < -180)
        outRot.Pitch += 360;

    if (outRot.Pitch < -75.f)
        outRot.Pitch = -75.f;
    else if (outRot.Pitch > 75.f)
        outRot.Pitch = 75.f;

    while (outRot.Yaw < -180.0f)
        outRot.Yaw += 360.0f;
    while (outRot.Yaw > 180.0f)
        outRot.Yaw -= 360.0f;
    return outRot;
}

void VectorAnglesRadar(Vector3 &forward, FVector &angles) {
    if (forward.X == 0.f && forward.Y == 0.f) {
        angles.X = forward.Z > 0.f ? -360.f : 360.f;
        angles.Y = 0.f;
    } else {
        angles.X = RAD2DEG(atan2(-forward.Z, forward.Magnitude(forward)));
        angles.Y = RAD2DEG(atan2(forward.Y, forward.X));
    }
    angles.Z = 360.f;
}


FRotator ToRotator(FVector local, FVector target) {
    FVector rotation = Minus_VectorVector(local, target);
    float hyp = sqrt(rotation.X * rotation.X + rotation.Y * rotation.Y);
    FRotator newViewAngle = {0};
    newViewAngle.Pitch = -atan(rotation.Z / hyp) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Yaw = atan(rotation.Y / rotation.X) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Roll = (float) 0.f;
    if (rotation.X >= 0.f)
        newViewAngle.Yaw += 180.0f;
    return newViewAngle;
}

FVector WorldToRadar(float Yaw, FVector Origin, FVector LocalOrigin, float PosX, float PosY, Vector3 Size, bool & outbuff) {
bool flag = false;
double num = (double)Yaw;
double num2 = num * 0.017453292519943295;
float num3 = (float)std::cos(num2);
float num4 = (float)std::sin(num2);
float num5 = Origin.X - LocalOrigin.X;
float num6 = Origin.Y - LocalOrigin.Y;
struct FVector Xector;
Xector.X = (num6 * num3 - num5 * num4) / 150.f;
Xector.Y = (num5 * num3 + num6 * num4) / 150.f;
struct FVector Xector2;
Xector2.X = Xector.X + PosX + Size.X / 2.f;
Xector2.Y = -Xector.Y + PosY + Size.Y / 2.f;
bool flag2 = Xector2.X > PosX + Size.X;
if (flag2) {
Xector2.X = PosX + Size.X;
} else {
bool flag3 = Xector2.X < PosX;
if (flag3) {
Xector2.X = PosX;
}
}
bool flag4 = Xector2.Y > PosY + Size.Y;
if (flag4) {
Xector2.Y = PosY + Size.Y;
} else {
bool flag5 = Xector2.Y < PosY;
if (flag5) {
Xector2.Y = PosY;
}
}
bool flag6 = Xector2.Y == PosY || Xector2.X == PosX;
if (flag6) {
flag = true;
}
outbuff = flag;
return Xector2;
}



void DrawHalfFilledTriangle(UCanvas* Canvas, std::array<FVector, 4>& points, 
                            FLinearColor Color, float thickness)
{
    if (!Canvas) return;

    // 🔹 Outline - unchanged
    DrawLine(Canvas, FVector2D(points[0].X, points[0].Y), FVector2D(points[1].X, points[1].Y), thickness, Color);
    DrawLine(Canvas, FVector2D(points[1].X, points[1].Y), FVector2D(points[2].X, points[2].Y), thickness, Color);
    DrawLine(Canvas, FVector2D(points[2].X, points[2].Y), FVector2D(points[3].X, points[3].Y), thickness, Color);
    DrawLine(Canvas, FVector2D(points[3].X, points[3].Y), FVector2D(points[0].X, points[0].Y), thickness, Color);

    // 🔹 Half fill: Back Tip से Front Tip तक, left side
    FVector2D backTip(points[2].X, points[2].Y);  // Back Tip
    FVector2D frontTip(points[0].X, points[0].Y); // Front Tip

    int steps = 10; // जितनी lines से fill करेंगे
    for (int i = 0; i <= steps; i++) {
        float t = i / (float)steps * 0.5f; // 50% fill
        FVector2D start(
            backTip.X + (points[1].X - backTip.X) * t,
            backTip.Y + (points[1].Y - backTip.Y) * t
        );
        FVector2D end(
            backTip.X + (frontTip.X - backTip.X) * t,
            backTip.Y + (frontTip.Y - backTip.Y) * t
        );
        DrawLine(Canvas, start, end, 1.0f, Color);
    }
}

// ----------------------------
// RotateTriangle Function (unchanged)
void RotateTriangle(std::array<FVector, 4>& points, float angle)
{
    float rad = DEG2RAD(angle);
    float cosA = cosf(rad);
    float sinA = sinf(rad);

    FVector center =
        (points[0] + points[1] + points[2] + points[3]) / 4.f;

    for (auto& p : points)
    {
        float x = p.X - center.X;
        float y = p.Y - center.Y;

        p.X = x * cosA - y * sinA + center.X;
        p.Y = x * sinA + y * cosA + center.Y;
    }
}


bool isInsideFOVs(int x, int y) {
    auto glWidth = screenWidth;
    auto glHeight = screenHeight;
    if (!Cheat::Aimbot::Radius)
        return true;

    int circle_x = glWidth / 2;
    int circle_y = glHeight / 2;
    int rad = Cheat::Aimbot::Radius * 0.5f;
    return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}

auto GetTargetForAimBot() {
    ASTExtraPlayerCharacter *result = nullptr;
    float max = std::numeric_limits<float>::infinity();
    auto Actors = GetActors();
    auto localPlayer = Cheat::localPlayer;
    auto localController = Cheat::localController;
    
    auto glWidth = screenWidth;
    auto glHeight = screenHeight;

    if (localPlayer) {
        for (int i = 0; i < Actors.size(); i++) {
            auto Actor = Actors[i];
            if (isObjectInvalid(Actor))
                continue;

            if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                auto Player = (ASTExtraPlayerCharacter *)Actor;
                auto Target = (ASTExtraPlayerCharacter *)Actor;

                float dist = localPlayer->GetDistanceTo(Target) / 100.0f;
                if (dist > 500.0f)
                    continue;

                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;
                if (Player->TeamID == localPlayer->TeamID)
                    continue;
                if (Player->bDead)
                    continue;

                if (Cheat::Aimbot::IgnoreKnock) {
                    if (Player->Health == 0.0f)
                        continue;
                }

                if (Cheat::Aimbot::VisCheck) {
                    if (!localController->LineOfSightTo(Player, {0, 0, 0}, true))
                        continue;
                }
                if (Cheat::Aimbot::IgnoreBot) {
                    if (Player->bIsAI)
                        continue;
                }

                auto Root = Player->GetBonePos("Root", {});
                auto Head = Player->GetBonePos("Head", {});
                FVector2D RootSc, HeadSc;
                if (W2S(Root, &RootSc) && W2S(Head, &HeadSc)) {
                    float height = abs(HeadSc.Y - RootSc.Y);
                    float width = height * 0.20f;

                    FVector middlePoint = {HeadSc.X + (width / 2), HeadSc.Y + (height / 2), 0};
                    if ((middlePoint.X >= 0 && middlePoint.X <= glWidth) &&
                            (middlePoint.Y >= 0 && middlePoint.Y <= glHeight)) {
                        FVector2D v2Middle = FVector2D((float)(glWidth / 2), (float)(glHeight / 2));
                        FVector2D v2Loc = FVector2D(middlePoint.X, middlePoint.Y);

                        if (isInsideFOVs((int)middlePoint.X, (int)middlePoint.Y)) {
                            float dist = FVector2D::Distance(v2Middle, v2Loc);

                            if (dist < max) {
                                max = dist;
                                result = Player;
                            }
                        }
                    }
                }
            }
        }
    }

    return result;
}

bool isInsideFOV(int x, int y) {
    int circle_x = screenWidth / 2;
    int circle_y = screenHeight / 2;
    int rad = (int) FOVsizea;
    return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}

auto GetTargetByCross() {
    ASTExtraPlayerCharacter *result = 0;
    float max = std::numeric_limits<float>::infinity();
    auto Actors = GetActors();

    auto localPlayer = Cheat::localPlayer;
    auto localController = Cheat::localController;
    
    auto glWidth = screenWidth;
    auto glHeight = screenHeight;
    
    FVector PlayerPos = {};

    if (localPlayer) {
        for (int i = 0; i < Actors.size(); i++) {
            auto Actor = Actors[i];
            if (isObjectInvalid(Actor))
                continue;

            if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {

                auto Player = (ASTExtraPlayerCharacter *) Actor;
                float distx = localPlayer->GetDistanceTo(Player) / 100.0f;

                if (distx > Cheat::BulletTrack::BulletRange)
                    continue;

                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;

                if (Player->TeamID == localPlayer->TeamID)
                    continue;

                if (Player->bDead)
                    continue;

                if (Player->bHidden)
                    continue;

                if (Cheat::BulletTrack::IgnoreKnock) {
                    if (Player->Health == 0.0f)
                        continue;
                }

                if (Cheat::BulletTrack::VisCheck) {

                    auto CurrentWeaponReplicated = (ASTExtraShootWeapon*)Cheat::localPlayer->WeaponManagerComponent->CurrentWeaponReplicated;

                    if (CurrentWeaponReplicated) {
                        FVector weaponlocation = CurrentWeaponReplicated->K2_GetActorLocation();
                        FRotator weaponRotation = CurrentWeaponReplicated->K2_GetActorRotation();
                        float weaponBodyLength = CurrentWeaponReplicated->GetWeaponBodyLength();
                        FVector muzzlePosition = CalculateWeaponMuzzlePosition(weaponlocation, weaponRotation, weaponBodyLength / 1.5);
                        if (!localController->LineOfSightTo(Player, muzzlePosition, true))
                            continue;
                    }
                }
                if (Cheat::BulletTrack::IgnoreBot) {
                    if (Player->bEnsure)
                        continue;
                }
                auto Root = Player->GetBonePos("Root", {});
                auto Head = Player->GetBonePos("Head", {});
                FVector2D RootSc, HeadSc;
                if (W2S(Root, &RootSc) && W2S(Head, &HeadSc)) {
                    float height = abs(HeadSc.Y - RootSc.Y);
                    float width = height * 0.20f;

                    FVector middlePoint = {HeadSc.X + (width / 2), HeadSc.Y + (height / 2), 0};
                    if ((middlePoint.X >= 0 && middlePoint.X <= glWidth) &&
                            (middlePoint.Y >= 0 && middlePoint.Y <= glHeight)) {
                        FVector2D v2Middle = FVector2D((float)(glWidth / 2), (float)(glHeight / 2));
                        FVector2D v2Loc = FVector2D(middlePoint.X, middlePoint.Y);


                        float dist = FVector2D::Distance(v2Middle, v2Loc);

                        if (dist < max) {
                            max = dist;
                            result = Player;
                        }
                    }
                }
            }
        }
    }
    return result;
}


