#pragma once
#ifndef IM_ARRAYSIZE
#define IM_ARRAYSIZE(arr) ((int)(sizeof(arr)/sizeof(*(arr))))
#endif
#include <unordered_set>

// ── Skin system variables ──
uintptr_t AvatarComponent = 0xb98;
uintptr_t AvatarSyncData  = 0x3E8;

int  SkinCarDefault = 0;
int  SkinCarMod     = 0;
bool SkinCarNew     = false;

static std::unordered_set<uintptr_t> ChangedDeadBoxes;
