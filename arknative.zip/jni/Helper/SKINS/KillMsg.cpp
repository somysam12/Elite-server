#pragma once
// g_KillOutfitId — set by KC_SyncModSkinsIDFromPrefs() from KC_UserPrefs.h
// Declared here (in GunSkin.cpp scope) so KillMsg.cpp can use it
static int g_KillOutfitId = 0;

void (*orig_kill_message_event)(ASTExtraPlayerController* thiz, struct FFatalDamageParameter* FatalDamageParameter);
void kill_message_event(ASTExtraPlayerController* thiz, struct FFatalDamageParameter* FatalDamageParameter) {
    if (GunSkin) {
        if (thiz->PlayerKey == FatalDamageParameter->CauserKey && !thiz->STExtraBaseCharacter->CurrentVehicle) {
            // XSuit kill message — only if selected outfit is XSuit (>= 1405000)
            if (g_KillOutfitId >= 1405000) {
                FatalDamageParameter->CauserClothAvatarID = g_KillOutfitId;
            }
            // Weapon kill message — use ModSkinsID (updated by KC_SyncModSkinsIDFromPrefs)
            if (Cheat::localPlayer && Cheat::localPlayer->WeaponManagerComponent &&
                Cheat::localPlayer->WeaponManagerComponent->CurrentWeaponReplicated) {
                int WeaponID = Cheat::localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponID();
                auto it = ModSkinsID.find(WeaponID);
                if (it != ModSkinsID.end())
                    FatalDamageParameter->CauserWeaponAvatarID = it->second;
            }
        }
    }
    orig_kill_message_event(thiz, FatalDamageParameter);
}
