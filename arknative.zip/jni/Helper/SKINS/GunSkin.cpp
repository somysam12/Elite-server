#pragma once
#include "Includes/SkinDB.h"
#include <unordered_map>
#include <string>
struct OutfitData {
    const char* name;
    int itemId;
};

OutfitData g_Outfits[] = {
    {"Chaosphage Set",               1407906}, // index 0 — DEFAULT
    {"Phoenixtra X-Suit (7-Star)",   1407856},
    {"Blood Raven X-Suit",           1407895},
    {"Fiore X-Suit",                 1407103},
    {"Marmoris X-Suit (7-Star)",     1406971},
    {"Dark Raven X-Suit",            1405870},
    {"Avalanche X-Suit",             1406152},
    {"Poseidon X-Suit",              1407140},
    {"Silvanus X-Suit",              1407142},
    {"Ignis X-Suit",                 1407219},
    {"Galadria X-Suit",              1407366},
    {"Golden Pharaoh X-Suit",        1405628},
    {"Chennai Star Knights",         1407538},
    {"Witherbloom Prodigy green Set",1407811},
    {"Witherbloom Prodigy blue Set", 1407841},
    {"The Hermit's Chrysalis Set",   1407682},
    {"Wildsoul Warden Set",          1407812},
    {"Crimson Ephialtes Set",        1406897},
    {"Luminous Muse Set",            1407225},
    {"Foxy Flare Set",               1407106},
    {"The Lover's Grace Set",        1407276},
    {"Vampyra Countess Set",         1407391},
    {"Mercury Soldier Set",          1407285},
    {"Devious Cybercat Set",         1407286},
    {"Inferno Fiend Set",            1410668},
    {"Serpengleam Set",              1407161},
    {"Sandsylph Scion Set",          1407522},
    {"Jadefang Aurora Set",          1407471},
    {"Winter Highness Set",          1407107},
    {"The Sun's Ascendance Set",     1407558},
    {"Snowstar Sweetheart Set",      1407441},
    {"Moonlit Fantasy Set",          1406118},
    {"Chromatic Brilliance Set",     1406119},
    {"Red Commander Set",            1405593},
    {"Charged Armor Set",            1405481},
    {"Dazzling Youth Set",           1405583},
    {"Arctic Witch Set",             1405384},
    {"Wedding Dress",                1405174},
    {"Legacy Set",                   1405073},
    {"Chill Flow Set",               1407468},
    {"Bunny Girl Set",               1405487},
    {"Bonds of Ruby Set",            1406060},
    {"Dream Idol Set",               1405802},
};

struct PlayerOutfit {
    std::atomic<int> currentOutfit;
};

PlayerOutfit g_PlayerOutfit;

bool ReplaceItemId(int& itemId, const std::unordered_map<std::string, std::string>& mapTable) {
    auto it = mapTable.find(std::to_string(itemId));
    if (it != mapTable.end()) {
        itemId = std::stoi(it->second);
        return true;
    }
    return false;
}
//==============================================================================/
//==============================================================================/
std::unordered_map<int, int> Parachute = {
    {703001, 1401842},  // Dioscuri Parachute (lobby display)
    {703002, 1401842},  // alternate slot
};
//==============================================================================/
// Glider skin — shown during jump, same slot as parachute (703001 range)
// Starlight Galaxy Glider: 4151143
// Applied as separate entry alongside parachute
std::unordered_map<int, int> GliderSkin = {
    // ── Starlight Galaxy Glider (verified BPID 4151143) ──────────────────
    {4151000, 4151143},   // default glider base → Starlight Galaxy
    {4151140, 4151143},   // Starlight Galaxy (alt variant)
};
//==============================================================================/
// Grenade + Molotov skins — Crimson Skyblade series
// Base IDs VERIFIED from BGMI item dump:
//   612004000 = "Frag Grenade"     (base skin slot in SlotSyncData)
//   615004000 = "Molotov Cocktail" (base skin slot in SlotSyncData)
std::unordered_map<int, int> ThrowableSkin = {
    // ── Frag Grenade → Crimson Skyblade Grenade ───────────────────────────
    {612004000, 612004224},   // base → Crimson Skyblade Grenade (dump verified)
    // ── Molotov Cocktail → Crimson Skyblade Molotov ───────────────────────
    {615004000, 615004105},   // base → Crimson Skyblade Molotov (dump verified)
};
//==============================================================================/
std::unordered_map<int, int> Bagpack = {
    // ── Standard Backpack Tiers (Lv1/2/3) → Dioscuri ────────────────────
    {501001, 1501001724}, {501002, 1501002724}, {501003, 1501003724},
    {501004, 1501001724}, {501005, 1501002724}, {501006, 1501003724},
    {501007, 1501001724}, {501008, 1501002724}, {501009, 1501003724},
    {501010, 1501001724}, {501011, 1501002724}, {501012, 1501003724},
    {501015, 1501001724}, {501017, 1501002724},
    // ── Special backpack variants ─────────────────────────────────────────
    {501101, 1501001724}, {501102, 1501002724}, {501103, 1501003724},
    {501104, 1501001724}, {501105, 1501002724}, {501106, 1501003724},
    {501201, 1501003724},
    // ── Skin-base IDs (from existing skin maps) ───────────────────────────
    {1501001482, 1501001724}, {1501002482, 1501002724}, {1501003482, 1501003724},
    {1501001013, 1501001724}, {1501002013, 1501002724}, {1501003013, 1501003724},
    {1501002015, 1501002724}, {1501002025, 1501002724}, {1501003025, 1501003724},
    // ── Dioscuri self-map (prevent re-applying different level) ───────────
    {1501001677, 1501001724}, {1501002677, 1501002724}, {1501003677, 1501003724},
};
//==============================================================================/
std::unordered_map<int, int> Helmet = {
    // ── Lv1 base helmets → Dioscuri Lv1 (502001, 502004, 502114, 502101) ──
    {502001, 1502001497}, {502004, 1502001497}, {502114, 1502001497},
    {502101, 1502001497},
    // ── Lv2 base helmets → Dioscuri Lv2 ──────────────────────────────────
    {502002, 1502002497}, {502005, 1502002497}, {502115, 1502002497},
    {502102, 1502002497},
    // ── Lv3 base helmets → Dioscuri Lv3 ──────────────────────────────────
    {502003, 1502003497}, {502116, 1502003497}, {502103, 1502003497},
    // ── EvoGround Lv4/5/6 helmets → Dioscuri Lv3 (best available) ────────
    {502104, 1502003497}, {502105, 1502003497}, {502106, 1502003497},
    {502107, 1502003497}, {502108, 1502003497}, {502109, 1502003497},
    {502110, 1502003497}, {502111, 1502003497}, {502112, 1502003497},
    // ── Dioscuri self-map (if another Dioscuri level was applied, keep Lv3) ─
    {1502000497, 1502003497},  // base level → Lv3
    {1502001497, 1502003497},  // Lv1 → Lv3
    {1502002497, 1502003497},  // Lv2 → Lv3
    // ── Common other helmet skins → Dioscuri Lv3 (catches pre-existing skins) ─
    {1502003014, 1502003497},  // previous default used in many sources → Dioscuri
    {1502003025, 1502003497},
    {1502003015, 1502003497},
};
//==============================================================================/
std::unordered_map<int, int> FaceSkin = {
	{401985, 1400563}, // 
	{401990, 1400563}, // 
    {401991, 1400563}, // 
    {401992, 1400563}, // 
    {401993, 1400563}, // Face A
    {401994, 1400563}, // Face G
    {401995, 1400563}, // Face F
    {401996, 1400563}, // Face E
    {401997, 1400563}, // Face D
    {401998, 1400563}, // Face C
    {401999, 1400563}  // Face B
};
//==============================================================================/
std::unordered_map<int, int> HairSkin = {
    {40601001, 40605011}, // Hair A
    {40604002, 40605011}, // Hair B
    {40604003, 40605011}, // Hair C
    {40604004, 40605011}, // Hair D
    {40604005, 40605011}, // Hair E
    {40604006, 40605011}, // Hair F
    {40604007, 40605011}, // Hair G
    {40604008, 40605011}, // Hair H
    {40604009, 40605011}  // Hair I
};


std::unordered_map<int, int> VehicleSkinMap = {
    // ── Coupe RB (1961xxx) ─────────────────────────────────────────────
    {1961001, 1961021},  // Lamborghini Centenario Galassia
    // ── Buggy (1907xxx) ────────────────────────────────────────────────
    {1907001, 1907063},  // Goldensands Apex Buggy (Lv.4)
    {1907002, 1907063},
    {1907003, 1907063},
    {1907004, 1907063},
    // ── Mirado Open Top (1915xxx) ──────────────────────────────────────
    {1915001, 1915099},  // Golden Mirado (Open Top)
    {1915002, 1915099},
    {1915003, 1915099},
    {1915004, 1915099},
    {1915005, 1915099},
    // ── Dacia (1903xxx) ────────────────────────────────────────────────
    {1903001, 1903121},  // Dacia (Pagani Imola Arctic Aegis)
    {1903002, 1903121},
    {1903003, 1903121},
    {1903004, 1903121},
    // ── Pickup (1906xxx) ───────────────────────────────────────────────
    {1906001, 1906005},  // Wolves Pickup
    {1906002, 1906005},
    // ── UAZ (1908xxx) ──────────────────────────────────────────────────
    {1908001, 1908070},  // Robust Universe UAZ
    {1908002, 1908070},
    // ── Mini Bus (1904xxx) ─────────────────────────────────────────────
    {1904001, 1904013},  // Midnight Rose Mini Bus
    {1904002, 1904013},
    // ── Motorcycle 2-Seat (1901xxx) ────────────────────────────────────
    {1901001, 1901079},  // Romantic 2-Seat Motorcycle
    {1901002, 1901079},
    {1532907, 1901079},
    // ── Sidecar Motorcycle (1902xxx) ───────────────────────────────────
    {1902001, 1902067},  // Violet Eclipse Sidecar
    {1902002, 1902067},
    // ── Scooter (1917xxx) ──────────────────────────────────────────────
    {1917001, 1917006},  // Phantasma Bloom Scooter
    // ── Horse (1987xxx) ────────────────────────────────────────────────
    {1987001, 1987002},  // Violet Flame Horse
    // ── Armored Mirado (1914xxx) ───────────────────────────────────────
    {1914001, 1914011},  // Armored Hunter Mirado
    {1914002, 1914011},
    // ── Snowbike (1918xxx) ─────────────────────────────────────────────
    {1918001, 1918012},  // Polar Roamer Snowbike
    // ── Tuk Tuk (1919xxx) ──────────────────────────────────────────────
    {1919001, 1919011},  // 8-bit Unicorn Tukshai
    // ── Quad (1930xxx) ─────────────────────────────────────────────────
    {1930001, 1930003},  // Quad
    {1930002, 1930003},
    // ── Bicycle (1965/1967xxx) ─────────────────────────────────────────
    {1965001, 1965002},  // Tech Matrix Bicycle
    {1967001, 1967004},  // Royale Delight Bicycle
    // ── Monster Truck (1953xxx) ────────────────────────────────────────
    {1953001, 1953009},  // Monster Truck
    {1953002, 1953009},
    // ── Speedboat (1911xxx) ────────────────────────────────────────────
    {1911001, 1911015},  // Frigid Sea Speedboat
    {1911002, 1911015},
    // ── Jet Ski (1912xxx) ──────────────────────────────────────────────
    {1912001, 1912012},  // General Beetle Jet Ski
    // ── Tesla (1916xxx) ────────────────────────────────────────────────
    {1916001, 1916006},  // Tesla Cybertruck
    {1916002, 1916006},
    // ── T.Rex (1972xxx) ────────────────────────────────────────────────
    {1972001, 1972001},  // T.Rex
    // ── Polaris RZR (1966xxx) ──────────────────────────────────────────
    {1966001, 1966017},  // Polaris RZR Pro R 4
    {1966002, 1966017},
};



std::unordered_map<int, int> ModSkinsID = {
    {101001, 1101001276}, // AKM - Pulsing Light (Lv.8) — matches AKMSkinsID body
    {101002, 1101002029}, // M16A4 - Blood & Bones
    {101003, 1101003227}, // SCAR-L - Phoenix Rising (Lv.8) — matches SCARLSkinsID body
    {101004, 1101004246}, // M416 - Crimson Skyblade
    {101005, 1101005038}, // Groza - Ryomen Sukuna
    {101006, 1101006085}, // AUG - Nyxen Rose
    {101007, 1101007046}, // QBZ - Nether Phantom
    {101008, 1101008126}, // M762 - Noctum Sunder
    {101101, 1101101007}, // ASM Abakan - Bloodwing Raven
    {101012, 1101012033}, // HoneyBadger - Sacred Witherbloom
    {101100, 1101100012}, // FAMAS - Origin Lumen
    {101102, 1101102025}, // ACE32 - Mystic Kraken
    {102001, 1102001120}, // UZI - Glacier Hammer
    {102002, 1102002446}, // Crimson Twin - UMP45 (Lv.8)
    {102005, 1102005064}, // Bizon - Spectral Byte
    {102003, 1102003080}, // Vector - Mecha Drake
    {103001, 1103001146}, // KAR98K - Titanium Shark
    {103002, 1103002030}, // M24 - Pharaoh's Might
    {103003, 1103003042}, // AWM - Godzilla
    {103004, 1103004037}, // SKS - Lady Carmine
    {103006, 1103006030}, // Mini14 - Icicle
    {103007, 1103007028}, // MK14 - Drakreign
    {103012, 1103012010}, // AMR - Crimson Ephialtes
    {103102, 1103102007}, // DSR - Hyperion Ship
    {105002, 1105002091}, // DP28 - Bloodbane Parasite
    {105010, 1105010019}, // MG3 - Sky Huntress
    {105001, 1105001034}, // M249 - Party Parcel
    {102007, 1102007022}, // MP5K - Retro Pixel (Lv.3)
    {104001, 1104001035}, // S686 - Lethal Venom (Lv.5)
    {104002, 1104002022}, // S1897 - Twilight Hunt (Lv.5)
    {104003, 1104003026}, // S12K - GACKT (Lv.7)
    {104004, 1104004035}, // DBS - Cosmic Beast (Lv.5)
    {104102, 1104102004}, // NS2000 - Rustborn Strider (Lv.3)
    {102105, 1102105012}, // P90 - Devious Cybercat (Lv.7)
};

// ════════════════════════════════════════════════════════════════
// GUN SKIN MAPS — key=SlotTypeSpecificID, value=SkinID
// ════════════════════════════════════════════════════════════════
// M416 — Glacier - M416 (Lv.7) (21 entries)
// M416 — Crimson Skyblade
std::unordered_map<int, int> M416SkinsID = {
    {101004, 1101004246}, // [BODY] Crimson Skyblade
    {203015, 1010042394}, {203004, 1010042395}, {203014, 1010042396},
    {203003, 1010042397}, {203002, 1010042398}, {203001, 1010042399},
    {204011, 1010042400}, {204012, 1010042404}, {204013, 1010042405},
    {201010, 1010042406}, {201009, 1010042407}, {201011, 1010042408},
    {202001, 1010042409}, {202006, 1010042410}, {202002, 1010042414},
    {205002, 1010042415}, {202004, 1010042416}, {202005, 1010042417},
    {203016, 1010042418}, {203100, 1010042419}, {205003, 1010042420},
};

// AKM — Decisive Day - AKM (Lv.8) (19 entries)
// AKM — Sandspring Dominion
std::unordered_map<int, int> AKMSkinsID = {
    {101001, 1101001276}, // [BODY] Pulsing Light (Lv.8)
    {203015, 1010012692}, // 6x Scope
    {203004, 1010012693}, // 4x Scope
    {203014, 1010012694}, // 3x Scope
    {203003, 1010012695}, // 2x Scope
    {203002, 1010012696}, // Holographic Sight
    {203001, 1010012697}, // Red Dot Sight
    {201010, 1010012698}, // Flash Hider
    {201009, 1010012699}, // Compensator
    {201011, 1010012700}, // Suppressor
    {204011, 1010012702}, // Extended Mag
    {204012, 1010012703}, // Quickdraw Mag
    {204013, 1010012704}, // Extended Quickdraw Mag
    {203100, 1010012705}, // Canted Sight
};

// M16A4 — Dracoguard - M16A4 (Lv.5) (15 entries)
// M16A4 — Blood & Bones
std::unordered_map<int, int> M16A4SkinsID = {
    {101002, 1101002029}, // [BODY] Blood & Bones
    {203015, 1010020235}, {203004, 1010020236}, {203014, 1010020237},
    {203003, 1010020238}, {203002, 1010020239}, {203001, 1010020240},
    {204011, 1010020246}, {204012, 1010020247}, {204013, 1010020248},
    {201010, 1010020249}, {201009, 1010020250}, {201011, 1010020255},
    {203100, 1010020256}, {205002, 1010020257}, {205003, 1010020258},
};

// SCARL — Operation Tomorrow - SCAR-L (Lv.7) (20 entries)
// SCAR-L — Bloodstained Nemesis
std::unordered_map<int, int> SCARLSkinsID = {
    {101003, 1101003227}, // [BODY] Phoenix Rising (Lv.8)
    {203015, 1010032202}, // 6x Scope
    {203004, 1010032203}, // 4x Scope
    {203014, 1010032204}, // 3x Scope
    {203003, 1010032205}, // 2x Scope
    {203002, 1010032206}, // Holographic Sight
    {203001, 1010032207}, // Red Dot Sight
    {204011, 1010032208}, // Extended Mag
    {204012, 1010032209}, // Quickdraw Mag
    {204013, 1010032210}, // Extended Quickdraw Mag
    {201009, 1010032242}, // Compensator
    {201010, 1010032243}, // Flash Hider
    {201011, 1010032244}, // Suppressor
    {202001, 1010032245}, // Angled Foregrip
    {202006, 1010032246}, // Thumb Grip
    {202002, 1010032247}, // Vertical Foregrip
    {203016, 1010032248}, // Laser Sight
    {202004, 1010032249}, // Light Grip
    {202005, 1010032250}, // Half Grip
    {203100, 1010032252}, // Canted Sight
};

// M762 — Concerto of Love - M762 (Lv.7) (19 entries)
// M762 — Noctum Sunder
std::unordered_map<int, int> M762SkinsID = {
    {101008, 1101008126}, // [BODY] Noctum Sunder
    {203004, 1010081202}, {203014, 1010081203}, {203003, 1010081204},
    {203002, 1010081205}, {203001, 1010081206}, {204011, 1010081207},
    {204012, 1010081208}, {204013, 1010081209}, {201010, 1010081210},
    {201009, 1010081213}, {202006, 1010081214}, {201011, 1010081215},
    {202001, 1010081216}, {202002, 1010081217}, {203015, 1010081218},
    {202004, 1010081219}, {202005, 1010081220}, {203016, 1010081222},
    {203100, 1010081223}, {205002, 1010081228}, {205003, 1010081229},
};

// AUG — Abyssal Howl - AUG (Lv.8) (18 entries)
// AUG — Nyxen Rose
// AUG — Nine-Tails Fury - AUG (Lv. 8) + Exclusive Attachments
std::unordered_map<int, int> AUGSkinsID = {
    {101006, 1101006098}, // [BODY] Nine-Tails Fury - AUG (Lv. 8)
    {203015, 1010061033}, {203004, 1010061034}, {203014, 1010061035},
    {203003, 1010061036}, {203002, 1010061037}, {203001, 1010061038},
    {204011, 1010061039}, {204012, 1010061040}, {204013, 1010061043},
    {201009, 1010061044}, {201010, 1010061045}, {201011, 1010061046},
    {202001, 1010061047}, {202006, 1010061048}, {202002, 1010061049},
    {203016, 1010061050}, {202004, 1010061053}, {202005, 1010061054},
    {203100, 1010061055},
};

// GROZA — River Styx - Groza (Lv.7) (12 entries)
// Groza — Ryomen Sukuna
std::unordered_map<int, int> GROZASkinsID = {
    {101005, 1101005038}, // [BODY] Ryomen Sukuna
    {203004, 1010050322}, {203014, 1010050323}, {203003, 1010050324},
    {203002, 1010050325}, {203001, 1010050326}, {201011, 1010050327},
    {204011, 1010050328}, {204012, 1010050329}, {204013, 1010050330},
    {203015, 1010050334},
};

// QBZ — Fatal Foil - QBZ (Lv.7) (19 entries)
// QBZ — Nether Phantom
std::unordered_map<int, int> QBZSkinsID = {
    {101007, 1101007046}, // [BODY] Nether Phantom
    {203004, 1010070402}, {203014, 1010070403}, {203003, 1010070404},
    {203002, 1010070405}, {203001, 1010070406}, {204011, 1010070407},
    {204012, 1010070408}, {204013, 1010070409}, {201010, 1010070410},
    {201009, 1010070413}, {201011, 1010070414}, {202001, 1010070415},
    {202006, 1010070416}, {202002, 1010070417}, {203015, 1010070418},
    {203016, 1010070419}, {202004, 1010070420}, {202005, 1010070422},
    {203100, 1010070423},
};

// ACE32 — Mystic Kraken - ACE32 (Lv.8) (20 entries)
// ACE32 — Mystic Kraken
std::unordered_map<int, int> ACE32SkinsID = {
    {101102, 1101102025}, // [BODY] Mystic Kraken
    {203015, 1011020114}, {203004, 1011020115}, {203014, 1011020116},
    {203003, 1011020117}, {203002, 1011020118}, {203001, 1011020119},
    {204011, 1011020124}, {204012, 1011020125}, {204013, 1011020126},
    {201010, 1011020127}, {201009, 1011020128}, {201011, 1011020129},
    {202001, 1011020134}, {202006, 1011020135}, {202002, 1011020136},
    {205002, 1011020137}, {202004, 1011020138}, {202005, 1011020139},
    {203016, 1011020144}, {203100, 1011020145},
};

// FAMAS — Origin Lumen - FAMAS (Lv.7) (11 entries)
// FAMAS — Origin Lumen
std::unordered_map<int, int> FAMASSkinsID = {
    {101100, 1101100012}, // [BODY] Origin Lumen
    {203015, 1011000053}, {203004, 1011000054}, {203014, 1011000055},
    {203003, 1011000056}, {203002, 1011000057}, {203001, 1011000058},
    {201010, 1011000066}, {201009, 1011000067}, {201011, 1011000068},
    {203100, 1011000073},
};

// AWM — Field Commander - AWM (Lv.7) (16 entries)
// AWM — Godzilla
std::unordered_map<int, int> AWMSkinsID = {
    {103003, 1103003042}, // [BODY] Godzilla
    {203005, 1030030362}, {203015, 1030030363}, {203004, 1030030364},
    {204011, 1030030369}, {204012, 1030030372}, {204013, 1030030373},
    {201010, 1030030374}, {201009, 1030030375}, {201011, 1030030376},
    {203006, 1030030377},
};

// KAR98K — Billowing Mirage - Kar98K (Lv.7) (13 entries)
// KAR98K — Titanium Shark
std::unordered_map<int, int> KAR98KSkinsID = {
    {103001, 1103001146}, // [BODY] Titanium Shark
    {203005, 1030011341}, {203015, 1030011342}, {203004, 1030011343},
    {201010, 1030011344}, {201009, 1030011345}, {201011, 1030011346},
    {203006, 1030011347}, {203007, 1030011348},
};

// M24 — Anniversary Celebration - M24 (Lv.7) (16 entries)
// M24 — Pharaoh's Might
std::unordered_map<int, int> M24SkinsID = {
    {103002, 1103002030}, // [BODY] Pharaoh's Might
    {203005, 1030020242}, {203015, 1030020243}, {203004, 1030020244},
    {201010, 1030020245}, {201009, 1030020246}, {201011, 1030020247},
    {203006, 1030020248}, {204011, 1030020249}, {204012, 1030020252},
    {204013, 1030020253}, {203014, 1030020255}, {203003, 1030020256},
    {203002, 1030020257}, {203001, 1030020258},
};

// MK14 — Drakreign - Mk14 (Lv.8) (21 entries)
// MK14 — Drakreign
std::unordered_map<int, int> MK14SkinsID = {
    {103007, 1103007028}, // [BODY] Drakreign
    {203005, 1030070212}, {203015, 1030070213}, {203004, 1030070214},
    {203014, 1030070215}, {203003, 1030070216}, {203002, 1030070217},
    {203001, 1030070218}, {203100, 1030070219}, {204011, 1030070222},
    {204012, 1030070223}, {204013, 1030070224}, {204015, 1030070225},
    {204014, 1030070226}, {204016, 1030070227}, {201010, 1030070228},
    {201009, 1030070229}, {201011, 1030070232}, {201012, 1030070233},
    {201013, 1030070234}, {201014, 1030070235}, {203006, 1030070236},
};

// SKS — Season 15 - SKS (Lv.7) (17 entries)
// SKS — Lady Carmine
std::unordered_map<int, int> SKSSkinsID = {
    {103004, 1103004037}, // [BODY] Lady Carmine
    {203005, 1030040312}, {203015, 1030040313}, {203004, 1030040314},
    {201010, 1030040315}, {201009, 1030040316}, {201011, 1030040317},
    {204016, 1030040318}, {204015, 1030040319}, {204014, 1030040322},
    {204013, 1030040323}, {204011, 1030040324}, {204012, 1030040325},
    {202001, 1030040326}, {202002, 1030040327}, {202006, 1030040328},
    {203006, 1030040329},
};

// MINI14 — Cyber Tribe - Mini14 (Lv.7) (11 entries)
// Mini14 — Icicle
std::unordered_map<int, int> MINI14SkinsID = {
    {103006, 1103006030}, // [BODY] Icicle
    {203005, 1030060242}, {203015, 1030060243}, {203004, 1030060244},
    {201010, 1030060245}, {201009, 1030060246}, {201011, 1030060247},
    {204016, 1030060248}, {204015, 1030060249}, {204013, 1030060252},
    {204011, 1030060253},
};

// SLR — Lion Reign - SLR (11 entries)
// SLR — (no skin requested, keep default)
std::unordered_map<int, int> SLRSkinsID = {
    {103009, 1103009039},
};

// MK12 — Precise Predator - Mk12 (1 entries)
// MK12 — (no skin requested, keep default)
std::unordered_map<int, int> MK12SkinsID = {
    {103100, 1103100007},
};

// VSS — Candy Cane - VSS (Lv.5) (2 entries)
std::unordered_map<int, int> VSSSkinsID = {
    {103005, 1103005024}, // [BODY] Candy Cane - VSS (Lv.5)
    {291004, 1030050131}, // Mag
};

// AMR — Crimson Ephialtes - AMR (Lv.8) (9 entries)
// AMR — Crimson Ephialtes
std::unordered_map<int, int> AMRSkinsID = {
    {103012, 1103012010}, // [BODY] Crimson Ephialtes
    {203005, 1030120032}, {203015, 1030120033}, {203004, 1030120034},
    {203014, 1030120035}, {203003, 1030120036}, {203002, 1030120037},
    {203001, 1030120038},
};

// M249 — Malus Majesty - M249 (Lv.7) (11 entries)
// M249 — Party Parcel
std::unordered_map<int, int> M249SkinsID = {
    {105001, 1105001034}, // [BODY] Party Parcel
    {203004, 1050010282}, {203014, 1050010283}, {203003, 1050010284},
    {203002, 1050010285}, {203001, 1050010286}, {204011, 1050010287},
    {204013, 1050010289}, {205002, 1050010292},
};

// MG3 — Sky Huntress - MG3 (Lv.7) (8 entries)
// MG3 — Sky Huntress
std::unordered_map<int, int> MG3SkinsID = {
    {105010, 1105010019}, // [BODY] Sky Huntress
    {203015, 1050100138}, {203004, 1050100139}, {203014, 1050100141},
    {203003, 1050100142}, {203002, 1050100143}, {203001, 1050100144},
};

// DP28 — Street Art - DP-28 (Lv.5) (2 entries)
// DP28 — Bloodbane Parasite
std::unordered_map<int, int> DP28SkinsID = {
    {105002, 1105002091}, // [BODY] Bloodbane Parasite
    {203015, 1050020842}, {203004, 1050020843}, {203014, 1050020844},
    {203003, 1050020845}, {203002, 1050020846}, {203001, 1050020847},
    {206001, 1050020848},
};

// UZI — Spirit Sentry - UZI (max) (11 entries)
// UZI — Glacier Hammer
std::unordered_map<int, int> UZISkinsID = {
    {102001, 1102001120}, // [BODY] Glacier Hammer
    {203002, 1020011132}, {203001, 1020011133}, {204011, 1020011134},
    {204012, 1020011135}, {204013, 1020011136}, {201010, 1020011137},
    {201009, 1020011138}, {201011, 1020011139}, {205005, 1020011142},
};

// UMP45 — Crimson Twin - UMP45 (Lv.8)
std::unordered_map<int, int> UMP45SkinsID = {
    {102002, 1102002446}, // [BODY] Crimson Twin - UMP45 (Lv.8)
    {203015, 1020024392}, // 6x Scope
    {203004, 1020024393}, // 4x Scope
    {203014, 1020024394}, // 3x Scope
    {203003, 1020024395}, // 2x Scope
    {203002, 1020024396}, // Holographic Sight
    {203001, 1020024397}, // Red Dot Sight
    {204004, 1020024398}, // Extended Mag
    {204005, 1020024399}, // Quickdraw Mag
    {204006, 1020024400}, // Extended Quickdraw Mag
    {201002, 1020024402}, // Compensator
    {201004, 1020024403}, // Flash Hider
    {201006, 1020024404}, // Suppressor
    {202001, 1020024405}, // Angled Foregrip
    {202006, 1020024406}, // Thumb Grip
    {202002, 1020024407}, // Vertical Foregrip
    {202007, 1020024408}, // Laser Sight
    {202004, 1020024409}, // Light Grip
    {202005, 1020024410}, // Half Grip
    {203012, 1020024412}, // Canted Sight
};

// VECTORSKinsID — Mecha Drake - Vector (Lv.7) (18 entries)
// Vector — Mecha Drake
std::unordered_map<int, int> VECTORSKinsID = {
    {102003, 1102003080}, // [BODY] Mecha Drake
    {203004, 1020030744}, {203014, 1020030745}, {203003, 1020030746},
    {203002, 1020030747}, {203001, 1020030748}, {204011, 1020030749},
    {204013, 1020030754}, {201010, 1020030755}, {201009, 1020030756},
    {202005, 1020030757}, {201011, 1020030758}, {202004, 1020030759},
    {202002, 1020030760}, {203015, 1020030764}, {205002, 1020030765},
};

// THOMPSON — Smooth Hitman - Thompson SMG (2 entries)
std::unordered_map<int, int> THOMPSONSkinsID = {
    {102004, 1102004018}, // [BODY] Smooth Hitman - Thompson SMG
    {292004, 1020040111}, // Mag
};

// BIZON — Soldier Soul - PP-19 Bizon (Lv.5) (2 entries)
// Bizon — Spectral Byte
std::unordered_map<int, int> BIZONSkinsID = {
    {102005, 1102005064}, // [BODY] Spectral Byte
    {203015, 1020050582}, {203004, 1020050583}, {203014, 1020050584},
    {203003, 1020050585}, {203002, 1020050586}, {203001, 1020050587},
    {201010, 1020050588}, {201009, 1020050589}, {201011, 1020050590},
    {203100, 1020050592},
};

// P90 — Devious Cybercat - P90 (Lv.7) (2 entries)
std::unordered_map<int, int> P90SkinsID = {
    {102105, 1102105012}, // [BODY] Devious Cybercat - P90 (Lv.7)
    // NOTE: Devious Cybercat has NO themed attachment skins in game data
    // (1021050121 does not exist). Body-only — attachments stay default.
};

// S12K — GACKT - S12K (Lv.7) (7 entries)
std::unordered_map<int, int> S12KSkinsID = {
    {104003, 1104003026}, // [BODY] GACKT - S12K (Lv.7)
    {291004, 1040030261}, // Mag
    {203008, 1040030262}, // Sight
    {205005, 1040030263}, // Stock
    {201001, 1040030261}, // Choke (reuses mag code as choke slot)
    {204011, 1040030271}, // Extended Mag
    {203015, 1040030281}, // 6x Scope
};

// S1897 — Twilight Hunt - S1897 (Lv.5) (1 entries)
std::unordered_map<int, int> S1897SkinsID = {
    {104002, 1104002022}, // [BODY] Twilight Hunt - S1897 (Lv.5)
};

// DBS — Cosmic Beast - DBS (Lv.5) (1 entries)
std::unordered_map<int, int> DBSSkinsID = {
    {104004, 1104004035}, // [BODY] Cosmic Beast - DBS (Lv.5)
};

// HoneyBadger — Honey Badger (1 entries)
// HoneyBadger — Sacred Witherbloom
std::unordered_map<int, int> HoneyBadgerSkinsID = {
    {101012, 1101012033}, // [BODY] Sacred Witherbloom
    {203015, 1010120273}, {203004, 1010120274}, {203014, 1010120275},
    {203003, 1010120276}, {203002, 1010120277}, {203001, 1010120278},
    {204011, 1010120279}, {204012, 1010120280}, {204013, 1010120283},
    {201010, 1010120284}, {201009, 1010120285}, {201011, 1010120286},
    {203100, 1010120287},
};

// PAN — Accolade - Pan (Lv.6) — pre-applied default
std::unordered_map<int, int> PANSkinsID = {
    {108004, 1108004283}, // [BODY] Accolade - Pan (Lv.6)
};

// Machete — Kusanagi Blade (Lv.3) — pre-applied default
std::unordered_map<int, int> MacheteSkinsID = {
    {108001, 1108001107}, // [BODY] Kusanagi Blade (Lv.3)
};

// Dagger — Tundra Knight (Lv.3) (1 entries)
std::unordered_map<int, int> DaggerSkinsID = {
    {108005, 1108005050}, // [BODY] Tundra Knight - Dagger (Lv.3)
};

// Crowbar / Trident — Frost Graze - Crowbar — pre-applied default
std::unordered_map<int, int> CrowbarSkinsID = {
    {108002, 1108002039}, // [BODY] Frost Graze - Crowbar
};

// MP5K — Retro Pixel (Lv.3)
std::unordered_map<int, int> MP5KSkinsID = {
    {102007, 1102007022}, // [BODY] Retro Pixel - MP5K (Lv.3)
    // Body-only: attachment slot→skin mapping unverified for this build.
};

// S686 — Lethal Venom (Lv.5)
std::unordered_map<int, int> S686SkinsID = {
    {104001, 1104001035}, // [BODY] Lethal Venom - S686 (Lv.5)
};

// NS2000 — Rustborn Strider (Lv.3)
std::unordered_map<int, int> NS2000SkinsID = {
    {104102, 1104102004}, // [BODY] Rustborn Strider - NS2000 (Lv.3)
    // Body-only: attachment slot→skin mapping unverified for this build.
};

//  SKIN PERSISTENCE — save/load all skin maps to file so they survive restart
// ══════════════════════════════════════════════════════════════════════════
static const char* SKIN_CFG_PATH = []()->const char*{ static char _p[64]; if(!_p[0]){const char* s="/data/data/com.pubg.imobile/cache/kc_skins.ini";strncpy(_p,s,63);} return _p; }();

// Helper: write one map to file as  PREFIX_KEY=VALUE\n
static void WriteSkinMap(FILE* f, const char* prefix,
                         const std::unordered_map<int,int>& m) {
    for (auto& kv : m)
        fprintf(f, "%s_%d=%d\n", prefix, kv.first, kv.second);
}

// Save all runtime skin maps → file

// ASM Abakan — Bloodwing Raven
std::unordered_map<int, int> ASMAbakanSkinsID = {
    {101101, 1101101007}, // [BODY] Bloodwing Raven
    {203015, 1011020424}, {203004, 1011020425}, {203014, 1011020426},
    {203003, 1011020427}, {203002, 1011020428}, {203001, 1011020429},
    {204011, 1011020430}, {204012, 1011020434}, {204013, 1011020435},
    {201010, 1011020436}, {201009, 1011020437}, {201011, 1011020438},
    {202001, 1011020439}, {202006, 1011020440}, {202002, 1011020444},
    {205002, 1011020445}, {202004, 1011020446}, {202005, 1011020447},
    {203016, 1011020448}, {203100, 1011020449}, {205003, 1011020450},
};

// DSR — Hyperion Ship
std::unordered_map<int, int> DSRSkinsID = {
    {103102, 1103102007}, // [BODY] Hyperion Ship
    {203005, 1031020013}, {203015, 1031020014}, {203004, 1031020015},
    {203014, 1031020016}, {203003, 1031020017}, {203002, 1031020018},
    {203001, 1031020019}, {204011, 1031020023}, {204012, 1031020024},
    {204013, 1031020025}, {201010, 1031020026}, {201009, 1031020027},
    {201011, 1031020028}, {203006, 1031020029},
};

static void SkinCfg_Save() {
    FILE* f = fopen(SKIN_CFG_PATH, "w");
    if (!f) return;

    // Skin enabled flags — persist across restarts
    fprintf(f, "%s=%d\n","skin_enabled", (int)GunSkin);

    // Outfit index
    fprintf(f, "%s=%d\n","outfit_index", g_PlayerOutfit.currentOutfit.load());

    // All gun skin maps
    WriteSkinMap(f, "mod",      ModSkinsID);
    WriteSkinMap(f, "m416",     M416SkinsID);
    WriteSkinMap(f, "akm",      AKMSkinsID);
    WriteSkinMap(f, "m16",      M16A4SkinsID);
    WriteSkinMap(f, "scarl",    SCARLSkinsID);
    WriteSkinMap(f, "groza",    GROZASkinsID);
    WriteSkinMap(f, "aug",      AUGSkinsID);
    WriteSkinMap(f, "qbz",      QBZSkinsID);
    WriteSkinMap(f, "m762",     M762SkinsID);
    WriteSkinMap(f, "ace32",    ACE32SkinsID);
    WriteSkinMap(f, "famas",    FAMASSkinsID);
    WriteSkinMap(f, "awm",      AWMSkinsID);
    WriteSkinMap(f, "m24",      M24SkinsID);
    WriteSkinMap(f, "kar98k",   KAR98KSkinsID);
    WriteSkinMap(f, "amr",      AMRSkinsID);
    WriteSkinMap(f, "mk14",     MK14SkinsID);
    WriteSkinMap(f, "sks",      SKSSkinsID);
    WriteSkinMap(f, "mini14",   MINI14SkinsID);
    WriteSkinMap(f, "slr",      SLRSkinsID);
    WriteSkinMap(f, "mk12",     MK12SkinsID);
    WriteSkinMap(f, "mg3",      MG3SkinsID);
    WriteSkinMap(f, "m249",     M249SkinsID);
    WriteSkinMap(f, "dp28",     DP28SkinsID);
    WriteSkinMap(f, "uzi",      UZISkinsID);
    WriteSkinMap(f, "ump45",    UMP45SkinsID);
    WriteSkinMap(f, "vector",   VECTORSKinsID);
    WriteSkinMap(f, "thompson", THOMPSONSkinsID);
    WriteSkinMap(f, "bizon",    BIZONSkinsID);
    WriteSkinMap(f, "vss",      VSSSkinsID);
    WriteSkinMap(f, "p90",      P90SkinsID);
    WriteSkinMap(f, "s12k",     S12KSkinsID);
    WriteSkinMap(f, "s1897",    S1897SkinsID);
    WriteSkinMap(f, "dbs",      DBSSkinsID);
    WriteSkinMap(f, "hbadger",  HoneyBadgerSkinsID);
    WriteSkinMap(f, "abakan",   ASMAbakanSkinsID);
    WriteSkinMap(f, "dsr",      DSRSkinsID);
    WriteSkinMap(f, "pan",      PANSkinsID);
    WriteSkinMap(f, "machete",  MacheteSkinsID);
    WriteSkinMap(f, "dagger",   DaggerSkinsID);
    WriteSkinMap(f, "crowbar",  CrowbarSkinsID);
    WriteSkinMap(f, "mp5k",     MP5KSkinsID);
    WriteSkinMap(f, "s686",     S686SkinsID);
    WriteSkinMap(f, "ns2000",   NS2000SkinsID);

    // Vehicle / cosmetics
    WriteSkinMap(f, "vehicle",  VehicleSkinMap);
    WriteSkinMap(f, "bagpack",  Bagpack);
    WriteSkinMap(f, "helmet",   Helmet);
    WriteSkinMap(f, "parachute",Parachute);
    WriteSkinMap(f, "face",     FaceSkin);
    WriteSkinMap(f, "hair",     HairSkin);

    fclose(f);
}

// Helper: parse PREFIX from "PREFIX_KEY" string
static bool ParseSkinLine(const char* line, char* prefix, int& key, int& val) {
    // Format: PREFIX_KEY=VALUE   (prefix may contain letters only, key is last _INT)
    char tmp[256];
    if (sscanf(line, "%255[^\n]", tmp) != 1) return false;
    // Split on '='
    char* eq = strchr(tmp, '=');
    if (!eq) return false;
    *eq = 0;
    val = atoi(eq + 1);
    // Find last '_' to split prefix from key
    char* lastUs = strrchr(tmp, '_');
    if (!lastUs) return false;
    *lastUs = 0;
    strncpy(prefix, tmp, 63); prefix[63] = 0;
    key = atoi(lastUs + 1);
    return key != 0 || (lastUs[1] == '0');
}

// Load skin file → restore all maps
static void SkinCfg_Load() {
    FILE* f = fopen(SKIN_CFG_PATH, "r");
    if (!f) return;

    // Clear all hardcoded attachment entries from per-gun maps before loading saved config.
    // Without this, saved Shinobi codes mix with hardcoded Glacier defaults → wrong skin.
    auto clrAttach = [](std::unordered_map<int,int>& m, int base_id) {
        for (auto it = m.begin(); it != m.end(); ) {
            it = (it->first != base_id) ? m.erase(it) : ++it;
        }
    };
    clrAttach(M416SkinsID, 101004);   clrAttach(AKMSkinsID, 101001);
    clrAttach(M16A4SkinsID, 101002);  clrAttach(SCARLSkinsID, 101003);
    clrAttach(GROZASkinsID, 101005);  clrAttach(AUGSkinsID, 101006);
    clrAttach(QBZSkinsID, 101007);    clrAttach(M762SkinsID, 101008);
    clrAttach(ACE32SkinsID, 101102);  clrAttach(FAMASSkinsID, 101100);
    clrAttach(AWMSkinsID, 103003);    clrAttach(M24SkinsID, 103002);
    clrAttach(KAR98KSkinsID, 103001); clrAttach(AMRSkinsID, 103012);
    clrAttach(MK14SkinsID, 103007);   clrAttach(SKSSkinsID, 103004);
    clrAttach(MINI14SkinsID, 103006); clrAttach(SLRSkinsID, 103009);
    clrAttach(MK12SkinsID, 103100);   clrAttach(MG3SkinsID, 105010);
    clrAttach(M249SkinsID, 105001);   clrAttach(DP28SkinsID, 105002);
    clrAttach(UZISkinsID, 102001);    clrAttach(UMP45SkinsID, 102002);
    clrAttach(VECTORSKinsID, 102003); clrAttach(THOMPSONSkinsID, 102004);
    clrAttach(BIZONSkinsID, 102005);  clrAttach(VSSSkinsID, 103005);
    clrAttach(P90SkinsID, 102105);    clrAttach(S12KSkinsID, 104003);
    clrAttach(S1897SkinsID, 104002);  clrAttach(DBSSkinsID, 104004);
    clrAttach(HoneyBadgerSkinsID, 101012);
    clrAttach(ASMAbakanSkinsID,    101101);
    clrAttach(DSRSkinsID,          103102);
    ModSkinsID.clear(); // cleared here; saved entries will repopulate it below

    char line[256];
    while (fgets(line, sizeof(line), f)) {
        // Special: skin_enabled=N
        if (strncmp(line, "skin_enabled=", 13) == 0) {
            bool en = (bool)atoi(line + 13);
            GunSkin = en; VehicleSkin = en;
            continue;
        }
        // Special: outfit_index=N
        if (strncmp(line, "outfit_index=", 13) == 0) {
            g_PlayerOutfit.currentOutfit.store(atoi(line + 13));
            continue;
        }

        char prefix[64]; int key = 0, val = 0;
        if (!ParseSkinLine(line, prefix, key, val) || val == 0) continue;

        // Route to correct map
        if      (!strcmp(prefix, "mod"))      ModSkinsID[key]         = val;
        else if (!strcmp(prefix, "m416"))     M416SkinsID[key]        = val;
        else if (!strcmp(prefix, "akm"))      AKMSkinsID[key]         = val;
        else if (!strcmp(prefix, "m16"))      M16A4SkinsID[key]       = val;
        else if (!strcmp(prefix, "scarl"))    SCARLSkinsID[key]       = val;
        else if (!strcmp(prefix, "groza"))    GROZASkinsID[key]       = val;
        else if (!strcmp(prefix, "aug"))      AUGSkinsID[key]         = val;
        else if (!strcmp(prefix, "qbz"))      QBZSkinsID[key]         = val;
        else if (!strcmp(prefix, "m762"))     M762SkinsID[key]        = val;
        else if (!strcmp(prefix, "ace32"))    ACE32SkinsID[key]       = val;
        else if (!strcmp(prefix, "famas"))    FAMASSkinsID[key]       = val;
        else if (!strcmp(prefix, "awm"))      AWMSkinsID[key]         = val;
        else if (!strcmp(prefix, "m24"))      M24SkinsID[key]         = val;
        else if (!strcmp(prefix, "kar98k"))   KAR98KSkinsID[key]      = val;
        else if (!strcmp(prefix, "amr"))      AMRSkinsID[key]         = val;
        else if (!strcmp(prefix, "mk14"))     MK14SkinsID[key]        = val;
        else if (!strcmp(prefix, "sks"))      SKSSkinsID[key]         = val;
        else if (!strcmp(prefix, "mini14"))   MINI14SkinsID[key]      = val;
        else if (!strcmp(prefix, "slr"))      SLRSkinsID[key]         = val;
        else if (!strcmp(prefix, "mk12"))     MK12SkinsID[key]        = val;
        else if (!strcmp(prefix, "mg3"))      MG3SkinsID[key]         = val;
        else if (!strcmp(prefix, "m249"))     M249SkinsID[key]        = val;
        else if (!strcmp(prefix, "dp28"))     DP28SkinsID[key]        = val;
        else if (!strcmp(prefix, "uzi"))      UZISkinsID[key]         = val;
        else if (!strcmp(prefix, "ump45"))    UMP45SkinsID[key]       = val;
        else if (!strcmp(prefix, "vector"))   VECTORSKinsID[key]      = val;
        else if (!strcmp(prefix, "thompson")) THOMPSONSkinsID[key]    = val;
        else if (!strcmp(prefix, "bizon"))    BIZONSkinsID[key]       = val;
        else if (!strcmp(prefix, "vss"))      VSSSkinsID[key]         = val;
        else if (!strcmp(prefix, "p90"))      P90SkinsID[key]         = val;
        else if (!strcmp(prefix, "s12k"))     S12KSkinsID[key]        = val;
        else if (!strcmp(prefix, "s1897"))    S1897SkinsID[key]       = val;
        else if (!strcmp(prefix, "dbs"))      DBSSkinsID[key]         = val;
        else if (!strcmp(prefix, "hbadger"))  HoneyBadgerSkinsID[key] = val;
        else if (!strcmp(prefix, "abakan"))   ASMAbakanSkinsID[key]  = val;
        else if (!strcmp(prefix, "dsr"))      DSRSkinsID[key]        = val;
        else if (!strcmp(prefix, "pan"))      PANSkinsID[key]         = val;
        else if (!strcmp(prefix, "machete"))  MacheteSkinsID[key]     = val;
        else if (!strcmp(prefix, "dagger"))   DaggerSkinsID[key]      = val;
        else if (!strcmp(prefix, "crowbar"))  CrowbarSkinsID[key]     = val;
        else if (!strcmp(prefix, "mp5k"))     MP5KSkinsID[key]        = val;
        else if (!strcmp(prefix, "s686"))     S686SkinsID[key]        = val;
        else if (!strcmp(prefix, "ns2000"))   NS2000SkinsID[key]      = val;
        else if (!strcmp(prefix, "vehicle"))  VehicleSkinMap[key]     = val;
        else if (!strcmp(prefix, "bagpack"))  Bagpack[key]            = val;
        else if (!strcmp(prefix, "helmet"))   Helmet[key]             = val;
        else if (!strcmp(prefix, "parachute"))Parachute[key]          = val;
        else if (!strcmp(prefix, "face"))     FaceSkin[key]           = val;
        else if (!strcmp(prefix, "hair"))     HairSkin[key]           = val;
    }
    fclose(f);
}

// ══════════════════════════════════════════════════════════════════════════
//  DYNAMIC ATTACHMENT SKIN RESOLVER
//  Given any gun skin code, computes and applies the matching attachment skins.
//  Formula (verified against SkinDB for all major guns, ~96-100% coverage):
//    attach_base = attach_prefix_for_gun * 1000 + (gun_skin_code % 1000) * 10
//    attach_code = attach_base + slot_offset
//  Each slot_offset maps to a specific attachment slot item ID.
// ══════════════════════════════════════════════════════════════════════════
// Attachment DB now in SkinDB.h (SkinDB_GetAttachments)

// Clear all attachment entries from a per-gun skin map (keep gun base ID entry)
// This must be called before applying new attachment skins to avoid mixing old+new
static void ClearGunAttachments(std::unordered_map<int,int>& gunMap, int gun_base_id) {
    auto it = gunMap.begin();
    while (it != gunMap.end()) {
        if (it->first != gun_base_id)
            it = gunMap.erase(it);
        else
            ++it;
    }
}

// Also clear corresponding attachment entries from ModSkinsID
// (ModSkinsID uses same attachment item IDs as keys)
static void ClearModSkinsAttachments(std::unordered_map<int,int>& modMap,
                                      const std::unordered_map<int,int>& gunMap) {
    for (auto& kv : gunMap) {
        modMap.erase(kv.first);
    }
}

// Apply matching attachment skins for a given gun skin code into ModSkinsID (and per-gun map)
// Returns number of attachments applied
// Uses SkinDB_GetAttachments() — reads directly from organized SkinDB entries
// Each attachment entry has slot_item_id (synData key) and code (skin code value)
static int ApplyMatchingAttachments(int gun_base_id, long long gun_skin_code,
                                    std::unordered_map<int,int>& outMap,
                                    std::unordered_map<int,int>* perGunMap = nullptr) {
    // ── Clear old attachment entries first ──
    // Without this, hardcoded default entries (e.g. Glacier scope/grip/stock)
    // remain in the map even after applying a new skin → mixing of two skins
    if (perGunMap) {
        ClearModSkinsAttachments(outMap, *perGunMap);  // remove from ModSkinsID
        ClearGunAttachments(*perGunMap, gun_base_id);  // remove from XxxSkinsID
    }

    auto attachments = SkinDB_GetAttachments(gun_skin_code);
    int applied = 0;
    for (const SkinEntry* e : attachments) {
        if (e->slot_item_id == 0) continue;
        outMap[e->slot_item_id] = (int)e->code;
        if (perGunMap) (*perGunMap)[e->slot_item_id] = (int)e->code;
        applied++;
    }
    return applied;
}
