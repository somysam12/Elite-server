#pragma once
__int64 (*oLobbyWeaponSkin)(__int64 result, int WeaponSkinID, bool bUse, bool bSync);
__int64 hLobbyWeaponSkin(__int64 result, int WeaponSkinID, bool bUse, bool bSync) {
    auto it = ModSkinsID.find(WeaponSkinID);
    if (it != ModSkinsID.end()) {
        WeaponSkinID = it->second;
    }
    return oLobbyWeaponSkin(result, WeaponSkinID, bUse, bSync);
}

// ── Inline SetAvatarID via ProcessEvent (avoids prebuilt .a linking issue) ──
static void KC_TombBox_SetAvatarID(APlayerTombBox* box, int avatarID) {
    static UFunction* pFunc = nullptr;
    if (!pFunc)
        pFunc = UObject::FindObject<UFunction>("Function ShadowTrackerExtra.PlayerTombBox.SetAvatarID");
    if (!pFunc) return;
    struct { int AvatarID; } params;
    params.AvatarID = avatarID;
    auto flags = pFunc->FunctionFlags;
    pFunc->FunctionFlags |= 0x400;
    ((UObject*)box)->ProcessEvent(pFunc, &params);
    pFunc->FunctionFlags = flags;
}

static std::unordered_set<uintptr_t> g_KCChangedDeadBoxes;

static void KC_DrawDeadBoxSkins() {
    if (!Cheat::localPlayer || !Cheat::localController) return;

    int desiredSkin = 0;
    auto* WM = Cheat::localPlayer->WeaponManagerComponent;
    if (WM && (uintptr_t)WM > 0x100000 && WM->CurrentWeaponReplicated) {
        int wid = WM->CurrentWeaponReplicated->GetWeaponID();
        auto it = ModSkinsID.find(wid);
        if (it != ModSkinsID.end()) desiredSkin = it->second;
    }
    if (desiredSkin == 0) return;

    auto Actors = GetActors();
    for (auto* Actor : Actors) {
        if (!Actor || (uintptr_t)Actor < 0x100000) continue;
        if (!Actor->IsA(APlayerTombBox::StaticClass())) continue;
        auto* TombBox = (APlayerTombBox*)Actor;
        if (!TombBox->DamageCauser || !TombBox->TargetPlayer) continue;
        if (TombBox->DamageCauser->PlayerKey != Cheat::localController->PlayerKey) continue;
        uintptr_t addr = (uintptr_t)TombBox;
        if (g_KCChangedDeadBoxes.find(addr) == g_KCChangedDeadBoxes.end()) {
            KC_TombBox_SetAvatarID(TombBox, desiredSkin);
            g_KCChangedDeadBoxes.insert(addr);
        }
    }
}
