#pragma once
#include "KCConfig.h"   // APNA CONFIG YAHAN HAI
// ╔════════════════════════════════════════════════════╗
// ║  KCSecure.h — Panel URL obfuscation + Anti-Tamper ║
// ╚════════════════════════════════════════════════════╝
#include <cstdint>
#include <cstring>
#include <string>
#include <signal.h>
#include <dirent.h>
#include <fstream>
#include <fcntl.h>
#include <unistd.h>
#include <array>

// ── Compile-time XOR obfuscation ─────────────────────
// KCHardSec.h (included before this) already defines OBF_S via _KCStr.
// Only define ObfStr + macros if they haven't been defined yet.
#ifndef OBF_S
template<std::size_t N>
struct ObfStr {
    std::array<char, N> data;
    static constexpr uint8_t KEY = 0x5A;
    constexpr ObfStr(const char (&s)[N]) : data{} {
        for (std::size_t i = 0; i < N; i++) data[i] = s[i] ^ KEY;
    }
    __attribute__((noinline)) std::string str() const {
        std::string r(N - 1, '\0');
        for (std::size_t i = 0; i < N - 1; i++) r[i] = data[i] ^ KEY;
        return r;
    }
};
#define OBF_S(s) (ObfStr<sizeof(s)>(s))
#define OBF(s)   (ObfStr<sizeof(s)>(s).str())
#endif

// Panel URL — Hikari OLLVM (fla+bcf+sub+indibran) obfuscates XOR decryption
__attribute__((__annotate__(("fla bcf sub indibran")))) __attribute__((noinline))
static std::string KC_PANEL_URL() {
    static constexpr auto _o = OBF_S(KC_MY_PANEL_URL);
    return _o.str();
}

// ── Anti-Tamper ───────────────────────────────────────
__attribute__((noinline, noreturn, used))
static void _KC_HardCrash() {
    raise(9);
    volatile uintptr_t* _bad = (volatile uintptr_t*)0x00000004;
    *_bad = 0xDEADBEEF;
    abort();
    __builtin_unreachable();
}

__attribute__((__annotate__(("fla bcf sub indibran")))) __attribute__((noinline))
static bool _kc_is_frida() {
    std::ifstream maps("/proc/self/maps");
    std::string line;
    while (std::getline(maps, line)) {
        if (line.find("frida")     != std::string::npos) return true;
        if (line.find("gadget")    != std::string::npos) return true;
        if (line.find("linjector") != std::string::npos) return true;
    }
    return false;
}

__attribute__((__annotate__(("fla bcf sub indibran")))) __attribute__((noinline))
static bool _kc_is_ptrace() {
    int fd = open("/proc/self/status", O_RDONLY);
    if (fd < 0) return false;
    char buf[512] = {};
    read(fd, buf, 511); close(fd);
    const char* p = strstr(buf, "TracerPid:");
    if (!p) return false;
    p += 10;
    while (*p == ' ' || *p == '\t') p++;
    return (*p != '0');
}

__attribute__((__annotate__(("fla bcf sub indibran")))) __attribute__((noinline))
static bool _kc_is_mt_manager() {
    DIR* dir = opendir("/proc");
    if (!dir) return false;
    struct dirent* ent;
    while ((ent = readdir(dir)) != nullptr) {
        if (ent->d_type != DT_DIR) continue;
        std::string cmdpath = std::string("/proc/") + ent->d_name + "/cmdline";
        std::ifstream cmd(cmdpath);
        std::string cmdline;
        if (!std::getline(cmd, cmdline)) continue;
        if (cmdline.find("mt.manager")   != std::string::npos ||
            cmdline.find("gameguardian") != std::string::npos ||
            cmdline.find("cheatengine")  != std::string::npos) {
            closedir(dir); return true;
        }
    }
    closedir(dir); return false;
}

__attribute__((__annotate__(("fla bcf sub indibran")))) __attribute__((noinline))
static void KC_AntiTamperCheck() {
    if (_kc_is_frida() || _kc_is_ptrace() || _kc_is_mt_manager())
        _KC_HardCrash();
}
