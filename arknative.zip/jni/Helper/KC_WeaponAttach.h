// ═══════════════════════════════════════════════════════════════════════════
// KC_WeaponAttach.h — Nexus weapon attachment ownership Lua module
// Registers weapon skin ownership including all attachment skin IDs via the
// official CommerAvatarDataUtil:InitWeaponSkinList → AddWeaponAvatarItem path.
// ═══════════════════════════════════════════════════════════════════════════
#pragma once

static const char kc_weapon_attach_script[] = R"KCLUA(
if _G.__NexusWeaponAttachmentOwnershipReady then return end
_G.__NexusWeaponAttachmentOwnershipReady = true

if _G.NexusAttachmentOwnershipMode == nil then
    _G.NexusAttachmentOwnershipMode = true
end

local function toInt(v) return tonumber(v) or 0 end
local function isSkinItem(id) return toInt(id) >= 1000000000 end
local function isVanillaAttach(id) local n = toInt(id); return n > 0 and n < 1000000000 end

local function getLocalChar()
    local PlayerController = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
    if not PlayerController or not slua.isValid(PlayerController) then return nil end
    return PlayerController:GetPlayerCharacterSafety()
end

local function nexusGetLocalPC()
    local ch = getLocalChar()
    if not ch or not slua.isValid(ch) then return nil end
    local pc = nil
    pcall(function()
        if ch.GetPlayerControllerSafety then pc = ch:GetPlayerControllerSafety() end
    end)
    return (pc and slua.isValid(pc)) and pc or nil
end

local OwnershipMgr = {
    SOCKET_SLOT_MAX = 12,
    _cache = nil,
    _skinCtx = {},
}

function OwnershipMgr:cfg(resID)
    resID = toInt(resID)
    if resID <= 0 or not CDataTable or not CDataTable.GetTableData then return nil end
    return CDataTable.GetTableData("Item", resID)
end

function OwnershipMgr:gameUtils()
    if not self._gu then
        self._gu = {}
        pcall(function() self._gu.au = import("AvatarUtils") end)
        pcall(function() self._gu.bu = import("BackpackUtils") end)
        if not self._gu.au then pcall(function() self._gu.au = import("/Script/ShadowTrackerExtra.AvatarUtils") end) end
        if not self._gu.bu then pcall(function() self._gu.bu = import("/Script/ShadowTrackerExtra.BackpackUtils") end) end
    end
    return self._gu.au, self._gu.bu
end

function OwnershipMgr:avatarBPID(resId)
    resId = toInt(resId)
    if resId <= 0 then return 0 end
    local au, bu = self:gameUtils()
    local bp = 0
    pcall(function()
        if au and au.GetBPIDByResID then bp = toInt(au.GetBPIDByResID(resId)) end
    end)
    if bp <= 0 then
        pcall(function()
            if bu and bu.GetBPIDByResID then bp = toInt(bu.GetBPIDByResID(resId)) end
        end)
    end
    return bp > 0 and bp or resId
end

function OwnershipMgr:makeIntArray()
    local ok, a = pcall(function()
        return slua.Array(UEnums.EPropertyClass.Int)
    end)
    return ok and a or nil
end

function OwnershipMgr:splitList(str, sep)
    if not str or str == "" then return {} end
    local ok, StringUtil = pcall(require, "common.string_util")
    if ok and StringUtil and StringUtil.Split then
        return StringUtil.Split(str, sep)
    end
    local out = {}
    for part in string.gmatch(str, "[^" .. sep .. "]+") do
        out[#out + 1] = part
    end
    return out
end

function OwnershipMgr:parsePairList(str)
    local out = {}
    for _, chunk in pairs(self:splitList(str, "|")) do
        local parts = self:splitList(chunk, "-")
        if #parts >= 2 then
            local key = toInt(parts[1])
            local val = toInt(parts[2])
            if val > 0 then out[#out + 1] = { key = key, val = val } end
        else
            local id = toInt(parts[1])
            if id > 0 then out[#out + 1] = { key = 0, val = id } end
        end
    end
    return out
end

function OwnershipMgr:buildCache()
    if self._cache then return self._cache end
    local c = {
        groupOf = {}, groupParts = {},
        diffColor = {},
        parentOf = {}, socketOf = {}, canon = {},
        ready = false,
    }
    if not CDataTable or not CDataTable.GetTable then
        self._cache = c
        return c
    end
    local got = 0
    local up = CDataTable.GetTable("ItemUpgradeConfig")
    if up then
        got = got + 1
        for _, row in pairs(up) do
            local itm, gid = toInt(row.ItemID), toInt(row.GroupID)
            if isSkinItem(itm) and gid > 0 then
                c.groupOf[itm] = gid
            end
        end
    end
    local unlock = CDataTable.GetTable("ItemUpgradeUnLockConfig")
    if unlock then
        got = got + 1
        for _, row in pairs(unlock) do
            local gid, part = toInt(row.GroupID), toInt(row.PartId or row.PartID)
            if gid > 0 and isSkinItem(part) then
                local list = c.groupParts[gid]
                if not list then list = {}; c.groupParts[gid] = list end
                list[#list + 1] = part
            end
        end
    end
    local diff = CDataTable.GetTable("ItemUpgradeDiffColorPart")
    if diff then
        for _, row in pairs(diff) do
            local alt = toInt(row.DiffColorPartID)
            if alt > 0 then c.diffColor[alt] = true end
        end
    end
    c.ready = (got == 2)
    self._cache = c
    return c
end

function OwnershipMgr:parentOf(partId)
    partId = toInt(partId)
    if not isSkinItem(partId) then return 0 end
    local c = self:buildCache()
    if c.parentOf[partId] ~= nil then return c.parentOf[partId] end
    local v = 0
    pcall(function()
        local row = CDataTable.GetTableData("WeaponAttachAttrBPTable", partId)
        if row and row.ParentID then v = toInt(row.ParentID) end
    end)
    if v <= 0 then
        pcall(function()
            local au = self:gameUtils()
            if au and au.GetWeaponAttachmentSkinParentID then
                local bp = self:avatarBPID(partId)
                local p = toInt(au.GetWeaponAttachmentSkinParentID(bp))
                if isVanillaAttach(p) and self:cfg(p) then v = p end
            end
        end)
    end
    if not isVanillaAttach(v) then v = 0 end
    c.parentOf[partId] = v
    return v
end

function OwnershipMgr:socketOf(resId)
    resId = toInt(resId)
    if resId <= 0 then return -1 end
    local c = self:buildCache()
    if c.socketOf[resId] ~= nil then return c.socketOf[resId] end
    local s = -1
    pcall(function()
        local _, bu = self:gameUtils()
        if bu and bu.getSocketByAttachResID then
            local r = bu.getSocketByAttachResID(resId)
            if r ~= nil then s = tonumber(r) or -1 end
        end
    end)
    c.socketOf[resId] = s
    return s
end

function OwnershipMgr:canonicalVanilla(id)
    id = toInt(id)
    if not isVanillaAttach(id) then return 0 end
    local c = self:buildCache()
    if c.canon[id] ~= nil then return c.canon[id] end
    local v = id
    pcall(function()
        local au = self:gameUtils()
        if au and au.GetAdjustWeaponAttachmentID then
            local adj = toInt(au.GetAdjustWeaponAttachmentID(id))
            if isVanillaAttach(adj) then v = adj end
        end
    end)
    c.canon[id] = v
    return v
end

function OwnershipMgr:betterPart(a, b)
    local c = self:buildCache()
    local da, db = c.diffColor[a] == true, c.diffColor[b] == true
    if da ~= db then return db end
    return a < b
end

function OwnershipMgr:baseWeaponId(weaponSkinId)
    weaponSkinId = toInt(weaponSkinId)
    if weaponSkinId <= 0 then return 0 end
    local base = 0
    pcall(function()
        local row = CDataTable.GetTableData("WeaponSkinMapping", weaponSkinId)
        if row then base = toInt(row.WeaponID or row.weaponID or row.WeaponId) end
    end)
    if base <= 0 then
        pcall(function()
            if CDataTable.GetTableData("ArmoryConfig", weaponSkinId) then
                base = weaponSkinId
            end
        end)
    end
    return base > 0 and base or weaponSkinId
end

function OwnershipMgr:getSkinContext(weaponSkinId)
    weaponSkinId = toInt(weaponSkinId)
    if weaponSkinId <= 0 then return nil end
    if self._skinCtx[weaponSkinId] then return self._skinCtx[weaponSkinId] end
    local c = self:buildCache()
    local ctx = {
        weaponSkinId = weaponSkinId,
        byVanilla = {},
        parts = {},
        defaultVanilla = {},
        defaultSkinByVanilla = {},
        defaultSkinBySlot = {},
    }
    local gid = c.groupOf[weaponSkinId]
    local list = gid and c.groupParts[gid]
    if list then
        for _, part in ipairs(list) do
            ctx.parts[part] = true
            local van = self:parentOf(part)
            if van > 0 then
                local cur = ctx.byVanilla[van]
                if not cur or self:betterPart(part, cur) then
                    ctx.byVanilla[van] = part
                end
            end
        end
    end
    local skinBp = self:avatarBPID(weaponSkinId)
    pcall(function()
        local row = CDataTable.GetTableData("WeaponAttrBPTable", skinBp)
        if row and row.AttachmentSkinIDList and row.AttachmentSkinIDList ~= "" then
            for _, pair in ipairs(self:parsePairList(row.AttachmentSkinIDList)) do
                local skinId, key = pair.val, pair.key
                if isSkinItem(skinId) and self:cfg(skinId) then
                    ctx.parts[skinId] = true
                    local van = self:parentOf(skinId)
                    if van > 0 then
                        ctx.defaultSkinByVanilla[van] = skinId
                        if not ctx.byVanilla[van] then ctx.byVanilla[van] = skinId end
                    end
                    if isVanillaAttach(key) then
                        local canon = self:canonicalVanilla(key)
                        ctx.defaultSkinByVanilla[canon] = skinId
                        if not ctx.byVanilla[canon] then ctx.byVanilla[canon] = skinId end
                    elseif key >= 0 and key <= self.SOCKET_SLOT_MAX then
                        ctx.defaultSkinBySlot[key] = skinId
                    end
                end
            end
        end
    end)
    local baseId = self:baseWeaponId(weaponSkinId)
    local baseBp = self:avatarBPID(baseId)
    pcall(function()
        local row = CDataTable.GetTableData("WeaponAttrBPTable", baseBp)
        if row and row.AttachmentIDList_a and row.AttachmentIDList_a ~= "" then
            for _, pair in ipairs(self:parsePairList(row.AttachmentIDList_a)) do
                local vanId = pair.val > 0 and pair.val or pair.key
                if isVanillaAttach(vanId) then
                    local slot = self:socketOf(vanId)
                    if slot >= 0 and slot <= self.SOCKET_SLOT_MAX then
                        ctx.defaultVanilla[slot] = self:canonicalVanilla(vanId)
                    end
                end
            end
        end
    end)
    pcall(function()
        local au = self:gameUtils()
        if not au or not au.GetWeaponAvatarDefaultAttachment then return end
        local outArr = self:makeIntArray()
        if not outArr then return end
        outArr = au.GetWeaponAvatarDefaultAttachment(baseBp, outArr, false)
        if not outArr or not slua.isValid(outArr) then return end
        local n = 0
        pcall(function() n = outArr:Num() end)
        for i = 0, n - 1 do
            local vanId = 0
            pcall(function() vanId = toInt(outArr:Get(i)) end)
            if vanId > 0 then
                local slot = self:socketOf(vanId)
                if slot >= 0 and slot <= self.SOCKET_SLOT_MAX then
                    ctx.defaultVanilla[slot] = self:canonicalVanilla(vanId)
                end
            end
        end
    end)
    self._skinCtx[weaponSkinId] = ctx
    return ctx
end

function OwnershipMgr:collectAttachmentSkinIds(weaponSkinId)
    weaponSkinId = toInt(weaponSkinId)
    if weaponSkinId <= 0 then return {} end
    local ctx = self:getSkinContext(weaponSkinId)
    if not ctx then return {} end
    local out, seen = {}, {}
    for partId, _ in pairs(ctx.parts) do
        partId = toInt(partId)
        if isSkinItem(partId) and not seen[partId] then
            seen[partId] = true
            out[#out + 1] = partId
        end
    end
    table.sort(out)
    return out
end

function OwnershipMgr:buildWeaponAttachSkinMap(weaponSkinIds)
    local map = {}
    if type(weaponSkinIds) ~= "table" then return map end
    for _, sid in ipairs(weaponSkinIds) do
        sid = toInt(sid)
        if sid > 0 and isSkinItem(sid) then
            local parts = self:collectAttachmentSkinIds(sid)
            if #parts > 0 then map[sid] = parts end
        end
    end
    return map
end

function OwnershipMgr:mergeWeaponAttachSkinMaps(base, extra)
    base = base or {}
    for sid, list in pairs(extra or {}) do
        sid = toInt(sid)
        if sid > 0 and type(list) == "table" and #list > 0 then
            local dst = base[sid]
            if type(dst) ~= "table" then dst = {}; base[sid] = dst end
            local seen = {}
            for _, x in ipairs(dst) do seen[toInt(x)] = true end
            for _, x in ipairs(list) do
                x = toInt(x)
                if x > 0 and not seen[x] then
                    seen[x] = true
                    dst[#dst + 1] = x
                end
            end
        end
    end
    return base
end

function OwnershipMgr:mergeWeaponSkinIdList(existing)
    if _G.NexusMatchWeaponSkin and _G.NexusMatchWeaponSkin.mergeWeaponSkinIdList then
        return _G.NexusMatchWeaponSkin.mergeWeaponSkinIdList(existing)
    end
    existing = existing or {}
    if type(existing) ~= "table" then return {} end
    local out, seen = {}, {}
    local function add(id)
        id = toInt(id)
        if id > 0 and isSkinItem(id) and not seen[id] then
            seen[id] = true
            out[#out + 1] = id
        end
    end
    for _, id in ipairs(existing) do add(id) end
    if _G.NexusWeaponSkinIdList and type(_G.NexusWeaponSkinIdList) == "table" then
        for _, id in ipairs(_G.NexusWeaponSkinIdList) do add(id) end
    end
    return out
end

function OwnershipMgr:registerWeaponAvatarOwnership(pc, weaponSkinIds)
    if not pc or not slua.isValid(pc) then return false end
    self:buildCache()
    local merged = self:mergeWeaponSkinIdList(weaponSkinIds)
    if type(merged) ~= "table" or #merged == 0 then return false end
    local attachMap = self:buildWeaponAttachSkinMap(merged)
    pcall(function()
        local CommerAvatarDataUtil = require("GameLua.Activity.Commercialize.GamePlay.CommerAvatarDataUtil")
        if CommerAvatarDataUtil and CommerAvatarDataUtil.InitWeaponSkinList then
            CommerAvatarDataUtil:InitWeaponSkinList(pc, merged, attachMap, nil)
        end
    end)
    local added = {}
    local function regItem(resID)
        resID = toInt(resID)
        if resID <= 0 or added[resID] then return end
        added[resID] = true
        pcall(function()
            if pc.AddWeaponAvatarItem then pc:AddWeaponAvatarItem(resID) end
        end)
    end
    for _, sid in ipairs(merged) do regItem(sid) end
    for _, list in pairs(attachMap) do
        for _, pid in ipairs(list) do regItem(pid) end
    end
    pcall(function() if pc.InitWeaponAvatarItems then pc:InitWeaponAvatarItems() end end)
    pcall(function() if pc.OnWeaponAvatarUpdate then pc:OnWeaponAvatarUpdate() end end)
    return true
end

function OwnershipMgr:installInitWeaponSkinListHook()
    if self._initHooked then return end
    self._initHooked = true
    local mgr = self
    pcall(function()
        local CommerAvatarDataUtil = require("GameLua.Activity.Commercialize.GamePlay.CommerAvatarDataUtil")
        if not CommerAvatarDataUtil or not CommerAvatarDataUtil.InitWeaponSkinList then return end
        if CommerAvatarDataUtil._nexus_ownership_init_hooked then return end
        CommerAvatarDataUtil._nexus_ownership_init_hooked = true
        local orig = CommerAvatarDataUtil.InitWeaponSkinList
        CommerAvatarDataUtil.InitWeaponSkinList = function(self, uPlayerController, weapon_skin_list, weaponattach_skin_list, WeaponPendantInfo)
            if _G.NexusAttachmentOwnershipMode == true then
                local skins = mgr:mergeWeaponSkinIdList(weapon_skin_list)
                local autoMap = mgr:buildWeaponAttachSkinMap(skins or {})
                weaponattach_skin_list = mgr:mergeWeaponAttachSkinMaps(weaponattach_skin_list, autoMap)
            end
            return orig(self, uPlayerController, weapon_skin_list, weaponattach_skin_list, WeaponPendantInfo)
        end
    end)
end

function OwnershipMgr:ResetCache()
    self._cache = nil
    self._skinCtx = {}
end

_G.NexusWeaponAttachOwnership = OwnershipMgr
_G.NexusAutoAttach = OwnershipMgr

function _G.NexusBuildWeaponAttachSkinMap(weaponSkinIds)
    return OwnershipMgr:buildWeaponAttachSkinMap(weaponSkinIds or {})
end

function _G.NexusSyncWeaponAvatarOwnership(pc, weaponSkinIds)
    if _G.__WeaponAttachPaused then return false end
    pc = pc or nexusGetLocalPC()
    if not pc or not slua.isValid(pc) then return false end
    return OwnershipMgr:registerWeaponAvatarOwnership(pc, weaponSkinIds) == true
end

function _G.NexusRefreshAllWeaponAttachmentOwnership()
    if _G.__WeaponAttachPaused then return false end
    return _G.NexusSyncWeaponAvatarOwnership(nil, nil) == true
end

OwnershipMgr:installInitWeaponSkinListHook()
)KCLUA";
