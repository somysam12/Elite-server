#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unistd.h>
#include <cstring>
#include <android/log.h>



struct MemoryRegion {
    uintptr_t start;
    uintptr_t end;
    std::string perms;
    std::string pathname;
};

std::vector<MemoryRegion> parseMaps() {
    std::ifstream maps("/proc/self/maps");
    std::string line;
    std::vector<MemoryRegion> regions;

    while (std::getline(maps, line)) {
        std::istringstream iss(line);
        std::string addr, perms, offset, dev, inode, pathname;

        iss >> addr >> perms >> offset >> dev >> inode;
        std::getline(iss, pathname);
        if (!pathname.empty()) {
            pathname = pathname.substr(1);  // Remove leading space
        }

        uintptr_t start, end;
        sscanf(addr.c_str(), "%lx-%lx", &start, &end);

        regions.push_back({start, end, perms, pathname});
    }

    return regions;
}

MemoryRegion findLibRegion(const std::string& libName) {
    for (const auto& region : parseMaps()) {
        if (region.pathname.find(libName) != std::string::npos && region.perms.find("r-xp") != std::string::npos) {
            return region;
        }
    }
    return {0, 0, "", ""};
}

MemoryRegion findBssRegionNearLib(const MemoryRegion& libRegion) {
    for (const auto& region : parseMaps()) {
        if (( region.pathname.find("libanogs.so") != std::string::npos) &&
            region.perms.find("r-xp") != std::string::npos &&
            region.start >= libRegion.start &&
            region.start <= libRegion.end + 0x300000) {
            return region;
        }
    }
    return {0, 0, "", ""};
}

uintptr_t resolveAddress(uintptr_t offset) {
    MemoryRegion lib = findLibRegion("libanogs.so");
    if (lib.start == 0) {
        return 0;
    }

    MemoryRegion bss = findBssRegionNearLib(lib);
    if (bss.start == 0) {
        return 0;
    }

    uintptr_t address = bss.start + offset;
    return address;
}

void makeWritable(void* addr) {
    uintptr_t page = (uintptr_t)addr & ~(getpagesize() - 1);
    mprotect((void*)page, getpagesize(), PROT_READ | PROT_WRITE);
}

void patchMemory(uintptr_t address, int value) {
    if (address == 0) {
        return;
    }
    makeWritable((void*)address);
    *(int*)address = value;
}

void CrashFix() {
  patchMemory(resolveAddress(0x6C6678), 1);
}
