// ═══════════════════════════════════════════════════════════════════════════
// KC_TwitterLogin.h — Twitter app-login forcing (Lua)
//
// Purpose: Force Twitter login to open the APP instead of the system webview.
// MUST inject EARLY (before the login page appears) — so it uses a SEPARATE
// early-injection path, NOT the wardrobe's 20-ProcessEvent-delayed inject.
//
// Injection: as soon as luaL_loadbufferx hands us the Lua state, we inject
// this script once (login page hasn't rendered yet → hooks are ready in time).
// ═══════════════════════════════════════════════════════════════════════════
#pragma once

static const char* kc_twitter_login_script = R"KCTWITTER(
pcall(function()
    local Bridge = rawget(_G, "NewX")
    local Log = (Bridge and Bridge.Log) or function() end

    local DeeplinkLogin = require("client.logic.login.logic_imsdk_deeplink_login")
    if not DeeplinkLogin then
        Log("deeplink login module unavailable, skipping")
        return
    end

    local TwitterPlatform = BP_ENUM_PLAYFORM_TWITTER or 42
    local TwitterChannel = BP_ENUM_IMSDK_CHANNEL_TWITTER or 35

    local OriginalWebviewLogin = DeeplinkLogin.LoginViaSystemWebview
    if OriginalWebviewLogin then
        DeeplinkLogin.LoginViaSystemWebview = function(Self, LoginType)
            if LoginType == TwitterPlatform then
                Log("blocked Twitter web login (deeplink)")
                return false
            end
            return OriginalWebviewLogin(Self, LoginType)
        end
    end

    local OriginalWebviewBind = DeeplinkLogin.BindViaSystemWebview
    if OriginalWebviewBind then
        DeeplinkLogin.BindViaSystemWebview = function(Self, LoginType)
            if LoginType == TwitterChannel then
                Log("blocked Twitter web bind (deeplink)")
                return false
            end
            return OriginalWebviewBind(Self, LoginType)
        end
    end

    local ImsdkInterface = require("client.logic.login.logic_imsdk_interface")
    if ImsdkInterface then
        local OriginalLogin = ImsdkInterface.Login
        if OriginalLogin then
            ImsdkInterface.Login = function(Self, LoginType, ExtraJson, SkipLocalCacheCheck)
                local ImsdkHelper = import("IMSDKHelper")
                if ImsdkHelper then
                    local Helper = ImsdkHelper.GetInstance()
                    if Helper then
                        local Channel = Helper:ConvertTConndChannel2IMSDKChannel(LoginType)
                        if LoginType == TwitterPlatform or Channel == TwitterChannel then
                            Helper:SetMSDKConfig({IMSDK_TWITTER_LOGIN_USING_WEB = "false"}, false)
                            Log("forced Twitter app login (interface.Login)")
                        end
                    end
                end
                return OriginalLogin(Self, LoginType, ExtraJson, SkipLocalCacheCheck)
            end
        end
    end

    local ImsdkHelper = import("IMSDKHelper")
    if ImsdkHelper then
        local Helper = ImsdkHelper.GetInstance()
        if Helper then
            local OriginalSetConfig = Helper.SetMSDKConfig
            if OriginalSetConfig then
                Helper.SetMSDKConfig = function(Self, Config, Save)
                    if Config and Config.IMSDK_TWITTER_LOGIN_USING_WEB then
                        if Config.IMSDK_TWITTER_LOGIN_USING_WEB ~= "false" then
                            Log("coerced IMSDK_TWITTER_LOGIN_USING_WEB -> false")
                        end
                        Config.IMSDK_TWITTER_LOGIN_USING_WEB = "false"
                    end
                    return OriginalSetConfig(Self, Config, Save)
                end
            end

            local OriginalNativeLogin = Helper.OriginalLogin
            if OriginalNativeLogin then
                Helper.OriginalLogin = function(Self, ExtraJson, Permissions, SkipLocalCacheCheck)
                    local Channel = Self:GetChannel()
                    if Channel and string.lower(Channel) == "twitter" then
                        Self:SetMSDKConfig({IMSDK_TWITTER_LOGIN_USING_WEB = "false"}, false)
                        Log("forced Twitter app login (OriginalLogin)")
                    end
                    return OriginalNativeLogin(Self, ExtraJson, Permissions, SkipLocalCacheCheck)
                end
            end
        end
    end
    Log("Twitter app-login hooks installed")
end)
)KCTWITTER";
