#pragma once
// Vehicle skin enable flag — toggled from ImGui menu
static bool g_KCVehicleEnabled = true;
