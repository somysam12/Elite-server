#pragma once
#include <map>
#include <vector>
#include <string>

// ═══════════════════════════════════════════════════════════════
//  GUN SKINS WITH ATTACHMENTS - USER SPECIFIED
// ═══════════════════════════════════════════════════════════════

// ASSAULT RIFLES
namespace AssaultRifles {
    
    // AKM - Sandspring Dominion
    const int AKM_SKIN = 9001;
    const int AKM_NAME = 101001;
    const std::string AKM_SKIN_NAME = "Sandspring Dominion";
    const int AKM_SCOPE = 5001;
    const int AKM_SILENCER = 5101;
    const int AKM_MAG = 5201;
    const int AKM_STOCK = 5301;
    const int AKM_GRIP = 5401;
    
    // M16A4 - Blood & Bones
    const int M16A4_SKIN = 9002;
    const int M16A4_NAME = 101002;
    const std::string M16A4_SKIN_NAME = "Blood & Bones";
    const int M16A4_SCOPE = 5002;
    const int M16A4_SILENCER = 5102;
    const int M16A4_MAG = 5202;
    const int M16A4_STOCK = 5302;
    const int M16A4_GRIP = 5402;
    
    // M416 - Crimson Skyblade
    const int M416_SKIN = 9003;
    const int M416_NAME = 101004;
    const std::string M416_SKIN_NAME = "Crimson Skyblade";
    const int M416_SCOPE = 5003;
    const int M416_SILENCER = 5103;
    const int M416_MAG = 5203;
    const int M416_STOCK = 5303;
    const int M416_GRIP = 5403;
    
    // SCAR-L - Bloodstained Nemesis
    const int SCARL_SKIN = 9004;
    const int SCARL_NAME = 101003;
    const std::string SCARL_SKIN_NAME = "Bloodstained Nemesis";
    const int SCARL_SCOPE = 5004;
    const int SCARL_SILENCER = 5104;
    const int SCARL_MAG = 5204;
    const int SCARL_STOCK = 5304;
    const int SCARL_GRIP = 5404;
    
    // AUG - Nyxen Rose
    const int AUG_SKIN = 9005;
    const int AUG_NAME = 101006;
    const std::string AUG_SKIN_NAME = "Nyxen Rose";
    const int AUG_SCOPE = 5005;
    const int AUG_SILENCER = 5105;
    const int AUG_MAG = 5205;
    const int AUG_STOCK = 5305;
    const int AUG_GRIP = 5405;
    
    // FAMAS - ORIGIN LUMEN
    const int FAMAS_SKIN = 9006;
    const int FAMAS_NAME = 101007;
    const std::string FAMAS_SKIN_NAME = "ORIGIN LUMEN";
    const int FAMAS_SCOPE = 5006;
    const int FAMAS_SILENCER = 5106;
    const int FAMAS_MAG = 5206;
    const int FAMAS_STOCK = 5306;
    const int FAMAS_GRIP = 5406;
    
    // GROZA - RYOMEN SUKUNA
    const int GROZA_SKIN = 9007;
    const int GROZA_NAME = 101005;
    const std::string GROZA_SKIN_NAME = "RYOMEN SUKUNA";
    const int GROZA_SCOPE = 5007;
    const int GROZA_SILENCER = 5107;
    const int GROZA_MAG = 5207;
    const int GROZA_STOCK = 5307;
    const int GROZA_GRIP = 5407;
    
    // QBZ - NETHER PHANTOM
    const int QBZ_SKIN = 9008;
    const int QBZ_NAME = 101007;
    const std::string QBZ_SKIN_NAME = "NETHER PHANTOM";
    const int QBZ_SCOPE = 5008;
    const int QBZ_SILENCER = 5108;
    const int QBZ_MAG = 5208;
    const int QBZ_STOCK = 5308;
    const int QBZ_GRIP = 5408;
    
    // M762 - Noctum Sunder
    const int M762_SKIN = 9009;
    const int M762_NAME = 101008;
    const std::string M762_SKIN_NAME = "Noctum Sunder";
    const int M762_SCOPE = 5009;
    const int M762_SILENCER = 5109;
    const int M762_MAG = 5209;
    const int M762_STOCK = 5309;
    const int M762_GRIP = 5409;
    
    // ASM ABAKAN - BLOODWING RAVEN
    const int ABAKAN_SKIN = 9010;
    const int ABAKAN_NAME = 101009;
    const std::string ABAKAN_SKIN_NAME = "BLOODWING RAVEN";
    const int ABAKAN_SCOPE = 5010;
    const int ABAKAN_SILENCER = 5110;
    const int ABAKAN_MAG = 5210;
    const int ABAKAN_STOCK = 5310;
    const int ABAKAN_GRIP = 5410;
    
    // HONEY BADGER - SACRED WITHERBLOOM
    const int HONEY_BADGER_SKIN = 9011;
    const int HONEY_BADGER_NAME = 101010;
    const std::string HONEY_BADGER_SKIN_NAME = "SACRED WITHERBLOOM";
    const int HONEY_BADGER_SCOPE = 5011;
    const int HONEY_BADGER_SILENCER = 5111;
    const int HONEY_BADGER_MAG = 5211;
    const int HONEY_BADGER_STOCK = 5311;
    const int HONEY_BADGER_GRIP = 5411;
    
    // ACE32 - MYSTIC KRAKEN
    const int ACE32_SKIN = 9012;
    const int ACE32_NAME = 101102;
    const std::string ACE32_SKIN_NAME = "MYSTIC KRAKEN";
    const int ACE32_SCOPE = 5012;
    const int ACE32_SILENCER = 5112;
    const int ACE32_MAG = 5212;
    const int ACE32_STOCK = 5312;
    const int ACE32_GRIP = 5412;
}

// SMGS
namespace SMGs {
    
    // UZI - GLACIER HAMMER
    const int UZI_SKIN = 9101;
    const int UZI_NAME = 102001;
    const std::string UZI_SKIN_NAME = "GLACIER HAMMER";
    const int UZI_SCOPE = 6001;
    const int UZI_SILENCER = 6101;
    const int UZI_MAG = 6201;
    
    // UMP - DRAGONFIRE
    const int UMP_SKIN = 9102;
    const int UMP_NAME = 102002;
    const std::string UMP_SKIN_NAME = "DRAGONFIRE";
    const int UMP_SCOPE = 6002;
    const int UMP_SILENCER = 6102;
    const int UMP_MAG = 6202;
    
    // PP19 BISON - SPECTRAL BYTE
    const int BISON_SKIN = 9103;
    const int BISON_NAME = 102005;
    const std::string BISON_SKIN_NAME = "SPECTRAL BYTE";
    const int BISON_SCOPE = 6003;
    const int BISON_SILENCER = 6103;
    const int BISON_MAG = 6203;
    
    // VECTOR - MECHADRAKE
    const int VECTOR_SKIN = 9104;
    const int VECTOR_NAME = 102003;
    const std::string VECTOR_SKIN_NAME = "MECHADRAKE";
    const int VECTOR_SCOPE = 6004;
    const int VECTOR_SILENCER = 6104;
    const int VECTOR_MAG = 6204;
}

// SNIPER RIFLES
namespace SniperRifles {
    
    // KAR98K - TITANIUM SHARK
    const int KAR98K_SKIN = 9201;
    const int KAR98K_NAME = 103001;
    const std::string KAR98K_SKIN_NAME = "TITANIUM SHARK";
    const int KAR98K_SCOPE = 7001;
    const int KAR98K_SILENCER = 7101;
    const int KAR98K_MAG = 7201;
    
    // M24 - PHAROAH MIGHT
    const int M24_SKIN = 9202;
    const int M24_NAME = 103002;
    const std::string M24_SKIN_NAME = "PHAROAH MIGHT";
    const int M24_SCOPE = 7002;
    const int M24_SILENCER = 7102;
    const int M24_MAG = 7202;
    
    // AWM - GODZILLA
    const int AWM_SKIN = 9203;
    const int AWM_NAME = 103003;
    const std::string AWM_SKIN_NAME = "GODZILLA";
    const int AWM_SCOPE = 7003;
    const int AWM_SILENCER = 7103;
    const int AWM_MAG = 7203;
    
    // MK14 - DRAKREIGN
    const int MK14_SKIN = 9204;
    const int MK14_NAME = 103007;
    const std::string MK14_SKIN_NAME = "DRAKREIGN";
    const int MK14_SCOPE = 7004;
    const int MK14_SILENCER = 7104;
    const int MK14_MAG = 7204;
    
    // AMR - CRIMSON EPHIALTES
    const int AMR_SKIN = 9205;
    const int AMR_NAME = 103012;
    const std::string AMR_SKIN_NAME = "CRIMSON EPHIALTES";
    const int AMR_SCOPE = 7005;
    const int AMR_SILENCER = 7105;
    const int AMR_MAG = 7205;
    
    // DSR - HYPERION SHIP
    const int DSR_SKIN = 9206;
    const int DSR_NAME = 103011;
    const std::string DSR_SKIN_NAME = "HYPERION SHIP";
    const int DSR_SCOPE = 7006;
    const int DSR_SILENCER = 7106;
    const int DSR_MAG = 7206;
    
    // SKS - LADY CARMINE
    const int SKS_SKIN = 9207;
    const int SKS_NAME = 103004;
    const std::string SKS_SKIN_NAME = "LADY CARMINE";
    const int SKS_SCOPE = 7007;
    const int SKS_SILENCER = 7107;
    const int SKS_MAG = 7207;
    
    // MINI14 - ICICLE
    const int MINI14_SKIN = 9208;
    const int MINI14_NAME = 103006;
    const std::string MINI14_SKIN_NAME = "ICICLE";
    const int MINI14_SCOPE = 7008;
    const int MINI14_SILENCER = 7108;
    const int MINI14_MAG = 7208;
}

// LIGHT MACHINE GUNS
namespace LMGs {
    
    // DP28 - BLOODBANE PARASITE
    const int DP28_SKIN = 9301;
    const int DP28_NAME = 105002;
    const std::string DP28_SKIN_NAME = "BLOODBANE PARASITE";
    const int DP28_SCOPE = 8001;
    const int DP28_SILENCER = 8101;
    const int DP28_MAG = 8201;
    
    // M63 - SKY HUNTRESS
    const int M63_SKIN = 9302;
    const int M63_NAME = 105003;
    const std::string M63_SKIN_NAME = "SKY HUNTRESS";
    const int M63_SCOPE = 8002;
    const int M63_SILENCER = 8102;
    const int M63_MAG = 8202;
    
    // M249 - PARTY PARCEL
    const int M249_SKIN = 9303;
    const int M249_NAME = 105001;
    const std::string M249_SKIN_NAME = "PARTY PARCEL";
    const int M249_SCOPE = 8003;
    const int M249_SILENCER = 8103;
    const int M249_MAG = 8203;
}

// DESIGNATED MARKSMAN RIFLES
namespace DMRs {
    
    // MK12 - Not specified, leaving default
    const int MK12_SKIN = 9401;
    const int MK12_NAME = 103100;
    const std::string MK12_SKIN_NAME = "Default MK12";
    const int MK12_SCOPE = 9001;
    const int MK12_SILENCER = 9101;
    const int MK12_MAG = 9201;
    
    // SLR - Not specified, leaving default
    const int SLR_SKIN = 9402;
    const int SLR_NAME = 103009;
    const std::string SLR_SKIN_NAME = "Default SLR";
    const int SLR_SCOPE = 9002;
    const int SLR_SILENCER = 9102;
    const int SLR_MAG = 9202;
}

// ═══════════════════════════════════════════════════════════════
//  GUN SKIN APPLY FUNCTION
// ═══════════════════════════════════════════════════════════════

inline void ApplyGunSkinWithAttachments(int gunID, int skinID, int scopeID, int silencerID, int magID) {
    // stub — gun skins applied via synData loop in _PostRenderHook
    (void)gunID; (void)skinID; (void)scopeID; (void)silencerID; (void)magID;
}
