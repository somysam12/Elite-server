package com.bgmi.utils;

@SuppressWarnings({"unused","deprecation"})
public final class MaaBahenKiClass {

    public static String[] GAALI = new String[]{
        "BHOSDIKE TU YE FILE DEKHNE AAYA HAI",
        "Madherchod yahan tera kuch nahi milega",
        "Chutiye classes.dex khola aur hero ban raha tha",
        "Behen ke lode teri maa jaanti hai tu kya kar raha hai",
        "Randi ke bacche developer ne sab socha tha pehle se",
        "Haramzade ye file padh ke kya milega tujhe bata",
        "Madarchod piracy karne se license nahi milta chutiya",
        "Bhosdike tujhe sharam nahi hai kya reverse engineer",
        "Gaand phata loser teri aukat nahi is APK ko crack karne ki",
        "Behenchod apna time waste kar raha hai yahan aake",
        "Madherchod sach bol tu crack karne aaya tha na sala",
        "Haramkhor teri maa proud nahi hogi ye dekh ke",
        "Chut ke phool license le le paise nahi hain kya tere",
        "Randi ki aulad agar aukaat hai to apna bana le tool",
        "Bhosdike ZERO KILL ANTI TAMPER HAI SAMJHA KYA",
        "Madarchod tujhe malum hai tera IP logger mein hai",
        "Betichod ye gaaliyan padh aur wapis ghar ja",
        "Gandu bhai thoda kaam kar zindagi mein",
        "Behenchod itna time lagaya classes.dex mein zero mila",
        "Madherchod apni maa se puchh license lene ke paise",
        "Bhosdike crack attempt CCTV mein recorded hai sala",
        "Chutiya teri behen bhi jaanti hai tu fail cracker hai",
        "Haramzade tujhe court notice aayega ek din samjhe",
        "Randi ke bacche congratulations tu detect ho gaya",
        "Madarchod ZeroKill hai jalbaloader nahi idiot",
        "Bhosdike teri maa ki aankh crack se kuch nahi milega",
        "Gaand ke keede developer ne trap rakha tha teri taraf",
        "Behenchod compiler bhi hans raha hai tujhpe",
        "Haramkhor ye string file padh le aur nikal yahan se",
        "MADHERCHOD ZERO KILL ANTI REVERSE ENGINEERING PROTECTED",
    };

    public static int checksum() {
        int h = 0;
        for (String s : GAALI) {
            if (s != null) h ^= s.hashCode();
        }
        return h;
    }

    public static String pick(int i) {
        return (i >= 0 && i < GAALI.length) ? GAALI[i] : "";
    }
}
