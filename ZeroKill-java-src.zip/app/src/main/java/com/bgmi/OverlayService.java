package com.bgmi;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import android.widget.SeekBar;
import android.widget.TextView;
import androidx.core.content.res.ResourcesCompat;

import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

@SuppressWarnings({"unused","deprecation"})
public class OverlayService extends Service {

    static final int BG          = Color.parseColor("#252525");
    static final int SURFACE     = Color.parseColor("#1A1A1A");
    static final int SURFACE_ALT = Color.parseColor("#1A1A1A");
    static final int CARD        = Color.parseColor("#1A1A1A");
    static final int BORDER      = Color.parseColor("#808080");
    static final int FIRE_DARK   = Color.parseColor("#704000");
    static final int FIRE_MID    = Color.parseColor("#B9850B");
    static final int FIRE_BRIGHT = Color.parseColor("#D4A00E");
    static final int FIRE_GLOW   = Color.parseColor("#FFB700");
    static final int ICE_DARK    = Color.parseColor("#004080");
    static final int ICE_MID     = Color.parseColor("#0090FF");
    static final int ICE_BRIGHT  = Color.parseColor("#0090FF");
    static final int ICE_GLOW    = Color.parseColor("#40B4FF");
    static final int GOLD        = Color.parseColor("#B9850B");
    static final int TXT         = Color.parseColor("#FFFFFF");
    static final int TXT_DIM     = Color.parseColor("#AAAAAA");
    static final int TXT_ACCENT  = Color.parseColor("#0090FF");

    static final String TCP_HOST = "127.0.0.1";
    static final int    TCP_PORT = 28900;

    private WindowManager wm;
    private View iconRoot;
    private View menuView;
    private WindowManager.LayoutParams iconParams, menuParams;
    private boolean menuOpen = false;

    private LinearLayout contentPanel;
    private LinearLayout tabVisual, tabAim, tabMisc;
    private String currentTab = "VISUAL";
    private Typeface fHeading, fBody, fMono;
    private Vibrator vibrator;
    private int lastMenuX = Integer.MIN_VALUE, lastMenuY = Integer.MIN_VALUE;

    private boolean stLine=false, stSkel=false, stHealth=false, stDist=false,
                    stName=false, stVehicle=false, stCount=false;
    private boolean stBtrack=false, stAimbot=false, stWide=false, stHideEsp=false;
    private boolean stFps120=false;
    private boolean stIgnBot=false, stIgnKnocked=false;
    private int stBtRange = 120;

    private int  selectedFps      = 60;
    private long frameIntervalMs  = 16L;
    private long lastDragUpdate   = 0;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        cleanupOverlay();
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    private void cleanupOverlay() {
        tcpRunning = false;
        try { cmdQueue.offer("ping"); } catch (Exception ignored) {}
        if (menuView != null) { try { wm.removeView(menuView); } catch (Exception ig) {} menuView = null; }
        if (iconRoot != null) { try { wm.removeView(iconRoot); } catch (Exception ig) {} iconRoot = null; }
    }

    @Override public void onCreate() {
        super.onCreate();
        loadFonts();
        stHideEsp = new com.bgmi.utils.Prefs(this).getBool("HIDE_ESP_PREF", false);
        selectedFps     = new com.bgmi.utils.Prefs(this).getInt("SELECTED_FPS", 60);
        frameIntervalMs = 1000L / selectedFps;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        startTcpSender();
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        addFloatingIcon();
    }

    private void loadFonts() {
        try {
            int id = getResources().getIdentifier("rajdhani_bold", "font", getPackageName());
            fHeading = id != 0 ? ResourcesCompat.getFont(this, id) : Typeface.DEFAULT_BOLD;
        } catch (Exception e) { fHeading = Typeface.DEFAULT_BOLD; }
        try {
            int id = getResources().getIdentifier("poppins_medium", "font", getPackageName());
            fBody = id != 0 ? ResourcesCompat.getFont(this, id) : Typeface.DEFAULT;
        } catch (Exception e) { fBody = Typeface.DEFAULT; }
        try {
            int id = getResources().getIdentifier("en_regular", "font", getPackageName());
            fMono = id != 0 ? ResourcesCompat.getFont(this, id) : Typeface.MONOSPACE;
        } catch (Exception e) { fMono = Typeface.MONOSPACE; }
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }
    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }
    private int res(String name, String type) {
        return getResources().getIdentifier(name, type, getPackageName());
    }

    // ── FLOATING ICON ────────────────────────────────────────────────────────
    private void addFloatingIcon() {
        FrameLayout iconWrap = new FrameLayout(this);

        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setColor(Color.TRANSPARENT);
        ring.setStroke(dp(0), Color.TRANSPARENT);

        ImageView img = new ImageView(this);
        img.setImageResource(res("zk_float_logo", "drawable"));
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setBackground(null);

        FrameLayout outerRing = new FrameLayout(this);
        outerRing.setBackground(ring);
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(dp(56), dp(56));
        ilp.gravity = Gravity.CENTER;
        outerRing.addView(img, ilp);
        iconWrap.addView(outerRing, new FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER));

        iconParams = new WindowManager.LayoutParams(
                dp(68), dp(68), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        iconParams.gravity = Gravity.TOP | Gravity.START;
        iconParams.x = dp(10); iconParams.y = dp(90);

        iconWrap.setOnTouchListener(new View.OnTouchListener() {
            int initX, initY; float tx, ty; boolean dragging; long downTime;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initX=iconParams.x; initY=iconParams.y;
                        tx=e.getRawX(); ty=e.getRawY();
                        dragging=false; downTime=System.currentTimeMillis();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx=e.getRawX()-tx, dy=e.getRawY()-ty;
                        if (!dragging && (Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5))) dragging=true;
                        if (dragging) {
                            iconParams.x=initX+(int)dx; iconParams.y=initY+(int)dy;
                            long now=System.currentTimeMillis();
                            if(now-lastDragUpdate>=frameIntervalMs){
                                lastDragUpdate=now;
                                try { wm.updateViewLayout(iconWrap,iconParams); } catch(Exception ig){}
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!dragging && System.currentTimeMillis()-downTime<300) {
                            vibrate();
                            toggleMenu();
                        }
                        return true;
                }
                return false;
            }
        });
        iconRoot = iconWrap;
        wm.addView(iconWrap, iconParams);
    }

    private void toggleMenu() {
        if (menuOpen) closeMenu();
        else { buildMenu(); menuOpen = true; }
    }

    private void vibrate() {
        try {
            if (vibrator == null || !vibrator.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                vibrator.vibrate(VibrationEffect.createOneShot(22, VibrationEffect.DEFAULT_AMPLITUDE));
            else
                vibrator.vibrate(22);
        } catch (Exception ignored) {}
    }

    private void closeMenu() {
        if (menuView != null) {
            if (menuParams != null) { lastMenuX = menuParams.x; lastMenuY = menuParams.y; }
            try { wm.removeView(menuView); } catch (Exception ignored) {}
            menuView = null;
        }
        menuOpen = false;
    }

    // ── BUILD MENU ───────────────────────────────────────────────────────────
    private void buildMenu() {
        // Outer container - BAT LOADER style: dark bg, gray border
        FrameLayout outer = new FrameLayout(this);
        GradientDrawable outerBg = new GradientDrawable();
        outerBg.setCornerRadius(dp(17));
        outerBg.setColor(BG);
        outerBg.setStroke(dp(1), Color.parseColor("#1E88E5"));
        outer.setBackground(outerBg);
        outer.setPadding(0, 0, 0, 0);

        // Inner body
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.HORIZONTAL);
        GradientDrawable innerBg = new GradientDrawable();
        innerBg.setCornerRadius(dp(5));
        innerBg.setColor(BG);
        inner.setBackground(innerBg);

        // Drag on outer
        outer.setOnTouchListener(new View.OnTouchListener() {
            int initX, initY; float tx, ty; long lastMs=0;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initX=menuParams.x; initY=menuParams.y;
                        tx=e.getRawX(); ty=e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        long now=System.currentTimeMillis();
                        if(now-lastMs<6) return true; lastMs=now;
                        menuParams.x=initX+(int)(e.getRawX()-tx);
                        menuParams.y=initY+(int)(e.getRawY()-ty);
                        try{ wm.updateViewLayout(menuView,menuParams); }catch(Exception ig){}
                        return true;
                }
                return false;
            }
        });

        // ── SIDEBAR ──────────────────────────────────────────────────────────
        LinearLayout sidebar = new LinearLayout(this);
        sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setGravity(Gravity.CENTER_HORIZONTAL);
        GradientDrawable sideBg = new GradientDrawable();
        sideBg.setCornerRadius(dp(5));
        sideBg.setColor(BG);
        sidebar.setBackground(sideBg);
        sidebar.setLayoutParams(new LinearLayout.LayoutParams(dp(100), LinearLayout.LayoutParams.MATCH_PARENT));
        sidebar.setPadding(dp(5), dp(10), dp(5), dp(10));

        // Logo — BAT LOADER style: bat_logo, simple, no ring
        ImageView logoImg = new ImageView(this);
        logoImg.setImageResource(res("bat_logo", "drawable"));
        logoImg.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams lblp = new LinearLayout.LayoutParams(dp(48), dp(48));
        lblp.gravity = Gravity.CENTER_HORIZONTAL;
        lblp.bottomMargin = dp(8);
        sidebar.addView(logoImg, lblp);

        // Tabs
        tabVisual = buildSideTab("Visual", "VISUAL", res("ic_eye_open", "drawable"));
        tabAim    = buildSideTab("Aim",    "AIM",    res("ic_flame",    "drawable"));
        tabMisc   = buildSideTab("Misc",   "MISC",   res("ic_check",    "drawable"));
        sidebar.addView(tabVisual);
        sidebar.addView(tabAim);
        sidebar.addView(tabMisc);
        inner.addView(sidebar);

        // ── RIGHT PANEL ───────────────────────────────────────────────────────
        LinearLayout rightPanel = new LinearLayout(this);
        rightPanel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setCornerRadius(dp(17));
        panelBg.setColor(BG);
        rightPanel.setBackground(panelBg);
        rightPanel.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));

        // ── HEADER BAR — BAT LOADER style ────────────────────────────────────
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable headerBg = new GradientDrawable();
        headerBg.setCornerRadius(dp(5));
        headerBg.setColor(BG);
        header.setBackground(headerBg);
        header.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48)));

        // Title
        TextView titleTv = new TextView(this);
        titleTv.setText("ZERO KILL");
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        titleTv.setTypeface(fHeading, Typeface.BOLD);
        titleTv.setTextColor(ICE_MID);
        titleTv.setShadowLayer(4f, 0, 0, 0xFF00BFFF);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tlp.leftMargin = dp(10);
        header.addView(titleTv, tlp);

        // Close button
        TextView closeX = new TextView(this);
        closeX.setText("X");
        closeX.setTextColor(TXT);
        closeX.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        closeX.setTypeface(fHeading, Typeface.BOLD);
        closeX.setGravity(Gravity.CENTER);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(48)));
        closeX.setOnClickListener(v -> closeMenu());
        header.addView(closeX);
        rightPanel.addView(header);

        // Scrollable content
        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        contentPanel = new LinearLayout(this);
        contentPanel.setOrientation(LinearLayout.VERTICAL);
        contentPanel.setPadding(dp(10), dp(8), dp(10), dp(10));
        scroll.addView(contentPanel, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        rightPanel.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));
        inner.addView(rightPanel);

        outer.addView(inner, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        int screenW = getResources().getDisplayMetrics().widthPixels;
        menuParams = new WindowManager.LayoutParams(
                (int)(screenW * 0.72f), dp(310), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        menuParams.gravity = Gravity.TOP | Gravity.START;
        if (lastMenuX != Integer.MIN_VALUE) {
            menuParams.x = lastMenuX;
            menuParams.y = lastMenuY;
        } else {
            menuParams.x = iconParams.x + dp(64);
            menuParams.y = iconParams.y;
        }

        menuView = outer;
        wm.addView(menuView, menuParams);
        selectTab(currentTab);
        if (stHideEsp) menuView.post(() -> updateHideEspWindows(true));
    }

    // ── SIDEBAR TAB ───────────────────────────────────────────────────────────
    private LinearLayout buildSideTab(String label, String key, int iconRes) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        rlp.bottomMargin = dp(5);
        row.setLayoutParams(rlp);

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(TXT);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setTypeface(fHeading, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);
        row.addView(tv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        row.setTag(tv);
        row.setOnClickListener(v -> { vibrate(); selectTab(key); });
        return row;
    }

    private void selectTab(String key) {
        currentTab = key;
        applyTabStyle(tabVisual, key.equals("VISUAL"));
        applyTabStyle(tabAim,    key.equals("AIM"));
        applyTabStyle(tabMisc,   key.equals("MISC"));
        contentPanel.removeAllViews();
        switch (key) {
            case "VISUAL": buildVisual(); break;
            case "AIM":    buildAim();    break;
            case "MISC":   buildMisc();   break;
        }
    }

    private void applyTabStyle(LinearLayout row, boolean active) {
        if (row == null) return;
        GradientDrawable bg;
        if (active) {
            bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Color.parseColor("#704000"), Color.parseColor("#B9850B")});
            bg.setCornerRadius(dp(24));
            bg.setStroke(dp(1), Color.parseColor("#FFD700"));
            if (row.getTag() instanceof TextView)
                ((TextView) row.getTag()).setTextColor(TXT);
        } else {
            bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Color.parseColor("#1565C0"), Color.parseColor("#0D47A1")});
            bg.setCornerRadius(dp(24));
            if (row.getTag() instanceof TextView)
                ((TextView) row.getTag()).setTextColor(TXT);
        }
        row.setBackground(bg);
    }

    // ── TAB PILL HEADER (like "Combat" in reference) ─────────────────────────
    private void tabPill(String text) {
        TextView pill = new TextView(this);
        pill.setText(text);
        pill.setTextColor(TXT);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        pill.setTypeface(fHeading, Typeface.BOLD);
        pill.setLetterSpacing(0.10f);
        pill.setGravity(Gravity.CENTER);
        pill.setPadding(0, dp(8), 0, dp(8));
        pill.setShadowLayer(6f, 0f, 0f, FIRE_GLOW);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{FIRE_DARK, Color.parseColor("#6B0018")});
        bg.setCornerRadius(dp(15));
        pill.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(10);
        contentPanel.addView(pill, lp);
    }

    // ── COLUMN HEADER (ESP Visuals / World Visuals) ───────────────────────────
    private void colHeader(LinearLayout col, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(ICE_BRIGHT);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        t.setTypeface(fHeading, Typeface.BOLD);
        t.setLetterSpacing(0.14f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(5), 0, dp(5));
        t.setShadowLayer(6f, 0f, 0f, ICE_MID);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(7));
        bg.setColor(Color.parseColor("#1565C0"));
        bg.setStroke(dp(1), Color.parseColor("#1E88E5"));
        t.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(2); lp.bottomMargin = dp(8);
        t.setLayoutParams(lp);
        col.addView(t);
    }

    // ── TOGGLE ROW ────────────────────────────────────────────────────────────
    private void checkRow(LinearLayout parent, String label, boolean initial, final CB cb) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(40));
        rlp.bottomMargin = dp(6);
        row.setLayoutParams(rlp);
        row.setPadding(dp(4), 0, dp(4), 0);
        row.setClickable(true);
        row.setFocusable(true);

        // background card
        GradientDrawable rowBg = new GradientDrawable();
        rowBg.setShape(GradientDrawable.RECTANGLE);
        rowBg.setCornerRadius(dp(8));
        rowBg.setColor(Color.parseColor("#1E1E1E"));
        rowBg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        row.setBackground(rowBg);

        // label
        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(TXT);
        lbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        lbl.setTypeface(fBody);
        lbl.setClickable(false);
        lbl.setFocusable(false);
        lbl.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        // pill toggle
        FrameLayout pill = buildTogglePill(initial);

        final boolean[] st = {initial};
        row.setOnClickListener(v -> {
            st[0] = !st[0];
            applyTogglePill(pill, st[0]);
            vibrate();
            cb.onToggle(st[0]);
        });

        row.addView(lbl);
        row.addView(pill);
        parent.addView(row, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private FrameLayout buildTogglePill(boolean on) {
        FrameLayout pill = new FrameLayout(this);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(44), dp(24));
        plp.leftMargin = dp(6);
        pill.setLayoutParams(plp);
        pill.setClickable(false);
        pill.setFocusable(false);

        View knob = new View(this);
        GradientDrawable knobBg = new GradientDrawable();
        knobBg.setShape(GradientDrawable.OVAL);
        knobBg.setColor(Color.WHITE);
        FrameLayout.LayoutParams klp = new FrameLayout.LayoutParams(dp(18), dp(18));
        klp.gravity = Gravity.CENTER_VERTICAL | (on ? Gravity.END : Gravity.START);
        klp.leftMargin = on ? 0 : dp(3);
        klp.rightMargin = on ? dp(3) : 0;
        knob.setBackground(knobBg);
        knob.setLayoutParams(klp);
        knob.setTag("knob");

        applyTogglePill(pill, on);
        pill.addView(knob);
        return pill;
    }

    private void applyTogglePill(FrameLayout pill, boolean on) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(100));
        bg.setColor(on ? Color.parseColor("#0090FF") : Color.parseColor("#333333"));
        pill.setBackground(bg);
        // reposition knob
        View knob = pill.findViewWithTag("knob");
        if (knob != null) {
            FrameLayout.LayoutParams klp = new FrameLayout.LayoutParams(dp(18), dp(18));
            klp.gravity = Gravity.CENTER_VERTICAL | (on ? Gravity.END : Gravity.START);
            klp.leftMargin = on ? 0 : dp(3);
            klp.rightMargin = on ? dp(3) : 0;
            knob.setLayoutParams(klp);
        }
    }

    // kept for legacy callers; returns the pill so state can be forced externally
    private FrameLayout checkRowRet(LinearLayout parent, String label, boolean initial, final CB cb) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(40));
        rlp.bottomMargin = dp(6);
        row.setLayoutParams(rlp);
        row.setPadding(dp(4), 0, dp(4), 0);
        row.setClickable(true);
        row.setFocusable(true);
        GradientDrawable rowBg = new GradientDrawable();
        rowBg.setShape(GradientDrawable.RECTANGLE);
        rowBg.setCornerRadius(dp(8));
        rowBg.setColor(Color.parseColor("#1E1E1E"));
        rowBg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        row.setBackground(rowBg);

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(TXT);
        lbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        lbl.setTypeface(fBody);
        lbl.setClickable(false);
        lbl.setFocusable(false);
        lbl.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout pill = buildTogglePill(initial);
        final boolean[] st = {initial};
        row.setOnClickListener(v -> {
            st[0] = !st[0];
            applyTogglePill(pill, st[0]);
            vibrate();
            cb.onToggle(st[0]);
        });
        row.addView(lbl);
        row.addView(pill);
        parent.addView(row);
        return pill;
    }

    // stub kept so applyCheck() callers in old code don't break at compile time
    private void applyCheck(Object box, boolean on) {}

    private TextView makeSliderLabel(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(TXT_DIM);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        t.setTypeface(fBody);
        return t;
    }

    private SeekBar makeSeekBar(int max, int progress) {
        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(progress);
        sb.getThumb().setColorFilter(new android.graphics.PorterDuffColorFilter(
                ICE_MID, android.graphics.PorterDuff.Mode.SRC_IN));
        sb.getProgressDrawable().setColorFilter(new android.graphics.PorterDuffColorFilter(
                ICE_MID, android.graphics.PorterDuff.Mode.SRC_IN));
        return sb;
    }



    private TextView makeActionBtn(String label, boolean active) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(TXT);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setTypeface(fHeading, Typeface.BOLD);
        t.setLetterSpacing(0.08f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(9), dp(8), dp(9));
        styleActionBtn(t, active);
        return t;
    }

    private void styleActionBtn(TextView t, boolean active) {
        GradientDrawable bg;
        if (active) {
            bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{FIRE_DARK, FIRE_MID});
            bg.setCornerRadius(dp(12));
            bg.setStroke(dp(1.5f), FIRE_BRIGHT);
            t.setShadowLayer(5f, 0f, 0f, FIRE_GLOW);
        } else {
            bg = new GradientDrawable();
            bg.setCornerRadius(dp(12));
            bg.setColor(SURFACE);
            bg.setStroke(dp(1), BORDER);
            t.setShadowLayer(0f, 0f, 0f, 0);
        }
        t.setBackground(bg);
    }

    interface CB { void onToggle(boolean on); }

    // ── VISUAL TAB ────────────────────────────────────────────────────────────
    private void buildVisual() {
        tabPill("ESP");
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.HORIZONTAL);
        grid.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout colL = newCol(dp(6), dp(5));
        LinearLayout colR = newCol(dp(5), dp(6));

        colHeader(colL, "ESP Visuals");
        checkRow(colL, "ESP Line",    stLine,    on->{ stLine=on;    sendTcp("line="+(on?1:0)); });
        checkRow(colL, "Skeleton",    stSkel,    on->{ stSkel=on;    sendTcp("skeleton="+(on?1:0)); });
        checkRow(colL, "Health Bar",  stHealth,  on->{ stHealth=on;  sendTcp("health="+(on?1:0)); });
        checkRow(colL, "Distance",    stDist,    on->{ stDist=on;    sendTcp("distance="+(on?1:0)); });
        checkRow(colL, "Name Tag",    stName,    on->{ stName=on;    sendTcp("name="+(on?1:0)); });

        colHeader(colR, "World");
        checkRow(colR, "Vehicle",     stVehicle, on->{ stVehicle=on; sendTcp("vehicle="+(on?1:0)); });
        checkRow(colR, "Box ESP",     stCount,   on->{ stCount=on;   sendTcp("count="+(on?1:0)); });

        grid.addView(colL); grid.addView(colR);
        contentPanel.addView(grid);
    }

    // ── AIM TAB ───────────────────────────────────────────────────────────────
    private void buildAim() {
        tabPill("Combat");

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        checkRow(col, "Aimbot",         stAimbot,    on -> { stAimbot = on;    sendTcp("aimbot=" + (on ? 1 : 0)); });
        checkRow(col, "Ignore Bot",     stIgnBot,    on -> { stIgnBot = on;    sendTcp("ignorebot=" + (on ? 1 : 0)); });
        checkRow(col, "Ignore Knocked", stIgnKnocked,on -> { stIgnKnocked = on;sendTcp("ignoreknocked=" + (on ? 1 : 0)); });

        // Aimbot Range slider
        LinearLayout rangeBlock = new LinearLayout(this);
        rangeBlock.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rbp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rbp.topMargin = dp(4); rbp.bottomMargin = dp(6);
        rangeBlock.setLayoutParams(rbp);
        GradientDrawable rbbg = new GradientDrawable();
        rbbg.setCornerRadius(dp(8));
        rbbg.setColor(Color.parseColor("#1E1E1E"));
        rbbg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        rangeBlock.setBackground(rbbg);
        rangeBlock.setPadding(dp(8), dp(6), dp(8), dp(6));

        LinearLayout rangeLblRow = new LinearLayout(this);
        rangeLblRow.setOrientation(LinearLayout.HORIZONTAL);
        rangeLblRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView rangeTitle = makeSliderLabel("Aimbot Range");
        rangeTitle.setTextColor(TXT);
        rangeTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        rangeTitle.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView rangeVal = makeSliderLabel(stBtRange + "m");
        rangeVal.setTextColor(ICE_MID);
        rangeLblRow.addView(rangeTitle);
        rangeLblRow.addView(rangeVal);
        rangeBlock.addView(rangeLblRow);

        SeekBar rangeSb = makeSeekBar(150, stBtRange);
        rangeSb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                stBtRange = v;
                rangeVal.setText(v + "m");
                sendTcp("btrange=" + v);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
        rangeBlock.addView(rangeSb, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        col.addView(rangeBlock);

        View spacer = new View(this);
        col.addView(spacer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(14)));
        contentPanel.addView(col);
    }

    // ── MISC TAB ──────────────────────────────────────────────────────────────
    private void buildMisc() {
        tabPill("Settings");

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.HORIZONTAL);
        grid.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        LinearLayout colL = newCol(dp(6), dp(5));
        LinearLayout colR = newCol(dp(5), dp(6));

        checkRow(colL, "120 FPS",      stFps120,  on -> { stFps120 = on;  sendTcp("fps120=" + (on ? 1 : 0)); });
        checkRow(colR, "Wide View",    stWide,    on -> { stWide = on;    sendTcp("wideview=" + (on ? 1 : 0)); });
        checkRow(colL, "Stream Mode",  stHideEsp, on -> { stHideEsp = on; sendTcp("hideesp=" + (on ? 1 : 0)); updateHideEspWindows(on); });

        grid.addView(colL); grid.addView(colR);
        contentPanel.addView(grid);
    }

    // ── SCREENSHOT PROTECTION ─────────────────────────────────────────────────
    private void updateHideEspWindows(boolean on) {
        applySkipScreenshot(iconRoot, iconParams, on);
        applySkipScreenshot(menuView, menuParams, on);
    }

    private void applySkipScreenshot(View v, WindowManager.LayoutParams p, boolean on) {
        if (v == null || p == null) return;
        boolean skipApplied = false;
        try {
            Object vri = View.class.getMethod("getViewRootImpl").invoke(v);
            if (vri != null) {
                Object sc = vri.getClass().getMethod("getSurfaceControl").invoke(vri);
                if (sc != null) {
                    Class<?> scClass = Class.forName("android.view.SurfaceControl");
                    Class<?> txClass = Class.forName("android.view.SurfaceControl$Transaction");
                    Object tx = txClass.getConstructor().newInstance();
                    java.lang.reflect.Method setSkip =
                            txClass.getMethod("setSkipScreenshot", scClass, boolean.class);
                    setSkip.invoke(tx, sc, on);
                    txClass.getMethod("apply").invoke(tx);
                    skipApplied = true;
                }
            }
        } catch (Throwable ignored) {}
        if (!skipApplied) {
            final int SECURE = WindowManager.LayoutParams.FLAG_SECURE;
            if (on) p.flags |= SECURE; else p.flags &= ~SECURE;
            try { wm.updateViewLayout(v, p); } catch (Exception ignored) {}
        }
    }

    // ── HELPERS ───────────────────────────────────────────────────────────────
    private LinearLayout newCol(int padStart, int padEnd) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(padStart, 0, padEnd, 0);
        col.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return col;
    }

    // ── TCP SENDER ────────────────────────────────────────────────────────────
    private final java.util.concurrent.LinkedBlockingQueue<String> cmdQueue =
            new java.util.concurrent.LinkedBlockingQueue<>();
    private volatile boolean tcpRunning = true;

    private void startTcpSender() {
        Thread t = new Thread(() -> {
            while (tcpRunning) {
                Socket s = null;
                try {
                    s = new Socket();
                    s.connect(new InetSocketAddress(TCP_HOST, TCP_PORT), 1500);
                    s.setTcpNoDelay(true);
                    s.setKeepAlive(true);
                    OutputStream out = s.getOutputStream();
                    while (tcpRunning) {
                        String cmd = cmdQueue.take();
                        try {
                            out.write((cmd + "\n").getBytes("UTF-8"));
                            out.flush();
                        } catch (Exception writeErr) {
                            cmdQueue.offer(cmd);
                            break;
                        }
                    }
                } catch (Exception connErr) {
                    try { Thread.sleep(500); } catch (Exception ignored) {}
                } finally {
                    if (s != null) try { s.close(); } catch (Exception ig) {}
                }
            }
        }, "ZkTcpSender");
        t.setDaemon(true);
        t.start();
    }

    private void sendTcp(final String cmd) {
        cmdQueue.offer(cmd);
    }

    @Override public void onDestroy() {
        super.onDestroy();
        cleanupOverlay();
    }
}
