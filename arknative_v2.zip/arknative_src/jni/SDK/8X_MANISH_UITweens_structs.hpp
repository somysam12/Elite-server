#pragma once

// SDK GENERATE BY TELEGRAM ;- (@Manish8x) (4.6.0 -- 64Bit) DM TO BUY TOOL AVLABLE FOR SELL
// Telegram:- @Manish8x
// GEN ONWed Sep 16 07:42:26 2026
 
namespace SDK
{
//---------------------By Tg @Manish8x---------------------------
//Enums
//---------------------By Tg @Manish8x---------------------------

// Enum UITweens.EUITweenEaseType
enum class EUITweenEaseType : uint8_t
{
	EUITweenEaseType__Linear       = 0,
	EUITweenEaseType__EaseInQuad   = 1,
	EUITweenEaseType__EaseOutQuad  = 2,
	EUITweenEaseType__EaseInOutQuad = 3,
	EUITweenEaseType__EaseOutInQuad = 4,
	EUITweenEaseType__EaseInCubic  = 5,
	EUITweenEaseType__EaseOutCubic = 6,
	EUITweenEaseType__EaseInOutCubic = 7,
	EUITweenEaseType__EaseOutInCubic = 8,
	EUITweenEaseType__EaseInQuart  = 9,
	EUITweenEaseType__EaseOutQuart = 10,
	EUITweenEaseType__EaseInOutQuart = 11,
	EUITweenEaseType__EaseOutInQuart = 12,
	EUITweenEaseType__EaseInQuint  = 13,
	EUITweenEaseType__EaseOutQuint = 14,
	EUITweenEaseType__EaseInOutQuint = 15,
	EUITweenEaseType__EaseOutInQuint = 16,
	EUITweenEaseType__EaseInSine   = 17,
	EUITweenEaseType__EaseOutSine  = 18,
	EUITweenEaseType__EaseInOutSine = 19,
	EUITweenEaseType__EaseOutInSine = 20,
	EUITweenEaseType__EaseInExpo   = 21,
	EUITweenEaseType__EaseOutExpo  = 22,
	EUITweenEaseType__EaseInOutExpo = 23,
	EUITweenEaseType__EaseOutInExpo = 24,
	EUITweenEaseType__EaseInCirc   = 25,
	EUITweenEaseType__EaseOutCirc  = 26,
	EUITweenEaseType__EaseInOutCirc = 27,
	EUITweenEaseType__EaseOutInCirc = 28,
	EUITweenEaseType__EaseInElastic = 29,
	EUITweenEaseType__EaseOutElastic = 30,
	EUITweenEaseType__EaseInOutElastic = 31,
	EUITweenEaseType__EaseOutInElastic = 32,
	EUITweenEaseType__EaseInBack   = 33,
	EUITweenEaseType__EaseOutBack  = 34,
	EUITweenEaseType__EaseInOutBack = 35,
	EUITweenEaseType__EaseOutInBack = 36,
	EUITweenEaseType__EaseInBounce = 37,
	EUITweenEaseType__EaseOutBounce = 38,
	EUITweenEaseType__EaseInOutBounce = 39,
	EUITweenEaseType__EaseOutInBounce = 40,
	EUITweenEaseType__EUITweenEaseType_MAX = 41
};



}

