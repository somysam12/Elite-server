#!/bin/bash
# build_v4.sh — ZeroKill v4 four-pass build
#
#  LIB PASS 1  : build libv4.so (placeholder lib hash)
#  LIB STRIP 1 : strip Hikari .comment from libv4.so
#  LIB HASH    : compute sentinel-masked SHA256 → patch kLEX in LibIntegrity.cpp
#  LIB PASS 2  : rebuild libv4.so with real kLEX → strip → copy to OUT
#
#  APK PASS 1  : Gradle assembleRelease (placeholder APK hash)
#  APK STRIP 1 : strip_and_resign (removes Hikari .comment from libZeroKill.so + re-sign)
#  APK HASH    : compute APK hash → patch kEX in APK's ApkIntegrity.cpp
#  APK PASS 2  : Gradle assembleRelease (real kEX) → strip_and_resign → final APK

set -e

NDK=/usr/lib/android-sdk/ndk/24.0.8215888/ndk-build
OBJCOPY=/usr/lib/android-sdk/ndk/24.0.8215888/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-objcopy
JNI_DIR=/tmp/zk_jni_check
APK_SRC=/tmp/zerokill_work/sigma_src/SIGMAxVISION_JAVA_4_6
JNILIBS=$APK_SRC/app/src/main/jniLibs/arm64-v8a
OUT=/home/user/Elite-server

KS=$APK_SRC/app/zen.jks
KS_PASS="TWINZZZGODD@6"
KS_ALIAS="SLAYTWINZ@66"

# ── XOR key (must match kK1/kK2 in LibIntegrity.cpp and ApkIntegrity.cpp) ────
KEY_HEX="A37FC211E8553D901BA64EF782296CD45A3871BC0E93F42768AB1D56E39F40CC"

# ── Strip Hikari .comment from libv4.so standalone ───────────────────────────
strip_lib() {
    local LIB="$JNI_DIR/libs/arm64-v8a/libv4.so"
    $OBJCOPY --remove-section=.comment "$LIB" 2>/dev/null || true
    echo "[+] Stripped .comment from libv4.so"
}

# ── Strip Hikari .comment from all .so inside APK, re-sign ───────────────────
strip_and_resign() {
    local APK=$1
    local TMP
    TMP=$(mktemp -d)
    local UNSIGNED="$TMP/unsigned.apk"
    local ALIGNED="$TMP/aligned.apk"

    echo "[*] Stripping Hikari .comment from APK libs ..."
    unzip -q "$APK" -d "$TMP/apk_contents"

    find "$TMP/apk_contents/lib" -name '*.so' 2>/dev/null | while read -r so; do
        $OBJCOPY --remove-section=.comment "$so" 2>/dev/null || true
        echo "[+] stripped: $(basename "$so")"
    done

    # Remove old signature — will re-sign below
    rm -rf "$TMP/apk_contents/META-INF"

    # Repack: .so files stored uncompressed (Android requirement)
    cd "$TMP/apk_contents"
    find lib -name '*.so' -print0 2>/dev/null | xargs -0 zip -0 -q "$UNSIGNED" -- 2>/dev/null || true
    # Compress everything else except META-INF and already-added libs
    find . -not -path './META-INF/*' -not -path './lib/*/*.so' -not -name '.' -type f \
        | sort | xargs zip -q "$UNSIGNED" -- 2>/dev/null || true
    # Any non-.so files under lib/
    find lib -not -name '*.so' -type f 2>/dev/null | xargs zip -q "$UNSIGNED" -- 2>/dev/null || true
    cd -

    zipalign -f 4 "$UNSIGNED" "$ALIGNED"

    apksigner sign --ks "$KS" --ks-pass "pass:$KS_PASS" \
              --ks-key-alias "$KS_ALIAS" --key-pass "pass:$KS_PASS" \
              --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
              --out "$APK" "$ALIGNED"

    rm -rf "$TMP"
    echo "[+] Re-signed APK (Hikari strings removed)"
}

# ── Patch lib hash into LibIntegrity.cpp ─────────────────────────────────────
patch_lib_hash() {
    local LIB=$1
    local HASH_HEX
    HASH_HEX=$(python3 "$JNI_DIR/compute_lib_hash.py" "$LIB")
    echo "[*] Lib hash (sentinel-masked): $HASH_HEX"

    python3 - "$HASH_HEX" "$KEY_HEX" "$JNI_DIR/jni/LibIntegrity.cpp" <<'PYEOF'
import sys, re

hash_hex = sys.argv[1].strip()
key_hex  = sys.argv[2].strip()
filepath = sys.argv[3]

h = bytes.fromhex(hash_hex)
k = bytes.fromhex(key_hex)
xd = bytes(a ^ b for a, b in zip(h, k))

def fmt_bytes(b):
    rows = []
    for i in range(0, 32, 8):
        chunk = b[i:i+8]
        rows.append('    ' + ','.join(f'0x{x:02X}' for x in chunk))
    return ',\n'.join(rows)

new_block = f"""                // BEGIN_LIB_HASH_PLACEHOLDER
{fmt_bytes(xd)}
    // END_LIB_HASH_PLACEHOLDER"""

with open(filepath) as f:
    src = f.read()

src = re.sub(
    r'// BEGIN_LIB_HASH_PLACEHOLDER.*?// END_LIB_HASH_PLACEHOLDER',
    new_block,
    src,
    flags=re.DOTALL
)
with open(filepath, 'w') as f:
    f.write(src)

print(f"[+] Patched kLEX into LibIntegrity.cpp")
PYEOF
}

# ── Patch APK hash into APK's ApkIntegrity.cpp ───────────────────────────────
patch_apk_hash() {
    local APK=$1
    local APK_JNI="/tmp/zerokill_work/sigma_src/SIGMAxVISION_JAVA_4_6/app/src/main/jni/ApkIntegrity.cpp"
    local HASH_HEX
    HASH_HEX=$(python3 "$JNI_DIR/compute_apk_hash.py" "$APK")
    echo "[*] APK hash: $HASH_HEX"

    python3 - "$HASH_HEX" "$KEY_HEX" "$APK_JNI" <<'PYEOF'
import sys, re

hash_hex = sys.argv[1].strip()
key_hex  = sys.argv[2].strip()
filepath = sys.argv[3]

h = bytes.fromhex(hash_hex)
k = bytes.fromhex(key_hex)
xd = bytes(a ^ b for a, b in zip(h, k))

def fmt_bytes(b):
    rows = []
    for i in range(0, 32, 8):
        chunk = b[i:i+8]
        rows.append('    ' + ','.join(f'0x{x:02X}' for x in chunk))
    return ',\n'.join(rows)

new_block = f"""    // BEGIN_HASH_PLACEHOLDER
{fmt_bytes(xd)}
    // END_HASH_PLACEHOLDER"""

with open(filepath) as f:
    src = f.read()

src = re.sub(
    r'// BEGIN_HASH_PLACEHOLDER.*?// END_HASH_PLACEHOLDER',
    new_block,
    src,
    flags=re.DOTALL
)
with open(filepath, 'w') as f:
    f.write(src)

print(f"[+] Patched kEX into APK ApkIntegrity.cpp")
PYEOF
}

# ── Build libv4.so (NDK only, NOT copied to jniLibs) ─────────────────────────
build_ndk() {
    echo "[*] NDK build → libv4.so ..."
    cd "$JNI_DIR"
    $NDK NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=./jni/Android.mk NDK_APPLICATION_MK=./jni/Application.mk 2>&1 \
        | grep -E "Compile|SharedLib|Install|error:|warning:|Error"
    echo "[+] libv4.so built (not bundled in APK)"
}

# ── Build APK via Gradle ──────────────────────────────────────────────────────
build_apk() {
    echo "[*] Gradle assembleRelease ..."
    cd "$APK_SRC"
    ./gradlew assembleRelease 2>&1 | grep -E "FrozenFire|Signed|BUILD|error:|FAILED|Task :"
    cp "$APK_SRC/app/build/outputs/apk/release/app-release_protected.apk" "$OUT/zerokill_v4.apk"
    echo "[+] APK → $OUT/zerokill_v4.apk"
}

# ═══════════════════════════════════════════════════════════════════════════════
#  LIB PASS 1 — build libv4.so with placeholder kLEX (all zeros)
# ═══════════════════════════════════════════════════════════════════════════════
echo "═══ LIB PASS 1: placeholder lib hash ═══"
build_ndk
strip_lib

# ═══════════════════════════════════════════════════════════════════════════════
#  COMPUTE LIB HASH & PATCH
# ═══════════════════════════════════════════════════════════════════════════════
echo "═══ Patching lib hash into LibIntegrity.cpp ═══"
patch_lib_hash "$JNI_DIR/libs/arm64-v8a/libv4.so"

# ═══════════════════════════════════════════════════════════════════════════════
#  LIB PASS 2 — rebuild with real kLEX embedded
# ═══════════════════════════════════════════════════════════════════════════════
echo "═══ LIB PASS 2: final lib with embedded hash ═══"
build_ndk
strip_lib
cp "$JNI_DIR/libs/arm64-v8a/libv4.so" "$OUT/libv4.so"
echo "[+] libv4.so → $OUT/libv4.so"

# ═══════════════════════════════════════════════════════════════════════════════
#  APK PASS 1 — build APK with placeholder kEX
# ═══════════════════════════════════════════════════════════════════════════════
echo "═══ APK PASS 1: placeholder APK hash ═══"
build_apk
strip_and_resign "$OUT/zerokill_v4.apk"

# ═══════════════════════════════════════════════════════════════════════════════
#  COMPUTE APK HASH & PATCH
# ═══════════════════════════════════════════════════════════════════════════════
echo "═══ Patching APK hash into APK ApkIntegrity.cpp ═══"
patch_apk_hash "$OUT/zerokill_v4.apk"

# ═══════════════════════════════════════════════════════════════════════════════
#  APK PASS 2 — rebuild with real kEX embedded
# ═══════════════════════════════════════════════════════════════════════════════
echo "═══ APK PASS 2: final APK with embedded hash ═══"
build_apk
strip_and_resign "$OUT/zerokill_v4.apk"

echo ""
echo "═══════════════════════════════════════════════"
echo "v4 BUILD COMPLETE"
echo "  APK : $OUT/zerokill_v4.apk"
echo "  LIB : $OUT/libv4.so"
echo "═══════════════════════════════════════════════"
