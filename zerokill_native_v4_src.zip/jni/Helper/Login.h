#pragma once
#include "KCSecure.h"    // KC_PANEL_URL() — obfuscated URL at runtime

#include <curl/curl.h>
#include <openssl/md5.h>
#include <jni.h>
#include <string>
#include <ctime>
#include <cstring>
#include <cstdlib>

// ── Global declarations ───────────────────────────────────────────────────
bool        bconfiger = false;
bool        bValid    = false;
bool        isLogin   = false;
std::string EXP;
std::string g_Token, g_Auth;
android_app *g_App = 0;

// ══════════════════════════════════════════════════════════════════════════
//  XOR SHADOW PROTECTION
//  Patching the plain bool/string variables alone is not enough.
//  Every read goes through a getter that cross-checks the shadow.
//  Hikari BCF+CFF on getters makes them hard to trace/patch.
// ══════════════════════════════════════════════════════════════════════════

// ── bValid shadow ─────────────────────────────────────────────────────────
#define _BV_XK  0xDEADC0DEu
volatile uint32_t __bv_shadow = _BV_XK;
__attribute__((noinline, annotate("bcf"), annotate("cff")))
static void _bv_set(bool v) {
    bValid      = v;
    __bv_shadow = v ? (_BV_XK ^ 1u) : _BV_XK;
}
__attribute__((noinline, annotate("bcf"), annotate("cff")))
static bool _bv_get() {
    volatile uint32_t s = __bv_shadow;
    volatile bool     b = bValid;
    return b && ((s ^ _BV_XK) == 1u);
}

// ── bconfiger shadow ──────────────────────────────────────────────────────
#define _BC_XK  0xBEEFCAFEu
volatile uint32_t __bc_shadow = _BC_XK;
__attribute__((noinline, annotate("bcf"), annotate("cff")))
static void _bc_set(bool v) {
    bconfiger   = v;
    __bc_shadow = v ? (_BC_XK ^ 1u) : _BC_XK;
}
__attribute__((noinline, annotate("bcf"), annotate("cff")))
static bool _bc_get() {
    volatile uint32_t s = __bc_shadow;
    volatile bool     b = bconfiger;
    return b && ((s ^ _BC_XK) == 1u);
}

// ── isLogin shadow ────────────────────────────────────────────────────────
#define _IL_XK  0xCAFED00Du
volatile uint32_t __il_shadow = _IL_XK;
__attribute__((noinline, annotate("bcf"), annotate("cff")))
static void _il_set(bool v) {
    isLogin     = v;
    __il_shadow = v ? (_IL_XK ^ 1u) : _IL_XK;
}
__attribute__((noinline, annotate("bcf"), annotate("cff")))
static bool _il_get() {
    volatile uint32_t s = __il_shadow;
    volatile bool     b = isLogin;
    return b && ((s ^ _IL_XK) == 1u);
}

// ── g_Token / g_Auth CRC32 shadows ────────────────────────────────────────
// Cracker patching the raw std::string internals also invalidates the shadow.
#define _STR_XK  0x13579BDFu
static volatile uint32_t __token_shadow = 0;
static volatile uint32_t __auth_shadow  = 0;

__attribute__((noinline))
static uint32_t _str_crc32(const std::string &s) {
    uint32_t crc = 0xFFFFFFFFu;
    for (unsigned char c : s) {
        crc ^= c;
        for (int j = 0; j < 8; j++)
            crc = (crc >> 1) ^ (0xEDB88320u & -(crc & 1u));
    }
    return crc ^ 0xFFFFFFFFu;
}
__attribute__((noinline, annotate("bcf"), annotate("cff")))
static void _tok_set(const std::string &v) {
    g_Token        = v;
    __token_shadow = _str_crc32(v) ^ _STR_XK;
}
__attribute__((noinline, annotate("bcf"), annotate("cff")))
static void _auth_set(const std::string &v) {
    g_Auth        = v;
    __auth_shadow = _str_crc32(v) ^ _STR_XK;
}
__attribute__((noinline, annotate("bcf"), annotate("cff")))
static bool _tok_auth_valid() {
    // Tokens must be non-empty, equal, and shadows must match current values
    if (g_Token.empty() || g_Auth.empty()) return false;
    volatile uint32_t ts = __token_shadow;
    volatile uint32_t as = __auth_shadow;
    volatile uint32_t tc = _str_crc32(g_Token) ^ _STR_XK;
    volatile uint32_t ac = _str_crc32(g_Auth)  ^ _STR_XK;
    return (ts == tc) && (as == ac) && (g_Token == g_Auth);
}

// Expiry unix timestamp from server reply.
//   -1 = unknown/not set   ·   0 = lifetime   ·   >0 = expiry unix ts
long long g_KC_ExpUnix = -1;

// ─────────────────────────────────────────────────────────────────────────

std::string getClipboardText() {
    if (!g_App) return "";
    auto activity = g_App->activity;
    if (!activity) return "";
    auto vm = activity->vm;
    if (!vm) return "";
    auto object = activity->clazz;
    if (!object) return "";

    std::string result;
    JNIEnv *env;
    vm->AttachCurrentThread(&env, 0);
    {
        auto ContextClass = env->FindClass("android/content/Context");
        auto getSystemServiceMethod = env->GetMethodID(ContextClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
        auto str = env->NewStringUTF("clipboard");
        auto clipboardManager = env->CallObjectMethod(object, getSystemServiceMethod, str);
        env->DeleteLocalRef(str);
        auto ClipboardManagerClass = env->FindClass("android/content/ClipboardManager");
        auto getText = env->GetMethodID(ClipboardManagerClass, "getText", "()Ljava/lang/CharSequence;");
        auto CharSequenceClass = env->FindClass("java/lang/CharSequence");
        auto toStringMethod = env->GetMethodID(CharSequenceClass, "toString", "()Ljava/lang/String;");
        auto text = env->CallObjectMethod(clipboardManager, getText);
        if (text) {
            str = (jstring) env->CallObjectMethod(text, toStringMethod);
            result = env->GetStringUTFChars(str, 0);
            env->DeleteLocalRef(str);
            env->DeleteLocalRef(text);
        }
        env->DeleteLocalRef(CharSequenceClass);
        env->DeleteLocalRef(ClipboardManagerClass);
        env->DeleteLocalRef(clipboardManager);
        env->DeleteLocalRef(ContextClass);
    }
    vm->DetachCurrentThread();
    return result;
}

const char *GetAndroidID(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(StrEnc("`L+&0^[S+-:J^$,r9q92(as", "\x01\x22\x4F\x54\x5F\x37\x3F\x7C\x48\x42\x54\x3E\x3B\x4A\x58\x5D\x7A\x1E\x57\x46\x4D\x19\x07", 23).c_str());
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass, StrEnc("E8X\\7r7ys_Q%JS+L+~", "\x22\x5D\x2C\x1F\x58\x1C\x43\x1C\x1D\x2B\x03\x40\x39\x3C\x47\x3A\x4E\x0C", 18).c_str(), StrEnc("8^QKmj< }5D:9q7f.BXkef]A*GYLNg}B!/L", "\x10\x77\x1D\x2A\x03\x0E\x4E\x4F\x14\x51\x6B\x59\x56\x1F\x43\x03\x40\x36\x77\x28\x0A\x08\x29\x24\x44\x33\x0B\x29\x3D\x08\x11\x34\x44\x5D\x77", 35).c_str());
    jclass settingSecureClass = env->FindClass(StrEnc("T1yw^BCF^af&dB_@Raf}\\FS,zT~L(3Z\"", "\x35\x5F\x1D\x05\x31\x2B\x27\x69\x2E\x13\x09\x50\x0D\x26\x3A\x32\x7D\x32\x03\x09\x28\x2F\x3D\x4B\x09\x70\x2D\x29\x4B\x46\x28\x47", 32).c_str());
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass, StrEnc("e<F*J5c0Y", "\x02\x59\x32\x79\x3E\x47\x0A\x5E\x3E", 9).c_str(), StrEnc("$6*%R*!XO\"m18o,0S!*`uI$IW)l_/_knSdlRiO1T`2sH|Ouy__^}%Y)JsQ:-\"(2_^-$i{?H", "\x0C\x7A\x4B\x4B\x36\x58\x4E\x31\x2B\x0D\x0E\x5E\x56\x1B\x49\x5E\x27\x0E\x69\x0F\x1B\x3D\x41\x27\x23\x7B\x09\x2C\x40\x33\x1D\x0B\x21\x5F\x20\x38\x08\x39\x50\x7B\x0C\x53\x1D\x2F\x53\x1C\x01\x0B\x36\x31\x39\x46\x0C\x15\x43\x2B\x05\x30\x15\x41\x43\x46\x55\x70\x0D\x59\x56\x00\x15\x58\x73", 71).c_str());
    auto obj = env->CallObjectMethod(context, getContentResolverMethod);
    auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj, env->NewStringUTF(StrEnc("ujHO)8OfOE", "\x14\x04\x2C\x3D\x46\x51\x2B\x39\x26\x21", 10).c_str()));
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceModel(JNIEnv *env) {
    jclass buildClass = env->FindClass(StrEnc("m5I{GKGWBP-VOxkA", "\x0C\x5B\x2D\x09\x28\x22\x23\x78\x2D\x23\x02\x14\x3A\x11\x07\x25", 16).c_str());
    jfieldID modelId = env->GetStaticFieldID(buildClass, StrEnc("|}[q:", "\x31\x32\x1F\x34\x76", 5).c_str(), StrEnc(".D:C:ETZ1O-Ib&^h.Y", "\x62\x2E\x5B\x35\x5B\x6A\x38\x3B\x5F\x28\x02\x1A\x16\x54\x37\x06\x49\x62", 18).c_str());
    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceBrand(JNIEnv *env) {
    jclass buildClass = env->FindClass(StrEnc("0iW=2^>0zTRB!B90", "\x51\x07\x33\x4F\x5D\x37\x5A\x1F\x15\x27\x7D\x00\x54\x2B\x55\x54", 16).c_str());
    jfieldID modelId = env->GetStaticFieldID(buildClass, StrEnc("@{[FP", "\x02\x29\x1A\x08\x14", 5).c_str(), StrEnc(".D:C:ETZ1O-Ib&^h.Y", "\x62\x2E\x5B\x35\x5B\x6A\x38\x3B\x5F\x28\x02\x1A\x16\x54\x37\x06\x49\x62", 18).c_str());
    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetPackageName(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(StrEnc("`L+&0^[S+-:J^$,r9q92(as", "\x01\x22\x4F\x54\x5F\x37\x3F\x7C\x48\x42\x54\x3E\x3B\x4A\x58\x5D\x7A\x1E\x57\x46\x4D\x19\x07", 23).c_str());
    jmethodID getPackageNameId = env->GetMethodID(contextClass, StrEnc("YN4DaP)!{wRGN}", "\x3E\x2B\x40\x14\x00\x33\x42\x40\x1C\x12\x1C\x26\x23\x18", 14).c_str(), StrEnc("VnpibEspM(b]<s#[9cQD", "\x7E\x47\x3C\x03\x03\x33\x12\x5F\x21\x49\x0C\x3A\x13\x20\x57\x29\x50\x0D\x36\x7F", 20).c_str());
    auto str = (jstring) env->CallObjectMethod(context, getPackageNameId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceUniqueIdentifier(JNIEnv *env, const char *uuid) {
    jclass uuidClass = env->FindClass(StrEnc("B/TxJ=3BZ_]SFx", "\x28\x4E\x22\x19\x65\x48\x47\x2B\x36\x70\x08\x06\x0F\x3C", 14).c_str());
    auto len = strlen(uuid);
    jbyteArray myJByteArray = env->NewByteArray(len);
    env->SetByteArrayRegion(myJByteArray, 0, len, (jbyte *) uuid);
    jmethodID nameUUIDFromBytesMethod = env->GetStaticMethodID(uuidClass, StrEnc("P6LV|'0#A+zQmoat,", "\x3E\x57\x21\x33\x29\x72\x79\x67\x07\x59\x15\x3C\x2F\x16\x15\x11\x5F", 17).c_str(), StrEnc("sW[\"Q[W3,7@H.vT0) xB", "\x5B\x0C\x19\x0B\x1D\x31\x36\x45\x4D\x18\x35\x3C\x47\x1A\x7B\x65\x7C\x69\x3C\x79", 20).c_str());
    jmethodID toStringMethod = env->GetMethodID(uuidClass, StrEnc("2~5292eW", "\x46\x11\x66\x46\x4B\x5B\x0B\x30", 8).c_str(), StrEnc("P$BMc' #j?<:myTh_*h0", "\x78\x0D\x0E\x27\x02\x51\x41\x0C\x06\x5E\x52\x5D\x42\x2A\x20\x1A\x36\x44\x0F\x0B", 20).c_str());
    auto obj = env->CallStaticObjectMethod(uuidClass, nameUUIDFromBytesMethod, myJByteArray);
    auto str = (jstring) env->CallObjectMethod(obj, toStringMethod);
    return env->GetStringUTFChars(str, 0);
}

// ── UUID cache: Check() stores it so nativeGetSerial() can return it ─────
static std::string g_zk_uuid_cache;

// ── Simple curl write callback ────────────────────────────────────────────
static size_t _zk_curl_write(char *ptr, size_t sz, size_t nmemb, std::string *out) {
    out->append(ptr, sz * nmemb);
    return sz * nmemb;
}

// ── JSON helpers ──────────────────────────────────────────────────────────

// Finds "key":"value" — returns value string
static std::string _zk_json_str(const std::string &json, const char *key) {
    std::string k = std::string("\"") + key + "\"";
    auto pos = json.find(k);
    if (pos == std::string::npos) return "";
    pos = json.find(':', pos + k.size());
    if (pos == std::string::npos) return "";
    pos = json.find('"', pos + 1);
    if (pos == std::string::npos) return "";
    auto end = json.find('"', pos + 1);
    if (end == std::string::npos) return "";
    return json.substr(pos + 1, end - pos - 1);
}

// Finds "key": N — returns integer
static long long _zk_json_int(const std::string &json, const char *key) {
    std::string k = std::string("\"") + key + "\"";
    auto pos = json.find(k);
    if (pos == std::string::npos) return -1;
    pos = json.find(':', pos + k.size());
    if (pos == std::string::npos) return -1;
    pos++;
    while (pos < json.size() && (json[pos] == ' ' || json[pos] == '\t')) pos++;
    if (pos >= json.size()) return -1;
    return strtoll(json.c_str() + pos, nullptr, 10);
}

// Finds "key": true/false — returns bool
static bool _zk_json_bool(const std::string &json, const char *key) {
    std::string k = std::string("\"") + key + "\"";
    auto pos = json.find(k);
    if (pos == std::string::npos) return false;
    pos = json.find(':', pos + k.size());
    if (pos == std::string::npos) return false;
    pos++;
    while (pos < json.size() && (json[pos] == ' ' || json[pos] == '\t')) pos++;
    if (pos + 4 > json.size()) return false;
    return json.substr(pos, 4) == "true";
}

// Extracts nested object string for "key": { ... }
static std::string _zk_json_obj(const std::string &json, const char *key) {
    std::string k = std::string("\"") + key + "\"";
    auto pos = json.find(k);
    if (pos == std::string::npos) return "";
    pos = json.find(':', pos + k.size());
    if (pos == std::string::npos) return "";
    pos = json.find('{', pos + 1);
    if (pos == std::string::npos) return "";
    int depth = 1;
    size_t end = pos + 1;
    while (end < json.size() && depth > 0) {
        if      (json[end] == '{') depth++;
        else if (json[end] == '}') depth--;
        end++;
    }
    if (depth != 0) return "";
    return json.substr(pos, end - pos);
}

// Inline MD5 via OpenSSL — returns lowercase hex string
static std::string _zk_md5(const std::string &s) {
    unsigned char hash[MD5_DIGEST_LENGTH];
    char tmp[4];
    MD5_CTX ctx;
    MD5_Init(&ctx);
    MD5_Update(&ctx, s.c_str(), s.length());
    MD5_Final(hash, &ctx);
    std::string result;
    result.reserve(32);
    for (unsigned char c : hash) {
        sprintf(tmp, "%02x", c);
        result += tmp;
    }
    return result;
}

// ── POST to ZeroKill panel — KingCheats token-based verification ──────────
// Panel returns: {"status": true, "data": {"token":"...", "EXP":"...", "rng": <ts>}}
// or:            {"status": false, "reason": "EXPIRED"|"MAX_DEVICE"|...}
static std::string ZK_DoLogin(const std::string &url,
                               const char *userKey,
                               const std::string &serial,
                               const std::string & /*pkgName*/) {
    for (int attempt = 0; attempt < 3; attempt++) {
        CURL *curl = curl_easy_init();
        if (!curl) return "CONNECTION_FAILED";

        std::string resp;
        char *escapedKey = curl_easy_escape(curl, userKey, 0);
        std::string fields = std::string("game=PUBG&user_key=")
                           + (escapedKey ? escapedKey : userKey)
                           + "&serial=" + serial;
        if (escapedKey) curl_free(escapedKey);

        struct curl_slist *headers = nullptr;
        headers = curl_slist_append(headers, "Accept: application/json");
        headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");
        headers = curl_slist_append(headers, "Charset: UTF-8");

        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_easy_setopt(curl, CURLOPT_URL,           url.c_str());
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_DEFAULT_PROTOCOL, "https");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER,    headers);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS,    fields.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, _zk_curl_write);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA,     &resp);
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT,       20L);
        curl_easy_setopt(curl, CURLOPT_NOSIGNAL,      1L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYSTATUS, 0L);
        curl_easy_setopt(curl, CURLOPT_USERAGENT,     "");

        CURLcode rc = curl_easy_perform(curl);
        curl_slist_free_all(headers);
        curl_easy_cleanup(curl);

        if (rc != CURLE_OK || resp.empty()) {
            if (attempt < 2) { usleep(800000); continue; }
            return "CONNECTION_FAILED";
        }

        bool statusOk = _zk_json_bool(resp, "status");

        if (statusOk) {
            std::string dataObj = _zk_json_obj(resp, "data");
            if (dataObj.empty()) {
                if (attempt < 2) { usleep(800000); continue; }
                return "CONNECTION_FAILED";
            }

            std::string token  = _zk_json_str(dataObj, "token");
            std::string expStr = _zk_json_str(dataObj, "EXP");
            long long   rngt   = _zk_json_int(dataObj, "rng");

            // Freshness check — server timestamp must be within 30s
            if (rngt + 30 <= (long long)time(nullptr)) {
                if (attempt < 2) { usleep(800000); continue; }
                return "CONNECTION_FAILED";
            }

            // Token = MD5("PUBG-" + key + "-" + UUID + "-" + license_secret)
            static constexpr auto _lic = OBF_S("Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E");
            std::string authInput = std::string("PUBG-") + userKey + "-" + serial + "-" + _lic.str();
            std::string computedAuth = _zk_md5(authInput);

            _tok_set(token);
            _auth_set(computedAuth);
            _bv_set(_tok_auth_valid());

            if (!_bv_get()) {
                _bc_set(false);
                g_KC_ExpUnix  = -1;
                EXP           = "";
                return "INVALID";
            }

            // Parse expiry
            if (!expStr.empty() && expStr != "NULL" && expStr != "0") {
                EXP = expStr;
                struct tm tmv = {};
                char *parsed = strptime(expStr.c_str(), "%Y-%m-%d", &tmv);
                if (parsed) {
                    tmv.tm_hour = 23; tmv.tm_min = 59; tmv.tm_sec = 59;
                    g_KC_ExpUnix = (long long)mktime(&tmv);
                } else {
                    g_KC_ExpUnix = 0;
                    EXP = "Lifetime";
                }
            } else {
                g_KC_ExpUnix = 0;
                EXP = "Lifetime";
            }

            _bc_set(true);
            return "OK";
        }

        // status == false — genuine rejection, no retry
        g_KC_ExpUnix = -1;
        EXP          = "";
        _bv_set(false);
        _bc_set(false);
        _tok_set("");
        _auth_set("");

        std::string reason = _zk_json_str(resp, "reason");
        if (reason == "MAINTENANCE") return "MAINTENANCE";
        if (reason == "EXPIRED")     return "EXPIRED";
        if (reason == "MAX_DEVICE")  return "MAX_DEVICE";
        if (reason == "CLONE")       return "CLONE";
        if (reason == "BLOCKED")     return "BLOCKED";
        return "INVALID";
    }
    return "CONNECTION_FAILED";
}

// ─────────────────────────────────────────────────────────────────────────

std::string Login(const char *userKey) {
    if (!g_App)                  return "Internal Error";
    auto activity = g_App->activity;
    if (!activity)               return "Internal Error";
    auto vm = activity->vm;
    if (!vm)                     return "Internal Error";
    auto object = activity->clazz;
    if (!object)                 return "Internal Error";

    JNIEnv *env;
    vm->AttachCurrentThread(&env, 0);
    std::string hwid = userKey;
    hwid += GetAndroidID(env, object);
    hwid += GetDeviceModel(env);
    hwid += GetDeviceBrand(env);
    std::string UUID    = GetDeviceUniqueIdentifier(env, hwid.c_str());
    std::string pkgName = (Gamepackage && Gamepackage[0]) ? Gamepackage : "com.bgmi";
    vm->DetachCurrentThread();

    g_zk_uuid_cache = UUID;
    return ZK_DoLogin(KC_PANEL_URL(), userKey, UUID, pkgName);
}

// Called when loader already wrote serial to lic file — use loader's UUID directly.
std::string LoginWithSerial(const char *userKey, const std::string &preComputedUUID) {
    g_zk_uuid_cache = preComputedUUID;
    std::string pkgName = (Gamepackage && Gamepackage[0]) ? Gamepackage : "com.bgmi";
    return ZK_DoLogin(KC_PANEL_URL(), userKey, preComputedUUID, pkgName);
}

// ── JNI exports for com.bgmi.LoginActivity ────────────────────────────────
// Java: private static native String Check(Context ctx, String key);
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_LoginActivity_Check(JNIEnv *env, jclass, jobject mContext, jstring mUserKey) {
    const char *user_key = env->GetStringUTFChars(mUserKey, nullptr);
    std::string hwid = user_key;
    hwid += GetAndroidID(env, mContext);
    hwid += GetDeviceModel(env);
    hwid += GetDeviceBrand(env);
    std::string UUID = GetDeviceUniqueIdentifier(env, hwid.c_str());
    g_zk_uuid_cache = UUID;
    std::string result = ZK_DoLogin(KC_PANEL_URL(), user_key, UUID, "com.bgmi");
    env->ReleaseStringUTFChars(mUserKey, user_key);
    return env->NewStringUTF(result.c_str());
}

// Java: private static native String nativeGetSerial();
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_LoginActivity_nativeGetSerial(JNIEnv *env, jclass) {
    return env->NewStringUTF(g_zk_uuid_cache.c_str());
}
