// LibIntegrity.cpp — ZeroKill v4 lib tamper detection
// Hashes own .so bytes with kLEX region zeroed (sentinel-masked).
// If tampered after distribution, crash on next load.
// All string literals AES-encrypted at compile time by Hikari -enable-strcry

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <string>
#include <android/log.h>
#include <openssl/sha.h>

#define ZL(fmt,...) ((void)0)
#define ZE(fmt,...) ((void)0)

// ── DECOY — visible bait for crackers ────────────────────────────────────────
// char-array literals: Hikari strcry does NOT encrypt these — intended as bait
[[maybe_unused]] static volatile char g_DLib[]  = {'l','i','b','v','4','.','s','o','\0'};
[[maybe_unused]] static volatile char g_DChk[]  = {'l','i','b','_','h','a','s','h','_','o','k','\0'};
[[maybe_unused]] static volatile char g_DFail[] = {'l','i','b','_','t','a','m','p','e','r','e','d','\0'};

[[maybe_unused, gnu::noinline]]
static bool _DecoyCheck(const char* s) {
    volatile bool r = (strcmp(s, (const char*)g_DLib) == 0);
    return r;
}

// ══════════════════════════════════════════════════════════════════════════════
//  SENTINEL — 16 distinctive bytes that uniquely bracket kLEX in the binary.
//  Build tool and runtime both find this, zero the 32 kLEX bytes after it,
//  then SHA256. This makes the hash stable regardless of kLEX content.
// ══════════════════════════════════════════════════════════════════════════════
static const uint8_t kS1[16] = {
    0xF0,0x0D,0xCA,0xFE,0xDE,0xAD,0xBE,0xEF,
    0x13,0x37,0xC0,0xDE,0x5A,0xF3,0x7A,0x91
};

// ── XOR KEY (same split key as ApkIntegrity) ─────────────────────────────────
static const uint8_t kK1[16] = {
    0xA3,0x7F,0xC2,0x11,0xE8,0x55,0x3D,0x90,
    0x1B,0xA6,0x4E,0xF7,0x82,0x29,0x6C,0xD4
};
static const uint8_t kK2[16] = {
    0x5A,0x38,0x71,0xBC,0x0E,0x93,0xF4,0x27,
    0x68,0xAB,0x1D,0x56,0xE3,0x9F,0x40,0xCC
};

// kLEX[i] = SHA256_stable(libv4.so)[i] ^ key[i] — patched by build_v4.sh
// SHA256_stable = SHA256 computed with these 32 bytes zeroed (sentinel-masked)
static const uint8_t kLEX[32] = {
                // BEGIN_LIB_HASH_PLACEHOLDER
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
    // END_LIB_HASH_PLACEHOLDER
};

// ── Decode expected hash ──────────────────────────────────────────────────────
__attribute__((noinline, annotate("bcf"), annotate("cff"), annotate("vmobf")))
static void _DecodeLib(uint8_t out[32]) {
    volatile uint8_t k[32];
    for (int i = 0; i < 16; i++) k[i]    = kK1[i];
    for (int i = 0; i < 16; i++) k[16+i] = kK2[i];
    for (int i = 0; i < 32; i++) out[i]  = kLEX[i] ^ k[i];
    volatile uint8_t sink = 0;
    for (int i = 0; i < 32; i++) sink ^= k[i];
    (void)sink;
}

// ── Find own .so path from /proc/self/maps ────────────────────────────────────
// Plain string literals here — Hikari strcry encrypts each one
__attribute__((noinline))
static std::string _FindSelf() {
    FILE* f = fopen("/proc/self/maps","r"); if (!f) return "";
    char line[512]; std::string res;
    while (fgets(line,sizeof(line),f)) {
        if (!strstr(line,"libv4.so")) continue;
        char* sl = strchr(line,'/'); if (!sl) continue;
        char* en = sl;
        while (*en && *en!='\n' && *en!='\r' && *en!=' ' && *en!='(') en++;
        *en = '\0'; res = sl; break;
    }
    fclose(f); return res;
}

// ── Hash the .so with kLEX bytes zeroed (sentinel search) ────────────────────
// Finds kS1 in the file data, zeros 32 bytes after it, then SHA256.
// Result is stable: same hash whether kLEX contains placeholder or real value.
__attribute__((noinline, annotate("bcf"), annotate("cff")))
static bool _HashLib(const char* path, uint8_t out[32]) {
    FILE* f = fopen(path,"rb"); if (!f) return false;

    fseek(f, 0, SEEK_END);
    long fsz = ftell(f);
    rewind(f);
    if (fsz <= 0) { fclose(f); return false; }

    uint8_t* buf = (uint8_t*)malloc((size_t)fsz);
    if (!buf) { fclose(f); return false; }

    if ((long)fread(buf, 1, (size_t)fsz, f) != fsz) {
        free(buf); fclose(f); return false;
    }
    fclose(f);

    // Find sentinel kS1 — zero the 32 bytes (kLEX) that follow it
    long lex_off = -1;
    for (long i = 0; i <= fsz - (long)sizeof(kS1) - 32; i++) {
        if (memcmp(buf + i, kS1, sizeof(kS1)) == 0) {
            lex_off = i + (long)sizeof(kS1);
            break;
        }
    }
    if (lex_off < 0) { free(buf); return false; }  // sentinel not found → abort
    memset(buf + lex_off, 0, 32);

    SHA256_CTX ctx; SHA256_Init(&ctx);
    SHA256_Update(&ctx, buf, (size_t)fsz);
    SHA256_Final(out, &ctx);
    free(buf);
    return true;
}

// ── PUBLIC ENTRY ─────────────────────────────────────────────────────────────
__attribute__((noinline, annotate("bcf"), annotate("cff"), annotate("vmobf")))
void CheckLibIntegrity() {
    std::string self = _FindSelf();
    if (self.empty()) { abort(); }

    uint8_t computed[32]{};
    if (!_HashLib(self.c_str(), computed)) { abort(); }

    uint8_t expected[32]{};
    _DecodeLib(expected);

    volatile uint32_t diff = 0;
    for (int i = 0; i < 32; i++)
        diff |= (uint32_t)(computed[i] ^ expected[i]);

    if (diff != 0) {
        volatile int* p = nullptr;
        *p = 0;
        __builtin_unreachable();
    }
}
