LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := libdobby
LOCAL_SRC_FILES := Dobby/libraries/$(TARGET_ARCH_ABI)/libdobby.a
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)/Dobby/include
include $(PREBUILT_STATIC_LIBRARY)



PREBUILT_DIR := prebuilt/fuck

include $(CLEAR_VARS)
LOCAL_MODULE := tools
LOCAL_SRC_FILES := $(PREBUILT_DIR)/tools.a
include $(PREBUILT_STATIC_LIBRARY)


include $(CLEAR_VARS)
LOCAL_MODULE := libARMP_PUBGM_Basic
LOCAL_SRC_FILES := SDK/prebuilt/ARMP_PUBGM_Basic.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libARMP_PUBGM_Basic_functions
LOCAL_SRC_FILES := SDK/prebuilt/ARMP_PUBGM_Basic_functions.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libARMP_PUBGM_CoreUObject_functions
LOCAL_SRC_FILES := SDK/prebuilt/ARMP_PUBGM_CoreUObject_functions.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libARMP_PUBGM_Engine_functions
LOCAL_SRC_FILES := SDK/prebuilt/ARMP_PUBGM_Engine_functions.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libARMP_PUBGM_ShadowTrackerExtra_functions
LOCAL_SRC_FILES := SDK/prebuilt/ARMP_PUBGM_ShadowTrackerExtra_functions.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libARMP_PUBGM_Client_functions
LOCAL_SRC_FILES := SDK/prebuilt/ARMP_PUBGM_Client_functions.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := KittyMemory
LOCAL_SRC_FILES := $(PREBUILT_DIR)/KittyMemory/KittyMemory.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := MemoryPatch
LOCAL_SRC_FILES := $(PREBUILT_DIR)/KittyMemory/MemoryPatch.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := MemoryBackup
LOCAL_SRC_FILES := $(PREBUILT_DIR)/KittyMemory/MemoryBackup.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := KittyUtils
LOCAL_SRC_FILES := $(PREBUILT_DIR)/KittyMemory/KittyUtils.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := hde64
LOCAL_SRC_FILES := $(PREBUILT_DIR)/Substrate/hde64.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := SubstrateHook
LOCAL_SRC_FILES := $(PREBUILT_DIR)/Substrate/SubstrateHook.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := SubstrateDebug
LOCAL_SRC_FILES := $(PREBUILT_DIR)/Substrate/SubstrateDebug.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := SubstratePosixMemory
LOCAL_SRC_FILES := $(PREBUILT_DIR)/Substrate/SubstratePosixMemory.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := base64
LOCAL_SRC_FILES := $(PREBUILT_DIR)/base64/base64.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := ElfImg
LOCAL_SRC_FILES := $(PREBUILT_DIR)/ElfImg.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := fake_dlfcn
LOCAL_SRC_FILES := $(PREBUILT_DIR)/fake_dlfcn.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := android_native_app_glue
LOCAL_SRC_FILES := $(PREBUILT_DIR)/android_native_app_glue.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := plthook_elf
LOCAL_SRC_FILES := $(PREBUILT_DIR)/plthook_elf.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := And64InlineHook
LOCAL_SRC_FILES := $(PREBUILT_DIR)/And64InlineHook/And64InlineHook.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := selfmade
LOCAL_SRC_FILES := $(PREBUILT_DIR)/libbgmi_selfmade.a
include $(PREBUILT_STATIC_LIBRARY)





include $(CLEAR_VARS)
LOCAL_MODULE := libcurl_prebuilt
LOCAL_SRC_FILES := curl/curl-android-$(TARGET_ARCH_ABI)/lib/libcurl.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libssl_prebuilt
LOCAL_SRC_FILES := curl/openssl-android-$(TARGET_ARCH_ABI)/lib/libssl.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libcrypto_prebuilt
LOCAL_SRC_FILES := curl/openssl-android-$(TARGET_ARCH_ABI)/lib/libcrypto.a
include $(PREBUILT_STATIC_LIBRARY)

# ── ApkIntegrity: maximum Hikari protection (strcry + heavy BCF/CFF) ──────
include $(CLEAR_VARS)
LOCAL_MODULE    := v4_integrity
LOCAL_CPPFLAGS  := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w -std=c++17
LOCAL_CPPFLAGS  += -Wno-error=c++11-narrowing -fno-rtti -fno-exceptions -fpermissive
LOCAL_CPPFLAGS  += -mllvm -enable-bcfobf -mllvm -enable-cffobf
LOCAL_CPPFLAGS  += -mllvm -enable-subobf -mllvm -enable-indibran
LOCAL_CPPFLAGS  += -mllvm -enable-strcry -mllvm -enable-funcwra
LOCAL_CPPFLAGS  += -mllvm -bcf_loop=3 -mllvm -bcf_prob=70
LOCAL_C_INCLUDES += $(LOCAL_PATH)/curl/openssl-android-$(TARGET_ARCH_ABI)/include
LOCAL_SRC_FILES := LibIntegrity.cpp
include $(BUILD_STATIC_LIBRARY)

# ── Main shared library ───────────────────────────────────────────────────
include $(CLEAR_VARS)
LOCAL_MODULE    := v4

LOCAL_CFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w
LOCAL_CFLAGS += -fno-rtti -fno-exceptions -fpermissive
LOCAL_CPPFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w -Werror -s -std=c++17
LOCAL_CPPFLAGS += -Wno-error=c++11-narrowing -fms-extensions -fno-rtti -fno-exceptions -fpermissive
# Hikari LLVM — BCF/CFF/SUB on main module (no strcry/indibran/funcwra: too heavy for large main.cpp)
LOCAL_CPPFLAGS += -mllvm -enable-bcfobf -mllvm -enable-cffobf
LOCAL_CPPFLAGS += -mllvm -enable-subobf
LOCAL_CPPFLAGS += -mllvm -bcf_loop=1 -mllvm -bcf_prob=30
LOCAL_LDFLAGS := -Wl,--gc-sections,--strip-all -llog -Wl,--exclude-libs,ALL
LOCAL_ARM_MODE := arm

LOCAL_C_INCLUDES += $(LOCAL_PATH)/curl/curl-android-$(TARGET_ARCH_ABI)/include
LOCAL_C_INCLUDES += $(LOCAL_PATH)/curl/openssl-android-$(TARGET_ARCH_ABI)/include

LOCAL_SRC_FILES :=  main.cpp \
                    TelegramIntegration.cpp \
                    TcpFeatureServer.cpp \
                    imgui/imgui.cpp \
                    imgui/imgui_draw.cpp \
                    imgui/imgui_tables.cpp \
                    imgui/imgui_widgets.cpp \
                    imgui/backends/imgui_impl_android.cpp \
                    imgui/backends/imgui_impl_opengl3.cpp \

LOCAL_C_INCLUDES += $(LOCAL_PATH)/imgui
LOCAL_C_INCLUDES += $(LOCAL_PATH)/imgui/backends
LOCAL_CPPFLAGS += -DIMGUI_IMPL_OPENGL_ES3

LOCAL_CPP_FEATURES := exceptions

LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv2 -lGLESv3 -lGLESv1_CM -lz

LOCAL_STATIC_LIBRARIES := v4_integrity libdobby And64InlineHook ElfImg fake_dlfcn android_native_app_glue plthook_elf tools base64 SubstrateDebug SubstrateHook hde64 SubstratePosixMemory KittyMemory MemoryPatch MemoryBackup KittyUtils libARMP_PUBGM_Basic libARMP_PUBGM_Basic_functions libARMP_PUBGM_CoreUObject_functions libARMP_PUBGM_Engine_functions libARMP_PUBGM_ShadowTrackerExtra_functions libARMP_PUBGM_Client_functions selfmade libcurl_prebuilt libssl_prebuilt libcrypto_prebuilt

include $(BUILD_SHARED_LIBRARY)
