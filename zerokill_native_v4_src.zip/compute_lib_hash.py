#!/usr/bin/env python3
"""compute_lib_hash.py — SHA256 of libv4.so with kLEX sentinel region zeroed.

Finds the 16-byte sentinel kS1 in the binary, zeros the 32 bytes (kLEX) that
follow it, then SHA256s the whole file. This gives a stable hash that is the
same whether kLEX holds a placeholder or the real embedded value.

Usage:
    python3 compute_lib_hash.py <libv4.so_path>
Output:
    64-char hex SHA256
"""
import sys, hashlib

SENTINEL = bytes([
    0xF0,0x0D,0xCA,0xFE,0xDE,0xAD,0xBE,0xEF,
    0x13,0x37,0xC0,0xDE,0x5A,0xF3,0x7A,0x91
])
LEX_LEN = 32

def compute(path: str) -> str:
    data = bytearray(open(path, 'rb').read())
    idx = data.find(SENTINEL)
    if idx == -1:
        raise RuntimeError(f"Sentinel not found in {path}")
    # Verify uniqueness
    if data.find(SENTINEL, idx + 1) != -1:
        raise RuntimeError("Sentinel appears more than once in binary!")
    lex_off = idx + len(SENTINEL)
    if lex_off + LEX_LEN > len(data):
        raise RuntimeError("kLEX region extends past end of file!")
    data[lex_off:lex_off + LEX_LEN] = bytes(LEX_LEN)
    h = hashlib.sha256(bytes(data)).hexdigest()
    print(f"[+] Lib sentinel at offset 0x{idx:x}, kLEX at 0x{lex_off:x}", file=sys.stderr)
    return h

if __name__ == '__main__':
    path = sys.argv[1] if len(sys.argv) > 1 else 'libv4.so'
    print(compute(path))
