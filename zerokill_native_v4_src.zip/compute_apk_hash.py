#!/usr/bin/env python3
"""
compute_apk_hash.py — ZeroKill v4 APK integrity hash calculator
Hashes uncompressed content of all ZIP entries except lib/ entries.
Same logic as ApkIntegrity.cpp::ComputeApkHash().

Usage:
    python3 compute_apk_hash.py  <apk_path>

Output:
    64-char hex SHA256
"""
import sys
import hashlib
import zipfile

def compute(apk_path: str) -> str:
    h = hashlib.sha256()
    with zipfile.ZipFile(apk_path, 'r') as z:
        entries = sorted(z.infolist(), key=lambda e: e.filename)
        count = 0
        for info in entries:
            n = info.filename
            # Skip lib/ (changes with each libv4.so rebuild)
            # Skip classes*.dex (FrozenFire re-encrypts on every build)
            # Skip META-INF/ (signature files change on every re-sign)
            if n.startswith('lib/') or n.startswith('META-INF/') or n.startswith('classes'):
                continue
            # FrozenFire regenerates these on every build (non-deterministic)
            if n == 'assets/ff_core.bin' or n.startswith('assets/dexopt/'):
                continue
            if info.file_size == 0:
                continue
            data = z.read(n)
            if data:
                h.update(data)
                count += 1
        print(f"[+] Hashed {count} APK entries (skipped lib/, classes*, META-INF/, ff_core.bin, dexopt/)", file=sys.stderr)
    return h.hexdigest()

if __name__ == '__main__':
    path = sys.argv[1] if len(sys.argv) > 1 else 'zerokill.apk'
    print(compute(path))
