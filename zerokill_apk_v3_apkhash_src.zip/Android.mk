LOCAL_PATH:= $(call my-dir)

# ── ApkIntegrity: maximum Hikari (strcry + heavy BCF/CFF/IND/FW) ─────────────
include $(CLEAR_VARS)
LOCAL_MODULE    := apk_integrity
LOCAL_CPPFLAGS  := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w -std=c++17
LOCAL_CPPFLAGS  += -Wno-error=c++11-narrowing -fno-rtti -fno-exceptions -fpermissive
LOCAL_CPPFLAGS  += -mllvm -enable-bcfobf -mllvm -enable-cffobf
LOCAL_CPPFLAGS  += -mllvm -enable-subobf -mllvm -enable-indibran
LOCAL_CPPFLAGS  += -mllvm -enable-strcry -mllvm -enable-funcwra
LOCAL_CPPFLAGS  += -mllvm -bcf_loop=3 -mllvm -bcf_prob=70
LOCAL_C_INCLUDES := $(LOCAL_PATH)/
LOCAL_C_INCLUDES += $(LOCAL_PATH)/includes/curl/openssl-android-$(TARGET_ARCH_ABI)/include
LOCAL_SRC_FILES := ApkIntegrity.cpp
include $(BUILD_STATIC_LIBRARY)

# ── Main ZeroKill shared library ─────────────────────────────────────────────
include $(CLEAR_VARS)

LOCAL_MODULE := ZeroKill

LOCAL_CFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w
LOCAL_CFLAGS += -fno-rtti -fno-exceptions -fpermissive
LOCAL_CPPFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w -Werror -s -std=c++17
LOCAL_CPPFLAGS += -Wno-error=c++11-narrowing -fms-extensions -fno-rtti -fno-exceptions -fpermissive
LOCAL_CPPFLAGS +=
LOCAL_LDFLAGS += -Wl,--gc-sections,--strip-all, -llog
LOCAL_ARM_MODE := arm

LOCAL_C_INCLUDES := $(LOCAL_PATH)/
LOCAL_C_INCLUDES += $(LOCAL_PATH)/includes
LOCAL_C_INCLUDES += $(LOCAL_PATH)/includes/curl/curl-android-$(TARGET_ARCH_ABI)/include
LOCAL_C_INCLUDES += $(LOCAL_PATH)/includes/curl/openssl-android-$(TARGET_ARCH_ABI)/include

# Exclude ApkIntegrity.cpp — compiled separately above with stronger Hikari flags
CLIENT_SRC_FILES := $(filter-out $(LOCAL_PATH)/ApkIntegrity.cpp,$(wildcard $(LOCAL_PATH)/*.cpp))
LOCAL_SRC_FILES := $(CLIENT_SRC_FILES:$(LOCAL_PATH)/%=%)

LOCAL_CPP_FEATURES := exceptions
LOCAL_LDLIBS    := -llog -landroid -lz

LOCAL_STATIC_LIBRARIES := apk_integrity libcurl libssl libcrypto

include $(BUILD_SHARED_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libcurl
LOCAL_SRC_FILES := includes/curl/curl-android-$(TARGET_ARCH_ABI)/lib/libcurl.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libssl
LOCAL_SRC_FILES := includes/curl/openssl-android-$(TARGET_ARCH_ABI)/lib/libssl.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libcrypto
LOCAL_SRC_FILES := includes/curl/openssl-android-$(TARGET_ARCH_ABI)/lib/libcrypto.a
include $(PREBUILT_STATIC_LIBRARY)
