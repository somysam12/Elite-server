#!/bin/bash
# build_v3_apk.sh — ZeroKill v3 APK 2-pass build
#
#  APK PASS 1  : Gradle assembleRelease (placeholder kEX = all zeros)
#  APK STRIP 1 : strip_and_resign (removes Hikari .comment + re-sign)
#  APK HASH    : compute SHA256 of stable entries → patch kEX in ApkIntegrity.cpp
#  APK PASS 2  : Gradle assembleRelease (real kEX) → strip_and_resign → final APK

set -e

OBJCOPY=/usr/lib/android-sdk/ndk/24.0.8215888/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-objcopy
APK_SRC=/tmp/zk_v3_build/SIGMAxVISION_JAVA_4_6
HASH_SCRIPT=/tmp/zk_jni_check/compute_apk_hash.py
OUT=/home/user/Elite-server

KS=$APK_SRC/app/zen.jks
KS_PASS="TWINZZZGODD@6"
KS_ALIAS="SLAYTWINZ@66"

KEY_HEX="A37FC211E8553D901BA64EF782296CD45A3871BC0E93F42768AB1D56E39F40CC"

# ── Strip Hikari .comment from all .so inside APK, re-sign ───────────────────
strip_and_resign() {
    local APK=$1
    local TMP
    TMP=$(mktemp -d)
    local UNSIGNED="$TMP/unsigned.apk"
    local ALIGNED="$TMP/aligned.apk"

    echo "[*] Stripping Hikari .comment from APK libs ..."
    unzip -q "$APK" -d "$TMP/apk_contents"

    find "$TMP/apk_contents/lib" -name '*.so' 2>/dev/null | while read -r so; do
        $OBJCOPY --remove-section=.comment "$so" 2>/dev/null || true
        echo "[+] stripped: $(basename "$so")"
    done

    rm -rf "$TMP/apk_contents/META-INF"

    cd "$TMP/apk_contents"
    find lib -name '*.so' -print0 2>/dev/null | xargs -0 zip -0 -q "$UNSIGNED" -- 2>/dev/null || true
    find . -not -path './META-INF/*' -not -path './lib/*/*.so' -not -name '.' -type f \
        | sort | xargs zip -q "$UNSIGNED" -- 2>/dev/null || true
    find lib -not -name '*.so' -type f 2>/dev/null | xargs zip -q "$UNSIGNED" -- 2>/dev/null || true
    cd -

    zipalign -f 4 "$UNSIGNED" "$ALIGNED"

    apksigner sign --ks "$KS" --ks-pass "pass:$KS_PASS" \
              --ks-key-alias "$KS_ALIAS" --key-pass "pass:$KS_PASS" \
              --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
              --out "$APK" "$ALIGNED"

    rm -rf "$TMP"
    echo "[+] Re-signed APK (Hikari strings removed)"
}

# ── Patch APK hash into ApkIntegrity.cpp ─────────────────────────────────────
patch_apk_hash() {
    local APK=$1
    local CPP="$APK_SRC/app/src/main/jni/ApkIntegrity.cpp"
    local HASH_HEX
    HASH_HEX=$(python3 "$HASH_SCRIPT" "$APK")
    echo "[*] APK hash: $HASH_HEX"

    python3 - "$HASH_HEX" "$KEY_HEX" "$CPP" <<'PYEOF'
import sys, re

hash_hex = sys.argv[1].strip()
key_hex  = sys.argv[2].strip()
filepath = sys.argv[3]

h = bytes.fromhex(hash_hex)
k = bytes.fromhex(key_hex)
xd = bytes(a ^ b for a, b in zip(h, k))

def fmt_bytes(b):
    rows = []
    for i in range(0, 32, 8):
        chunk = b[i:i+8]
        rows.append('    ' + ','.join(f'0x{x:02X}' for x in chunk))
    return ',\n'.join(rows)

new_block = f"""    // BEGIN_HASH_PLACEHOLDER
{fmt_bytes(xd)}
    // END_HASH_PLACEHOLDER"""

with open(filepath) as f:
    src = f.read()

src = re.sub(
    r'// BEGIN_HASH_PLACEHOLDER.*?// END_HASH_PLACEHOLDER',
    new_block,
    src,
    flags=re.DOTALL
)
with open(filepath, 'w') as f:
    f.write(src)

print(f"[+] Patched kEX into ApkIntegrity.cpp")
PYEOF
}

# ── Build APK via Gradle ──────────────────────────────────────────────────────
build_apk() {
    echo "[*] Gradle assembleRelease ..."
    cd "$APK_SRC"
    ./gradlew assembleRelease 2>&1 | grep -E "FrozenFire|Signed|BUILD|error:|FAILED|Task :"
    cp "$APK_SRC/app/build/outputs/apk/release/app-release_protected.apk" "$OUT/zerokill_v3.apk"
    echo "[+] APK → $OUT/zerokill_v3.apk"
}

# ═══════════════════════════════════════════════════════════════════════════════
#  APK PASS 1 — build with placeholder kEX (all zeros)
# ═══════════════════════════════════════════════════════════════════════════════
echo "═══ APK PASS 1: placeholder APK hash ═══"
build_apk
strip_and_resign "$OUT/zerokill_v3.apk"

# ═══════════════════════════════════════════════════════════════════════════════
#  COMPUTE APK HASH & PATCH
# ═══════════════════════════════════════════════════════════════════════════════
echo "═══ Patching APK hash into ApkIntegrity.cpp ═══"
patch_apk_hash "$OUT/zerokill_v3.apk"

# ═══════════════════════════════════════════════════════════════════════════════
#  APK PASS 2 — rebuild with real kEX embedded
# ═══════════════════════════════════════════════════════════════════════════════
echo "═══ APK PASS 2: final APK with embedded hash ═══"
build_apk
strip_and_resign "$OUT/zerokill_v3.apk"

echo ""
echo "═══════════════════════════════════════════════"
echo "v3 BUILD COMPLETE"
echo "  APK : $OUT/zerokill_v3.apk"
echo "═══════════════════════════════════════════════"
