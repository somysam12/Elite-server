#pragma once
// StreamESP.h — HideESP / Stream Mode — Dual ImGui context (identical to canvas ESP)
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <android/native_activity.h>
#include <android/native_window.h>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cfloat>
#include "ANwCreator.hpp"

// ImGui (pragma once — no-op if already pulled in by main.cpp)
#ifndef IMGUI_IMPL_OPENGL_ES3
#define IMGUI_IMPL_OPENGL_ES3
#endif
#include "imgui/imgui.h"
#include "imgui/backends/imgui_impl_opengl3.h"
#include "Helper/KCVisionFont.h"
#include "Helper/KCHindiFont.h"

static bool           g_StreamMode  = false;
static bool           s_streamReady = false;
static EGLDisplay     s_sDpy        = EGL_NO_DISPLAY;
static EGLSurface     s_sSurf       = EGL_NO_SURFACE;
static EGLContext     s_sCtx        = EGL_NO_CONTEXT;
static ANativeWindow* s_sWin        = nullptr;
static int            s_sW = 0, s_sH = 0;
static bool           s_streamGLES3 = false;

// Dual ImGui context
static ImGuiContext*  s_StreamImGuiCtx   = nullptr;
static bool           s_StreamImGuiReady = false;
static ImFont*        s_sVisionFont      = nullptr;

// ── Player / Vehicle structs ──────────────────────────────────────────────────
struct StreamPlayer {
    float headX, headY, footX, footY;
    float health, healthMax, distance;
    char  name[32];
    bool  hasLOS;
    bool  isBot;
    bool  isKnocked;
    float bones[16][2];
};

struct StreamVehicle {
    float scrX, scrY;
    float distance;
    char  name[32];
    bool  hasDriver;
};

// ── Init — creates eSkipScreenshot surface with GLES3 context (GLES2 fallback)
static bool StreamESP_Init(ANativeActivity* act) {
    if (s_streamReady) return true;
    if (!act) return false;

    android::ANwCreator::CreateOptions opts;
    opts.name = "KC_StreamESP"; opts.skipScreenshot = true;
    opts.width = -1; opts.height = -1;
    s_sWin = android::ANwCreator::Create(act, opts);
    if (!s_sWin) { LOGI("StreamESP: Create failed"); return false; }

    s_sDpy = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(s_sDpy, nullptr, nullptr);

    // Prefer GLES3 so ImGui's "#version 300 es" shaders compile correctly
    EGLConfig cfg; EGLint nc = 0;
    const EGLint ca3[] = {
        EGL_SURFACE_TYPE,    EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, 0x40,  // EGL_OPENGL_ES3_BIT_KHR
        EGL_RED_SIZE,   8, EGL_GREEN_SIZE, 8,
        EGL_BLUE_SIZE,  8, EGL_ALPHA_SIZE, 8,
        EGL_NONE
    };
    if (!eglChooseConfig(s_sDpy, ca3, &cfg, 1, &nc) || nc == 0) {
        // Fallback: GLES2 config
        const EGLint ca2[] = {
            EGL_SURFACE_TYPE,    EGL_WINDOW_BIT,
            EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
            EGL_RED_SIZE,   8, EGL_GREEN_SIZE, 8,
            EGL_BLUE_SIZE,  8, EGL_ALPHA_SIZE, 8,
            EGL_NONE
        };
        if (!eglChooseConfig(s_sDpy, ca2, &cfg, 1, &nc) || nc == 0) {
            eglTerminate(s_sDpy); s_sDpy = EGL_NO_DISPLAY;
            android::ANwCreator::Destroy(act, s_sWin); s_sWin = nullptr;
            return false;
        }
    }

    const EGLint cxa3[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    s_sCtx = eglCreateContext(s_sDpy, cfg, EGL_NO_CONTEXT, cxa3);
    s_streamGLES3 = (s_sCtx != EGL_NO_CONTEXT);
    if (!s_streamGLES3) {
        const EGLint cxa2[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };
        s_sCtx = eglCreateContext(s_sDpy, cfg, EGL_NO_CONTEXT, cxa2);
    }

    s_sSurf = eglCreateWindowSurface(s_sDpy, cfg, s_sWin, nullptr);
    if (s_sCtx == EGL_NO_CONTEXT || s_sSurf == EGL_NO_SURFACE) {
        if (s_sSurf != EGL_NO_SURFACE) eglDestroySurface(s_sDpy, s_sSurf);
        if (s_sCtx != EGL_NO_CONTEXT) eglDestroyContext(s_sDpy, s_sCtx);
        eglTerminate(s_sDpy); s_sDpy = EGL_NO_DISPLAY;
        android::ANwCreator::Destroy(act, s_sWin); s_sWin = nullptr;
        return false;
    }

    eglMakeCurrent(s_sDpy, s_sSurf, s_sSurf, s_sCtx);
    eglQuerySurface(s_sDpy, s_sSurf, EGL_WIDTH,  &s_sW);
    eglQuerySurface(s_sDpy, s_sSurf, EGL_HEIGHT, &s_sH);
    glViewport(0, 0, s_sW, s_sH);
    glClearColor(0.f, 0.f, 0.f, 0.f);

    android::ANwCreator::EnsureVisible(act, s_sWin);
    eglMakeCurrent(EGL_NO_DISPLAY, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);

    s_streamReady = true;
    LOGI("StreamESP ready (%dx%d, GLES%d)", s_sW, s_sH, s_streamGLES3 ? 3 : 2);
    return true;
}

// ── Lazy-init stream ImGui context — must be called while stream EGL is current
static void _StreamImGui_Init(int w, int h) {
    if (s_StreamImGuiReady) return;

    s_StreamImGuiCtx = ImGui::CreateContext();
    ImGui::SetCurrentContext(s_StreamImGuiCtx);

    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename  = nullptr;
    io.DisplaySize  = ImVec2((float)w, (float)h);

    // Use the same GLSL version as main context when GLES3, "#version 100" for GLES2
    ImGui_ImplOpenGL3_Init(s_streamGLES3 ? "#version 300 es" : "#version 100");

    float fsz = (float)h * 0.024f;
    if (fsz < 15.0f) fsz = 15.0f;
    if (fsz > 30.0f) fsz = 30.0f;

    // Same Vision font as main context
    ImFontConfig cfg; cfg.FontDataOwnedByAtlas = false;
    static const ImWchar latin_ranges[] = {
        0x0020,0x00FF, 0x2000,0x206F, 0x2190,0x21FF, 0x2600,0x26FF, 0 };
    s_sVisionFont = io.Fonts->AddFontFromMemoryTTF(
        (void*)KC_VISION_FONT_DATA, (int)KC_VISION_FONT_SIZE, fsz, &cfg, latin_ranges);

    ImFontConfig cfg2; cfg2.MergeMode = true; cfg2.FontDataOwnedByAtlas = false;
    static const ImWchar hindi_ranges[] = { 0x0900,0x097F, 0xA8E0,0xA8FF, 0 };
    io.Fonts->AddFontFromMemoryTTF(
        (void*)KC_HINDI_FONT_DATA, (int)KC_HINDI_FONT_SIZE, fsz, &cfg2, hindi_ranges);
    io.Fonts->Build();

    s_StreamImGuiReady = true;
    LOGI("StreamESP ImGui ctx ready (font %.1f)", fsz);
}

// ── Draw frame — called each PostRender when stream mode is active ────────────
static void StreamESP_DrawFrame(
    const StreamPlayer*  players,  int count,
    const StreamVehicle* vehicles, int vcount,
    int gameW, int gameH,
    bool drawLine, bool drawSkel, bool drawHealth,
    bool drawName, bool drawDist,
    int enemyCount, int botCount,
    const char* watermark, const char* expiry = nullptr)
{
    if (!s_streamReady) return;

    // Save main EGL + ImGui context
    EGLDisplay    saveDpy      = eglGetCurrentDisplay();
    EGLSurface    saveDraw     = eglGetCurrentSurface(EGL_DRAW);
    EGLSurface    saveRead     = eglGetCurrentSurface(EGL_READ);
    EGLContext    saveEGLCtx   = eglGetCurrentContext();
    ImGuiContext* saveImGuiCtx = ImGui::GetCurrentContext();

    eglMakeCurrent(s_sDpy, s_sSurf, s_sSurf, s_sCtx);
    eglQuerySurface(s_sDpy, s_sSurf, EGL_WIDTH,  &s_sW);
    eglQuerySurface(s_sDpy, s_sSurf, EGL_HEIGHT, &s_sH);
    glViewport(0, 0, s_sW, s_sH);

    // Lazy-init (must happen while stream EGL is current for GL resource creation)
    _StreamImGui_Init(s_sW, s_sH);
    if (!s_StreamImGuiReady) {
        eglMakeCurrent(saveDpy, saveDraw, saveRead, saveEGLCtx);
        return;
    }

    ImGui::SetCurrentContext(s_StreamImGuiCtx);
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)s_sW, (float)s_sH);
    io.DeltaTime   = 1.0f / 60.0f;

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();

    ImDrawList* dl = ImGui::GetForegroundDrawList();
    ImFont* vf     = s_sVisionFont ? s_sVisionFont : ImGui::GetFont();
    float   vfSz   = vf->FontSize;

    float SW = (float)s_sW;
    float SH = (float)s_sH;
    float sx = (gameW > 0) ? SW / (float)gameW : 1.f;
    float sy = (gameH > 0) ? SH / (float)gameH : 1.f;

    // ── 1. Enemy Counter — cyan pill, identical to canvas ESP ─────────────────
    char cbuf[48];
    snprintf(cbuf, sizeof(cbuf), "%02d - %02d", enemyCount, botCount);
    ImVec2 ctSz  = vf->CalcTextSizeA(vfSz, 9999.f, 0.f, cbuf);
    float  ctX   = SW * 0.5f - ctSz.x * 0.5f;
    float  ctY   = 14.0f;
    float  pad   = 6.0f;
    dl->AddRectFilled(
        ImVec2(ctX - pad,         ctY - pad),
        ImVec2(ctX + ctSz.x + pad, ctY + ctSz.y + pad),
        IM_COL32(0, 200, 200, 70), 4.0f);
    dl->AddRect(
        ImVec2(ctX - pad,         ctY - pad),
        ImVec2(ctX + ctSz.x + pad, ctY + ctSz.y + pad),
        IM_COL32(0, 220, 220, 140), 4.0f, 0, 1.5f);
    dl->AddText(vf, vfSz, ImVec2(ctX + 1, ctY + 1), IM_COL32(0, 0, 0, 180),     cbuf);
    dl->AddText(vf, vfSz, ImVec2(ctX,     ctY),     IM_COL32(0, 220, 220, 255), cbuf);

    // Line origin — just below the counter box (same as canvas)
    float lineOriginX = SW * 0.5f;
    float lineOriginY = ctY + ctSz.y + pad + 12.0f;

    // ── 2. Watermark — red text with black shadow, bottom-right ───────────────
    if (watermark && watermark[0]) {
        float wmSz_w = vf->CalcTextSizeA(vfSz * 1.25f, 9999.f, 0.f, watermark).x;
        float wmSz_h = vfSz * 1.25f;
        float wx = SW - wmSz_w - 80.0f;
        float wy = SH - wmSz_h - 60.0f;
        dl->AddRectFilled(
            ImVec2(wx - 6, wy - 4), ImVec2(wx + wmSz_w + 6, wy + wmSz_h + 4),
            IM_COL32(0, 0, 0, 180), 4.0f);
        dl->AddText(vf, vfSz * 1.25f, ImVec2(wx + 1, wy + 1), IM_COL32(0,   0,   0,   255), watermark);
        dl->AddText(vf, vfSz * 1.25f, ImVec2(wx,     wy),     IM_COL32(255, 0,   0,   255), watermark);
    }

    // ── 3. Expiry — red text, bottom-left ─────────────────────────────────────
    if (expiry && expiry[0]) {
        float exSz_w = vf->CalcTextSizeA(vfSz, 9999.f, 0.f, expiry).x;
        float exSz_h = vfSz;
        float ex = 90.0f;
        float ey = SH - exSz_h - 60.0f;
        dl->AddRectFilled(
            ImVec2(ex - 6, ey - 4), ImVec2(ex + exSz_w + 6, ey + exSz_h + 4),
            IM_COL32(0, 0, 0, 180), 4.0f);
        dl->AddText(vf, vfSz, ImVec2(ex + 1, ey + 1), IM_COL32(0,   0, 0,   255), expiry);
        dl->AddText(vf, vfSz, ImVec2(ex,     ey),     IM_COL32(255, 0, 0,   255), expiry);
    }

    // ── 4. Vehicles ───────────────────────────────────────────────────────────
    for (int i = 0; i < vcount; i++) {
        const StreamVehicle& v = vehicles[i];
        float vx = v.scrX * sx, vy = v.scrY * sy;
        char  vbuf[64];
        snprintf(vbuf, sizeof(vbuf), "{%s %dm}", v.name, (int)v.distance);
        float vtsz_w = vf->CalcTextSizeA(vfSz * 0.8f, 9999.f, 0.f, vbuf).x;
        float vtsz_h = vfSz * 0.8f;
        float nvx = vx - vtsz_w * 0.5f;
        float nvy = vy - vtsz_h - 4.0f;
        dl->AddRectFilled(
            ImVec2(nvx - 3, nvy - 2), ImVec2(nvx + vtsz_w + 3, nvy + vtsz_h + 2),
            IM_COL32(10, 10, 15, 200), 2.0f);
        ImU32 vcol = v.hasDriver ? IM_COL32(255, 0, 0, 255) : IM_COL32(255, 255, 0, 255);
        dl->AddText(vf, vfSz * 0.8f, ImVec2(nvx + 1, nvy + 1), IM_COL32(0, 0, 0, 180), vbuf);
        dl->AddText(vf, vfSz * 0.8f, ImVec2(nvx,     nvy),     vcol,                    vbuf);
    }

    // ── 5. Players ────────────────────────────────────────────────────────────
    for (int i = 0; i < count; i++) {
        const StreamPlayer& e = players[i];
        float hx = e.headX * sx, hy = e.headY * sy;
        float fx = e.footX * sx, fy = e.footY * sy;

        // Line color: green=LOS, red=no LOS (same as canvas)
        ImU32 lineCol = e.hasLOS ? IM_COL32(0,255,0,255) : IM_COL32(255,0,0,255);
        // Skeleton color: green=LOS, cyan=no LOS (canvas uses cyan for covered skeleton)
        ImU32 skelCol = e.hasLOS ? IM_COL32(0,255,0,255) : IM_COL32(0,255,255,255);

        // ESP line — from below counter to head
        if (drawLine) {
            dl->AddLine(
                ImVec2(lineOriginX, lineOriginY),
                ImVec2(hx, hy - 20.f * sy),
                lineCol, 1.0f);
        }

        // Skeleton — upper body only (no leg lines, same as canvas)
        if (drawSkel) {
            auto bl = [&](int a, int b) {
                float ax = e.bones[a][0]*sx, ay = e.bones[a][1]*sy;
                float bx = e.bones[b][0]*sx, by = e.bones[b][1]*sy;
                dl->AddLine(ImVec2(ax,ay), ImVec2(bx,by), skelCol, 0.8f);
            };
            // Spine
            bl(0,1); bl(1,2); bl(2,3); bl(3,4); bl(4,5);
            // Right arm
            bl(1,6); bl(6,7); bl(7,8);
            // Left arm
            bl(1,9); bl(9,10); bl(10,11);
            // Head dot
            dl->AddRectFilled(ImVec2(hx-3.f,hy-3.f), ImVec2(hx+3.f,hy+3.f), lineCol);
        }

        // Health bar — blue alive, red knocked (exact canvas colors)
        if (drawHealth && e.healthMax > 0.f) {
            float hp  = std::max(0.f, std::min(e.health / e.healthMax, 1.f));
            float bw  = std::max(20.f, std::min(34.f * sx, 50.f));
            float bht = 3.0f;
            float bx2 = hx - bw * 0.5f;
            float by2 = hy - 8.f * sy;
            dl->AddRectFilled(
                ImVec2(bx2, by2), ImVec2(bx2 + bw, by2 + bht),
                IM_COL32(25, 25, 25, 178));
            ImU32 hpcol = e.isKnocked
                ? IM_COL32(255, 0,   0,   242)   // red — knocked
                : IM_COL32(51,  153, 255, 242);   // blue — alive
            dl->AddRectFilled(
                ImVec2(bx2, by2), ImVec2(bx2 + bw * hp, by2 + bht),
                hpcol);
        }

        // Distance — yellow text
        if (drawDist) {
            char db[16]; snprintf(db, sizeof(db), "%dm", (int)e.distance);
            float dtsz_w = vf->CalcTextSizeA(vfSz * 0.75f, 9999.f, 0.f, db).x;
            float dtsz_h = vfSz * 0.75f;
            float dx = fx - dtsz_w * 0.5f;
            float dy = fy + 4.0f;
            dl->AddRectFilled(
                ImVec2(dx-3, dy-2), ImVec2(dx+dtsz_w+3, dy+dtsz_h+2),
                IM_COL32(12, 12, 18, 209), 2.0f);
            dl->AddText(vf, vfSz*0.75f, ImVec2(dx+1, dy+1), IM_COL32(0,   0,   0,   230), db);
            dl->AddText(vf, vfSz*0.75f, ImVec2(dx,   dy),   IM_COL32(255, 255, 0,   255), db);
        }

        // Name — white text (same as canvas ESP)
        if (drawName) {
            const char* nm = e.isBot ? "Bot" : e.name;
            float ntsz_w   = vf->CalcTextSizeA(vfSz * 0.75f, 9999.f, 0.f, nm).x;
            float ntsz_h   = vfSz * 0.75f;
            float dnx = fx - ntsz_w * 0.5f;
            float dny = fy + 4.0f + (drawDist ? (vfSz * 0.75f + 8.0f) : 0.0f);
            dl->AddRectFilled(
                ImVec2(dnx-3, dny-2), ImVec2(dnx+ntsz_w+3, dny+ntsz_h+2),
                IM_COL32(10, 10, 15, 209), 2.0f);
            dl->AddText(vf, vfSz*0.75f, ImVec2(dnx+1, dny+1), IM_COL32(0,   0,   0,   230), nm);
            dl->AddText(vf, vfSz*0.75f, ImVec2(dnx,   dny),   IM_COL32(255, 255, 255, 255), nm);
        }
    }

    // Render ImGui frame to stream surface
    ImGui::Render();
    glClearColor(0.f, 0.f, 0.f, 0.f);
    glClear(GL_COLOR_BUFFER_BIT);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(s_sDpy, s_sSurf);

    // Restore main ImGui context and EGL context
    ImGui::SetCurrentContext(saveImGuiCtx);
    eglMakeCurrent(saveDpy, saveDraw, saveRead, saveEGLCtx);
}

// ── Clear stream surface — call when HideESP turns OFF ───────────────────────
static void StreamESP_ClearOnce() {
    if (!s_streamReady) return;

    EGLDisplay    saveDpy      = eglGetCurrentDisplay();
    EGLSurface    saveDraw     = eglGetCurrentSurface(EGL_DRAW);
    EGLSurface    saveRead     = eglGetCurrentSurface(EGL_READ);
    EGLContext    saveCtx      = eglGetCurrentContext();
    ImGuiContext* saveImGuiCtx = ImGui::GetCurrentContext();

    eglMakeCurrent(s_sDpy, s_sSurf, s_sSurf, s_sCtx);
    eglQuerySurface(s_sDpy, s_sSurf, EGL_WIDTH,  &s_sW);
    eglQuerySurface(s_sDpy, s_sSurf, EGL_HEIGHT, &s_sH);
    glViewport(0, 0, s_sW, s_sH);
    glClearColor(0.f, 0.f, 0.f, 0.f);
    glClear(GL_COLOR_BUFFER_BIT);
    eglSwapBuffers(s_sDpy, s_sSurf);

    ImGui::SetCurrentContext(saveImGuiCtx);
    eglMakeCurrent(saveDpy, saveDraw, saveRead, saveCtx);
}
