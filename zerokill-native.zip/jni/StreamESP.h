#pragma once
// ═══════════════════════════════════════════════════════════════════════════
// StreamESP.h — HideESP / Stream Mode
// Same colors as canvas ESP. Rendered on eSkipScreenshot surface.
// ═══════════════════════════════════════════════════════════════════════════
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <android/native_activity.h>
#include <android/native_window.h>
#include <cmath>
#include <cstring>
#include <cstdio>
#include "ANwCreator.hpp"

static bool           g_StreamMode  = false;
static bool           s_streamReady = false;
static EGLDisplay     s_sDpy   = EGL_NO_DISPLAY;
static EGLSurface     s_sSurf  = EGL_NO_SURFACE;
static EGLContext     s_sCtx   = EGL_NO_CONTEXT;
static ANativeWindow* s_sWin   = nullptr;
static int            s_sW = 0, s_sH = 0;
static GLuint s_sProg = 0;
static GLint  s_sAPOS = -1, s_sUSCR = -1, s_sUCOL = -1;

static const char* S_VS = R"(
attribute vec2 aPos;
uniform vec2 uScreen;
void main(){
    vec2 n = (aPos / uScreen) * 2.0 - 1.0;
    n.y = -n.y;
    gl_Position = vec4(n, 0.0, 1.0);
})";
static const char* S_FS = R"(
precision mediump float;
uniform vec4 uColor;
void main(){ gl_FragColor = uColor; })";

static GLuint s_cmpSh(GLenum t,const char* src){
    GLuint s=glCreateShader(t);
    glShaderSource(s,1,&src,nullptr); glCompileShader(s);
    GLint ok=0; glGetShaderiv(s,GL_COMPILE_STATUS,&ok);
    if(!ok){glDeleteShader(s);return 0;} return s;
}
static bool s_buildProg(){
    GLuint vs=s_cmpSh(GL_VERTEX_SHADER,S_VS);
    GLuint fs=s_cmpSh(GL_FRAGMENT_SHADER,S_FS);
    if(!vs||!fs) return false;
    s_sProg=glCreateProgram();
    glAttachShader(s_sProg,vs); glAttachShader(s_sProg,fs);
    glLinkProgram(s_sProg);
    glDeleteShader(vs); glDeleteShader(fs);
    GLint ok=0; glGetProgramiv(s_sProg,GL_LINK_STATUS,&ok);
    if(!ok){glDeleteProgram(s_sProg);s_sProg=0;return false;}
    s_sAPOS=glGetAttribLocation(s_sProg,"aPos");
    s_sUSCR=glGetUniformLocation(s_sProg,"uScreen");
    s_sUCOL=glGetUniformLocation(s_sProg,"uColor");
    return true;
}
static void s_col(float r,float g,float b,float a=1.f){glUniform4f(s_sUCOL,r,g,b,a);}
static void s_line(float x0,float y0,float x1,float y1,float w=1.5f){
    glLineWidth(w);
    float v[4]={x0,y0,x1,y1};
    glVertexAttribPointer(s_sAPOS,2,GL_FLOAT,GL_FALSE,0,v);
    glEnableVertexAttribArray(s_sAPOS);
    glDrawArrays(GL_LINES,0,2);
}
static void s_rect(float l,float t,float r,float b){
    float v[8]={l,t,r,t,l,b,r,b};
    glVertexAttribPointer(s_sAPOS,2,GL_FLOAT,GL_FALSE,0,v);
    glEnableVertexAttribArray(s_sAPOS);
    glDrawArrays(GL_TRIANGLE_STRIP,0,4);
}

// 5×7 pixel font
static const uint8_t S_F5x7[][5]={
{0,0,0,0,0},{0,0,0x5F,0,0},{0,7,0,7,0},{0x14,0x7F,0x14,0x7F,0x14},
{0x24,0x2A,0x7F,0x2A,0x12},{0x23,0x13,8,0x64,0x62},{0x36,0x49,0x55,0x22,0x50},
{0,5,3,0,0},{0,0x1C,0x22,0x41,0},{0,0x41,0x22,0x1C,0},{0xA,4,0x1F,4,0xA},
{8,8,0x3E,8,8},{0,0x50,0x30,0,0},{8,8,8,8,8},{0,0x60,0x60,0,0},
{0x20,0x10,8,4,2},{0x3E,0x51,0x49,0x45,0x3E},{0,0x42,0x7F,0x40,0},
{0x42,0x61,0x51,0x49,0x46},{0x21,0x41,0x45,0x4B,0x31},{0x18,0x14,0x12,0x7F,0x10},
{0x27,0x45,0x45,0x45,0x39},{0x3C,0x4A,0x49,0x49,0x30},{1,0x71,9,5,3},
{0x36,0x49,0x49,0x49,0x36},{6,0x49,0x49,0x29,0x1E},{0,0x36,0x36,0,0},
{0,0x56,0x36,0,0},{8,0x14,0x22,0x41,0},{0x14,0x14,0x14,0x14,0x14},
{0,0x41,0x22,0x14,8},{2,1,0x51,9,6},{0x32,0x49,0x79,0x41,0x3E},
{0x7E,0x11,0x11,0x11,0x7E},{0x7F,0x49,0x49,0x49,0x36},{0x3E,0x41,0x41,0x41,0x22},
{0x7F,0x41,0x41,0x22,0x1C},{0x7F,0x49,0x49,0x49,0x41},{0x7F,9,9,9,1},
{0x3E,0x41,0x49,0x49,0x7A},{0x7F,8,8,8,0x7F},{0,0x41,0x7F,0x41,0},
{0x20,0x40,0x41,0x3F,1},{0x7F,8,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},
{0x7F,2,0xC,2,0x7F},{0x7F,4,8,0x10,0x7F},{0x3E,0x41,0x41,0x41,0x3E},
{0x7F,9,9,9,6},{0x3E,0x41,0x51,0x21,0x5E},{0x7F,9,0x19,0x29,0x46},
{0x46,0x49,0x49,0x49,0x31},{1,1,0x7F,1,1},{0x3F,0x40,0x40,0x40,0x3F},
{0x1F,0x20,0x40,0x20,0x1F},{0x3F,0x40,0x38,0x40,0x3F},{0x63,0x14,8,0x14,0x63},
{7,8,0x70,8,7},{0x61,0x51,0x49,0x45,0x43},{0,0x7F,0x41,0x41,0},
{2,4,8,0x10,0x20},{0,0x41,0x41,0x7F,0},{4,2,1,2,4},{0x40,0x40,0x40,0x40,0x40},
{0,1,2,4,0},{0x20,0x54,0x54,0x54,0x78},{0x7F,0x48,0x44,0x44,0x38},
{0x38,0x44,0x44,0x44,0x20},{0x38,0x44,0x44,0x48,0x7F},{0x38,0x54,0x54,0x54,0x18},
{8,0x7E,9,1,2},{0xC,0x52,0x52,0x52,0x3E},{0x7F,8,4,4,0x78},
{0,0x44,0x7D,0x40,0},{0x20,0x40,0x44,0x3D,0},{0x7F,0x10,0x28,0x44,0},
{0,0x41,0x7F,0x40,0},{0x7C,4,0x18,4,0x78},{0x7C,8,4,4,0x78},
{0x38,0x44,0x44,0x44,0x38},{0x7C,0x14,0x14,0x14,8},{8,0x14,0x14,0x18,0x7C},
{0x7C,8,4,4,8},{0x48,0x54,0x54,0x54,0x20},{4,0x3F,0x44,0x40,0x20},
{0x3C,0x40,0x40,0x20,0x7C},{0x1C,0x20,0x40,0x20,0x1C},{0x3C,0x40,0x30,0x40,0x3C},
{0x44,0x28,0x10,0x28,0x44},{0xC,0x50,0x50,0x50,0x3C},{0x44,0x64,0x54,0x4C,0x44},
{0,8,0x36,0x41,0},{0,0,0x7F,0,0},{0,0x41,0x36,8,0},{0xC,2,0xC,0x10,0xC},
};
static void s_drawTxt(const char* s,float px,float py,float sc){
    float cx=px;
    for(;*s;s++){
        unsigned char c=(unsigned char)*s;
        if(c<32||c>126)c=32;
        const uint8_t* g=S_F5x7[c-32];
        for(int col=0;col<5;col++){
            uint8_t cd=g[col];
            for(int row=0;row<7;row++){
                if(cd&(1<<row)){
                    float fx=cx+(float)col*sc, fy=py+(float)row*sc;
                    s_rect(fx,fy,fx+sc,fy+sc);
                }
            }
        }
        cx+=6.f*sc;
    }
}
static float s_txtW(const char* s,float sc){
    int n=0; for(const char*p=s;*p;p++)n++;
    return n*6.f*sc;
}

// ── Player data struct ─────────────────────────────────────────────────────
struct StreamPlayer {
    float headX,headY,footX,footY;
    float health,healthMax,distance;
    char  name[32];
    bool  hasLOS;
    bool  isBot;
    bool  isKnocked;
    float bones[16][2];
};

struct StreamVehicle {
    float scrX, scrY;
    float distance;
    char  name[32];
    bool  hasDriver;  // true = driven by enemy (red), false = empty (yellow)
};

// ── Init ───────────────────────────────────────────────────────────────────
static bool StreamESP_Init(ANativeActivity* act) {
    if (s_streamReady) return true;
    if (!act) return false;
    android::ANwCreator::CreateOptions opts;
    opts.name="KC_StreamESP"; opts.skipScreenshot=true;
    opts.width=-1; opts.height=-1;
    s_sWin=android::ANwCreator::Create(act,opts);
    if(!s_sWin){LOGI("StreamESP: Create failed");return false;}
    s_sDpy=eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(s_sDpy,nullptr,nullptr);
    const EGLint ca[]={EGL_SURFACE_TYPE,EGL_WINDOW_BIT,EGL_RENDERABLE_TYPE,EGL_OPENGL_ES2_BIT,
        EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,EGL_BLUE_SIZE,8,EGL_ALPHA_SIZE,8,EGL_NONE};
    EGLConfig cfg; EGLint nc=0;
    if(!eglChooseConfig(s_sDpy,ca,&cfg,1,&nc)||nc==0){
        eglTerminate(s_sDpy);s_sDpy=EGL_NO_DISPLAY;
        android::ANwCreator::Destroy(act,s_sWin);s_sWin=nullptr;return false;}
    const EGLint cxa[]={EGL_CONTEXT_CLIENT_VERSION,2,EGL_NONE};
    s_sCtx=eglCreateContext(s_sDpy,cfg,EGL_NO_CONTEXT,cxa);
    s_sSurf=eglCreateWindowSurface(s_sDpy,cfg,s_sWin,nullptr);
    if(s_sCtx==EGL_NO_CONTEXT||s_sSurf==EGL_NO_SURFACE){
        if(s_sSurf!=EGL_NO_SURFACE)eglDestroySurface(s_sDpy,s_sSurf);
        if(s_sCtx!=EGL_NO_CONTEXT)eglDestroyContext(s_sDpy,s_sCtx);
        eglTerminate(s_sDpy);s_sDpy=EGL_NO_DISPLAY;
        android::ANwCreator::Destroy(act,s_sWin);s_sWin=nullptr;return false;}
    eglMakeCurrent(s_sDpy,s_sSurf,s_sSurf,s_sCtx);
    eglQuerySurface(s_sDpy,s_sSurf,EGL_WIDTH,&s_sW);
    eglQuerySurface(s_sDpy,s_sSurf,EGL_HEIGHT,&s_sH);
    glViewport(0,0,s_sW,s_sH);
    glClearColor(0,0,0,0);
    s_buildProg();
    android::ANwCreator::EnsureVisible(act,s_sWin);
    eglMakeCurrent(EGL_NO_DISPLAY,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);
    s_streamReady=true;
    LOGI("✅ StreamESP ready (%dx%d)",s_sW,s_sH);
    return true;
}

// ── Draw frame — called from PostRender ────────────────────────────────────
static void StreamESP_DrawFrame(
    const StreamPlayer* players, int count,
    const StreamVehicle* vehicles, int vcount,
    int gameW, int gameH,
    bool drawLine, bool drawSkel, bool drawHealth,
    bool drawName, bool drawDist,
    int enemyCount, int botCount,
    const char* watermark, const char* expiry = nullptr)
{
    if(!s_streamReady||!s_sProg) return;

    EGLDisplay saveDpy=eglGetCurrentDisplay();
    EGLSurface saveDraw=eglGetCurrentSurface(EGL_DRAW);
    EGLSurface saveRead=eglGetCurrentSurface(EGL_READ);
    EGLContext saveCtx=eglGetCurrentContext();

    eglMakeCurrent(s_sDpy,s_sSurf,s_sSurf,s_sCtx);
    eglQuerySurface(s_sDpy,s_sSurf,EGL_WIDTH,&s_sW);
    eglQuerySurface(s_sDpy,s_sSurf,EGL_HEIGHT,&s_sH);
    glViewport(0,0,s_sW,s_sH);
    glClear(GL_COLOR_BUFFER_BIT);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glUseProgram(s_sProg);
    glUniform2f(s_sUSCR,(float)s_sW,(float)s_sH);

    float sx=(gameW>0)?(float)s_sW/(float)gameW:1.f;
    float sy=(gameH>0)?(float)s_sH/(float)gameH:1.f;

    // ── 1. Enemy Counter — red box, white 2-digit text "EE - BB" ─────────
    const float CSC = 2.2f;
    char cbuf[48];
    snprintf(cbuf,sizeof(cbuf),"%02d - %02d",enemyCount,botCount);
    float ctw=s_txtW(cbuf,CSC), cth=7.f*CSC;
    float ctx2=(float)s_sW*0.5f-ctw*0.5f, cty=14.f;
    // Red filled background (100% opacity — matches the canvas pill colour)
    s_col(1.f,0.f,0.f,1.f); s_rect(ctx2-10,cty-5,ctx2+ctw+10,cty+cth+5);
    // White text
    s_col(0,0,0,0.9f); s_drawTxt(cbuf,ctx2+1,cty+1,CSC);
    s_col(1.f,1.f,1.f,1.f); s_drawTxt(cbuf,ctx2,cty,CSC);

    // Line origin — below counter, same Y as canvas (screenW/2, ~60)
    float lineOriginY = cty+cth+12.f;
    float lineOriginX = (float)s_sW*0.5f;

    // ── 2. Watermark — "ZEROKILL | 4.6" all red ──────────────────────────────
    {
        const float wsc=2.5f;
        const char* wm="ZEROKILL | 4.6";
        float totalW=s_txtW(wm,wsc), th=7.f*wsc;
        float wx=(float)s_sW-totalW-80.f, wy=(float)s_sH-th-60.f;
        s_col(0,0,0,0.75f); s_rect(wx-6,wy-4,wx+totalW+6,wy+th+4);
        s_col(0,0,0,1.f); s_drawTxt(wm,wx+1,wy+1,wsc);
        s_col(1.f,0.15f,0.15f,1.f); s_drawTxt(wm,wx,wy,wsc);
    }

    // ── 2b. Expiry — red, same row as watermark ───────────────────────────────
    if(expiry && expiry[0]){
        const float esc=2.2f;
        float tw=s_txtW(expiry,esc), th=7.f*esc;
        float ex=90.f, ey=(float)s_sH-th-60.f;
        s_col(0,0,0,0.75f); s_rect(ex-6,ey-4,ex+tw+6,ey+th+4);
        s_col(0,0,0,1.f);         s_drawTxt(expiry,ex+1,ey+1,esc);
        s_col(1.f,0.15f,0.15f,1.f); s_drawTxt(expiry,ex,ey,esc);
    }

    // ── 3. Vehicles ──────────────────────────────────────────────────────
    for(int i=0;i<vcount;i++){
        const StreamVehicle& v=vehicles[i];
        float vx=v.scrX*sx, vy=v.scrY*sy;
        const float vsc=1.5f;
        // name + distance text
        char vbuf[64];
        snprintf(vbuf,sizeof(vbuf),"{%s %dm}",v.name,(int)v.distance);
        float tw=s_txtW(vbuf,vsc), th=7.f*vsc;
        float nx=vx-tw*0.5f, ny=vy-th-4.f;
        s_col(0.04f,0.04f,0.06f,0.8f); s_rect(nx-3,ny-2,nx+tw+3,ny+th+2);
        // yellow = empty, red = enemy inside
        if(v.hasDriver) s_col(1.f,0.f,0.f,1.f);   // red — enemy driving
        else             s_col(1.f,1.f,0.f,1.f);   // yellow — empty
        s_col(0,0,0,0.9f); s_drawTxt(vbuf,nx+1,ny+1,vsc);
        if(v.hasDriver) s_col(1.f,0.15f,0.15f,1.f);
        else            s_col(1.f,1.f,0.f,1.f);
        s_drawTxt(vbuf,nx,ny,vsc);
    }

    // ── 4. Players ───────────────────────────────────────────────────────
    for(int i=0;i<count;i++){
        const StreamPlayer& e=players[i];
        float hx=e.headX*sx, hy=e.headY*sy;
        float fx=e.footX*sx, fy=e.footY*sy;

        float cr,cg,cb2;
        if(e.isBot) {
            // Bot: visible=green, in cover=red (user pick)
            if(e.hasLOS){ cr=0.f;  cg=1.f; cb2=0.f; }   // green — bot outside cover
            else         { cr=1.f;  cg=0.f; cb2=0.f; }   // red — bot in cover
        } else {
            // Enemy: visible=green, in cover=red
            if(e.hasLOS){ cr=0.f;  cg=1.f; cb2=0.f; }   // green — enemy outside cover
            else         { cr=1.f;  cg=0.f; cb2=0.f; }   // red — enemy in cover
        }

        // ESP Line — from below counter to head (ONLY, no feet line)
        if(drawLine){
            s_col(cr,cg,cb2,1.f);
            s_line(lineOriginX,lineOriginY, hx,hy-20.f*sy, 1.0f);
        }

        // Skeleton — UPPER BODY ONLY (no leg/feet lines)
        // Removed: pelvis→thigh→calf→foot chains
        if(drawSkel){
            auto bl=[&](int a,int b){
                float ax=e.bones[a][0]*sx,ay=e.bones[a][1]*sy;
                float bx=e.bones[b][0]*sx,by=e.bones[b][1]*sy;
                s_col(cr,cg,cb2,0.9f); s_line(ax,ay,bx,by,0.8f);
            };
            // Spine: Head(0)→neck(1)→spine_03(2)→spine_02(3)→spine_01(4)→pelvis(5)
            bl(0,1);bl(1,2);bl(2,3);bl(3,4);bl(4,5);
            // Right arm: neck(1)→clavicle_r(6)→lowerarm_r(7)→hand_r(8)
            bl(1,6);bl(6,7);bl(7,8);
            // Left arm: neck(1)→clavicle_l(9)→lowerarm_l(10)→hand_l(11)
            bl(1,9);bl(9,10);bl(10,11);
            // NO LEG LINES (removed bl(5,12)→thigh→calf→foot)
            // head dot
            s_col(cr,cg,cb2,1.f); s_rect(hx-3.f,hy-3.f,hx+3.f,hy+3.f);
        }

        // Health — green=alive, red=knocked
        if(drawHealth && e.healthMax>0.f){
            float hp=std::max(0.f,std::min(e.health/e.healthMax,1.f));
            float bw=34.f*sx; if(bw<20.f)bw=20.f; if(bw>50.f)bw=50.f;
            float bht=3.f, bx2=hx-bw*0.5f, by2=hy-8.f*sy;
            s_col(0.1f,0.1f,0.1f,0.7f); s_rect(bx2,by2,bx2+bw,by2+bht);
            float hr,hg,hb2;
            if(e.isKnocked){ hr=1.f;  hg=0.f;  hb2=0.f; }   // red — knocked
            else            { hr=0.2f; hg=0.6f; hb2=1.f; }  // blue — alive
            s_col(hr,hg,hb2,0.95f); s_rect(bx2,by2,bx2+bw*hp,by2+bht);
        }

        // Distance below foot
        if(drawDist){
            char db[16]; snprintf(db,sizeof(db),"%dm",(int)e.distance);
            const float dsc=1.6f;
            float tw=s_txtW(db,dsc),th=7.f*dsc;
            float dx=fx-tw*0.5f, dy=fy+4.f;
            s_col(0.05f,0.05f,0.07f,0.82f); s_rect(dx-3,dy-2,dx+tw+3,dy+th+2);
            s_col(0,0,0,0.9f); s_drawTxt(db,dx+1,dy+1,dsc);
            s_col(1.f,0.55f,0.f,1.f); s_drawTxt(db,dx,dy,dsc);  // orange
        }

        // Name below distance
        if(drawName){
            const char* nm=e.isBot?"Bot":e.name;
            const float nsc=1.6f;
            float tw=s_txtW(nm,nsc),th=7.f*nsc;
            float nx=fx-tw*0.5f, ny=fy+4.f+(drawDist?(7.f*1.6f+8.f):0.f);
            s_col(0.04f,0.04f,0.06f,0.82f); s_rect(nx-3,ny-2,nx+tw+3,ny+th+2);
            s_col(0,0,0,0.9f); s_drawTxt(nm,nx+1,ny+1,nsc);
            s_col(1.f,0.55f,0.f,1.f);  // orange for all names in HideESP mode
            s_drawTxt(nm,nx,ny,nsc);
        }
    }

    eglSwapBuffers(s_sDpy,s_sSurf);
    eglMakeCurrent(saveDpy,saveDraw,saveRead,saveCtx);
}

// ── Clear the hidden stream surface ONCE (blank it) ──────────────────────────
// Call this when HideESP turns OFF, so the last hidden-ESP frame doesn't stay
// stuck on the eSkipScreenshot surface next to the normal (canvas) ESP.
// Uses the SAME save/restore context pattern as StreamESP_DrawFrame (safe).
static void StreamESP_ClearOnce() {
    if(!s_streamReady) return;

    EGLDisplay saveDpy=eglGetCurrentDisplay();
    EGLSurface saveDraw=eglGetCurrentSurface(EGL_DRAW);
    EGLSurface saveRead=eglGetCurrentSurface(EGL_READ);
    EGLContext saveCtx=eglGetCurrentContext();

    eglMakeCurrent(s_sDpy,s_sSurf,s_sSurf,s_sCtx);
    eglQuerySurface(s_sDpy,s_sSurf,EGL_WIDTH,&s_sW);
    eglQuerySurface(s_sDpy,s_sSurf,EGL_HEIGHT,&s_sH);
    glViewport(0,0,s_sW,s_sH);
    glClearColor(0.f,0.f,0.f,0.f);
    glClear(GL_COLOR_BUFFER_BIT);
    eglSwapBuffers(s_sDpy,s_sSurf);

    eglMakeCurrent(saveDpy,saveDraw,saveRead,saveCtx);
}
