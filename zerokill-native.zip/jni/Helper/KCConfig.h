#pragma once
// ╔══════════════════════════════════════════════════════════════╗
// ║  KCConfig.h — APNA DETAILS YAHAN CHANGE KARO               ║
// ╚══════════════════════════════════════════════════════════════╝

// ── Loader APK Package Name ─────────────────────────────────

// ── Lic File written by the LOADER (read-only here) ─────────
// Loader writes: key\nserial\npkg  →  /storage/emulated/0/Android/ZeroKill.lic
#define LIC_FILE_NAME  "ZeroKill.lic"
#define LIC_DIR        "/storage/emulated/0/Android/"

// ── Panel URL (validbool endpoint) ──────────────────────────
#define KC_MY_PANEL_URL  "https://zerokill.authapi.xyz/server"
