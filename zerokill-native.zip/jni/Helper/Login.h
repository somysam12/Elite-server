#pragma once
#include "KCSecure.h"    // KC_PANEL_URL() — obfuscated URL at runtime

#include <curl/curl.h>
#include <string>
#include <ctime>
#include <cstring>
#include <cstdlib>

// ── Global declarations ───────────────────────────────────────────────────
bool        bconfiger = false;
bool        bValid    = false;
bool        isLogin   = false;
std::string EXP;
std::string g_Token, g_Auth;   // kept for compatibility; set equal on success
android_app *g_App = 0;

// Expiry unix timestamp from server reply.
//   -1 = unknown/not set   ·   0 = lifetime   ·   >0 = expiry unix ts
long long g_KC_ExpUnix = -1;

// ─────────────────────────────────────────────────────────────────────────

std::string getClipboardText() {
    if (!g_App) return "";
    auto activity = g_App->activity;
    if (!activity) return "";
    auto vm = activity->vm;
    if (!vm) return "";
    auto object = activity->clazz;
    if (!object) return "";

    std::string result;
    JNIEnv *env;
    vm->AttachCurrentThread(&env, 0);
    {
        auto ContextClass = env->FindClass("android/content/Context");
        auto getSystemServiceMethod = env->GetMethodID(ContextClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
        auto str = env->NewStringUTF("clipboard");
        auto clipboardManager = env->CallObjectMethod(object, getSystemServiceMethod, str);
        env->DeleteLocalRef(str);
        auto ClipboardManagerClass = env->FindClass("android/content/ClipboardManager");
        auto getText = env->GetMethodID(ClipboardManagerClass, "getText", "()Ljava/lang/CharSequence;");
        auto CharSequenceClass = env->FindClass("java/lang/CharSequence");
        auto toStringMethod = env->GetMethodID(CharSequenceClass, "toString", "()Ljava/lang/String;");
        auto text = env->CallObjectMethod(clipboardManager, getText);
        if (text) {
            str = (jstring) env->CallObjectMethod(text, toStringMethod);
            result = env->GetStringUTFChars(str, 0);
            env->DeleteLocalRef(str);
            env->DeleteLocalRef(text);
        }
        env->DeleteLocalRef(CharSequenceClass);
        env->DeleteLocalRef(ClipboardManagerClass);
        env->DeleteLocalRef(clipboardManager);
        env->DeleteLocalRef(ContextClass);
    }
    vm->DetachCurrentThread();
    return result;
}

const char *GetAndroidID(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(StrEnc("`L+&0^[S+-:J^$,r9q92(as", "\x01\x22\x4F\x54\x5F\x37\x3F\x7C\x48\x42\x54\x3E\x3B\x4A\x58\x5D\x7A\x1E\x57\x46\x4D\x19\x07", 23).c_str());
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass, StrEnc("E8X\\7r7ys_Q%JS+L+~", "\x22\x5D\x2C\x1F\x58\x1C\x43\x1C\x1D\x2B\x03\x40\x39\x3C\x47\x3A\x4E\x0C", 18).c_str(), StrEnc("8^QKmj< }5D:9q7f.BXkef]A*GYLNg}B!/L", "\x10\x77\x1D\x2A\x03\x0E\x4E\x4F\x14\x51\x6B\x59\x56\x1F\x43\x03\x40\x36\x77\x28\x0A\x08\x29\x24\x44\x33\x0B\x29\x3D\x08\x11\x34\x44\x5D\x77", 35).c_str());
    jclass settingSecureClass = env->FindClass(StrEnc("T1yw^BCF^af&dB_@Raf}\\FS,zT~L(3Z\"", "\x35\x5F\x1D\x05\x31\x2B\x27\x69\x2E\x13\x09\x50\x0D\x26\x3A\x32\x7D\x32\x03\x09\x28\x2F\x3D\x4B\x09\x70\x2D\x29\x4B\x46\x28\x47", 32).c_str());
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass, StrEnc("e<F*J5c0Y", "\x02\x59\x32\x79\x3E\x47\x0A\x5E\x3E", 9).c_str(), StrEnc("$6*%R*!XO\"m18o,0S!*`uI$IW)l_/_knSdlRiO1T`2sH|Ouy__^}%Y)JsQ:-\"(2_^-$i{?H", "\x0C\x7A\x4B\x4B\x36\x58\x4E\x31\x2B\x0D\x0E\x5E\x56\x1B\x49\x5E\x27\x0E\x69\x0F\x1B\x3D\x41\x27\x23\x7B\x09\x2C\x40\x33\x1D\x0B\x21\x5F\x20\x38\x08\x39\x50\x7B\x0C\x53\x1D\x2F\x53\x1C\x01\x0B\x36\x31\x39\x46\x0C\x15\x43\x2B\x05\x30\x15\x41\x43\x46\x55\x70\x0D\x59\x56\x00\x15\x58\x73", 71).c_str());
    auto obj = env->CallObjectMethod(context, getContentResolverMethod);
    auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj, env->NewStringUTF(StrEnc("ujHO)8OfOE", "\x14\x04\x2C\x3D\x46\x51\x2B\x39\x26\x21", 10).c_str()));
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceModel(JNIEnv *env) {
    jclass buildClass = env->FindClass(StrEnc("m5I{GKGWBP-VOxkA", "\x0C\x5B\x2D\x09\x28\x22\x23\x78\x2D\x23\x02\x14\x3A\x11\x07\x25", 16).c_str());
    jfieldID modelId = env->GetStaticFieldID(buildClass, StrEnc("|}[q:", "\x31\x32\x1F\x34\x76", 5).c_str(), StrEnc(".D:C:ETZ1O-Ib&^h.Y", "\x62\x2E\x5B\x35\x5B\x6A\x38\x3B\x5F\x28\x02\x1A\x16\x54\x37\x06\x49\x62", 18).c_str());
    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceBrand(JNIEnv *env) {
    jclass buildClass = env->FindClass(StrEnc("0iW=2^>0zTRB!B90", "\x51\x07\x33\x4F\x5D\x37\x5A\x1F\x15\x27\x7D\x00\x54\x2B\x55\x54", 16).c_str());
    jfieldID modelId = env->GetStaticFieldID(buildClass, StrEnc("@{[FP", "\x02\x29\x1A\x08\x14", 5).c_str(), StrEnc(".D:C:ETZ1O-Ib&^h.Y", "\x62\x2E\x5B\x35\x5B\x6A\x38\x3B\x5F\x28\x02\x1A\x16\x54\x37\x06\x49\x62", 18).c_str());
    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetPackageName(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(StrEnc("`L+&0^[S+-:J^$,r9q92(as", "\x01\x22\x4F\x54\x5F\x37\x3F\x7C\x48\x42\x54\x3E\x3B\x4A\x58\x5D\x7A\x1E\x57\x46\x4D\x19\x07", 23).c_str());
    jmethodID getPackageNameId = env->GetMethodID(contextClass, StrEnc("YN4DaP)!{wRGN}", "\x3E\x2B\x40\x14\x00\x33\x42\x40\x1C\x12\x1C\x26\x23\x18", 14).c_str(), StrEnc("VnpibEspM(b]<s#[9cQD", "\x7E\x47\x3C\x03\x03\x33\x12\x5F\x21\x49\x0C\x3A\x13\x20\x57\x29\x50\x0D\x36\x7F", 20).c_str());
    auto str = (jstring) env->CallObjectMethod(context, getPackageNameId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceUniqueIdentifier(JNIEnv *env, const char *uuid) {
    jclass uuidClass = env->FindClass(StrEnc("B/TxJ=3BZ_]SFx", "\x28\x4E\x22\x19\x65\x48\x47\x2B\x36\x70\x08\x06\x0F\x3C", 14).c_str());
    auto len = strlen(uuid);
    jbyteArray myJByteArray = env->NewByteArray(len);
    env->SetByteArrayRegion(myJByteArray, 0, len, (jbyte *) uuid);
    jmethodID nameUUIDFromBytesMethod = env->GetStaticMethodID(uuidClass, StrEnc("P6LV|'0#A+zQmoat,", "\x3E\x57\x21\x33\x29\x72\x79\x67\x07\x59\x15\x3C\x2F\x16\x15\x11\x5F", 17).c_str(), StrEnc("sW[\"Q[W3,7@H.vT0) xB", "\x5B\x0C\x19\x0B\x1D\x31\x36\x45\x4D\x18\x35\x3C\x47\x1A\x7B\x65\x7C\x69\x3C\x79", 20).c_str());
    jmethodID toStringMethod = env->GetMethodID(uuidClass, StrEnc("2~5292eW", "\x46\x11\x66\x46\x4B\x5B\x0B\x30", 8).c_str(), StrEnc("P$BMc' #j?<:myTh_*h0", "\x78\x0D\x0E\x27\x02\x51\x41\x0C\x06\x5E\x52\x5D\x42\x2A\x20\x1A\x36\x44\x0F\x0B", 20).c_str());
    auto obj = env->CallStaticObjectMethod(uuidClass, nameUUIDFromBytesMethod, myJByteArray);
    auto str = (jstring) env->CallObjectMethod(obj, toStringMethod);
    return env->GetStringUTFChars(str, 0);
}

// ── Simple curl write callback ────────────────────────────────────────────
static size_t _zk_curl_write(char *ptr, size_t sz, size_t nmemb, std::string *out) {
    out->append(ptr, sz * nmemb);
    return sz * nmemb;
}

// ── Minimal JSON string extractor — finds "key":"value" ──────────────────
static std::string _zk_json_str(const std::string &json, const char *key) {
    std::string k = std::string("\"") + key + "\"";
    auto pos = json.find(k);
    if (pos == std::string::npos) return "";
    pos = json.find(':', pos + k.size());
    if (pos == std::string::npos) return "";
    pos = json.find('"', pos + 1);
    if (pos == std::string::npos) return "";
    auto end = json.find('"', pos + 1);
    if (end == std::string::npos) return "";
    return json.substr(pos + 1, end - pos - 1);
}

// ── Minimal JSON int extractor — finds "key": N ───────────────────────────
static long long _zk_json_int(const std::string &json, const char *key) {
    std::string k = std::string("\"") + key + "\"";
    auto pos = json.find(k);
    if (pos == std::string::npos) return -1;
    pos = json.find(':', pos + k.size());
    if (pos == std::string::npos) return -1;
    pos++;
    while (pos < json.size() && (json[pos] == ' ' || json[pos] == '\t')) pos++;
    if (pos >= json.size()) return -1;
    return strtoll(json.c_str() + pos, nullptr, 10);
}

// ── POST to ZeroKill panel and return status string ───────────────────────
// Request : game=BGMI&user_key=KEY&serial=SERIAL
// Response: JSON with "valid" (1/0), "status"/"msg", "expiry" ("YYYY-MM-DD" or "Lifetime")
static std::string ZK_DoLogin(const std::string &url,
                               const char *userKey,
                               const std::string &serial,
                               const std::string & /*pkgName*/) {
    CURL *curl = curl_easy_init();
    if (!curl) return "CONNECTION_FAILED";

    std::string resp;
    std::string fields = std::string("game=PUBG&user_key=") + userKey + "&serial=" + serial;

    curl_easy_setopt(curl, CURLOPT_URL,           url.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS,    fields.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, _zk_curl_write);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA,     &resp);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT,       15L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

    CURLcode rc = curl_easy_perform(curl);
    curl_easy_cleanup(curl);

    if (rc != CURLE_OK) return "CONNECTION_FAILED";

    // Parse fields
    long long   valid  = _zk_json_int(resp, "valid");
    std::string status = _zk_json_str(resp, "status");
    std::string msg    = _zk_json_str(resp, "msg");
    std::string expiry = _zk_json_str(resp, "expiry");

    bool ok = (valid == 1) || (status == "OK") || (status == "ok") || (status == "success");

    if (ok) {
        // Set expiry
        if (!expiry.empty() && expiry != "Lifetime" && expiry != "lifetime" && expiry != "0") {
            struct tm tmv = {};
            char *parsed = strptime(expiry.c_str(), "%Y-%m-%d", &tmv);
            if (parsed) {
                tmv.tm_hour = 23; tmv.tm_min = 59; tmv.tm_sec = 59;
                g_KC_ExpUnix = (long long)mktime(&tmv);
                EXP = expiry;
            } else {
                g_KC_ExpUnix = 0;
                EXP = "Lifetime";
            }
        } else {
            g_KC_ExpUnix = 0;
            EXP = "Lifetime";
        }
        // satisfy the g_Auth == g_Token check in main.cpp
        g_Token = "ZK_OK";
        g_Auth  = "ZK_OK";
        bValid    = true;
        bconfiger = true;
        return "OK";
    }

    g_KC_ExpUnix = -1;
    EXP          = "";
    bValid        = false;
    bconfiger     = false;

    // Map to status codes
    std::string code = msg.empty() ? status : msg;
    if (code == "MAINTENANCE") return "MAINTENANCE";
    if (code == "EXPIRED")     return "EXPIRED";
    if (code == "MAX_DEVICE")  return "MAX_DEVICE";
    if (code == "CLONE")       return "CLONE";
    if (code == "BLOCKED")     return "BLOCKED";
    return "INVALID";
}

// ─────────────────────────────────────────────────────────────────────────

std::string Login(const char *userKey) {
    if (!g_App)                  return "Internal Error";
    auto activity = g_App->activity;
    if (!activity)               return "Internal Error";
    auto vm = activity->vm;
    if (!vm)                     return "Internal Error";
    auto object = activity->clazz;
    if (!object)                 return "Internal Error";

    JNIEnv *env;
    vm->AttachCurrentThread(&env, 0);
    std::string hwid = userKey;
    hwid += GetAndroidID(env, object);
    hwid += GetDeviceModel(env);
    hwid += GetDeviceBrand(env);
    std::string UUID    = GetDeviceUniqueIdentifier(env, hwid.c_str());
    std::string pkgName = (Gamepackage && Gamepackage[0]) ? Gamepackage : "com.bgmi";
    vm->DetachCurrentThread();

    return ZK_DoLogin(KC_PANEL_URL(), userKey, UUID, pkgName);
}

// Called when loader already wrote serial to lic file — use loader's UUID directly.
std::string LoginWithSerial(const char *userKey, const std::string &preComputedUUID) {
    std::string pkgName = (Gamepackage && Gamepackage[0]) ? Gamepackage : "com.bgmi";
    return ZK_DoLogin(KC_PANEL_URL(), userKey, preComputedUUID, pkgName);
}
