// ═══════════════════════════════════════════════════════════════════════════
// KC_GuestLogin.h — Guest login channel injection (Lua)
//
// Fires at the same time as Twitter login (as soon as isLogin becomes true).
// Patches GetLoginTypeList to include the guest channel so the login screen
// shows the Guest option.
// ═══════════════════════════════════════════════════════════════════════════
#pragma once

static const char* kc_guest_login_script = R"KCGUEST(
pcall(function()
    local function _TDR_get_guest_channel_value()
        local shareSource = rawget(_G, "ShareSource")
        if type(shareSource) == "table" and shareSource.Guest ~= nil then
            return shareSource.Guest
        end
        return "guest"
    end

    local function _TDR_table_contains(list, value)
        if type(list) ~= "table" then return false end
        for _, v in ipairs(list) do
            if v == value then return true end
        end
        return false
    end

    local function _TDR_ensure_guest_channel_list(list)
        local guestChannel = _TDR_get_guest_channel_value()
        if type(list) ~= "table" then list = {} end
        if not _TDR_table_contains(list, guestChannel) then
            list[#list + 1] = guestChannel
        end
        return list
    end

    local function _TDR_generate_guest_name()
        math.randomseed(os.time() or 1)
        local prefix = "HyperX_"
        local charset = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        local suffix = {}
        for i = 1, 6 do
            suffix[#suffix + 1] = charset:sub(math.random(1, #charset), math.random(1, #charset))
        end
        local name = prefix .. table.concat(suffix)
        if #name > 14 then name = name:sub(1, 14) end
        _G.TDR_GuestGeneratedName = name
        return name
    end

    _G.TDR_GetGuestGeneratedName = function()
        local n = rawget(_G, "TDR_GuestGeneratedName")
        if type(n) == "string" and #n > 0 then return n end
        return _TDR_generate_guest_name()
    end

    local function _TDR_patch_login_module(m)
        if type(m) ~= "table" then return false end
        if m.__TDR_GuestLoginPatched == true then return true end
        if type(m.GetLoginTypeList) ~= "function" then return false end
        local orig = m.GetLoginTypeList
        m.GetLoginTypeList = function(self, ...)
            return _TDR_ensure_guest_channel_list(orig(self, ...))
        end
        m.__TDR_GuestLoginPatched = true
        return true
    end

    local function _TDR_try_patch()
        local ok, MM = pcall(require, "client.module_framework.ModuleManager")
        if ok and MM and MM.GetModule and MM.LobbyModuleConfig then
            local ok2, mod = pcall(function()
                return MM.GetModule(MM.LobbyModuleConfig.login_module)
            end)
            if ok2 and mod then _TDR_patch_login_module(mod) end
        end
    end

    pcall(function()
        local ok, ticker = pcall(require, "common.time_ticker")
        if ok and ticker and ticker.AddTimerLoop then
            ticker.AddTimerLoop(0, function() pcall(_TDR_try_patch) end, -1, 2.0)
        else
            pcall(_TDR_try_patch)
        end
    end)
end)
)KCGUEST";
