
-- Weapon Skin Maps - Only Weapon IDs
local WeaponSkins = {
   [101004] = 1101004046, -- M416
   [101001] = 1101001276, -- Akm
   [101003] = 1101003227, -- Scarl
   [101002] = 1101002081, -- M16A4
   [101005] = 1101005098, -- GROZA
   [101006] = 1101006106, -- AUG
   [101007] = 1101007062, -- QBZ
   [101008] = 1101008136, -- M762
   [101102] = 1101102056, -- Beam Blast - ACE32
   [101101] = 1101101007, -- Darkwing Raven - ASM Abakan
   [103003] = 1103003087, -- Serpengleam - AWM
   [103002] = 1103002087, -- Cadence Maestro - M24
   [103001] = 1103001179, -- Violet Volt - Kar98K
   [103012] = 1103012019, -- Scorching Blessing - AMR
   [103007] = 1103007028, -- Drakreign - Mk14
   [103004] = 1103004037, -- Lady Carmine - SKS
   [103009] = 1103009037, -- SLR
   [103006] = 1103006030, -- Icicle - Mini14
   [103100] = 1103100007, -- MK12
   [105002] = 1105002091, -- DP28
   [105010] = 1105010019, -- Sky Huntress - MG3
   [105001] = 1105001069, -- M249
   [102001] = 1102001120, -- Glacier Hammer - UZI
   [102002] = 1102002136, -- Cryofrost Shard - UMP45
   [102003] = 1102003080, -- Mecha Drake - Vector
   [102004] = 1102004018, -- THOMPSON
   [102005] = 1102005064, -- BIZON
   [103005] = 1103005024, -- VSS
   [102105] = 1102105028, -- P90
   [104003] = 1104003046, -- S12K
   [104002] = 1104002022, -- S1897
   [104004] = 1104004041, -- DBS
   [101012] = 1101012033, -- Honey Badger
   [101100] = 1101100012, -- Origin Lumen - FAMAS
   [108004] = 1108004027, -- PAN
   [108001] = 1108001069, -- Machete
   [108005] = 1108005053, -- Dagger
}

-- Force single path for kill counter
local SINGLE_KILL_PATH = '__DUNE_KILLCOUNTER_PATH__'

-- Override GetKillCounterPath to use single path
if _G.__DuneTrack then _G.__DuneTrack(_G, 'GetKillCounterPath') end
_G.GetKillCounterPath = function()
    return SINGLE_KILL_PATH
end

_G.killCountInfo = _G.killCountInfo or {}
_G.lastFileContent = ""
_G.isFileWatcherActive = false
_G.LastKillTime = {}
_G.lastDisplayedKills = {}

if _G.__DuneTrack then _G.__DuneTrack(_G, 'loadKillCountFromFile') end
function _G.loadKillCountFromFile()
    if not _G.ActiveKillCounterPath then _G.ActiveKillCounterPath = _G.GetKillCounterPath() end
    local path = _G.ActiveKillCounterPath
    
    local file = io.open(path, 'r')
    if file then
        local content = file:read('*a')
        file:close()
        _G.lastFileContent = content
        
        if content ~= '' then
            content = content:gsub('\239\187\191', ''):gsub('^%s+', '')
            local tempTable = {}
            for weaponID, count in content:gmatch('%[(%d+)%]%s*=%s*(%d+)') do
                tempTable[tonumber(weaponID)] = tonumber(count)
            end
            if next(tempTable) then 
                _G.killCountInfo = tempTable 
            end
        end
    end
end

local function saveKillCountToFile()
    local content = '{\n'
    for weaponID, count in pairs(_G.killCountInfo) do
        content = content .. string.format('    [%d] = %d,\n', weaponID, count)
    end
    content = content .. '}'
    
    if _G.ActiveKillCounterPath then
        local file = io.open(_G.ActiveKillCounterPath, 'w+')
        if file then
            file:write(content)
            file:close()
            _G.lastFileContent = content
            return
        end
        _G.ActiveKillCounterPath = nil
    end
    
    local path = _G.GetKillCounterPath()
    local file = io.open(path, 'w+')
    if file then
        file:write(content)
        file:close()
        _G.ActiveKillCounterPath = path
        _G.lastFileContent = content
        return
    end
end

if _G.__DuneTrack then _G.__DuneTrack(_G, 'getKills') end
function _G.getKills(weaponID)
    return weaponID and _G.killCountInfo[weaponID] or 0
end

if _G.__DuneTrack then _G.__DuneTrack(_G, 'UpdateCurrentWeaponSkinID') end
function _G.UpdateCurrentWeaponSkinID()
    pcall(function()
        local PlayerController = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
        if not PlayerController then return end
        local uCharacter = PlayerController:GetPlayerCharacterSafety()
        if not uCharacter then
            _G.CurrentWeaponAvatarSkinID = nil
            return
        end
        local currweapon = uCharacter:GetCurrentWeapon()
        if not slua.isValid(currweapon) then
            _G.CurrentWeaponAvatarSkinID = nil
            return
        end
        local wac = currweapon.WeaponAvatarComponent
        if slua.isValid(wac) and wac.GetEquippedItemDefineID then
            local ES = import("EWeaponAttachmentSocketType")
            local defineID = wac:GetEquippedItemDefineID(ES.MasterGun)
            if defineID and defineID.TypeSpecificID and defineID.TypeSpecificID > 0 then
                _G.CurrentWeaponAvatarSkinID = defineID.TypeSpecificID
                return
            end
        end
        _G.CurrentWeaponAvatarSkinID = nil
    end)
end

if _G.__DuneTrack then _G.__DuneTrack(_G, 'UpdateCurrentClothAvatarID') end
function _G.UpdateCurrentClothAvatarID()
    pcall(function()
        local PlayerController = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
        if not PlayerController then return end
        local uCharacter = PlayerController:GetPlayerCharacterSafety()
        if not uCharacter then
            _G.CurrentClothAvatarID = nil
            return
        end
        local AvatarComponent = uCharacter:getAvatarComponent2()
        if slua.isValid(AvatarComponent) then
            local DefienID = AvatarComponent:GetEquippedItemDefineID(5)
            if DefienID and DefienID.TypeSpecificID and DefienID.TypeSpecificID > 0 then
                _G.CurrentClothAvatarID = DefienID.TypeSpecificID
                return
            end
        end
        _G.CurrentClothAvatarID = nil
    end)
end

if _G.__DuneTrack then _G.__DuneTrack(_G, 'addKill') end
function _G.addKill(weaponID, count)
    if not weaponID or not count then return end
    
    local currentTime = os.clock()
    if _G.LastKillTime[weaponID] and (currentTime - _G.LastKillTime[weaponID]) < 0.5 then
        return
    end
    _G.LastKillTime[weaponID] = currentTime

    _G.killCountInfo[weaponID] = (_G.killCountInfo[weaponID] or 0) + count
    pcall(saveKillCountToFile)

    pcall(function()
        _G.UpdateCurrentWeaponSkinID()
        local PlayerController = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
        if PlayerController then
            local uCharacter = PlayerController:GetPlayerCharacterSafety()
            if uCharacter then
                local currweapon = uCharacter:GetCurrentWeapon()
                if currweapon and _G.OurkillCountSystem and _G.CurrentWeaponAvatarSkinID and _G.CurrentWeaponAvatarSkinID > 10000000 then
                    _G.OurkillCountSystem:UpdateMainKillCounterUI(true, weaponID, _G.CurrentWeaponAvatarSkinID)
                end
            end
        end
    end)
end

_G._CustomNameCache = nil
_G._CustomNameContentCache = nil

if _G.__DuneTrack then _G.__DuneTrack(_G, 'GetCustomNamePath') end
function _G.GetCustomNamePath()
    local possiblePaths = {
        '/storage/emulated/0/Android/obb/com.pubg.imobile/cahce.txt',
        '/storage/emulated/0/Android/data/com.pubg.krmobile/files/cahce.txt',
        '/storage/emulated/0/Android/data/com.vng.pubgmobile/files/cahce.txt',
        '/storage/emulated/0/Android/data/com.rekoo.pubgm/files/cahce.txt'
    }
    for _, path in ipairs(possiblePaths) do
        local file = io.open(path, 'r')
        if file then
            file:close()
            return path
        end
    end
    return nil
end

if _G.__DuneTrack then _G.__DuneTrack(_G, 'GetCustomName') end
function _G.GetCustomName()
    if not _G._CustomNameCache then
        _G._CustomNameCache = _G.GetCustomNamePath()
    end
    if not _G._CustomNameCache then return nil end
    
    pcall(function()
        local file = io.open(_G._CustomNameCache, 'r')
        if not file then
            _G._CustomNameCache = nil
            return
        end
        local content = file:read('*a') or ""
        file:close()
        content = content:gsub('^%s+', ''):gsub('%s+$', '')
        if content == "" then return end
        if content == _G._CustomNameContentCache then return end
        _G._CustomNameContentCache = content
    end)
    return _G._CustomNameContentCache
end

if _G.__DuneTrack then _G.__DuneTrack(_G, 'ForceUpdateKillCounterUI') end
function _G.ForceUpdateKillCounterUI()
    pcall(function()
        local PlayerController = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
        if not PlayerController or not slua.isValid(PlayerController) then return end
        
        local uCharacter = PlayerController:GetPlayerCharacterSafety()
        if not uCharacter or not slua.isValid(uCharacter) then return end
        
        local currweapon = uCharacter:GetCurrentWeapon()
        if not slua.isValid(currweapon) then return end
        
        local DefineID = currweapon:GetItemDefineID() and currweapon:GetItemDefineID().TypeSpecificID or 0
        if DefineID == 0 then return end
        
        local currentEquipAvatarID = _G.CurrentWeaponAvatarSkinID
        if not currentEquipAvatarID or currentEquipAvatarID <= 10000000 then return end
        
        local UIManager = require("client.slua_ui_framework.manager")
        local MainKillCounter = UIManager.GetUI(UIManager.UI_Config_InGame.MainKillCounter)
        
        if MainKillCounter and slua.isValid(MainKillCounter) then
            local ModuleManager = require("client.module_framework.ModuleManager")
            local LogicKillCounter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicKillCounter)
            
            local curEquipedKillCounter = LogicKillCounter:GetEquipedKillCounterId(6114302174, currentEquipAvatarID)
            if not curEquipedKillCounter or curEquipedKillCounter == 0 then
                curEquipedKillCounter = LogicKillCounter:GetBaseKillCounterIdByWeaponId(DefineID)
            end
            
            local kills = _G.getKills(DefineID)
            
            MainKillCounter:SetKillCounterItemShowWithNum(
                curEquipedKillCounter, 
                kills,
                currentEquipAvatarID
            )
            
            if MainKillCounter.KillCounterItem and MainKillCounter.KillCounterItem.SetVisibility then
                local ESlateVisibility = import("ESlateVisibility")
                MainKillCounter.KillCounterItem:SetVisibility(ESlateVisibility.Collapsed)
                MainKillCounter.KillCounterItem:SetVisibility(ESlateVisibility.SelfHitTestInvisible)
            end
        end
    end)
end

if _G.__DuneTrack then _G.__DuneTrack(_G, 'FileWatcher') end
function _G.FileWatcher()
    if not _G.isFileWatcherActive then return end
    
    pcall(function()
        if not _G.ActiveKillCounterPath then _G.ActiveKillCounterPath = _G.GetKillCounterPath() end
        local path = _G.ActiveKillCounterPath
        
        local file = io.open(path, 'r')
        if not file then return end
        
        local currentContent = file:read('*a') or ""
        file:close()
        
        currentContent = currentContent:gsub('\239\187\191', ''):gsub('^%s+', ''):gsub('%s+$', '')
        
        if currentContent == "" or currentContent == _G.lastFileContent then return end
        
        _G.lastFileContent = currentContent
        
        local tempTable = {}
        for weaponID, count in currentContent:gmatch('%[(%d+)%]%s*=%s*(%d+)') do
            tempTable[tonumber(weaponID)] = tonumber(count)
        end
        
        if not next(tempTable) then return end
        
        _G.killCountInfo = tempTable
        _G.ForceUpdateKillCounterUI()
    end)
end

if _G.__DuneTrack then _G.__DuneTrack(_G, 'CheckAndRefreshKillUI') end
function _G.CheckAndRefreshKillUI()
    pcall(function()
        local PlayerController = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
        if not PlayerController then return end
        
        local uCharacter = PlayerController:GetPlayerCharacterSafety()
        if not uCharacter then return end
        
        local currweapon = uCharacter:GetCurrentWeapon()
        if not currweapon then return end
        
        local DefineID = currweapon:GetItemDefineID().TypeSpecificID
        if DefineID == 0 then return end
        
        local realKills = _G.getKills(DefineID)
        local lastShown = _G.lastDisplayedKills[DefineID] or -1
        
        if realKills ~= lastShown then
            local UIManager = require("client.slua_ui_framework.manager")
            local MainKillCounter = UIManager.GetUI(UIManager.UI_Config_InGame.MainKillCounter)
            
            if MainKillCounter and slua.isValid(MainKillCounter) then
                local currentEquipAvatarID = _G.CurrentWeaponAvatarSkinID
                if currentEquipAvatarID and currentEquipAvatarID > 10000000 then
                    local ModuleManager = require("client.module_framework.ModuleManager")
                    local LogicKillCounter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicKillCounter)
                    
                    local curEquipedKillCounter = LogicKillCounter:GetEquipedKillCounterId(6114302174, currentEquipAvatarID)
                    if not curEquipedKillCounter or curEquipedKillCounter == 0 then
                        curEquipedKillCounter = LogicKillCounter:GetBaseKillCounterIdByWeaponId(DefineID)
                    end
                    
                    MainKillCounter:SetKillCounterItemShowWithNum(
                        curEquipedKillCounter, 
                        realKills,
                        currentEquipAvatarID
                    )
                    
                    _G.lastDisplayedKills[DefineID] = realKills
                end
            end
        end
    end)
end

-- Kill Info / Team Broadcast Hook
pcall(function()
    local SKillInfo = require("GameLua.Mod.BaseMod.Client.KillInfoTips.KillInfo")
    if not SKillInfo or not SKillInfo.__inner_impl then return end
    local ECharacterHealthStatus = import("ECharacterHealthStatus")
    local SKillInfoModuleManager = require("client.module_framework.ModuleManager")

    local O_FileItem = SKillInfo.__inner_impl.FileItem
    if _G.__DuneTrack then _G.__DuneTrack(SKillInfo.__inner_impl, 'FileItem') end
    SKillInfo.__inner_impl.FileItem = function(self, DamageRecordData)
        self.bSelfKill = false

        if not self or not DamageRecordData then
            return O_FileItem(self, DamageRecordData)
        end

        local LogicKillCounter = SKillInfoModuleManager.GetModule(SKillInfoModuleManager.CommonModuleConfig.LogicKillCounter)
        if not LogicKillCounter then
            return O_FileItem(self, DamageRecordData)
        end

        local uCharacter = slua_GameFrontendHUD
            and slua_GameFrontendHUD:GetPlayerController()
            and slua_GameFrontendHUD:GetPlayerController():GetPlayerCharacterSafety()
        if not uCharacter or not slua.isValid(uCharacter) then
            return O_FileItem(self, DamageRecordData)
        end

        local SelfName = uCharacter:GetPlayerNameSafety()
        if DamageRecordData.Causer == SelfName then
            self.bSelfKill = true

            local currWeapon = uCharacter:GetCurrentWeapon()
            if currWeapon and slua.isValid(currWeapon) then
                local DefineID = currWeapon:GetItemDefineID() and currWeapon:GetItemDefineID().TypeSpecificID or 0
                if DefineID ~= 0 then
                    local ExpandData = slua.LuaArchiverDecode(LuaStateWrapper, DamageRecordData.ExpandDataContent) or {}
                    local SupportKillCounter = LogicKillCounter:GetBaseKillCounterIdByWeaponId(DefineID)
                    if SupportKillCounter and DamageRecordData.ResultHealthStatus == ECharacterHealthStatus.FinishedLastBreath then
                        ExpandData.KillCounterItemId = DefineID
                        ExpandData.KillCounterNum = (ExpandData.KillCounterNum or 0) + 1
                        _G.addKill(DefineID, 1)
                    end
                    DamageRecordData.CauserWeaponAvatarID = _G.CurrentWeaponAvatarSkinID
                    DamageRecordData.CauserClothAvatarID = _G.CurrentClothAvatarID
                    DamageRecordData.CauserNation = ""
                    DamageRecordData.VictimNation = ""
                    local customName = _G.GetCustomName()
                    if customName then
                        DamageRecordData.Causer = customName
                    end
                    DamageRecordData.ExpandDataContent = slua.LuaArchiverEncode(LuaStateWrapper, ExpandData)
                end
            end
        end
        O_FileItem(self, DamageRecordData)
    end
end)

-- Main Kill Counter UI Hooks
pcall(function()
    local MyMainKillCounter = require("GameLua.Mod.BaseMod.Client.KillCounter.MainKillCounter")
    local MyKillCountSubSystem = require("GameLua.Mod.BaseMod.Client.KillCounter.KillCounterUISubsystem")
    local MyMainWeaponInfoItemUI = require("GameLua.Mod.BaseMod.Client.Backpack.MainWeaponInfoItemUI")
    local MyMainWeaponKillCounter = require("GameLua.Mod.BaseMod.Client.KillCounter.MainWeaponKillCounter")
    local SubsystemMgr = require("GameLua.GameCore.Module.Subsystem.SubsystemMgr")
    local SlotBase = require("GameLua.Mod.BaseMod.Client.MainControlUI.SwitchWeaponSlotMode2")

    _G.WeaponEvents = _G.WeaponEvents or { onWeaponChanged = function() end }
    _G.OurkillCountSystem = MyKillCountSubSystem.__inner_impl

    if _G.__DuneTrack then _G.__DuneTrack(MyKillCountSubSystem.__inner_impl, 'UpdateMainKillCounterUI') end
    MyKillCountSubSystem.__inner_impl.UpdateMainKillCounterUI = function(self, bShow, WeaponID, AvatarID)
        pcall(function()
            local UIManager = require("client.slua_ui_framework.manager")
            local MainKillCounter = UIManager.GetUI(UIManager.UI_Config_InGame.MainKillCounter)
            local uCharacter = slua_GameFrontendHUD:GetPlayerController():GetPlayerCharacterSafety()
            if not uCharacter then
                if MainKillCounter then UIManager.CloseUI(UIManager.UI_Config_InGame.MainKillCounter) end
                return
            end

            local currweapon = uCharacter:GetCurrentWeapon()
            if not slua.isValid(currweapon) then
                if MainKillCounter then UIManager.CloseUI(UIManager.UI_Config_InGame.MainKillCounter) end
                return
            end

            if not AvatarID or AvatarID <= 10000000 then
                _G.UpdateCurrentWeaponSkinID()
                AvatarID = _G.CurrentWeaponAvatarSkinID
            end

            if not AvatarID or AvatarID <= 10000000 then
                if MainKillCounter then UIManager.CloseUI(UIManager.UI_Config_InGame.MainKillCounter) end
                return
            end

            local DefineID = currweapon:GetItemDefineID().TypeSpecificID
            local ModuleManager = require("client.module_framework.ModuleManager")
            local LogicKillCounter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicKillCounter)
            local SupportKillCounter = LogicKillCounter:GetBaseKillCounterIdByWeaponId(DefineID)

            if not bShow or not SupportKillCounter then
                if MainKillCounter then UIManager.CloseUI(UIManager.UI_Config_InGame.MainKillCounter) end
                return
            end

            local kills = _G.getKills(DefineID)
            local curEquipedKillCounter = LogicKillCounter:GetEquipedKillCounterId(6114302174, AvatarID)

            if not MainKillCounter then
                UIManager.ShowUI(UIManager.UI_Config_InGame.MainKillCounter, DefineID, AvatarID)
                MainKillCounter = UIManager.GetUI(UIManager.UI_Config_InGame.MainKillCounter)
                if MainKillCounter then
                    MainKillCounter:SetKillCounterItemShowWithNum(curEquipedKillCounter, kills, AvatarID)
                end
            else
                if MainKillCounter.UpdateWeaponID then
                    MainKillCounter:UpdateWeaponID(DefineID, AvatarID)
                end
                MainKillCounter:SetKillCounterItemShowWithNum(curEquipedKillCounter, kills, AvatarID)
            end
        end)
    end

    if _G.__DuneTrack then _G.__DuneTrack(MyMainKillCounter.__inner_impl, 'OnRefreshUI') end
    MyMainKillCounter.__inner_impl.OnRefreshUI = function(self, _, _, UID)
        pcall(function()
            local ModuleManager = require("client.module_framework.ModuleManager")
            local LogicKillCounter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicKillCounter)
            local uCharacter = slua_GameFrontendHUD:GetPlayerController():GetPlayerCharacterSafety()
            if not uCharacter then return end
            
            local currweapon = uCharacter:GetCurrentWeapon()
            if currweapon then
                local DefineID = currweapon:GetItemDefineID().TypeSpecificID
                local currentEquipAvatarID = _G.CurrentWeaponAvatarSkinID
                if currentEquipAvatarID and currentEquipAvatarID > 10000000 then
                    local curEquipedKillCounter = LogicKillCounter:GetEquipedKillCounterId(6114302174, currentEquipAvatarID)
                    self.KillCounterItem:SetKillCounterItemShowWithNum(
                        curEquipedKillCounter, 
                        _G.getKills(DefineID),
                        currentEquipAvatarID
                    )
                end
            end
        end)
    end

    if _G.__DuneTrack then _G.__DuneTrack(MyKillCountSubSystem.__inner_impl, 'CheckSupportKCUI') end
    MyKillCountSubSystem.__inner_impl.CheckSupportKCUI = function(self)
        return true
    end

    local o_CheckNeedMainKillCounterUI = MyKillCountSubSystem.__inner_impl.CheckNeedMainKillCounterUI
    if _G.__DuneTrack then _G.__DuneTrack(MyKillCountSubSystem.__inner_impl, 'CheckNeedMainKillCounterUI') end
    MyKillCountSubSystem.__inner_impl.CheckNeedMainKillCounterUI = function(self, Weapon, PlayerID)
        pcall(function()
            local uCharacter = slua_GameFrontendHUD:GetPlayerController():GetPlayerCharacterSafety()
            if not uCharacter then return end
            
            local currweapon = uCharacter:GetCurrentWeapon()
            if currweapon then
                local DefineID = currweapon:GetItemDefineID().TypeSpecificID
                _G.WeaponEvents.onWeaponChanged(DefineID)
            end
        end)
    end

    if _G.__DuneTrack then _G.__DuneTrack(MyMainWeaponKillCounter.__inner_impl, 'OnRefresh') end
    MyMainWeaponKillCounter.__inner_impl.OnRefresh = function(self, SelfUID)
        pcall(function()
            local ModuleManager = require("client.module_framework.ModuleManager")
            local LogicKillCounter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicKillCounter)
            local curEquipedKillCounter = LogicKillCounter:GetMyEquipedKillCounterId(_G.CurrentWeaponAvatarSkinID)
            if _G.CurrentWeaponAvatarSkinID and _G.CurrentWeaponAvatarSkinID > 10000000 then
                self.KillCounterItem:SetKillCounterItemShowWithNum(
                    curEquipedKillCounter, 
                    _G.getKills(self.WeaponID),
                    _G.CurrentWeaponAvatarSkinID
                )
            end
        end)
    end

    local o_DUpdateWeaponAppearanceInfo = MyMainWeaponInfoItemUI.__inner_impl.UpdateWeaponAppearanceInfo
    if _G.__DuneTrack then _G.__DuneTrack(MyMainWeaponInfoItemUI.__inner_impl, 'UpdateWeaponAppearanceInfo') end
    MyMainWeaponInfoItemUI.__inner_impl.UpdateWeaponAppearanceInfo = function(self, TypeSpecificID, BattleData, DragOrigin)
        pcall(function()
            o_DUpdateWeaponAppearanceInfo(self, TypeSpecificID, BattleData, DragOrigin)
            self:UpdateKillCounter(true)
        end)
    end

    local o_DUpdateKillCounter = MyMainWeaponInfoItemUI.__inner_impl.UpdateKillCounter
    if _G.__DuneTrack then _G.__DuneTrack(MyMainWeaponInfoItemUI.__inner_impl, 'UpdateKillCounter') end
    MyMainWeaponInfoItemUI.__inner_impl.UpdateKillCounter = function(self, bShow)
        pcall(function()
            local KillCounterUISubsystem = SubsystemMgr:Get("KillCounterUISubsystem")
            if not KillCounterUISubsystem then bShow = false end
            
            if bShow then
                local ModuleManager = require("client.module_framework.ModuleManager")
                local LogicKillCounter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicKillCounter)
                local curEquipedKillCounter = LogicKillCounter:GetBaseKillCounterIdByWeaponId(self.ItemID)
                
                if self.ItemID == self.WeaponIDOrAvatarID then
                    self.UIRoot.CanvasPanel_KillCounter:SetVisibility(UEnums.GSlateVisibility.Collapsed)
                    return
                end
                
                if not curEquipedKillCounter then
                    self.UIRoot.CanvasPanel_KillCounter:SetVisibility(UEnums.GSlateVisibility.Collapsed)
                    return
                end
                
                local UIManager = require("client.slua_ui_framework.manager")
                if not self.KillCounterUI then
                    self.KillCounterUI = UIManager.ShowUI(UIManager.UI_Config_InGame.MainWeaponKillCounter, 
                        self.ItemID, self.WeaponIDOrAvatarID, self)
                    self.UIRoot.CanvasPanel_KillCounter.Slot:SetLayer(1)
                else
                    self.KillCounterUI:UpdateWeaponID(self.ItemID, self.WeaponIDOrAvatarID)
                    self.UIRoot.CanvasPanel_KillCounter:SetVisibility(UEnums.GSlateVisibility.SelfHitTestInvisible)
                end
            end
        end)
    end

    local o_CheckShowKCIcon = SlotBase.__inner_impl.CheckShowKCIcon
    if _G.__DuneTrack then _G.__DuneTrack(SlotBase.__inner_impl, 'CheckShowKCIcon') end
    SlotBase.__inner_impl.CheckShowKCIcon = function(self)
        pcall(function()
            o_CheckShowKCIcon(self)
            
            local ESlateVisibility = import("ESlateVisibility")
            local ModuleManager = require("client.module_framework.ModuleManager")
            local LogicKillCounter = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicKillCounter)
            local CurWeapon = self:GetCurrentWeapon()
            
            if not slua.isValid(CurWeapon) then
                self.KillCounterImg:SetVisibility(ESlateVisibility.Collapsed)
                return
            end
            
            local WeaponID = CurWeapon:GetWeaponID()
            local SupportKillCounter = LogicKillCounter:GetBaseKillCounterIdByWeaponId(WeaponID)
            if SupportKillCounter then
                self.KillCounterImg:SetVisibility(ESlateVisibility.SelfHitTestInvisible)
            end
        end)
    end

    if _G.__DuneTrack then _G.__DuneTrack(_G.WeaponEvents, 'onWeaponChanged') end
    _G.WeaponEvents.onWeaponChanged = function(weaponId)
        pcall(function()
            local retryCount = 0
            local function applySkinAndUpdate()
                _G.UpdateCurrentWeaponSkinID()
                _G.UpdateCurrentClothAvatarID()
                local skinID = _G.CurrentWeaponAvatarSkinID
                local PlayerController = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
                if not PlayerController then return false end
                local uCharacter = PlayerController:GetPlayerCharacterSafety()
                if not uCharacter or not _G.OurkillCountSystem then return false end
                local currweapon = uCharacter:GetCurrentWeapon()
                if not currweapon then
                    _G.OurkillCountSystem:UpdateMainKillCounterUI(false, 0, nil)
                    return true
                end
                local DefineID = currweapon:GetItemDefineID().TypeSpecificID
                if (not skinID or skinID <= 10000000) and retryCount < 5 then
                    return false
                end
                if skinID and skinID > 10000000 then
                    _G.OurkillCountSystem:UpdateMainKillCounterUI(true, DefineID, skinID)
                else
                    _G.OurkillCountSystem:UpdateMainKillCounterUI(false, 0, nil)
                end
                return true
            end
            
            local function tryApply()
                if _G.__DuneSkinCtl and not _G.__DuneSkinCtl.enabled then return end
                if applySkinAndUpdate() then return end
                retryCount = retryCount + 1
                if retryCount <= 5 then
                    local uCharacter = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController():GetPlayerCharacterSafety()
                    if uCharacter and uCharacter.AddGameTimer then
                        uCharacter:AddGameTimer(0.1, false, tryApply)
                    end
                end
            end
            
            tryApply()
        end)
    end
end)

-- Weapon Skin Hook - Backpack Function Library
pcall(function()
    local BPL = require("GameLua.Mod.BaseMod.Client.Backpack.BackPackFunctionLibrary")
    if BPL and BPL.GetWeaponAvatarRes and not BPL._lava_hooked_avatar_res then
        BPL._lava_hooked_avatar_res = true
        local origGetRes = BPL.GetWeaponAvatarRes
        if _G.__DuneTrack then _G.__DuneTrack(BPL, 'GetWeaponAvatarRes') end
        BPL.GetWeaponAvatarRes = function(WeaponID, AdditionalDataArray)
            WeaponID = tonumber(WeaponID) or 0
            if WeaponID <= 0 then return origGetRes(WeaponID, AdditionalDataArray) end
            
            local targetSkinID = WeaponSkins[WeaponID]
            if targetSkinID and targetSkinID > 0 and targetSkinID ~= WeaponID then
                return targetSkinID, ""
            end
            
            return origGetRes(WeaponID, AdditionalDataArray)
        end
    end
end)

_G.loadKillCountFromFile()
_G.isFileWatcherActive = true

if _G.Mytimer_ticker then
    pcall(function()
        _G.Mytimer_ticker.AddTimerLoop(0, _G.FileWatcher, -1, 0.5)       
        _G.Mytimer_ticker.AddTimerLoop(0, function()
            pcall(function()
                local PlayerController = slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()
                if not PlayerController then return end
                local uCharacter = PlayerController:GetPlayerCharacterSafety()
                if not uCharacter then return end
                local currweapon = uCharacter:GetCurrentWeapon()
                if not slua.isValid(currweapon) then
                    if _G.OurkillCountSystem then
                        _G.OurkillCountSystem:UpdateMainKillCounterUI(false, 0, nil)
                    end
                    return
                end
                _G.UpdateCurrentWeaponSkinID()
                _G.UpdateCurrentClothAvatarID()
                local skinID = _G.CurrentWeaponAvatarSkinID
                if skinID and skinID > 10000000 then
                    local DefineID = currweapon:GetItemDefineID().TypeSpecificID
                    if _G.OurkillCountSystem then
                        _G.OurkillCountSystem:UpdateMainKillCounterUI(true, DefineID, skinID)
                    end
                else
                    if _G.OurkillCountSystem then
                        _G.OurkillCountSystem:UpdateMainKillCounterUI(false, 0, nil)
                    end
                end
            end)
        end, -1, 0.3)
    end)
end
