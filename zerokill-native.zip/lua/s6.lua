-- Read only the local player's data for the existing victory feedback caption.
-- C++ invokes this on the captured Lua thread when a screenshot is ready.
_G.DuneFeedbackSnapshot = function(sequence)
    local okay, err = pcall(function()
        local role = _G.DataMgr and _G.DataMgr.roleData
        local uid = role and role.uid and tostring(role.uid) or ""
        local name = role and (role.playerName or role.roleName or role.name or
            role.nickname or role.nickName) or ""
        local rating = 0
        local kills = 0

        local result = _G.BP_STRUCT_BattleResultData
        local ratingData = result and (result.rating or result.BP_STRUCT_BTRating)
        if ratingData then
            rating = tonumber(ratingData.rank_rating) or 0
        end
        if result then
            kills = tonumber(result.BP_mykill) or 0
        end
        if rating == 0 and role and type(role.segment_rating) == "table" then
            for _, zone in pairs(role.segment_rating) do
                if type(zone) == "table" then
                    for _, value in pairs(zone) do
                        rating = math.max(rating, tonumber(value) or 0)
                    end
                else
                    rating = math.max(rating, tonumber(zone) or 0)
                end
            end
        end
        pcall(function()
            local gameplay = package.loaded["GameLua.GameCore.Data.GameplayData"]
                or require("GameLua.GameCore.Data.GameplayData")
            local character = gameplay and gameplay.GetPlayerCharacter and gameplay.GetPlayerCharacter()
            if character then
                if character.GetPlayerNameSafety then
                    local visibleName = character:GetPlayerNameSafety()
                    if visibleName and tostring(visibleName) ~= "" then name = visibleName end
                end
                if name == "" then name = character.PlayerName or "" end
                if kills == 0 then
                    local state = character.PlayerState or
                        (character.GetPlayerStateSafety and character:GetPlayerStateSafety())
                    kills = state and tonumber(state.Kills) or 0
                end
            end
        end)
        local function clean(value)
            return tostring(value or ""):gsub("[\r\n]", " "):sub(1, 120)
        end
        local path = "__DUNE_FEEDBACK_PATH__"
        local temp = path .. ".tmp"
        local file = io.open(temp, "wb")
        if not file then return end
        file:write(clean(sequence), "\n", clean(name), "\n", clean(uid), "\n",
                   clean(math.floor(rating)), "\n", clean(math.floor(kills)), "\n")
        file:close()
        os.rename(temp, path)
    end)
    if not okay then print("[DuneFeedback] snapshot failed: " .. tostring(err)) end
end
