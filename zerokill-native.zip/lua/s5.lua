
-- ================================================================
-- EMOTES + PET SKINS ONLY
-- Lobby Emotes + Battle Emotes + Pet Emotes (In-Game & Lobby)
-- ================================================================

if _G.__DanceSystemLoaded then
    pcall(function()
        local sys = _G.DanceSystem
        if sys and sys.ApplyNow then sys.ApplyNow() end
    end)
    return _G.DanceSystem
end

if _G.__LobbyEmotesLoaded then
    pcall(function()
        if _G.LobbyEmotesUnlock then
            local remoteEmotes = _G.RemoteEmotes
            if type(remoteEmotes) == "table" then
                local list = remoteEmotes.list or remoteEmotes
                local extraSet = _G._LobbyEmotesExtraSet or {}
                if remoteEmotes.overwrite then
                    for k in pairs(extraSet) do extraSet[k] = nil end
                    for _, v in ipairs(list) do extraSet[v] = true end
                else
                    for _, v in ipairs(list) do extraSet[v] = true end
                end
                _G._LobbyEmotesExtraSet = extraSet
            end
            if _G.LobbyEmotesUnlock.ApplyNow then
                _G.LobbyEmotesUnlock.ApplyNow()
            end
        end
    end)
    return _G.LobbyEmotesUnlock
end

-- ====================================================================
-- EXTRA EMOTE resIDs
-- ====================================================================

local EXTRA_EMOTES = {
    12201001, 12201701, 12203901, 12207901, 12219094, 12219090,
    12219248, 12220082, 12207401, 12220210, 12220320, 12201401,
    12219309, 12220470, 12220401, 12220413, 12220228, 12201301,
    12219207, 12210001, 12210801, 12212601, 12205601, 12219208,
    2200901, 12220475, 12220446, 12220412, 12219819, 12220288,
    12216101, 12209001, 12219022, 12200701, 12206001, 12206801,
    2203601, 12220543, 12220441, 12220407, 12219814, 12212201,
    12219561, 12208801, 12219242, 12205401, 12205201, 12209801,
    12220028, 12204601, 2200401, 12200801, 12204001,
}

-- Remote control merge/overwrite
do
    local remoteEmotes = _G.RemoteEmotes
    if type(remoteEmotes) == "table" then
        local list = remoteEmotes.list or remoteEmotes
        if remoteEmotes.overwrite then
            EXTRA_EMOTES = list
        else
            for _, v in ipairs(list) do
                table.insert(EXTRA_EMOTES, v)
            end
        end
    end
end

local _fakeDepot = {}
local _fakeDepotByRes = {}
local _extraResSet = {}
local hooksDone = false
local motionGuardDone = false
local lastApply = 0

local LobbyEmotesUnlock = {}

for _, id in ipairs(EXTRA_EMOTES) do
    _extraResSet[id] = true
end

local function luaDefer(sec, fn)
    local guarded = function(...)
        if _G.__DuneSkinCtl and not _G.__DuneSkinCtl.enabled then return end
        return fn(...)
    end
    pcall(function()
        if _G.SetTimer then _G.SetTimer(sec, guarded)
        else
            local tt = require("common.time_ticker")
            if tt and tt.AddTimerOnce then tt.AddTimerOnce(sec, guarded) end
        end
    end)
end

local function myUid()
    return DataMgr and DataMgr.roleData and tonumber(DataMgr.roleData.uid)
end

local function makeInsId(resID)
    return tostring(resID * 1000 + 1)
end

local function getItemSubType(resID)
    local ok, cfg = pcall(function() return CDataTable.GetTableData("Item", resID) end)
    if ok and cfg and cfg.ItemSubType then return cfg.ItemSubType end
    return 2201
end

local function isInjectedResID(resID)
    return _extraResSet[tonumber(resID)] == true
end

local function isInjectedInsID(insID)
    return _fakeDepot[tostring(insID)] ~= nil
end

local function buildFakeDepotEntry(resID)
    resID = tonumber(resID)
    if not resID or not isInjectedResID(resID) then return nil end
    if not _fakeDepotByRes[resID] then
        local insID = makeInsId(resID)
        local entry = {
            resID = resID,
            res_id = resID,
            insID = insID,
            instid = insID,
            expireTS = 0,
            count = 1,
            itemType = 22,
            itemSubType = getItemSubType(resID),
            colorID = 0,
            patternID = 0,
            isNew = false,
        }
        _fakeDepotByRes[resID] = entry
        _fakeDepot[insID] = entry
    end
    return _fakeDepotByRes[resID]
end

local function isInMotionSlotList(insID)
    if not DataMgr or not DataMgr.MotionSlotList then return false end
    insID = tostring(insID)
    for _, v in ipairs(DataMgr.MotionSlotList) do
        if tostring(v) == insID then return true end
    end
    return false
end

local DEFAULT_PET_ID = 50006

local function buildFullMotionList()
    local list = {}
    local seen = {}

    pcall(function()
        local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
        local TeamAvatarManager = require("client.logic.avatar.logic_team_avatar_manager")
        local showingAvatar = TeamAvatarManager.GetMainAvatar()
        local XMissionSystem = require("client.slua.logic.TxMission.logic_xmission_main")
        if XMissionSystem and XMissionSystem.IsInXMission and XMissionSystem.IsInXMission() then
            local XMissionAvatarMgr = require("client.slua.logic.TxMission.logic_xmission_avatar_mgr")
            showingAvatar = XMissionAvatarMgr.GetMainAvatar()
        end
        if showingAvatar then
            local CurWeaponID = showingAvatar:GetCurHoldingWeaponSkinID()
            local Cfg = CDataTable.GetTableData("WeaponAvatarBattleEffect", CurWeaponID)
            if Cfg then
                local ModuleManager = require("client.module_framework.ModuleManager")
                local ItemUpgradeMgr = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ItemUpgradeManager)
                if ItemUpgradeMgr and ItemUpgradeMgr.IsWeaponEmoteUnlockedWithOutCheckWeapon
                    and ItemUpgradeMgr:IsWeaponEmoteUnlockedWithOutCheckWeapon(Cfg.WeaponEmoteID) then
                    local id = Cfg.WeaponEmoteID
                    seen[id] = true
                    list[#list + 1] = { itemId = id, bWeaponBindEmote = true }
                end
            end
        end
        if DataMgr and DataMgr.MotionSlotList then
            for _, insID in ipairs(DataMgr.MotionSlotList) do
                local itemData = wardrobe_data:GetValidHallDepotItemDataByInsID(insID)
                if itemData and itemData.resID and itemData.resID > 0 and not seen[itemData.resID] then
                    seen[itemData.resID] = true
                    list[#list + 1] = { itemId = itemData.resID }
                end
            end
        end
    end)

    for _, resID in ipairs(EXTRA_EMOTES) do
        resID = tonumber(resID)
        if resID and resID > 0 and not seen[resID] then
            seen[resID] = true
            list[#list + 1] = { itemId = resID }
        end
    end
    return list
end

local function buildLobbyPetActionList()
    local list = {}
    pcall(function()
        local ModuleManager = require("client.module_framework.ModuleManager")
        local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
        local petID = DEFAULT_PET_ID
        if logic_pet and logic_pet.MyPetInfo and logic_pet.MyPetInfo.equip_pet_id
            and logic_pet.MyPetInfo.equip_pet_id > 0 then
            petID = logic_pet.MyPetInfo.equip_pet_id
        end
        local cfg = logic_pet and logic_pet.GetPetActionCfg and logic_pet:GetPetActionCfg()
        if cfg then
            for _, v in pairs(cfg) do
                if v.PetID == petID and v.ShowInLobby == 1 then
                    list[#list + 1] = {
                        PetID = v.PetID,
                        PetActionID = v.PetActionID,
                        NeedLevel = 0,
                        PetActionIcon = v.PetActionIcon,
                    }
                end
            end
        end
        if #list == 0 then
            for _, v in pairs(CDataTable.GetTable("PetActionTable") or {}) do
                if v.PetID == petID and v.ShowInLobby == 1 then
                    list[#list + 1] = {
                        PetID = v.PetID,
                        PetActionID = v.PetActionID,
                        NeedLevel = 0,
                        PetActionIcon = v.PetActionIcon,
                    }
                end
            end
        end
    end)
    return list
end

local function applyMotionSlots()
    if not DataMgr then return 0 end
    DataMgr.MotionSlotList = DataMgr.MotionSlotList or {}
    local wantMax = #EXTRA_EMOTES + 10
    DataMgr.MotionSlotMax = math.max(tonumber(DataMgr.MotionSlotMax) or 0, wantMax)
    local n = 0
    for _, resID in ipairs(EXTRA_EMOTES) do
        local entry = buildFakeDepotEntry(resID)
        if entry and not isInMotionSlotList(entry.insID) then
            table.insert(DataMgr.MotionSlotList, entry.insID)
            n = n + 1
        end
    end
    return n
end

local function reapplyAfterMotionSync()
    applyMotionSlots()
    luaDefer(0.05, refreshExpressionPopUI)
    luaDefer(0.3, refreshExpressionPopUI)
end

local function patchExpressionUtilModule(mod)
    if not mod then return false end
    if _G.__DuneTrack then _G.__DuneTrack(mod, 'GetMotionDataList') end
    mod.GetMotionDataList = function()
        local list = buildFullMotionList()
        return list
    end
    if _G.__DuneTrack then _G.__DuneTrack(mod, 'GetMotionGridMax') end
    mod.GetMotionGridMax = function()
        return math.max(tonumber(DataMgr and DataMgr.MotionSlotMax) or 10, #EXTRA_EMOTES + 10)
    end
    if _G.__DuneTrack then _G.__DuneTrack(mod, 'GetPetActionList') end
    mod.GetPetActionList = function()
        local list = buildLobbyPetActionList()
        return list or {}
    end
    mod.__LobbyEmotesMotionHook = true
    return true
end

local function patchExpressionPopInstance(ui)
    if not ui then return end
    if not ui.__LobbyEmotesInstPatched then
        ui.__LobbyEmotesInstPatched = true
        if ui.UpdateActionUI then
            local orig = ui.UpdateActionUI
            if _G.__DuneTrack then _G.__DuneTrack(ui, 'UpdateActionUI') end
            ui.UpdateActionUI = function(self, ...)
                local r = orig(self, ...)
                self.expressList = buildFullMotionList()
                if self.LoopScrollGrid_Action and self.LoopScrollGrid_Action.SetData then
                    self.LoopScrollGrid_Action:SetData(self.expressList)
                end
                return r
            end
        end
        if ui.UpdatePetUI then
            local orig = ui.UpdatePetUI
            if _G.__DuneTrack then _G.__DuneTrack(ui, 'UpdatePetUI') end
            ui.UpdatePetUI = function(self, ...)
                local petDatas = buildLobbyPetActionList()
                if petDatas and #petDatas > 0 then
                    self.nCurPetID = DEFAULT_PET_ID
                    if self.LoopScrollGrid_Pet and self.LoopScrollGrid_Pet.SetData then
                        self.LoopScrollGrid_Pet:SetData(petDatas)
                    end
                    return
                end
                return orig(self, ...)
            end
        end
    end
    ui.expressList = buildFullMotionList()
    if ui.LoopScrollGrid_Action and ui.LoopScrollGrid_Action.SetData then
        ui.LoopScrollGrid_Action:SetData(ui.expressList)
    end
    local pets = buildLobbyPetActionList()
    if pets and #pets > 0 and ui.LoopScrollGrid_Pet and ui.LoopScrollGrid_Pet.SetData then
        ui.LoopScrollGrid_Pet:SetData(pets)
    end
end

local function refreshExpressionPopUI()
    pcall(function()
        local UIManager = require("client.slua_ui_framework.manager")
        if not UIManager or not UIManager.GetUI or not UIManager.UI_Config then return end
        local ui = UIManager.GetUI(UIManager.UI_Config.ExpressionPop_New_UIBP)
        if ui then
            patchExpressionPopInstance(ui)
        end
    end)
end

local function fireMotionRefresh()
    pcall(function()
        if EventSystem and EVENTID_MOTION_UPDATE_SLOT_LIST then
            EventSystem:postEvent(EVENTTYPE_MOTION, EVENTID_MOTION_UPDATE_SLOT_LIST)
        end
    end)
    refreshExpressionPopUI()
end

local function mergeExtraIntoList(list)
    if not list then return list end
    local present = {}
    for _, e in ipairs(list) do
        if e and e.itemId and e.itemId > 0 then
            present[e.itemId] = true
        end
    end
    for _, resID in ipairs(EXTRA_EMOTES) do
        if not present[resID] then
            local placed = false
            for i, e in ipairs(list) do
                if e and (not e.itemId or e.itemId == 0) then
                    list[i] = { itemId = resID }
                    present[resID] = true
                    placed = true
                    break
                end
            end
            if not placed then
                table.insert(list, { itemId = resID })
                present[resID] = true
            end
        end
    end
    return list
end

-- ====================================================================
-- Hooks — wardrobe depot + Expression_Util.GetMotionDataList
-- ====================================================================

local function installWardrobeHooks()
    local ok, WardrobeData = pcall(require, "client.slua.logic.wardrobe.wardrobe_data")
    if not ok or not WardrobeData or WardrobeData.__LobbyEmotesWardrobe then return false end
    WardrobeData.__LobbyEmotesWardrobe = true

    for _, resID in ipairs(EXTRA_EMOTES) do
        buildFakeDepotEntry(resID)
    end

    local origValid = WardrobeData.GetValidHallDepotItemDataByInsID
    if _G.__DuneTrack then _G.__DuneTrack(WardrobeData, 'GetValidHallDepotItemDataByInsID') end
    WardrobeData.GetValidHallDepotItemDataByInsID = function(self, insID, ...)
        if isInjectedInsID(insID) then
            return _fakeDepot[tostring(insID)]
        end
        return origValid(self, insID, ...)
    end

    local origIns = WardrobeData.GetHallDepotItemDataByInsID
    if _G.__DuneTrack then _G.__DuneTrack(WardrobeData, 'GetHallDepotItemDataByInsID') end
    WardrobeData.GetHallDepotItemDataByInsID = function(self, insID, ...)
        if isInjectedInsID(insID) then
            return _fakeDepot[tostring(insID)]
        end
        return origIns(self, insID, ...)
    end

    local origRes = WardrobeData.GetHallDepotItemDataByResID
    if _G.__DuneTrack then _G.__DuneTrack(WardrobeData, 'GetHallDepotItemDataByResID') end
    WardrobeData.GetHallDepotItemDataByResID = function(self, resID, ...)
        if isInjectedResID(resID) then
            return buildFakeDepotEntry(resID)
        end
        return origRes(self, resID, ...)
    end

    if WardrobeData.GetHallDepotItemDataByResIDAndValidExpireTime then
        local origResValid = WardrobeData.GetHallDepotItemDataByResIDAndValidExpireTime
        if _G.__DuneTrack then _G.__DuneTrack(WardrobeData, 'GetHallDepotItemDataByResIDAndValidExpireTime') end
        WardrobeData.GetHallDepotItemDataByResIDAndValidExpireTime = function(self, resID, ...)
            if isInjectedResID(resID) then
                return buildFakeDepotEntry(resID)
            end
            return origResValid(self, resID, ...)
        end
    end

    if WardrobeData.HasItem then
        local origHas = WardrobeData.HasItem
        if _G.__DuneTrack then _G.__DuneTrack(WardrobeData, 'HasItem') end
        WardrobeData.HasItem = function(self, itemId, forever, ...)
            if isInjectedResID(itemId) then return true end
            return origHas(self, itemId, forever, ...)
        end
    end

    if WardrobeData.HasValidItem then
        local origHasValid = WardrobeData.HasValidItem
        if _G.__DuneTrack then _G.__DuneTrack(WardrobeData, 'HasValidItem') end
        WardrobeData.HasValidItem = function(self, itemId, forever, ...)
            if isInjectedResID(itemId) then return true end
            return origHasValid(self, itemId, forever, ...)
        end
    end

    return true
end

local function installExpressionHook()
    pcall(function()
        local mod = require("client.slua.umg.Souvenirs.Expression_Util")
        patchExpressionUtilModule(mod)
    end)
    pcall(function()
        if package and package.loaded then
            local mod = package.loaded["client.slua.umg.Souvenirs.Expression_Util"]
            patchExpressionUtilModule(mod)
        end
    end)
end

local function installExpressionPopHook()
    pcall(function()
        local ok, Panel = pcall(require, "client.slua.umg.Souvenirs.ExpressionPop_New_UIBP")
        if ok and Panel then
            local impl = Panel.__inner_impl or Panel
            if impl and not impl.__LobbyEmotesPopHook then
                impl.__LobbyEmotesPopHook = true
                if impl.UpdateActionUI then
                    local orig = impl.UpdateActionUI
                    if _G.__DuneTrack then _G.__DuneTrack(impl, 'UpdateActionUI') end
                    impl.UpdateActionUI = function(self, ...)
                        local r = orig(self, ...)
                        patchExpressionPopInstance(self)
                        return r
                    end
                end
                if impl.OnPostInitialize then
                    local orig = impl.OnPostInitialize
                    if _G.__DuneTrack then _G.__DuneTrack(impl, 'OnPostInitialize') end
                    impl.OnPostInitialize = function(self, ...)
                        local r = orig(self, ...)
                        luaDefer(0.1, function() patchExpressionPopInstance(self) end)
                        return r
                    end
                end
            end
        end
    end)

    pcall(function()
        local UIManager = require("client.slua_ui_framework.manager")
        if not UIManager or UIManager.__LobbyEmotesPopUIHook then return end
        UIManager.__LobbyEmotesPopUIHook = true
        if UIManager.ShowUI then
            local orig = UIManager.ShowUI
            if _G.__DuneTrack then _G.__DuneTrack(UIManager, 'ShowUI') end
            UIManager.ShowUI = function(cfg, ...)
                local ui = orig(cfg, ...)
                pcall(function()
                    if cfg == UIManager.UI_Config.ExpressionPop_New_UIBP and ui then
                        patchExpressionPopInstance(ui)
                        luaDefer(0.15, function() patchExpressionPopInstance(ui) end)
                        luaDefer(0.5, function() patchExpressionPopInstance(ui) end)
                    end
                end)
                return ui
            end
        end
    end)
end

local function installMotionGuard()
    if motionGuardDone then return end
    motionGuardDone = true

    pcall(function()
        if DataMgr and DataMgr.InitMotionInfo and not DataMgr.__LobbyEmotesMotionGuard then
            DataMgr.__LobbyEmotesMotionGuard = true
            local orig = DataMgr.InitMotionInfo
            if _G.__DuneTrack then _G.__DuneTrack(DataMgr, 'InitMotionInfo') end
            DataMgr.InitMotionInfo = function(motion_info, limit)
                local forced = math.max(tonumber(limit) or 0, #EXTRA_EMOTES + 10)
                orig(motion_info, forced)
                reapplyAfterMotionSync()
            end
        end
        if DataMgr and DataMgr.sync_motion_info and not DataMgr.__LobbyEmotesSyncGuard then
            DataMgr.__LobbyEmotesSyncGuard = true
            local orig = DataMgr.sync_motion_info
            if _G.__DuneTrack then _G.__DuneTrack(DataMgr, 'sync_motion_info') end
            DataMgr.sync_motion_info = function(motion_info, limit)
                local forced = math.max(tonumber(limit) or 0, #EXTRA_EMOTES + 10)
                orig(motion_info, forced)
                reapplyAfterMotionSync()
            end
        end
    end)

    pcall(function()
        if EventSystem and EVENTID_MOTION_UPDATE_SLOT_LIST and not EventSystem.__LobbyEmotesSlotEvt then
            EventSystem.__LobbyEmotesSlotEvt = true
            EventSystem:registEvent(EVENTTYPE_MOTION, EVENTID_MOTION_UPDATE_SLOT_LIST, function()
                reapplyAfterMotionSync()
            end)
        end
    end)
end

local function installHooks()
    installWardrobeHooks()
    installExpressionHook()
    installExpressionPopHook()
    installMotionGuard()
    hooksDone = true
    return true
end

-- ====================================================================
-- API
-- ====================================================================

if _G.__DuneTrack then _G.__DuneTrack(LobbyEmotesUnlock, 'ApplyNow') end
function LobbyEmotesUnlock.ApplyNow()
    if not myUid() then return false end
    local now = os.time and os.time() or 0
    if now - lastApply < 0.3 then return false end
    lastApply = now

    for _, resID in ipairs(EXTRA_EMOTES) do
        buildFakeDepotEntry(resID)
    end
    if not installHooks() then return false end

    local n = applyMotionSlots()
    reapplyAfterMotionSync()
    return true
end

if _G.__DuneTrack then _G.__DuneTrack(LobbyEmotesUnlock, 'Refresh') end
function LobbyEmotesUnlock.Refresh()
    return LobbyEmotesUnlock.ApplyNow()
end

if _G.__DuneTrack then _G.__DuneTrack(LobbyEmotesUnlock, 'GetExtraEmotes') end
function LobbyEmotesUnlock.GetExtraEmotes()
    return EXTRA_EMOTES
end

if _G.__DuneTrack then _G.__DuneTrack(LobbyEmotesUnlock, 'IsExtraEmote') end
function LobbyEmotesUnlock.IsExtraEmote(resID)
    return _extraResSet[tonumber(resID)] == true
end

LobbyEmotesUnlock.Config = setmetatable({ Enabled = true }, {
    __newindex = function() end,
    __index = function(_, k)
        if k == "Enabled" then return true end
        return nil
    end,
})

-- ====================================================================
-- Boot
-- ====================================================================

local function boot()
    LobbyEmotesUnlock.ApplyNow()
end

local function waitUid(attempt)
    attempt = attempt or 0
    if myUid() then boot(); return end
    if attempt < 60 then luaDefer(0.5, function() waitUid(attempt + 1) end) end
end

waitUid()
luaDefer(0.5, boot)
luaDefer(1, boot)
luaDefer(2, boot)
luaDefer(4, boot)
luaDefer(8, boot)
luaDefer(15, boot)

pcall(function()
    if EventSystem and not EventSystem.__LobbyEmotesLobby then
        EventSystem.__LobbyEmotesLobby = true
        EventSystem:registEvent(EVENTTYPE_STATE, EVENTID_ON_MODE_POST_SWITCH, function(_, _, next)
            if next == GameStatus.Lobby then
                luaDefer(0.3, boot)
                luaDefer(2, boot)
            end
        end)
    end
end)

_G.ModSharedExtraEmotes = EXTRA_EMOTES
_G.__LobbyEmotesLoaded = true
_G.LobbyEmotesUnlock = LobbyEmotesUnlock

-- ================================================================
-- BATTLE EMOTES + PET EMOTES (In-Game)
-- ================================================================

if _G.__BattleEmotesLoaded then
    pcall(function()
        if _G.BattleEmotesUnlock and _G.BattleEmotesUnlock.ApplyNow then
            _G.BattleEmotesUnlock.ApplyNow()
        end
    end)
    return _G.BattleEmotesUnlock
end

local SHOW_EXPRESSION = 2
local SHOW_PET = 6

local FALLBACK_EMOTES = {
    12201001, 12201701, 12203901, 12207901, 12219094, 12219090,
    12219248, 12220082, 12207401, 12220210, 12220320, 12201401,
    12219309, 12220470, 12220401, 12220413, 12220228, 12201301,
    12219207, 12210001, 12210801, 12212601, 12205601, 12219208,
    2200901, 12220475, 12220446, 12220412, 12219819, 12220288,
    12216101, 12209001, 12219022, 12200701, 12206001, 12206801,
    2203601, 12220543, 12220441, 12220407, 12219814, 12212201,
    12219561, 12208801, 12219242, 12205401, 12205201, 12209801,
    12220028, 12204601, 2200401, 12200801, 12204001,
}

local DEFAULT_PET_ID = 50006
local DEFAULT_PET_LEVEL = 6

local BattleEmotesUnlock = {}
local _extraSet = {}
local _petActionSet = {}
local _classHooksDone = false
local lastApply = 0

local function luaDefer(sec, fn)
    local guarded = function(...)
        if _G.__DuneSkinCtl and not _G.__DuneSkinCtl.enabled then return end
        return fn(...)
    end
    pcall(function()
        if _G.SetTimer then _G.SetTimer(sec, guarded)
        else
            local tt = require("common.time_ticker")
            if tt and tt.AddTimerOnce then tt.AddTimerOnce(sec, guarded) end
        end
    end)
end

local function getExtraEmotes()
    if _G.LobbyEmotesUnlock and _G.LobbyEmotesUnlock.GetExtraEmotes then
        local list = _G.LobbyEmotesUnlock.GetExtraEmotes()
        if list and #list > 0 then return list end
    end
    if _G.ModSharedExtraEmotes and #_G.ModSharedExtraEmotes > 0 then
        return _G.ModSharedExtraEmotes
    end
    return FALLBACK_EMOTES
end

local function rebuildExtraSet()
    _extraSet = {}
    for _, id in ipairs(getExtraEmotes()) do
        _extraSet[tonumber(id)] = true
    end
end

local function isExtraEmote(resID)
    resID = tonumber(resID)
    if not resID then return false end
    if _extraSet[resID] then return true end
    if _G.LobbyEmotesUnlock and _G.LobbyEmotesUnlock.IsExtraEmote then
        return _G.LobbyEmotesUnlock.IsExtraEmote(resID)
    end
    for _, id in ipairs(FALLBACK_EMOTES) do
        if tonumber(id) == resID then return true end
    end
    return false
end

local function isPetActionID(id)
    return _petActionSet[tonumber(id)] == true
end

local function isInLobby()
    if GameStatus and GameStatus.GetCurrent and GameStatus.InLobby then
        return GameStatus.GetCurrent() == GameStatus.InLobby
    end
    return false
end

local function isBattleContext()
    return not isInLobby()
end

local function collapsed()
    return UEnums and UEnums.ESlateVisibility and UEnums.ESlateVisibility.Collapsed or 1
end

local function visible()
    return UEnums and UEnums.ESlateVisibility and UEnums.ESlateVisibility.SelfHitTestInvisible or 0
end

local function getImpl(mod)
    if not mod then return nil end
    return mod.__inner_impl or mod
end

local function getActivePanel()
    local ok, ui = pcall(function()
        local UIManager = require("client.slua_ui_framework.manager")
        if not UIManager or not UIManager.UI_Config_InGame then return nil end
        return UIManager.GetUI(UIManager.UI_Config_InGame.QuickExpressionDecalSubPanel)
    end)
    return ok and ui or nil
end

local function collectNativeEmoteIDs()
    local ids, seen = {}, {}
    pcall(function()
        local GameplayData = require("GameLua.GameCore.Data.GameplayData")
        local STExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
        local BackpackUtils = import("BackpackUtils")
        local pc = GameplayData.GetPlayerController()
        if not pc or not slua.isValid(pc) then return end
        local comp = STExtraBlueprintFunctionLibrary.GetBackpackComponentFromController(pc)
        if not comp or not slua.isValid(comp) then return end
        local items = BackpackUtils.GetEmoteItemInBackpack(comp)
        if not items then return end
        for _, data in pairs(items) do
            if data and data.DefineID then
                local id = tonumber(data.DefineID.TypeSpecificID)
                if id and id > 0 and not seen[id] then
                    seen[id] = true
                    ids[#ids + 1] = id
                end
            end
        end
    end)
    return ids, seen
end

local function rebuildPlayerEmoteCache(self)
    local ids, seen = collectNativeEmoteIDs()
    for _, resID in ipairs(getExtraEmotes()) do
        resID = tonumber(resID)
        if resID and resID > 0 and not seen[resID] then
            seen[resID] = true
            ids[#ids + 1] = resID
        end
    end
    self.__BattlePlayerEmoteIDs = ids
    return ids
end

local function buildPetEmoteList()
    local list = {}
    _petActionSet = {}
    pcall(function()
        local tbl = CDataTable.GetTable("PetActionTable")
        if not tbl then return end
        for _, v in pairs(tbl) do
            if v.PetID == DEFAULT_PET_ID and (v.CanPlayInBattle == 1 or v.CanPlayInBattle == 2) then
                list[#list + 1] = {
                    ID = v.PetActionID,
                    IsLocked = false,
                    SortKey = v.SortKey or 0,
                    MasterSkillID = v.MasterSkillID,
                }
                _petActionSet[tonumber(v.PetActionID)] = true
            end
        end
    end)
    table.sort(list, function(a, b) return a.SortKey < b.SortKey end)
    return list
end

local function placeEmoteSlot(self, idx, resID, isPet, isLocked)
    local Item = self.GetQuickExpressionDecalItemByIndex and self:GetQuickExpressionDecalItemByIndex(idx)
    if not Item then return false end
    pcall(function()
        if Item.UIRoot and Item.UIRoot.WidgetSwitcher_Effect then
            Item.UIRoot.WidgetSwitcher_Effect:SetVisibility(collapsed())
        end
        if Item.UIRoot and Item.UIRoot.Image_Weapon then
            Item.UIRoot.Image_Weapon:SetVisibility(collapsed())
        end
    end)
    Item:Show()
    Item:RefreshData(resID, -1, isPet == true, isLocked == true)
    return true
end

local function hideEmptyMessage(self)
    pcall(function()
        if self.UIRoot then
            if self.UIRoot.VerticalBox_Empty then
                self.UIRoot.VerticalBox_Empty:SetVisibility(collapsed())
            end
            if self.UIRoot.WrapBox_List then
                self.UIRoot.WrapBox_List:SetVisibility(visible())
            end
            if self.UIRoot.CanvasPanel_List then
                self.UIRoot.CanvasPanel_List:SetVisibility(visible())
            end
        end
    end)
end

local function expandScrollForCount(self, count)
    pcall(function()
        if not self.UIRoot or not self.UIRoot.ScrollBox_0 or count <= 0 then return end
        local rowNum = math.ceil(count / 4)
        local targetY = math.min(rowNum * 60, 360)
        local slot = self.UIRoot.ScrollBox_0.Slot
        if slot and slot.GetSize then
            local origin = slot:GetSize()
            if origin then
                slot:SetSize(FVector2D(origin.X, targetY))
            end
        end
        self.UIRoot.ScrollBox_0.SizeY = targetY
    end)
end

local function renderPlayerEmoteGrid(self)
    if not self or not self.QuickExpressionDecalItemList then return 0 end
    local ids = self.__BattlePlayerEmoteIDs
    if not ids or #ids == 0 then
        ids = rebuildPlayerEmoteCache(self)
    end
    if #ids == 0 then return 0 end

    local cnt = 0
    for i, resID in ipairs(ids) do
        if placeEmoteSlot(self, i, resID, false, false) then
            cnt = i
        end
    end

    hideEmptyMessage(self)
    if self.HideRestBlocks then
        self:HideRestBlocks(cnt)
    end
    expandScrollForCount(self, cnt)
    return cnt
end

local function renderPetEmoteGrid(self)
    if not self then return 0 end
    if not self.__BattlePetEmoteList then
        self.__BattlePetEmoteList = buildPetEmoteList()
    end
    local list = self.__BattlePetEmoteList
    if #list == 0 then return 0 end

    self.PetID = DEFAULT_PET_ID
    self.PetLevel = DEFAULT_PET_LEVEL
    self.bShowMyPet = true
    self.CurPetExpressionList = list

    local cnt = 0
    for i, v in ipairs(list) do
        if placeEmoteSlot(self, i, v.ID, true, false) then
            cnt = i
        end
    end

    hideEmptyMessage(self)
    if self.HideRestBlocks then
        self:HideRestBlocks(cnt)
    end
    expandScrollForCount(self, cnt)
    return cnt
end

local function restoreCurrentGrid(self)
    if not self then return end
    if self.CurrentShowState == SHOW_PET then
        renderPetEmoteGrid(self)
    elseif self.CurrentShowState == SHOW_EXPRESSION then
        renderPlayerEmoteGrid(self)
    end
end

local function playPlayerEmote(self, ID)
    if isExtraEmote(ID) and self.PlayEmoteInternal then
        self:PlayEmoteInternal(ID, false)
        return true
    end
    if self.TryToPlayEmote then
        self:TryToPlayEmote(ID)
        return true
    end
    return false
end

local function playPetEmote(self, ID)
    local PlayerController = nil
    pcall(function()
        local GameplayData = require("GameLua.GameCore.Data.GameplayData")
        PlayerController = GameplayData.GetPlayerController()
    end)
    if not PlayerController or not slua.isValid(PlayerController) then return false end
    if PlayerController.PlaySpecifiedPetAnimation then
        pcall(function() PlayerController:PlaySpecifiedPetAnimation(ID) end)
        return true
    end
    return false
end

local HOOKS = {}

local function hookImpl(mod, name, key, factory)
    local impl = getImpl(mod)
    if not impl or not impl[name] or HOOKS[key] then return false end
    local orig = impl[name]
    HOOKS[key] = orig
    impl[name] = factory(orig)
    return true
end

local function patchPanelInstance(ui)
    if not ui or ui.__BattleEmotesPatched then return end
    ui.__BattleEmotesPatched = true

    if ui.GetIsEmoteExist and not ui.__OrigGetIsEmoteExist then
        ui.__OrigGetIsEmoteExist = ui.GetIsEmoteExist
        if _G.__DuneTrack then _G.__DuneTrack(ui, 'GetIsEmoteExist') end
        ui.GetIsEmoteExist = function(self, defineID)
            if isExtraEmote(defineID) or isPetActionID(defineID) then return true end
            return self.__OrigGetIsEmoteExist(self, defineID)
        end
    end

    if ui.GetCurPet and not ui.__OrigGetCurPet then
        ui.__OrigGetCurPet = ui.GetCurPet
        if _G.__DuneTrack then _G.__DuneTrack(ui, 'GetCurPet') end
        ui.GetCurPet = function(self)
            if self.CurrentShowState == SHOW_PET then
                return DEFAULT_PET_ID, DEFAULT_PET_LEVEL
            end
            return self.__OrigGetCurPet(self)
        end
    end

    if ui.GetShowMyPet and not ui.__OrigGetShowMyPet then
        ui.__OrigGetShowMyPet = ui.GetShowMyPet
        if _G.__DuneTrack then _G.__DuneTrack(ui, 'GetShowMyPet') end
        ui.GetShowMyPet = function(self)
            if self.CurrentShowState == SHOW_PET then return true end
            return self.__OrigGetShowMyPet(self)
        end
    end

    if ui.RefreshExpression and not ui.__OrigRefreshExpression then
        ui.__OrigRefreshExpression = ui.RefreshExpression
        if _G.__DuneTrack then _G.__DuneTrack(ui, 'RefreshExpression') end
        ui.RefreshExpression = function(self, ...)
            self.__OrigRefreshExpression(self, ...)
            rebuildPlayerEmoteCache(self)
            renderPlayerEmoteGrid(self)
        end
    end

    if ui.RefreshPetExpression and not ui.__OrigRefreshPetExpression then
        ui.__OrigRefreshPetExpression = ui.RefreshPetExpression
        if _G.__DuneTrack then _G.__DuneTrack(ui, 'RefreshPetExpression') end
        ui.RefreshPetExpression = function(self, ...)
            self.__BattlePetEmoteList = self.__BattlePetEmoteList or buildPetEmoteList()
            renderPetEmoteGrid(self)
        end
    end

    if ui.RefreshPetInfo and not ui.__OrigRefreshPetInfo then
        ui.__OrigRefreshPetInfo = ui.RefreshPetInfo
        if _G.__DuneTrack then _G.__DuneTrack(ui, 'RefreshPetInfo') end
        ui.RefreshPetInfo = function(self, ...)
            if self.CurrentShowState == SHOW_PET then
                self.PetID = DEFAULT_PET_ID
                self.PetLevel = DEFAULT_PET_LEVEL
                self.bShowMyPet = true
                self.__BattlePetEmoteList = self.__BattlePetEmoteList or buildPetEmoteList()
                self.CurPetExpressionList = self.__BattlePetEmoteList
                return
            end
            return self.__OrigRefreshPetInfo(self, ...)
        end
    end

    if ui.OnClickItem and not ui.__OrigOnClickItem then
        ui.__OrigOnClickItem = ui.OnClickItem
        if _G.__DuneTrack then _G.__DuneTrack(ui, 'OnClickItem') end
        ui.OnClickItem = function(self, ID)
            if not ID or ID <= 0 then return end
            if self.CurrentShowState == SHOW_EXPRESSION then
                playPlayerEmote(self, ID)
                luaDefer(0.05, function() restoreCurrentGrid(self) end)
                luaDefer(0.2, function() restoreCurrentGrid(self) end)
                return
            end
            if self.CurrentShowState == SHOW_PET then
                playPetEmote(self, ID)
                luaDefer(0.05, function() restoreCurrentGrid(self) end)
                luaDefer(0.2, function() restoreCurrentGrid(self) end)
                return
            end
            return self.__OrigOnClickItem(self, ID)
        end
    end

    if ui.RefreshGridPanel and not ui.__OrigRefreshGridPanel then
        ui.__OrigRefreshGridPanel = ui.RefreshGridPanel
        if _G.__DuneTrack then _G.__DuneTrack(ui, 'RefreshGridPanel') end
        ui.RefreshGridPanel = function(self, ...)
            self.__OrigRefreshGridPanel(self, ...)
            luaDefer(0.05, function() restoreCurrentGrid(self) end)
        end
    end

    if ui.OpenContent and not ui.__OrigOpenContent then
        ui.__OrigOpenContent = ui.OpenContent
        if _G.__DuneTrack then _G.__DuneTrack(ui, 'OpenContent') end
        ui.OpenContent = function(self, ...)
            local r = self.__OrigOpenContent(self, ...)
            luaDefer(0.1, function() restoreCurrentGrid(self) end)
            luaDefer(0.35, function() restoreCurrentGrid(self) end)
            return r
        end
    end

    if ui.OnButtonPetExpression and not ui.__OrigOnButtonPetExpression then
        ui.__OrigOnButtonPetExpression = ui.OnButtonPetExpression
        if _G.__DuneTrack then _G.__DuneTrack(ui, 'OnButtonPetExpression') end
        ui.OnButtonPetExpression = function(self, ...)
            local r = self.__OrigOnButtonPetExpression(self, ...)
            luaDefer(0.1, function() renderPetEmoteGrid(self) end)
            return r
        end
    end

    if ui.OnButtonPlayerExpression and not ui.__OrigOnButtonPlayerExpression then
        ui.__OrigOnButtonPlayerExpression = ui.OnButtonPlayerExpression
        if _G.__DuneTrack then _G.__DuneTrack(ui, 'OnButtonPlayerExpression') end
        ui.OnButtonPlayerExpression = function(self, ...)
            local r = self.__OrigOnButtonPlayerExpression(self, ...)
            luaDefer(0.1, function() renderPlayerEmoteGrid(self) end)
            return r
        end
    end
end

local function patchActivePanel()
    local ui = getActivePanel()
    if ui then patchPanelInstance(ui) end
    return ui
end

local function hookLogicEmote()
    pcall(function()
        local logic_emote = require("GameLua.Mod.Library.GamePlay.Avatar.Emote.logic_emote")
        if not logic_emote or logic_emote.__BattleEmotesHook then return end
        logic_emote.__BattleEmotesHook = true

        hookImpl(logic_emote, "CheckEmoteDownloaded", "CheckDownloaded", function(orig)
            return function(EmoteID, ...)
                if isExtraEmote(EmoteID) or isPetActionID(EmoteID) then return true end
                return orig(EmoteID, ...)
            end
        end)

        hookImpl(logic_emote, "IsEmoteExist", "IsEmoteExist", function(orig)
            return function(EmoteID)
                if isExtraEmote(EmoteID) or isPetActionID(EmoteID) then return true end
                return orig(EmoteID)
            end
        end)

        hookImpl(logic_emote, "PlayEmote", "PlayEmote", function(orig)
            return function(Player, EmoteID)
                if isExtraEmote(EmoteID) and Game and Game.IsValid and Game:IsValid(Player) then
                    if Player.OnPlayEmote then return Player:OnPlayEmote(EmoteID, "") end
                end
                return orig(Player, EmoteID)
            end
        end)
    end)
end

local function hookDecalClass()
    pcall(function()
        local Panel = require("GameLua.Mod.BaseMod.Client.Emote.QuickExpressionDecalSubPanel")
        if not Panel or Panel.__BattleEmotesClassHook then return end
        Panel.__BattleEmotesClassHook = true

        hookImpl(Panel, "GetIsEmoteExist", "DecalGetIsEmoteExist", function(orig)
            return function(self, defineID)
                if isExtraEmote(defineID) or isPetActionID(defineID) then return true end
                return orig(self, defineID)
            end
        end)

        hookImpl(Panel, "RefreshExpression", "DecalRefreshExpression", function(orig)
            return function(self, ...)
                orig(self, ...)
                rebuildPlayerEmoteCache(self)
                renderPlayerEmoteGrid(self)
            end
        end)

        hookImpl(Panel, "RefreshPetExpression", "DecalRefreshPet", function(orig)
            return function(self, ...)
                self.__BattlePetEmoteList = self.__BattlePetEmoteList or buildPetEmoteList()
                renderPetEmoteGrid(self)
            end
        end)

        hookImpl(Panel, "OnClickItem", "DecalOnClickItem", function(orig)
            return function(self, ID)
                if not ID or ID <= 0 then return end
                if self.CurrentShowState == SHOW_EXPRESSION then
                    playPlayerEmote(self, ID)
                    luaDefer(0.05, function() restoreCurrentGrid(self) end)
                    return
                end
                if self.CurrentShowState == SHOW_PET then
                    playPetEmote(self, ID)
                    luaDefer(0.05, function() restoreCurrentGrid(self) end)
                    return
                end
                return orig(self, ID)
            end
        end)

        hookImpl(Panel, "GetCurPet", "DecalGetCurPet", function(orig)
            return function(self)
                if self.CurrentShowState == SHOW_PET then
                    return DEFAULT_PET_ID, DEFAULT_PET_LEVEL
                end
                return orig(self)
            end
        end)

        hookImpl(Panel, "GetShowMyPet", "DecalGetShowMyPet", function(orig)
            return function(self)
                if self.CurrentShowState == SHOW_PET then return true end
                return orig(self)
            end
        end)
    end)
end

local function hookUIManager()
    pcall(function()
        local UIManager = require("client.slua_ui_framework.manager")
        if not UIManager or UIManager.__BattleEmotesUIHook then return end
        UIManager.__BattleEmotesUIHook = true

        if UIManager.ShowUI then
            local origShow = UIManager.ShowUI
            if _G.__DuneTrack then _G.__DuneTrack(UIManager, 'ShowUI') end
            UIManager.ShowUI = function(cfg, ...)
                local ui = origShow(cfg, ...)
                pcall(function()
                    if cfg == UIManager.UI_Config_InGame.QuickExpressionDecalSubPanel and ui then
                        luaDefer(0.1, function() patchPanelInstance(ui); restoreCurrentGrid(ui) end)
                    end
                end)
                return ui
            end
        end

        if UIManager.GetUI then
            local origGet = UIManager.GetUI
            if _G.__DuneTrack then _G.__DuneTrack(UIManager, 'GetUI') end
            UIManager.GetUI = function(cfg, ...)
                local ui = origGet(cfg, ...)
                pcall(function()
                    if cfg == UIManager.UI_Config_InGame.QuickExpressionDecalSubPanel and ui then
                        patchPanelInstance(ui)
                    end
                end)
                return ui
            end
        end
    end)
end

local function installEvents()
    pcall(function()
        if not EventSystem or EventSystem.__BattleEmotesEvents then return end
        EventSystem.__BattleEmotesEvents = true

        local function onPanelOpen()
            installClassHooks()
            rebuildExtraSet()
            buildPetEmoteList()
            local ui = patchActivePanel()
            if ui then restoreCurrentGrid(ui) end
            luaDefer(0.25, function()
                local p = getActivePanel()
                if p then restoreCurrentGrid(p) end
            end)
        end

        if EVENTTYPE_INGAME and EVENTID_INGAME_QUICK_EXPRESSION_DECAL_CLICK then
            EventSystem:registEvent(EVENTTYPE_INGAME, EVENTID_INGAME_QUICK_EXPRESSION_DECAL_CLICK, onPanelOpen)
        end
        if EVENTTYPE_INGAME and EVENTID_INGAME_QUICK_EXPRESSION_CLICK then
            EventSystem:registEvent(EVENTTYPE_INGAME, EVENTID_INGAME_QUICK_EXPRESSION_CLICK, onPanelOpen)
        end
        if EVENTTYPE_INGAME and EVENTID_REFRESH_EMOTE_ACTION_DATA then
            EventSystem:registEvent(EVENTTYPE_INGAME, EVENTID_REFRESH_EMOTE_ACTION_DATA, function()
                luaDefer(0.05, function()
                    local ui = getActivePanel()
                    if ui then restoreCurrentGrid(ui) end
                end)
            end)
        end
        if EVENTTYPE_STATE and EVENTID_ON_MODE_POST_SWITCH then
            EventSystem:registEvent(EVENTTYPE_STATE, EVENTID_ON_MODE_POST_SWITCH, function(_, _, next)
                if next == GameStatus.Fighting then
                    luaDefer(1, function()
                        installClassHooks()
                        patchActivePanel()
                    end)
                end
            end)
        end
    end)
end

local function installClassHooks()
    rebuildExtraSet()
    buildPetEmoteList()
    hookLogicEmote()
    hookDecalClass()
    hookUIManager()
    installEvents()
    _classHooksDone = true
end

if _G.__DuneTrack then _G.__DuneTrack(BattleEmotesUnlock, 'ApplyNow') end
function BattleEmotesUnlock.ApplyNow()
    installClassHooks()
    rebuildExtraSet()
    buildPetEmoteList()
    if not isBattleContext() then return false end
    local now = os.time and os.time() or 0
    if now - lastApply < 0.2 then return false end
    lastApply = now

    local ui = patchActivePanel()
    if ui then restoreCurrentGrid(ui) end
    return true
end

if _G.__DuneTrack then _G.__DuneTrack(BattleEmotesUnlock, 'Refresh') end
function BattleEmotesUnlock.Refresh()
    return BattleEmotesUnlock.ApplyNow()
end

BattleEmotesUnlock.renderPlayerEmoteGrid = renderPlayerEmoteGrid
BattleEmotesUnlock.renderPetEmoteGrid = renderPetEmoteGrid
BattleEmotesUnlock.getExtraEmotes = getExtraEmotes

BattleEmotesUnlock.Config = setmetatable({ Enabled = true }, {
    __newindex = function() end,
    __index = function(_, k)
        if k == "Enabled" then return true end
        return nil
    end,
})

local function bootRetry(n)
    installClassHooks()
    patchActivePanel()
    if n < 25 then luaDefer(2, function() bootRetry(n + 1) end) end
end

luaDefer(0.3, installClassHooks)
luaDefer(1, function() installClassHooks(); patchActivePanel() end)
bootRetry(0)

_G.__BattleEmotesLoaded = true
_G.BattleEmotesUnlock = BattleEmotesUnlock

-- ================================================================
-- DanceSystem — Unified entry point for Lobby + Battle emotes
-- ================================================================

_G.DanceSystem = _G.DanceSystem or {
    ApplyNow = function()
        if _G.LobbyEmotesUnlock and _G.LobbyEmotesUnlock.ApplyNow then pcall(_G.LobbyEmotesUnlock.ApplyNow) end
        if _G.BattleEmotesUnlock and _G.BattleEmotesUnlock.ApplyNow then pcall(_G.BattleEmotesUnlock.ApplyNow) end
    end,
    Refresh = function()
        if _G.LobbyEmotesUnlock and _G.LobbyEmotesUnlock.Refresh then pcall(_G.LobbyEmotesUnlock.Refresh) end
        if _G.BattleEmotesUnlock and _G.BattleEmotesUnlock.Refresh then pcall(_G.BattleEmotesUnlock.Refresh) end
    end,
}

_G.__DanceSystemLoaded = true

print("[DanceSystem] Emotes + Pet Skins loaded (Lobby + Battle)")
