

    local _outfitSavePathCache = nil
    local function _getOutfitSavePath()
        if _outfitSavePathCache then return _outfitSavePathCache end
        _outfitSavePathCache = '__DUNE_OUTFIT_PATH__'
        return _outfitSavePathCache
    end

    local function _saveEquippedCache()
        pcall(function()
            local cch = _G.AddOutfitEquippedCache
            if not cch then return end
            local path = _getOutfitSavePath()
            local lines = {}
            if cch.outfitRes then lines[#lines + 1] = "outfitRes=" .. tostring(cch.outfitRes) end
            if cch.outfitIns then lines[#lines + 1] = "outfitIns=" .. tostring(cch.outfitIns) end
            local clothIds = {}
            for resID in pairs(cch.clothes or {}) do
                clothIds[#clothIds + 1] = tostring(resID)
            end
            if #clothIds > 0 then
                lines[#lines + 1] = "clothes=" .. table.concat(clothIds, ",")
            end
            local eq = cch.equip or {}
            if eq.bag then lines[#lines + 1] = "equip_bag=" .. tostring(eq.bag) end
            if eq.helmet then lines[#lines + 1] = "equip_helmet=" .. tostring(eq.helmet) end
            if eq.armor then lines[#lines + 1] = "equip_armor=" .. tostring(eq.armor) end
            if eq.parachute then lines[#lines + 1] = "equip_parachute=" .. tostring(eq.parachute) end
            if eq.glider then lines[#lines + 1] = "equip_glider=" .. tostring(eq.glider) end
            if eq.bagIns then lines[#lines + 1] = "equip_bagIns=" .. tostring(eq.bagIns) end
            if eq.helmetIns then lines[#lines + 1] = "equip_helmetIns=" .. tostring(eq.helmetIns) end
            if eq.armorIns then lines[#lines + 1] = "equip_armorIns=" .. tostring(eq.armorIns) end
            if eq.parachuteIns then lines[#lines + 1] = "equip_parachuteIns=" .. tostring(eq.parachuteIns) end
            if eq.gliderIns then lines[#lines + 1] = "equip_gliderIns=" .. tostring(eq.gliderIns) end
            for wid, w in pairs(cch.weapons or {}) do
                lines[#lines + 1] = "weapon_" .. tostring(wid) .. "=" .. tostring(w.resID) .. ":" .. tostring(w.insID or 0)
            end
            pcall(function()
                if DataMgr and DataMgr.MotionSlotList then
                    local parts = {}
                    for _, ins in ipairs(DataMgr.MotionSlotList) do
                        ins = tonumber(ins)
                        if ins and ins > 0 then parts[#parts + 1] = tostring(ins) end
                    end
                    if #parts > 0 then lines[#lines + 1] = "motion=" .. table.concat(parts, ",") end
                end
            end)
            pcall(function()
                local AvatarData = require("client.logic.data.AvatarData")
                local parts = {}
                for _, ins in pairs(AvatarData.GetRoleWear()) do
                    ins = tonumber(ins)
                    if ins and ins > 0 then parts[#parts + 1] = tostring(ins) end
                end
                if #parts > 0 then lines[#lines + 1] = "rolewear=" .. table.concat(parts, ",") end
            end)
            pcall(function()
                if DataMgr and DataMgr.equipmentSkinInsIDTable then
                    for subType, ins in pairs(DataMgr.equipmentSkinInsIDTable) do
                        ins = tonumber(ins)
                        if ins and ins > 0 then
                            lines[#lines + 1] = "equipins_" .. tostring(subType) .. "=" .. tostring(ins)
                        end
                    end
                end
            end)
            pcall(function()
                if DataMgr and DataMgr.vst_skin then
                    local ins = tonumber(DataMgr.vst_skin)
                    if ins and ins > 0 then lines[#lines + 1] = "vst_skin=" .. tostring(ins) end
                end
            end)
            pcall(function()
                local HT = require("client.logic.lobby.hall_theme_utils")
                local ins = tonumber(HT.GetThemeInstId and HT.GetThemeInstId()) or 0
                if ins > 0 then
                    lines[#lines + 1] = "hall_theme_ins=" .. tostring(ins)
                    local res = tonumber(HT.homeThemeItemId) or 0
                    if res <= 0 and _G.AddOutfit_R and _G.AddOutfit_R.insToRes then
                        res = tonumber(_G.AddOutfit_R.insToRes[ins]) or 0
                    end
                    if res > 0 then lines[#lines + 1] = "hall_theme_res=" .. tostring(res) end
                end
            end)
            pcall(function()
                if DataMgr and DataMgr.VehicleSlotList then
                    for subType, insList in pairs(DataMgr.VehicleSlotList) do
                        if insList and type(insList) == "table" then
                            local parts = {}
                            for _, ins in ipairs(insList) do
                                ins = tonumber(ins)
                                if ins and ins > 0 then parts[#parts + 1] = tostring(ins) end
                            end
                            if #parts > 0 then
                                lines[#lines + 1] = "vehicle_" .. tostring(subType) .. "=" .. table.concat(parts, ",")
                            end
                        end
                    end
                end
            end)
            pcall(function()
                local GTS = ModuleManager and ModuleManager.GetModule
                    and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.GarageThemeSystem)
                if GTS and GTS.GarageVehicleInfo then
                    for slot, info in pairs(GTS.GarageVehicleInfo) do
                        if info and info.inst_id then
                            lines[#lines + 1] = "garage_" .. tostring(slot) .. "="
                                .. tostring(info.inst_id) .. ":" .. tostring(info.res_id or 0)
                        end
                    end
                end
            end)
            pcall(function()
                local cch2 = _G.AddOutfitEquippedCache
                if cch2 and cch2.throwObjects then
                    for st, info in pairs(cch2.throwObjects) do
                        if info.resID and info.resID > 0 then
                            lines[#lines + 1] = "throw_" .. tostring(st) .. "=" .. tostring(info.resID) .. ":" .. tostring(info.insID or 0)
                        end
                    end
                end
            end)
            local file = io.open(path, 'w+')
            if not file then return end
            file:write(table.concat(lines, "\n"))
            file:close()
        end)
    end

    local function _loadEquippedCache()
        pcall(function()
            local path = _getOutfitSavePath()
            local file = io.open(path, 'r')
            if not file then return end
            local content = file:read('*a')
            file:close()
            if not content or content == "" then return end

            _G._savedOutfitClothes = {}
            _G._savedOutfitRes = nil
            _G._savedOutfitIns = nil
            _G._savedOutfitEquip = {}
            _G._savedVehicleSlotList = {}
            _G._savedGarageVehicles = {}
            _G._savedMotionList = {}
            _G._savedRoleWearList = {}
            _G._savedEquipIns = {}
            _G._savedVstSkin = nil
            _G._savedHallThemeIns = nil
            _G._savedHallThemeRes = nil
            _G._savedThrowObjects = {}

            for line in content:gmatch("[^\n]+") do
                local key, val = line:match("^(.-)=(.+)$")
                if key and val then
                    if key == "outfitRes" then _G._savedOutfitRes = tonumber(val)
                    elseif key == "outfitIns" then _G._savedOutfitIns = tonumber(val)
                    elseif key == "clothes" then
                        for id in val:gmatch("([^,]+)") do
                            _G._savedOutfitClothes[tonumber(id)] = true
                        end
                    elseif key == "equip_bag" then _G._savedOutfitEquip.bag = tonumber(val)
                    elseif key == "equip_helmet" then _G._savedOutfitEquip.helmet = tonumber(val)
                    elseif key == "equip_armor" then _G._savedOutfitEquip.armor = tonumber(val)
                    elseif key == "equip_parachute" then _G._savedOutfitEquip.parachute = tonumber(val)
                    elseif key == "equip_glider" then _G._savedOutfitEquip.glider = tonumber(val)
                    elseif key == "equip_bagIns" then _G._savedOutfitEquip.bagIns = tonumber(val)
                    elseif key == "equip_helmetIns" then _G._savedOutfitEquip.helmetIns = tonumber(val)
                    elseif key == "equip_armorIns" then _G._savedOutfitEquip.armorIns = tonumber(val)
                    elseif key == "equip_parachuteIns" then _G._savedOutfitEquip.parachuteIns = tonumber(val)
                    elseif key == "equip_gliderIns" then _G._savedOutfitEquip.gliderIns = tonumber(val)
                    elseif key == "motion" then
                        for ins in val:gmatch("([^,]+)") do
                            ins = tonumber(ins)
                            if ins and ins > 0 then _G._savedMotionList[#_G._savedMotionList + 1] = ins end
                        end
                    elseif key == "rolewear" then
                        for ins in val:gmatch("([^,]+)") do
                            ins = tonumber(ins)
                            if ins and ins > 0 then _G._savedRoleWearList[#_G._savedRoleWearList + 1] = ins end
                        end
                    elseif key:match("^equipins_(%d+)$") then
                        local subType = tonumber(key:match("^equipins_(%d+)$"))
                        if subType then _G._savedEquipIns[subType] = tonumber(val) end
                    elseif key == "vst_skin" then _G._savedVstSkin = tonumber(val)
                    elseif key == "hall_theme_ins" then _G._savedHallThemeIns = tonumber(val)
                    elseif key == "hall_theme_res" then _G._savedHallThemeRes = tonumber(val)
                    elseif key:match("^weapon_(.+)$") then
                        local wid = tonumber(key:match("^weapon_(.+)$"))
                        local resID, insID = val:match("^(.-):(.+)$")
                        if wid and resID then
                            _G._savedOutfitEquip["weapon_" .. wid] = { resID = tonumber(resID), insID = tonumber(insID) or 0 }
                        end
                    elseif key:match("^vehicle_(%d+)$") then
                        local subType = tonumber(key:match("^vehicle_(%d+)$"))
                        if subType then
                            local list = {}
                            for ins in val:gmatch("([^,]+)") do
                                ins = tonumber(ins)
                                if ins and ins > 0 then list[#list + 1] = ins end
                            end
                            if #list > 0 then _G._savedVehicleSlotList[subType] = list end
                        end
                    elseif key:match("^garage_(%d+)$") then
                        local slot = tonumber(key:match("^garage_(%d+)$"))
                        local insID, resID = val:match("^(.-):(.+)$")
                        if slot and insID then
                            _G._savedGarageVehicles[slot] = {
                                inst_id = tonumber(insID),
                                res_id = tonumber(resID) or 0,
                            }
                        end
                    elseif key:match("^throw_(%d+)$") then
                        local st = tonumber(key:match("^throw_(%d+)$"))
                        if st then
                            local resID, insID = val:match("^(.-):(.+)$")
                            _G._savedThrowObjects[st] = { resID = tonumber(resID), insID = tonumber(insID) or 0 }
                        end
                    end
                end
            end

            if not _G.AddOutfitEquippedCache then
                _G.AddOutfitEquippedCache = {
                    outfitRes = nil, outfitIns = nil,
                    clothes = {}, equip = {}, weapons = {},
                }
            end
            local cch = _G.AddOutfitEquippedCache
            cch.clothes = cch.clothes or {}
            cch.equip = cch.equip or {}
            cch.weapons = cch.weapons or {}

            if _G._savedOutfitRes then
                cch.outfitRes = _G._savedOutfitRes
                cch.outfitIns = _G._savedOutfitIns
            end
            if not _G._addOutfitPersistLoaded and _G._savedOutfitClothes then
                for resID in pairs(_G._savedOutfitClothes) do
                    cch.clothes[resID] = true
                end
            end

            if _G._savedOutfitEquip then
                for k, v in pairs(_G._savedOutfitEquip) do
                    if k == "bag" then cch.equip.bag = v
                    elseif k == "helmet" then cch.equip.helmet = v
                    elseif k == "armor" then cch.equip.armor = v
                    elseif k == "parachute" then cch.equip.parachute = v
                    elseif k == "glider" then cch.equip.glider = v
                    elseif k == "bagIns" then cch.equip.bagIns = v
                    elseif k == "helmetIns" then cch.equip.helmetIns = v
                    elseif k == "armorIns" then cch.equip.armorIns = v
                    elseif k == "parachuteIns" then cch.equip.parachuteIns = v
                    elseif k == "gliderIns" then cch.equip.gliderIns = v
                    elseif type(k) == "string" and k:match("^weapon_(.+)$") then
                        local wid = tonumber(k:match("^weapon_(.+)$"))
                        if wid then cch.weapons[wid] = v end
                    end
                end
            end

            if _G._savedThrowObjects then
                cch.throwObjects = cch.throwObjects or {}
                for st, info in pairs(_G._savedThrowObjects) do
                    if info.resID and info.resID > 0 then
                        cch.throwObjects[st] = info
                    end
                end
            end

            _G._addOutfitPersistLoaded = true
            _lastSnapshot = _snapshotCache()
            print("[AddOutfit] Loaded saved IDs from file:", path)
        end)
    end

    local function _snapshotCache()
        local cch = _G.AddOutfitEquippedCache
        if not cch then return "" end
        local parts = {}
        parts[#parts + 1] = tostring(cch.outfitRes or 0)
        local clothIds = {}
        for resID in pairs(cch.clothes or {}) do
            clothIds[#clothIds + 1] = resID
        end
        table.sort(clothIds)
        parts[#parts + 1] = table.concat(clothIds, ",")
        local eq = cch.equip or {}
        parts[#parts + 1] = tostring(eq.bag or 0)
        parts[#parts + 1] = tostring(eq.helmet or 0)
        parts[#parts + 1] = tostring(eq.armor or 0)
        parts[#parts + 1] = tostring(eq.parachute or 0)
        parts[#parts + 1] = tostring(eq.glider or 0)
        local wIds = {}
        for wid in pairs(cch.weapons or {}) do wIds[#wIds + 1] = wid end
        table.sort(wIds)
        for _, wid in ipairs(wIds) do
            local w = cch.weapons[wid]
            parts[#parts + 1] = tostring(wid) .. ":" .. tostring(w.resID or 0)
        end
        if cch.throwObjects then
            local tIds = {}
            for st in pairs(cch.throwObjects) do tIds[#tIds + 1] = st end
            table.sort(tIds)
            for _, st in ipairs(tIds) do
                local info = cch.throwObjects[st]
                parts[#parts + 1] = "throw_" .. tostring(st) .. ":" .. tostring(info.resID or 0)
            end
        end
        return table.concat(parts, "|")
    end

    local _lastSnapshot = ""
    local _saveDirty = false
    local _saveInProgress = false
    local _lastSaveClock = 0
    local SAVE_MIN_INTERVAL = 2.5

    local function _flushSave(force)
        if _saveInProgress then
            _saveDirty = true
            return
        end
        local now = 0
        pcall(function() now = os.clock() end)
        if not force and _lastSaveClock > 0 and (now - _lastSaveClock) < SAVE_MIN_INTERVAL then
            _saveDirty = true
            return
        end
        _saveInProgress = true
        _saveDirty = false
        pcall(function()
            if _G.AddOutfitSyncCacheBeforeSave then _G.AddOutfitSyncCacheBeforeSave() end
            _lastSnapshot = _snapshotCache()
            pcall(_saveEquippedCache)
            local cch2 = _G.AddOutfitEquippedCache
            if cch2 then
                _G._savedOutfitRes = tonumber(cch2.outfitRes) and cch2.outfitRes > 0 and cch2.outfitRes or nil
                _G._savedOutfitIns = tonumber(cch2.outfitIns) and cch2.outfitIns > 0 and cch2.outfitIns or nil
                _G._savedOutfitClothes = {}
                for resID in pairs(cch2.clothes or {}) do
                    _G._savedOutfitClothes[resID] = true
                end
            end
        end)
        pcall(function() _lastSaveClock = os.clock() end)
        _saveInProgress = false
    end

    local _saveDeferred = false
    local function _AutoSaveOutfit(force)
        if force then
            _flushSave(true)
            return
        end
        _saveDirty = true
        if _saveDeferred then return end
        _saveDeferred = true
        local function _doDeferredFlush()
            if _G.__DuneSkinCtl and not _G.__DuneSkinCtl.enabled then return end
            _saveDeferred = false
            if _saveDirty then _flushSave(false) end
        end
        local ok = pcall(_G.SetTimer, 0.5, _doDeferredFlush)
        if not ok then _doDeferredFlush() end
    end

    if _G.__DuneTrack then _G.__DuneTrack(_G, 'AddOutfitTryFlushSave') end
    _G.AddOutfitTryFlushSave = function()
        if _saveDirty then _flushSave(false) end
    end

    -- ========== WardrobeNewHandler (Vehicle Save Fix) ==========
    pcall(function()
        local WardrobeNewHandler = {}

        local _bShowNotice = false

        local _ao_R = nil
        local function getR()
            if _ao_R then return _ao_R end
            _ao_R = _G.AddOutfit_R
            return _ao_R
        end
        local function aoIsInjectedIns(ins)
            ins = tonumber(ins)
            if not ins then return false end
            local R = getR()
            return R and R.insToRes[ins] ~= nil
        end

        if _G.__DuneTrack then _G.__DuneTrack(WardrobeNewHandler, 'send_depot_modify_combat_vehicle_req') end
        function WardrobeNewHandler.send_depot_modify_combat_vehicle_req(insID, slotIndex, bShowNotice)
            insID = tonumber(insID)
            slotIndex = tonumber(slotIndex) or 1
            _bShowNotice = bShowNotice
            if aoIsInjectedIns(insID) then
                local R = getR()
                local resID = R and R.insToRes[insID]
                local itemSubType = 0
                if resID and CDataTable and CDataTable.GetTableData then
                    local c = CDataTable.GetTableData("Item", resID)
                    itemSubType = c and tonumber(c.ItemSubType or c.itemSubType) or 0
                end
                if itemSubType and itemSubType > 0 and DataMgr then
                    DataMgr.VehicleSlotList = DataMgr.VehicleSlotList or {}
                    local slotList = DataMgr.VehicleSlotList[itemSubType] or {}
                    if bShowNotice then
                        for i = #slotList, 1, -1 do
                            if slotList[i] == insID then
                                table.remove(slotList, i)
                            end
                        end
                        slotList[slotIndex] = insID
                    else
                        for i, sid in ipairs(slotList) do
                            if sid == insID then
                                table.remove(slotList, i)
                                break
                            end
                        end
                    end
                    DataMgr.VehicleSlotList[itemSubType] = slotList
                end
                pcall(function()
                    local tabSurveillance = require("client.slua.logic.wardrobe.tab_surveillance")
                    if tabSurveillance and tabSurveillance.VehicleChange then
                        tabSurveillance.VehicleChange()
                    end
                end)
                if EventSystem and EVENTTYPE_WARDROBE and EVENTID_WARDROBE_VEHICLE_SLOT_DATA_CHANGE then
                    EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_VEHICLE_SLOT_DATA_CHANGE)
                end
                pcall(_AutoSaveOutfit)
                return
            end
            local NetManager = require("client.network.comm.NetManager")
            NetManager.SendPkg(1012780591, insID, slotIndex, bShowNotice)
        end

        if _G.__DuneTrack then _G.__DuneTrack(WardrobeNewHandler, 'on_depot_modify_combat_vehicle_rsp') end
        function WardrobeNewHandler.on_depot_modify_combat_vehicle_rsp(ret_code, vehicle_info)
            if ret_code ~= 0 and ret_code ~= NetErrorCode_NONE then
                if _bShowNotice and ShowNotice then ShowNotice(ret_code) end
                return
            end
            
            if vehicle_info and DataMgr then
                local injectedVehicles = {}
                if DataMgr.VehicleSlotList then
                    for subType, insList in pairs(DataMgr.VehicleSlotList) do
                        for i, insID in ipairs(insList) do
                            if aoIsInjectedIns(insID) then
                                injectedVehicles[subType] = injectedVehicles[subType] or {}
                                injectedVehicles[subType][i] = insID
                            end
                        end
                    end
                end

                DataMgr.VehicleSlotList = vehicle_info

                for subType, list in pairs(injectedVehicles) do
                    DataMgr.VehicleSlotList[subType] = DataMgr.VehicleSlotList[subType] or {}
                    for i, insID in pairs(list) do
                        DataMgr.VehicleSlotList[subType][i] = insID
                    end
                end
            end
            
            pcall(function()
                local tabSurveillance = require("client.slua.logic.wardrobe.tab_surveillance")
                if tabSurveillance and tabSurveillance.VehicleChange then
                    tabSurveillance.VehicleChange()
                end
            end)
            
            if EventSystem and EVENTTYPE_WARDROBE and EVENTID_WARDROBE_VEHICLE_SLOT_DATA_CHANGE then
                EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_VEHICLE_SLOT_DATA_CHANGE)
            end
        end

        if _G.__DuneTrack then _G.__DuneTrack(WardrobeNewHandler, 'send_select_item') end
        function WardrobeNewHandler.send_select_item(insID)
            local NetManager = require("client.network.comm.NetManager")
            NetManager.SendPkg(595484784, insID)
        end

        if _G.__DuneTrack then _G.__DuneTrack(WardrobeNewHandler, 'send_equip_motion_list_req') end
        function WardrobeNewHandler.send_equip_motion_list_req(motion_list)
            local NetManager = require("client.network.comm.NetManager")
            NetManager.SendPkg(1124239581, motion_list)
        end

        package.loaded["client.network.Protocol.WardrobeNewHandler"] = WardrobeNewHandler
        print("[AddOutfit] WardrobeNewHandler injected into package.loaded")
    end)

    local _ao_ok, _ao_err = pcall(function()
        local game_frontend_hud = require("game_frontend_hud")

        local function log(...)
            print("[AddOutfit]", ...)
        end

        local MATCH_CONFIG = {
            outfitRes = 0,
            weaponSkins = {},
            equip = { bag = 0, helmet = 0, armor = 0 },
        }

        local ITEMS = {}
        local _itemsLoaded = false

        local function buildNonMaxLevelSet()
            local nonMax = {}
            if not (CDataTable and CDataTable.GetTable) then return nonMax end

            pcall(function()
                local upTbl = CDataTable.GetTable("ItemUpgradeConfig")
                if not upTbl then return end
                local maxLvl, maxItem = {}, {}
                local groupMembers = {}
                for _, cfg in pairs(upTbl) do
                    local gid   = tonumber(cfg.GroupID)
                    local lvl   = tonumber(cfg.Level)
                    local itm   = tonumber(cfg.ItemID)
                    if gid and lvl and itm then
                        if not groupMembers[gid] then groupMembers[gid] = {} end
                        groupMembers[gid][#groupMembers[gid] + 1] = itm
                        if not maxLvl[gid] or lvl > maxLvl[gid] then
                            maxLvl[gid] = lvl
                            maxItem[gid] = itm
                        end
                    end
                end
                for gid, members in pairs(groupMembers) do
                    local topItem = maxItem[gid]
                    for _, itm in ipairs(members) do
                        if itm ~= topItem then nonMax[itm] = true end
                    end
                end
            end)

            local function processXSuitTable(tableName)
                pcall(function()
                    local tbl = CDataTable.GetTable(tableName)
                    if not tbl then return end
                    local maxStar, maxItem = {}, {}
                    local periodMembers = {}
                    for _, data in pairs(tbl) do
                        local period = tonumber(data.Period or data.period)
                        local star   = tonumber(data.Star or data.star or data.Level or data.level)
                        local itm    = tonumber(data.ItemID or data.itemID or data.ItemId)
                        if period and star and itm then
                            if not periodMembers[period] then periodMembers[period] = {} end
                            periodMembers[period][#periodMembers[period] + 1] = itm
                            if not maxStar[period] or star > maxStar[period] then
                                maxStar[period] = star
                                maxItem[period] = itm
                            end
                        end
                    end
                    for period, members in pairs(periodMembers) do
                        local topItem = maxItem[period]
                        for _, itm in ipairs(members) do
                            if itm ~= topItem then nonMax[itm] = true end
                        end
                    end
                end)
            end
            processXSuitTable("GoldenSuitUpgradeCfg")
            processXSuitTable("GoldenSuitUpgradeCfgKJ")
            processXSuitTable("GoldenSuitUpgradeCfgIN")

            pcall(function()
                local bpMap = CDataTable.GetTable("BackpackMapping")
                if not bpMap then return end
                for _, m in pairs(bpMap) do
                    local lv3 = tonumber(m.SkinItemIDLv3 or 0) or 0
                    local lv1 = tonumber(m.SkinItemIDLv1 or 0) or 0
                    local lv2 = tonumber(m.SkinItemIDLv2 or 0) or 0
                    if lv1 > 0 and lv1 ~= lv3 then nonMax[lv1] = true end
                    if lv2 > 0 and lv2 ~= lv3 then nonMax[lv2] = true end
                end
            end)

            return nonMax
        end


        -- ============================================================
        -- WEAPON SKIN MAPS - MULTIPLE SKINS PER WEAPON
        -- ============================================================
        local WeaponSkins = {
            -- M416
            [101004] = {
                1101004046, -- GLACIER
                1101004062, -- FOOL
                1101004209, -- TidalEmbrace
                1101004218, -- ShinobiKami
                1101004226, -- SealedNether
                1101004236, -- RoaringImmolation
            },
            -- AUG
            [101006] = {
                1101006075, -- Abyssal Howl
                1101006062, -- Forsaken Glace
                1101006085, -- Nyxen Rose
                1101006106, -- NineTailsAUG
            },
            -- AKM
            [101001] = {
                1101001213, -- Starsea Admiral
                1101001265, -- Sandspring Dominion
                1101001174, -- Wandering Tyrant
                1101001231, -- Bunny Munchkin
                1101001242, -- Decisive Day
                1101001256, -- Lightshift Gold Feather
                1101001276, -- Pulsing Light
            },
            -- SCAR-L
            [101003] = {
                1101003195, -- SereneLumina
                1101003167, -- Crimson Nemesis
                1101003099, -- Mystic Night
                1101003208, -- Fantasy Romance
                1101003181, -- Folly's Clasp
                1101003227, -- Phoenix Rising
                1101003219, -- Soulbound Prism
            },
            -- M762
            [101008] = {
                1101008126, -- Noctum_Sunder
                1101008136, -- Luminous_Muse
            },
            
            -- Single skin weapons
            [101002] = {1101002081}, -- M16A4
            [101005] = {1101005098}, -- GROZA
            [101007] = {1101007062}, -- QBZ
            [101102] = {1101102056}, -- ACE32
            [101101] = {1101101007}, -- ASM Abakan
            [101012] = {1101012033}, -- Honey Badger
            [101100] = {1101100012}, -- FAMAS
            [103003] = {1103003087}, -- AWM
            [103002] = {1103002087}, -- M24
            [103001] = {1103001179}, -- KAR98K
            [103012] = {1103012019}, -- AMR
            [103007] = {1103007028}, -- MK14
            [103004] = {1103004037}, -- SKS
            [103009] = {1103009037}, -- SLR
            [103006] = {1103006030}, -- MINI14
            [103100] = {1103100007}, -- MK12
            [105002] = {1105002091}, -- DP28
            [105010] = {1105010019}, -- MG3
            [105001] = {1105001069}, -- M249
            [102001] = {1102001120}, -- UZI
            [102002] = {1102002136}, -- UMP45
            [102003] = {1102003080}, -- VECTOR
            [102004] = {1102004018}, -- THOMPSON
            [102005] = {1102005064}, -- BIZON
            [103005] = {1103005024}, -- VSS
            [102105] = {1102105028}, -- P90
            [104003] = {1104003046}, -- S12K
            [104002] = {1104002022}, -- S1897
            [104004] = {1104004041}, -- DBS
            [108004] = {1108004027}, -- PAN
            [108001] = {1108001069}, -- Machete
            [108005] = {1108005053}, -- Dagger
        }

        -- ============================================================
        -- OUTFIT IDs - ONLY THESE
        -- ============================================================
        local OutfitIDs = {
            1407856, 1407512, 1406152, 1405870, 1407103, 1407366,
            1405628, 1407219, 1407667, 1406971, 1407140, 1407142,
            1407961, 1407962, 1407963, 1407964, 1407965, 1407966,
            1407967, 1407968, 1407969, 1407970, 1407971, 1407993, 1407994,
            1407920, 1407225, 1407894, 1407870, 1407812, 1407811,
            1407727, 1407079, 1407695, 1407682, 1407758, 1407776,
            1405045, 1405384, 931400288, 1406060, 1405487, 1405481,
            1407211, 1407468, 1406119, 1405583, 1405026, 1407286,
            1405802, 1407106, 12205101, 1410668, 1407471, 1405073,
            1407285, 1406118, 1400687, 1407632, 1400377, 1407618,
            1406891, 1407631, 1405798, 1405426, 1405593, 1405097,
            1407522, 1407161, 1405090, 1407441, 1405092, 1407276,
            1407558, 1405623, 1407391, 1405174, 1407107,1408045,1408038,1407990,
        }

        -- ============================================================
        -- LOBBY THEME IDs
        -- ============================================================
        local LobbyThemeIDs = {
            202408061,
            202408062,
            202408063,
            202408064,
            202408065,
        }

        -- ============================================================
        -- HELMET SKIN IDs
        -- ============================================================
        local HelmetSkins = {
    1502003014,
    1502003439,
    1502003410,
    1502003023,
    1502003012,
    1502003510,
}

-- ============================================================
-- BACKPACK SKIN IDs (Level 3 only)
-- ============================================================
local BackpackSkins = {
    1501003726,
    1501003711,
    1501003024,
    1501003220,
    1501003047,
    1501003710,
    1501003663,
    1501003699,
    1501003698,
    1501003688,
    1501003629,
    1501003741,
}

        -- ============================================================
        -- VEHICLE SKIN IDs
        -- ============================================================
        local VehicleSkins = {
            1903218, 1903220, 1903221, 1903222, 1903223, 1903219, 1903080, 1903079, 1903087, 1903071, 1903072, 1903073, 1903074, 1903075, 1903076, 1903197, 1903191, 1903192, 1903193, 1903212, 19116002, 19116003, 19116004,
            1907054, 1907053, 1907058, 1907059, 1907063, 1907047, 1907048, 1907052, 1907016,
            1915022, 1915018, 1915021, 1915019, 1915017, 1915016, 1915011, 1915012, 1914011, 1915008, 1915009, 1915006, 1915007, 1915005,
            1961062, 1961065, 1961066, 1961067, 1961047, 1961058, 1961059, 1961060, 1961061, 1961063, 1961064, 1961144, 1961147, 1961148, 1961149, 1961137, 1961138, 1961139, 1961051, 1961052, 1961053, 1961044, 1961045, 1961046, 1961145, 1961007, 1961010, 1961012, 1961013, 1961014, 1961015,
            1908108, 1908109, 1908066, 1908104, 1908095, 1908094, 1908085, 1908084, 1908068, 1908069, 1908070, 1908067, 1909019, 1909020, 1909023, 1909017, 1909015, 1909022, 1908189, 1908188, 1908099, 1908047, 1908036, 1908013,
            1901090, 1901070, 1901091, 1901027, 1901066, 1901089, 1901079, 1901047,
            1903012, 1903011, 1903010, 1903008, 1903004,
            1902018,
            1917006,
            1987002,
        }
        -- ============================================================
        -- COLLECT ITEMS - Only these IDs
        -- ============================================================
        local function refreshItems()
            if _itemsLoaded then return #ITEMS end
            if #ITEMS > 0 then return #ITEMS end
            
            -- Weapon skins (multiple per weapon)
            for weaponID, skinList in pairs(WeaponSkins) do
                if type(skinList) == "table" then
                    for _, skinID in ipairs(skinList) do
                        if skinID and skinID > 0 then
                            ITEMS[#ITEMS + 1] = skinID
                        end
                    end
                elseif skinList and skinList > 0 then
                    ITEMS[#ITEMS + 1] = skinList
                end
            end
            
            -- Outfits
            for _, id in ipairs(OutfitIDs) do
                if id and id > 0 then
                    ITEMS[#ITEMS + 1] = id
                end
            end
            
            -- Lobby Themes
            for _, id in ipairs(LobbyThemeIDs) do
                if id and id > 0 then
                    ITEMS[#ITEMS + 1] = id
                end
            end
            
            -- Helmets
            for _, id in ipairs(HelmetSkins) do
                if id and id > 0 then
                    ITEMS[#ITEMS + 1] = id
                end
            end
            
            -- Backpacks
            for _, id in ipairs(BackpackSkins) do
                if id and id > 0 then
                    ITEMS[#ITEMS + 1] = id
                end
            end
            
            -- Vehicles
            for _, id in ipairs(VehicleSkins) do
                if id and id > 0 then
                    ITEMS[#ITEMS + 1] = id
                end
            end
            
            table.sort(ITEMS)
            _itemsLoaded = true
            log("Collected", #ITEMS, "items for injection")
            return #ITEMS
        end


        local _K = {
            INS_BASE = 2000000000, PKG_SLOT = 3, MELEE_ID = 108,
            GUN_SUB = { [101]=true, [102]=true, [103]=true, [104]=true, [105]=true, [106]=true, [107]=true },
            NET_OK = NetErrorCode_NONE or "ok",
            GUN_MASTER_SYN_SLOT = 7,
            THROW_SUB = { [612] = "shoulei", [613] = "smoke", [614] = "stun", [615] = "burn" },
            THROW_AVATAR_KEY = { shoulei = "GrenadeAvatarShoulei", smoke = "GrenadeAvatarSmoke", stun = "GrenadeAvatarStun", burn = "GrenadeAvatarBurn" },
        }

        local R = { insToRes = {}, resToIns = {} }
        local _injectedResSet = {}
        for _, rid in ipairs(ITEMS) do _injectedResSet[rid] = true end

        local _C = { cfg = {}, fullSuit = {}, equipSlot = {}, weaponId = {}, itemTab = {}, vehicleItems = {}, pageMatch = {} }

        local _S = {
            matchApplied = false, matchTimer = nil, matchOutfitDone = false,
            avatarItemsRegistered = false, weaponApplied = false, weaponDiagDone = false,
            lastWeaponResID = 0, weaponSpawnHooked = false, bootstrapNotified = false,
            globalFrame = 0, weaponHookGuardUntil = 0, equipSkinApplying = false,
            injectedDone = false, lastAppliedWeaponID = 0, lastAppliedSkinID = 0,
            bootstrapped = false, lobbyApplied = false,
        }

        _G.AddOutfitSkinIdMappings = _G.AddOutfitSkinIdMappings or {}
        _G.AddOutfitLastAppliedSkin = _G.AddOutfitLastAppliedSkin or {}
        _G.AddOutfitLastLobbyOutfitRes = _G.AddOutfitLastLobbyOutfitRes or nil

        _K.ST_TOP     = (ENUM_ITEM_SUBTYPE and ENUM_ITEM_SUBTYPE.Package_Slot) or 403
        _K.ST_PANTS   = (ENUM_ITEM_SUBTYPE and ENUM_ITEM_SUBTYPE.Pants_Slot) or 404
        _K.ST_SHOES   = (ENUM_ITEM_SUBTYPE and ENUM_ITEM_SUBTYPE.Shoes_Slot) or 405
        _K.ST_UNDER_T = (ENUM_ITEM_SUBTYPE and ENUM_ITEM_SUBTYPE.UnderCloth) or 450
        _K.ST_UNDER_P = (ENUM_ITEM_SUBTYPE and ENUM_ITEM_SUBTYPE.UnderPants) or 451
        _K.WARDROBE_TAB_SUIT, _K.WARDROBE_TAB_CLOTHES = 10, 3
        _K.WARDROBE_TAB_TROUSERS, _K.WARDROBE_TAB_SHOES = 4, 5
        _K.WARDROBE_TAB_BAG, _K.WARDROBE_TAB_HELMET, _K.WARDROBE_TAB_ARMOR = 15, 16, 17
        _K.WARDROBE_TAB_GUN, _K.WARDROBE_TAB_PARACHUTE = 9, 7
        _K.WARDROBE_TAB_GLIDER = 20
        _K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_PAGE_WEAPON, _K.WARDROBE_PAGE_PARACHUTE, _K.WARDROBE_PAGE_VEHICLE = 1, 4, 5, 6
        pcall(function()
            local wm = require("client.slua.umg.Wardrobe.wardrobe_macro")
            local t = wm.ENUM_WardrobeSubTabString
            _K.WARDROBE_TAB_SUIT = t.ENUM_WardrobeSubTabString_suit
            _K.WARDROBE_TAB_CLOTHES = t.ENUM_WardrobeSubTabString_clothes
            _K.WARDROBE_TAB_TROUSERS = t.ENUM_WardrobeSubTabString_trousers
            _K.WARDROBE_TAB_SHOES = t.ENUM_WardrobeSubTabString_shoes
            _K.WARDROBE_TAB_BAG = t.ENUM_WardrobeSubTabString_bag
            _K.WARDROBE_TAB_HELMET = t.ENUM_WardrobeSubTabString_helmet
            _K.WARDROBE_TAB_ARMOR = t.ENUM_WardrobeSubTabString_armor
            _K.WARDROBE_TAB_GUN = t.ENUM_WardrobeSubTabString_gun
            _K.WARDROBE_TAB_PARACHUTE = t.ENUM_WardrobeSubTabString_parachute
            _K.WARDROBE_TAB_GLIDER = t.ENUM_WardrobeSubTabString_effect
            _K.WARDROBE_PAGE_AVATAR = wm.ENUM_WardrobePageTypeId.ENUM_WardrobePageType_Avatar
            _K.WARDROBE_PAGE_WEAPON = wm.ENUM_WardrobePageTypeId.ENUM_WardrobePageType_Weapon
            _K.WARDROBE_PAGE_PARACHUTE = wm.ENUM_WardrobePageTypeId.ENUM_WardrobePageType_Parachute
            _K.WARDROBE_PAGE_VEHICLE = wm.ENUM_WardrobePageTypeId.ENUM_WardrobePageType_Vehicle
        end)

        local FULL_SUIT_CLEAR_ST = {
            [_K.ST_TOP] = true, [_K.ST_PANTS] = true, [_K.ST_SHOES] = true,
            [_K.ST_UNDER_T] = true, [_K.ST_UNDER_P] = true,
        }

        local function cache()
            _G.AddOutfitEquippedCache = _G.AddOutfitEquippedCache or {
                outfitRes = nil, outfitIns = nil,
                clothes = {},
                equip = {},
                weapons = {},
            }
            return _G.AddOutfitEquippedCache
        end

        local function cfg(resID)
            if not resID or not CDataTable or not CDataTable.GetTableData then return nil end
            resID = tonumber(resID)
            if not resID then return nil end
            if _C.cfg[resID] ~= nil then return _C.cfg[resID] end
            local c = CDataTable.GetTableData("Item", resID)
            _C.cfg[resID] = c
            return c
        end

        local function subType(c)
            return c and (c.ItemSubType or c.itemSubType) or nil
        end

        local function isThrowObjectRes(resID)
            resID = tonumber(resID)
            if not resID then return nil end
            local c = cfg(resID)
            if not c then return nil end
            local st = tonumber(c.ItemSubType or c.itemSubType or 0)
            if _K.THROW_SUB[st] then return st end
            return nil
        end

        local function saveThrowObject(resID, insID)
            resID, insID = tonumber(resID), tonumber(insID)
            if not resID then return end
            local st = isThrowObjectRes(resID)
            if not st then return end
            local cch = cache()
            cch.throwObjects = cch.throwObjects or {}
            cch.throwObjects[st] = { resID = resID, insID = insID or R.resToIns[resID] or 0 }
        end

        local function isInjectedIns(ins)
            return ins and R.insToRes[tonumber(ins)] ~= nil
        end

        local function isInjectedRes(res)
            return res and (R.resToIns[tonumber(res)] ~= nil or _injectedResSet[tonumber(res)])
        end

        local function weaponIdFromSkin(resID)
            resID = tonumber(resID)
            if not resID then return nil end
            if _C.weaponId[resID] ~= nil then return _C.weaponId[resID] end
            local m = CDataTable and CDataTable.GetTableData and CDataTable.GetTableData("WeaponSkinMapping", resID)
            local wid = m and (m.WeaponID or m.WeaponId) or nil
            _C.weaponId[resID] = wid
            return wid
        end

        local function isHallThemeRes(resID)
            resID = tonumber(resID)
            if not resID then return false end
            local c = cfg(resID)
            if not c then return false end
            local it = tonumber(c.ItemType or c.itemType or 0)
            if ENUM_ITEM_TYPE and ENUM_ITEM_TYPE.Hall_Theme then
                return it == ENUM_ITEM_TYPE.Hall_Theme
            end
            return it == 202
        end

        local function getEquipSkinSlot(resID)
            resID = tonumber(resID)
            if not resID then return nil end
            if _C.equipSlot[resID] ~= nil then return _C.equipSlot[resID] end
            local slot = nil
            local itemCfg = cfg(resID)
            if itemCfg then
                local st = tonumber(itemCfg.ItemSubType or itemCfg.itemSubType or 0)
                local it = tonumber(itemCfg.ItemType or itemCfg.itemType or 0)
                if st == 501 or st == 504 then slot = "bag"
                elseif st == 502 or st == 505 then slot = "helmet"
                elseif st == 503 or st == 506 then slot = "armor"
                elseif it == 4 and st == 701 then slot = "parachute"
                elseif it == 4 and (st == 413 or st == 414 or st == 415) then slot = "glider" end
            end
            if not slot then
                if resID >= 1502000000 and resID < 1503000000 then slot = "helmet"
                elseif resID >= 1505000000 and resID < 1506000000 then slot = "helmet"
                elseif resID >= 1501000000 and resID < 1502000000 then slot = "bag"
                elseif resID >= 1504000000 and resID < 1505000000 then slot = "bag" end
            end
            _C.equipSlot[resID] = slot
            return slot
        end

        local function wardrobeTab(resID, depotData)
            if depotData and depotData.subTabType then return tonumber(depotData.subTabType) end
            local c = cfg(resID)
            return c and tonumber(c.WardrobeTab or c.wardrobeTab) or nil
        end

        local function wardrobeMainTab(resID, depotData)
            if depotData and depotData.mainTabType then return tonumber(depotData.mainTabType) end
            local c = cfg(resID)
            return c and tonumber(c.WardrobeMainTab or c.wardrobeMainTab) or _K.WARDROBE_PAGE_AVATAR
        end

        local function getInjectedItemTab(resID, depotData)
            resID = tonumber(resID)
            if not resID then return nil, nil end
            if _C.itemTab[resID] then
                return _C.itemTab[resID][1], _C.itemTab[resID][2]
            end
            local c = cfg(resID)
            local st = c and tonumber(c.ItemSubType or c.itemSubType) or 0

            local equipSlot = getEquipSkinSlot(resID)
            local result
            if equipSlot == "bag" then result = {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_BAG}
            elseif equipSlot == "helmet" then result = {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_HELMET}
            elseif equipSlot == "armor" then result = {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_ARMOR}
            elseif equipSlot == "parachute" then result = {_K.WARDROBE_PAGE_PARACHUTE, _K.WARDROBE_TAB_PARACHUTE}
            elseif equipSlot == "glider" then result = {_K.WARDROBE_PAGE_PARACHUTE, _K.WARDROBE_TAB_GLIDER}
            elseif weaponIdFromSkin(resID) then result = {_K.WARDROBE_PAGE_WEAPON, _K.WARDROBE_TAB_GUN}
            else
                local mainTab = wardrobeMainTab(resID, depotData)
                local subTab = wardrobeTab(resID, depotData)
                if subTab and subTab > 0 then result = {mainTab, subTab}
                elseif st == _K.ST_PANTS then result = {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_TROUSERS}
                elseif st == _K.ST_SHOES then result = {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_SHOES}
                elseif st == _K.ST_TOP then
                    if isFullSuitRes(resID, depotData) then result = {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_SUIT}
                    else result = {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_CLOTHES} end
                elseif st == 400 or st == 408 or st == 409 or st == 410 then
                    result = {_K.WARDROBE_PAGE_PARACHUTE, _K.WARDROBE_TAB_PARACHUTE}
                else
                    result = {mainTab, subTab or 0}
                end
            end
            _C.itemTab[resID] = result
            return result[1], result[2]
        end

        local function isFullSuitRes(resID, depotData)
            resID = tonumber(resID)
            if not resID or resID <= 0 then return false end
            if _C.fullSuit[resID] ~= nil then return _C.fullSuit[resID] end
            local result = false
            pcall(function()
                local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
                if LogicXSuit.IsXSuit(resID) then result = true end
            end)
            if not result then
                local tab = wardrobeTab(resID, depotData)
                if tab == _K.WARDROBE_TAB_SUIT then result = true end
            end
            _C.fullSuit[resID] = result
            return result
        end

        local function getClothKind(resID, depotData)
            resID = tonumber(resID)
            if not resID then return nil end
            local st = subType(cfg(resID))
            if st == _K.ST_TOP then
                return isFullSuitRes(resID, depotData) and "full_suit" or "top"
            end
            if st == _K.ST_PANTS then return "pants" end
            if st == _K.ST_SHOES then return "shoes" end
            if st == _K.ST_UNDER_T then return "under_top" end
            if st == _K.ST_UNDER_P then return "under_pants" end
            return nil
        end

        local function subTypesToClearForKind(kind)
            if kind == "full_suit" then return FULL_SUIT_CLEAR_ST end
            if kind == "top" then return { [_K.ST_TOP] = true } end
            if kind == "pants" then return { [_K.ST_PANTS] = true } end
            if kind == "shoes" then return { [_K.ST_SHOES] = true } end
            if kind == "under_top" then return { [_K.ST_UNDER_T] = true } end
            if kind == "under_pants" then return { [_K.ST_UNDER_P] = true } end
            return nil
        end

        local function isBodyClothSubType(st)
            st = tonumber(st)
            return st == _K.ST_TOP or st == _K.ST_PANTS or st == _K.ST_SHOES or st == _K.ST_UNDER_T or st == _K.ST_UNDER_P
        end

        local _outfitMergeCache = { key = nil, items = nil }
        local _weaponSkinResMergeCache = { key = nil, res = nil }
        local _convertCache = {}

        local function getConvertedAvatarCustom(resID)
            resID = tonumber(resID)
            if not resID then return nil end
            if _convertCache[resID] ~= nil then return _convertCache[resID] end
            local AvatarData = require("client.logic.data.AvatarData")
            local converted = AvatarData.ConvertToAvatarCustom({ resID, 0, 0 })
            _convertCache[resID] = converted
            return converted
        end

        local function invalidateSocialWearCache()
            local s = _G.AddOutfitSocialState
            if s then
                s.wearPatchKey, s.snapshotKey, s.fullSnapshot, s.lastHandSkin = nil, nil, nil, nil
            end
            _outfitMergeCache.key = nil
            _outfitMergeCache.items = nil
            _weaponSkinResMergeCache.key = nil
            _weaponSkinResMergeCache.res = nil
        end

        local EQUIP_LEVEL_SETS = {
            [1502000382] = { lv1 = 1502001382, lv2 = 1502002382, lv3 = 1502003382, slot = "helmet" },
        }
        local _equipLevelByRes = {}
        local function registerEquipLevelSet(catalog, lv1, lv2, lv3, slot)
            catalog = tonumber(catalog)
            if not catalog then return end
            local set = {
                catalog = catalog,
                lv1 = tonumber(lv1) or 0,
                lv2 = tonumber(lv2) or 0,
                lv3 = tonumber(lv3) or 0,
                slot = slot or "helmet",
            }
            EQUIP_LEVEL_SETS[catalog] = set
            for _, rid in ipairs({ catalog, set.lv1, set.lv2, set.lv3 }) do
                if rid and rid > 0 then _equipLevelByRes[rid] = set end
            end
        end
        for catalog, set in pairs(EQUIP_LEVEL_SETS) do
            registerEquipLevelSet(catalog, set.lv1, set.lv2, set.lv3, set.slot)
        end
        _G.AddOutfitRegisterEquipLevelSet = registerEquipLevelSet

        local EQUIP_LEVEL_RANGES = {
            { base = 1502000000, slot = "helmet" },
            { base = 1501000000, slot = "bag"    },
        }

        local function findEquipLevelRange(resID)
            resID = tonumber(resID)
            if not resID then return nil end
            for _, r in ipairs(EQUIP_LEVEL_RANGES) do
                if resID >= r.base and resID < r.base + 1000000 then return r end
            end
            return nil
        end

        local function detectLevelFromPattern(resID)
            resID = tonumber(resID)
            if not resID then return nil, nil end
            local r = findEquipLevelRange(resID)
            if not r then return nil, nil end
            if resID < r.base + 1000 or resID >= r.base + 4000 then return nil, nil end
            local tail = resID - r.base
            local levelDigit = math.floor(tail / 1000)
            if levelDigit >= 1 and levelDigit <= 3 then
                return levelDigit, r.base + (tail - levelDigit * 1000)
            end
            return nil, nil
        end

        local function buildPatternLevelSet(catalog)
            catalog = tonumber(catalog)
            if not catalog then return nil end
            local r = findEquipLevelRange(catalog)
            if not r then return nil end
            local tail = catalog - r.base
            if tail < 0 or tail >= 1000 then return nil end
            return {
                catalog = catalog,
                lv1 = catalog + 1000,
                lv2 = catalog + 2000,
                lv3 = catalog + 3000,
                slot = r.slot,
            }
        end

        local function getEquipLevelSet(resID)
            resID = tonumber(resID)
            if not resID then return nil end
            local set = _equipLevelByRes[resID]
            if set then return set end
            local level, catalog = detectLevelFromPattern(resID)
            if catalog then
                if EQUIP_LEVEL_SETS[catalog] then return EQUIP_LEVEL_SETS[catalog] end
                if level then return buildPatternLevelSet(catalog) end
            end
            local direct = buildPatternLevelSet(resID)
            if direct then
                _equipLevelByRes[resID] = direct
                if direct.lv1 > 0 then _equipLevelByRes[direct.lv1] = direct end
                if direct.lv2 > 0 then _equipLevelByRes[direct.lv2] = direct end
                if direct.lv3 > 0 then _equipLevelByRes[direct.lv3] = direct end
            end
            return direct
        end

        local function normalizeEquipCatalogRes(resID)
            resID = tonumber(resID)
            if not resID or resID <= 0 then return 0 end
            local set = getEquipLevelSet(resID)
            if set then return set.catalog end
            return resID
        end

        local function detectLevelFromEquipRes(resID)
            resID = tonumber(resID)
            if not resID then return nil end
            local set = getEquipLevelSet(resID)
            if set then
                if resID == set.lv1 then return 1
                elseif resID == set.lv2 then return 2
                elseif resID == set.lv3 then return 3 end
            end
            local level = detectLevelFromPattern(resID)
            return level
        end

        local function mapEquipLevelSet(set, level)
            if not set then return 0 end
            level = tonumber(level) or 3
            if level == 1 then return set.lv1 or 0
            elseif level == 2 then return set.lv2 or 0 end
            return set.lv3 or 0
        end

        local function mapEquipSkinRes(resID, level)
            resID, level = tonumber(resID), tonumber(level) or 3
            if not resID or resID <= 0 then return 0 end
            local catalogRes = normalizeEquipCatalogRes(resID)
            local set = getEquipLevelSet(catalogRes)
            if set then
                local mapped = mapEquipLevelSet(set, level)
                if mapped > 0 then return mapped end
            end
            local mapped = 0
            pcall(function()
                local itemMappingCfg = CDataTable.GetTableData("BackpackMapping", catalogRes)
                if itemMappingCfg then
                    if level == 1 then mapped = tonumber(itemMappingCfg.SkinItemIDLv1) or 0
                    elseif level == 2 then mapped = tonumber(itemMappingCfg.SkinItemIDLv2) or 0
                    else mapped = tonumber(itemMappingCfg.SkinItemIDLv3) or 0 end
                end
                if mapped <= 0 and DataMgr and DataMgr.GetEquipmentItemIDByResID then
                    mapped = tonumber(DataMgr.GetEquipmentItemIDByResID(level, catalogRes)) or 0
                end
            end)
            if mapped > 0 then return mapped end
            if isInjectedRes(catalogRes) then return catalogRes end
            return 0
        end

        local function ensureMatchEquipCache()
            local cch = cache()
            local eq = MATCH_CONFIG.equip or {}
            if (not cch.equip.bag or cch.equip.bag <= 0) and eq.bag and eq.bag > 0 then
                cch.equip.bag = eq.bag
            end
            if (not cch.equip.helmet or cch.equip.helmet <= 0) and eq.helmet and eq.helmet > 0 then
                cch.equip.helmet = eq.helmet
            end
            if (not cch.equip.armor or cch.equip.armor <= 0) and eq.armor and eq.armor > 0 then
                cch.equip.armor = eq.armor
            end
            if (not cch.equip.parachute or cch.equip.parachute <= 0) and eq.parachute and eq.parachute > 0 then
                cch.equip.parachute = eq.parachute
            end
            if (not cch.equip.glider or cch.equip.glider <= 0) and eq.glider and eq.glider > 0 then
                cch.equip.glider = eq.glider
            end
        end

        local function syncMatchConfigFromCache()
            local cch = cache()
            if cch.outfitRes and cch.outfitRes > 0 then
                MATCH_CONFIG.outfitRes = cch.outfitRes
            else
                MATCH_CONFIG.outfitRes = 0
            end
            MATCH_CONFIG.weaponSkins = MATCH_CONFIG.weaponSkins or {}
            for wid, w in pairs(cch.weapons or {}) do
                if w.resID and w.resID > 0 then
                    MATCH_CONFIG.weaponSkins[wid] = w.resID
                end
            end
            MATCH_CONFIG.equip = MATCH_CONFIG.equip or {}
            for _, slot in ipairs({ "bag", "helmet", "armor", "parachute", "glider" }) do
                if cch.equip[slot] and cch.equip[slot] > 0 then
                    MATCH_CONFIG.equip[slot] = cch.equip[slot]
                end
            end
        end

        local function restorePersistedVehicles()
            if not _G._addOutfitPersistLoaded then return end
            pcall(function()
                if _G._savedVehicleSlotList and DataMgr then
                    DataMgr.VehicleSlotList = DataMgr.VehicleSlotList or {}
                    for subType, insList in pairs(_G._savedVehicleSlotList) do
                        if insList and #insList > 0 then
                            DataMgr.VehicleSlotList[subType] = insList
                        end
                    end
                end
            end)
            pcall(function()
                if _G._savedGarageVehicles then
                    local GTS = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.GarageThemeSystem)
                    if GTS then
                        GTS.GarageVehicleInfo = GTS.GarageVehicleInfo or {}
                        for slot, info in pairs(_G._savedGarageVehicles) do
                            if info and info.inst_id then
                                GTS.GarageVehicleInfo[slot] = info
                            end
                        end
                    end
                end
            end)
        end

        local function restorePersistedMotions()
            if not _G._addOutfitPersistLoaded then return end
            pcall(function()
                if not _G._savedMotionList or #_G._savedMotionList == 0 then return end
                if not DataMgr then return end
                DataMgr.MotionSlotList = {}
                for i, ins in ipairs(_G._savedMotionList) do
                    DataMgr.MotionSlotList[i] = ins
                end
                if EventSystem and EVENTTYPE_MOTION and EVENTID_MOTION_UPDATE_SLOT_LIST then
                    EventSystem:postEvent(EVENTTYPE_MOTION, EVENTID_MOTION_UPDATE_SLOT_LIST)
                end
            end)
        end

        local function restorePersistedEquipIns()
            if not _G._addOutfitPersistLoaded then return end
            pcall(function()
                if not DataMgr then return end
                if _G._savedEquipIns then
                    DataMgr.equipmentSkinInsIDTable = DataMgr.equipmentSkinInsIDTable or {}
                    for subType, ins in pairs(_G._savedEquipIns) do
                        if ins and ins > 0 then
                            DataMgr.equipmentSkinInsIDTable[subType] = ins
                        end
                    end
                end
                if _G._savedVstSkin and _G._savedVstSkin > 0 then
                    DataMgr.vst_skin = _G._savedVstSkin
                end
            end)
        end

        local function restorePersistedThrowObjects()
            if not _G._addOutfitPersistLoaded then return end
            pcall(function()
                if not _G._savedThrowObjects then return end
                local cch = cache()
                cch.throwObjects = cch.throwObjects or {}
                for st, info in pairs(_G._savedThrowObjects) do
                    if info.resID and info.resID > 0 then
                        cch.throwObjects[st] = info
                    end
                end
            end)
        end

        local GAME_HELMET_LEVEL = {
            [502001] = 1, [502004] = 1,
            [502002] = 2, [502005] = 2,
            [502003] = 3,
        }
        local GAME_BAG_LEVEL = {
            [501001] = 1, [501004] = 1,
            [501002] = 2, [501005] = 2,
            [501003] = 3,
        }

        local function detectEquipLevelFromBaseId(baseId, catalogResID)
            baseId, catalogResID = tonumber(baseId), tonumber(catalogResID)
            if not baseId or baseId <= 0 then return nil end
            local level
            pcall(function()
                catalogResID = catalogResID and normalizeEquipCatalogRes(catalogResID) or catalogResID
                if catalogResID then
                    local set = getEquipLevelSet(catalogResID)
                    if set then
                        if baseId == set.lv1 then level = 1
                        elseif baseId == set.lv2 then level = 2
                        elseif baseId == set.lv3 then level = 3 end
                    end
                    if not level then
                        local m = CDataTable.GetTableData("BackpackMapping", catalogResID)
                        if m then
                            if tonumber(m.SkinItemIDLv1) == baseId then level = 1
                            elseif tonumber(m.SkinItemIDLv2) == baseId then level = 2
                            elseif tonumber(m.SkinItemIDLv3) == baseId then level = 3 end
                        end
                    end
                end
                if not level then
                    local patLevel, patCatalog = detectLevelFromPattern(baseId)
                    if patLevel and (not catalogResID or patCatalog == catalogResID) then
                        level = patLevel
                    end
                end
                if not level then level = GAME_HELMET_LEVEL[baseId] or GAME_BAG_LEVEL[baseId] end
                if not level and baseId >= 1505000001 and baseId <= 1505000003 then
                    level = baseId - 1505000000
                end
                if not level then
                    pcall(function()
                        local BU = require("GameLua.Mod.BaseMod.GamePlay.Backpack.BackpackUtils")
                        if BU.GetEquipmentHelmetLevel then
                            local hl = BU.GetEquipmentHelmetLevel(baseId)
                            if hl and hl >= 1 and hl <= 3 then level = hl end
                        end
                        if not level and BU.GetEquipmentBagLevel then
                            local bl = BU.GetEquipmentBagLevel(baseId)
                            if bl and bl >= 1 and bl <= 3 then level = bl end
                        end
                    end)
                end
            end)
            return level
        end

        local function isBaseEquipItemId(itemId)
            itemId = tonumber(itemId)
            if not itemId or itemId <= 0 then return false end
            if GAME_HELMET_LEVEL[itemId] or GAME_BAG_LEVEL[itemId] then return true end
            if itemId >= 1505000001 and itemId <= 1505000100 then return true end
            if itemId >= 1501000000 and itemId < 1502000000 then return true end
            if itemId >= 502001 and itemId <= 502999 then return true end
            if itemId >= 501001 and itemId <= 501999 then return true end
            return false
        end

        local function resolveMatchEquipSkin(catalogResID, baseItemID)
            catalogResID = normalizeEquipCatalogRes(catalogResID)
            if not catalogResID or catalogResID <= 0 then return 0 end
            local level = detectEquipLevelFromBaseId(baseItemID, catalogResID) or 3
            return mapEquipSkinRes(catalogResID, level)
        end

        local function getEquipDisplayLevel(resID, slot)
            local wornLevel = detectLevelFromEquipRes(resID)
            if wornLevel then return wornLevel end
            pcall(function()
                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                if slot == "bag" then wornLevel = fbd:GetBagLevel() or 3
                elseif slot == "helmet" then wornLevel = fbd:GetHelmetLevel() or 3 end
            end)
            return wornLevel or 3
        end

        local function syncEquipLevelFromRes(resID, slot)
            local level = detectLevelFromEquipRes(resID)
            if not level then return end
            pcall(function()
                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                if slot == "helmet" then
                    fbd:SetHelmetLevel(level)
                elseif slot == "bag" then
                    fbd:SetBagLevel(level)
                end
            end)
        end

        local function saveEquipSkin(resID, insID)
            resID, insID = tonumber(resID), tonumber(insID)
            if not resID then return end
            local slot = getEquipSkinSlot(resID)
            if not slot then return end
            local cch = cache()
            cch.equip[slot] = resID
            if insID then cch.equip[slot .. "Ins"] = insID end
            MATCH_CONFIG.equip = MATCH_CONFIG.equip or {}
            MATCH_CONFIG.equip[slot] = resID
            _S.matchApplied = false
            invalidateSocialWearCache()
            log("Equipment saved", slot, resID)
            pcall(_AutoSaveOutfit)
        end

        local function saveClothPiece(resID)
            resID = tonumber(resID)
            if not resID then return end
            local cch = cache()
            cch.clothes[resID] = true
            _S.matchApplied = false
            invalidateSocialWearCache()
            pcall(_AutoSaveOutfit)
        end

        local function clearClothesForKind(kind)
            local clearMap = subTypesToClearForKind(kind)
            if not clearMap then return end
            local cch = cache()
            for resID in pairs(cch.clothes) do
                local st = subType(cfg(resID))
                if st and clearMap[st] then cch.clothes[resID] = nil end
            end
            if kind == "full_suit" then
                cch.outfitRes, cch.outfitIns = nil, nil
            end
        end

        local function saveWeaponToCache(weaponID, resID, insID)
            weaponID, resID, insID = tonumber(weaponID), tonumber(resID), tonumber(insID)
            if not weaponID or not resID or resID <= 0 then return end
            local cch = cache()
            cch.weapons[weaponID] = { resID = resID, insID = insID or 0 }
            _G.AddOutfitLastAppliedSkin = {}
            _S.matchApplied = false
            invalidateSocialWearCache()
            log("Weapon skin saved", weaponID, "→", resID)
            pcall(_AutoSaveOutfit)
        end

        local function cacheWeaponSkinFromIns(weaponID, insID)
            weaponID, insID = tonumber(weaponID), tonumber(insID)
            if not weaponID or not insID or insID <= 0 then return end
            if isInjectedIns(insID) then
                saveWeaponToCache(weaponID, R.insToRes[insID], insID)
                return
            end
            pcall(function()
                local wd = require("client.slua.logic.wardrobe.wardrobe_data")
                local d = wd:GetValidHallDepotItemDataByInsID(insID) or wd:GetHallDepotItemDataByInsID(insID)
                if d and d.resID and tonumber(d.resID) > 0 then
                    saveWeaponToCache(weaponID, tonumber(d.resID), insID)
                end
            end)
        end

        local function saveEquip(resID, insID)
            resID, insID = tonumber(resID), tonumber(insID)
            if not resID or not insID then return end
            local c = cfg(resID)
            local st = subType(c)
            local kind = getClothKind(resID)
            local cch = cache()
            if kind == "full_suit" then
                clearClothesForKind("full_suit")
                cch.outfitRes, cch.outfitIns = resID, insID
                _G.AddOutfitLastLobbyOutfitRes = resID
                invalidateSocialWearCache()
            elseif kind then
                if cch.outfitRes and isFullSuitRes(cch.outfitRes) then
                    cch.outfitRes, cch.outfitIns = nil, nil
                    _G.AddOutfitLastLobbyOutfitRes = nil
                end
                clearClothesForKind(kind)
                saveClothPiece(resID)
            elseif getEquipSkinSlot(resID) then
                saveEquipSkin(resID, insID)
            elseif _K.GUN_SUB[st] then
                local wid = weaponIdFromSkin(resID)
                if not wid then
                    pcall(function()
                        local wgl = require("client.slua.logic.wardrobe.logic_wardrobe_gun")
                        wid = wgl.GetCurGunID and wgl:GetCurGunID() or nil
                        if not wid and wgl.GetCurrentGunID then
                            wid = wgl:GetCurrentGunID()
                        end
                    end)
                end
                if wid then saveWeaponToCache(wid, resID, insID) end
            elseif st == _K.MELEE_ID then
                saveWeaponToCache(_K.MELEE_ID, resID, insID)
            elseif isThrowObjectRes(resID) then
                saveThrowObject(resID, insID)
            elseif isInjectedRes(resID) then
                local mt = wardrobeMainTab(resID)
                if mt ~= _K.WARDROBE_PAGE_VEHICLE then
                    saveClothPiece(resID)
                end
            end
            _S.matchApplied = false
            pcall(_AutoSaveOutfit)
        end

        local _lastSyncWeaponCache = 0
        local function syncWeaponCacheFromLobby()
            local now = 0
            pcall(function() now = os.clock() end)
            if (now - _lastSyncWeaponCache) < 0.3 then return end
            _lastSyncWeaponCache = now
            local cch = cache()
            pcall(function()
                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                local bag = fbd.GetCurrentFashionBag and fbd:GetCurrentFashionBag()
                if bag then
                    if bag.bag_skin and tonumber(bag.bag_skin) > 0 then
                        local rid = isInjectedIns(bag.bag_skin) and R.insToRes[bag.bag_skin]
                            or (function()
                                local wd = require("client.slua.logic.wardrobe.wardrobe_data")
                                local d = wd:GetHallDepotItemDataByInsID(bag.bag_skin)
                                return d and tonumber(d.resID)
                            end)()
                        if rid and isInjectedRes(rid) then cch.equip.bag = rid end
                    end
                    if bag.helmet_skin and tonumber(bag.helmet_skin) > 0 then
                        local rid = isInjectedIns(bag.helmet_skin) and R.insToRes[bag.helmet_skin]
                            or (function()
                                local wd = require("client.slua.logic.wardrobe.wardrobe_data")
                                local d = wd:GetHallDepotItemDataByInsID(bag.helmet_skin)
                                return d and tonumber(d.resID)
                            end)()
                        if rid and isInjectedRes(rid) then cch.equip.helmet = rid end
                    end
                    if bag.weapon_skin_list then
                        for weaponID, entry in pairs(bag.weapon_skin_list) do
                            cacheWeaponSkinFromIns(weaponID, entry and (entry.skin_id or entry.skinId))
                        end
                    end
                end
            end)
            pcall(function()
                local Arm = require("client.logic.armory.logic_armory")
                if Arm.rsp_list and Arm.rsp_list.install_list then
                    for weaponID, entry in pairs(Arm.rsp_list.install_list) do
                        cacheWeaponSkinFromIns(weaponID, entry and entry.skin_id)
                    end
                end
            end)
            pcall(function()
                if DataMgr and DataMgr.equipmentSkinInsIDTable then
                    local function ridFromIns(ins)
                        ins = tonumber(ins)
                        if not ins or ins <= 0 then return nil end
                        if isInjectedIns(ins) then return R.insToRes[ins] end
                        local wd = require("client.slua.logic.wardrobe.wardrobe_data")
                        local d = wd:GetHallDepotItemDataByInsID(ins)
                        return d and tonumber(d.resID)
                    end
                    local bagRid = ridFromIns(DataMgr.equipmentSkinInsIDTable[504])
                    if bagRid and isInjectedRes(bagRid) then cch.equip.bag = bagRid end
                    local helmRid = ridFromIns(DataMgr.equipmentSkinInsIDTable[505])
                    if helmRid and isInjectedRes(helmRid) then cch.equip.helmet = helmRid end
                    local armorRid = ridFromIns(DataMgr.equipmentSkinInsIDTable[506])
                    if armorRid and isInjectedRes(armorRid) then cch.equip.armor = armorRid end
                end
            end)
        end

        local _lastSyncClothesCache = 0
        local function syncClothesCacheFromLobby()
            local now = 0
            pcall(function() now = os.clock() end)
            if (now - _lastSyncClothesCache) < 0.3 then return end
            _lastSyncClothesCache = now
            local cch = cache()
            pcall(function()
                local inLobby = false
                if GameStatus and GameStatus.IsInLobbyOrMainCity and GameStatus.IsInLobbyOrMainCity() then
                    inLobby = true
                end
                
                if inLobby and not _G._addOutfitPersistLoaded then
                    cch.outfitRes = nil
                    cch.outfitIns = nil
                    _G.AddOutfitLastLobbyOutfitRes = nil
                    cch.clothes = {}
                end

                local AvatarData = require("client.logic.data.AvatarData")
                local wd = require("client.slua.logic.wardrobe.wardrobe_data")
                for _, ins in pairs(AvatarData.GetRoleWear()) do
                    ins = tonumber(ins)
                    if ins and ins > 0 then
                        local resID = isInjectedIns(ins) and R.insToRes[ins]
                            or (function()
                                local d = wd:GetHallDepotItemDataByInsID(ins)
                                return d and tonumber(d.resID)
                            end)()
                        if resID and isInjectedRes(resID) then
                            if isFullSuitRes(resID) then
                                cch.outfitRes, cch.outfitIns = resID, ins
                                _G.AddOutfitLastLobbyOutfitRes = resID
                            elseif not getEquipSkinSlot(resID) and not weaponIdFromSkin(resID) then
                                cch.clothes[resID] = true
                            elseif getEquipSkinSlot(resID) then
                                local slot = getEquipSkinSlot(resID)
                                cch.equip[slot] = resID
                                cch.equip[slot .. "Ins"] = ins
                            end
                        end
                    end
                end

                pcall(function()
                    local fashionbag_data = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                    local paraInsID = tonumber(fashionbag_data:GetParachute())
                    if paraInsID and paraInsID > 0 then
                        local paraResID
                        if isInjectedIns(paraInsID) then
                            paraResID = R.insToRes[paraInsID]
                        else
                            local d = wd:GetHallDepotItemDataByInsID(paraInsID)
                            paraResID = d and tonumber(d.resID)
                        end
                        if paraResID and paraResID > 0 then
                            cch.equip.parachute = paraResID
                            cch.equip.parachuteIns = paraInsID
                            MATCH_CONFIG.equip = MATCH_CONFIG.equip or {}
                            MATCH_CONFIG.equip.parachute = paraResID
                        end
                    end
                end)

                pcall(function()
                    local fashionbag_data = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                    local gliderInsID = tonumber(fashionbag_data:GetAircraftOrGliding())
                    if gliderInsID and gliderInsID > 0 then
                        local gliderResID
                        if isInjectedIns(gliderInsID) then
                            gliderResID = R.insToRes[gliderInsID]
                        else
                            local d = wd:GetHallDepotItemDataByInsID(gliderInsID)
                            gliderResID = d and tonumber(d.resID)
                        end
                        if gliderResID and gliderResID > 0 then
                            cch.equip.glider = gliderResID
                            cch.equip.gliderIns = gliderInsID
                            MATCH_CONFIG.equip = MATCH_CONFIG.equip or {}
                            MATCH_CONFIG.equip.glider = gliderResID
                        end
                    end
                end)
            end)
        end

        local function syncClothesCacheFromLive()
            local cch = cache()
            pcall(function()
                local AvatarData = require("client.logic.data.AvatarData")
                local wd = require("client.slua.logic.wardrobe.wardrobe_data")
                for _, ins in pairs(AvatarData.GetRoleWear()) do
                    ins = tonumber(ins)
                    if ins and ins > 0 then
                        local resID = isInjectedIns(ins) and R.insToRes[ins]
                            or (function()
                                local d = wd:GetHallDepotItemDataByInsID(ins)
                                return d and tonumber(d.resID)
                            end)()
                        if resID and isInjectedRes(resID) then
                            if isFullSuitRes(resID) then
                                cch.outfitRes, cch.outfitIns = resID, ins
                                _G.AddOutfitLastLobbyOutfitRes = resID
                            elseif not getEquipSkinSlot(resID) and not weaponIdFromSkin(resID) then
                                cch.clothes[resID] = true
                            else
                                local slot = getEquipSkinSlot(resID)
                                if slot then
                                    cch.equip[slot] = resID
                                    cch.equip[slot .. "Ins"] = ins
                                end
                            end
                        end
                    end
                end
                pcall(function()
                    local fashionbag_data = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                    local paraInsID = tonumber(fashionbag_data:GetParachute())
                    if paraInsID and paraInsID > 0 then
                        local paraResID = isInjectedIns(paraInsID) and R.insToRes[paraInsID]
                            or (function()
                                local d = wd:GetHallDepotItemDataByInsID(paraInsID)
                                return d and tonumber(d.resID)
                            end)()
                        if paraResID and paraResID > 0 then
                            cch.equip.parachute = paraResID
                            cch.equip.parachuteIns = paraInsID
                        end
                    end
                    local gliderInsID = tonumber(fashionbag_data:GetAircraftOrGliding())
                    if gliderInsID and gliderInsID > 0 then
                        local gliderResID = isInjectedIns(gliderInsID) and R.insToRes[gliderInsID]
                            or (function()
                                local d = wd:GetHallDepotItemDataByInsID(gliderInsID)
                                return d and tonumber(d.resID)
                            end)()
                        if gliderResID and gliderResID > 0 then
                            cch.equip.glider = gliderResID
                            cch.equip.gliderIns = gliderInsID
                        end
                    end
                end)
            end)
        end

        local function syncThrowObjectCacheFromLobby()
            local cch = cache()
            pcall(function()
                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                local bag = fbd.GetCurrentFashionBag and fbd:GetCurrentFashionBag()
                if not bag or not bag.throw_object_list then return end
                cch.throwObjects = cch.throwObjects or {}
                for subType, insID in pairs(bag.throw_object_list) do
                    insID = tonumber(insID)
                    subType = tonumber(subType)
                    if insID and insID > 0 and subType and _K.THROW_SUB[subType] then
                        local resID
                        if isInjectedIns(insID) then
                            resID = R.insToRes[insID]
                        else
                            local wd = require("client.slua.logic.wardrobe.wardrobe_data")
                            local d = wd:GetHallDepotItemDataByInsID(insID)
                            resID = d and tonumber(d.resID)
                        end
                        if resID and isInjectedRes(resID) then
                            cch.throwObjects[subType] = { resID = resID, insID = insID }
                        end
                    end
                end
            end)
        end

        local function syncAllCacheFromLive()
            syncWeaponCacheFromLobby()
            syncClothesCacheFromLive()
            syncThrowObjectCacheFromLobby()
            ensureMatchEquipCache()
            syncMatchConfigFromCache()
        end
        _G.AddOutfitSyncCacheBeforeSave = syncAllCacheFromLive

        local function snapshotLobbyWear()
            syncWeaponCacheFromLobby()
            syncClothesCacheFromLobby()
            syncThrowObjectCacheFromLobby()
            ensureMatchEquipCache()
        end

        local function getCachedWeaponSkin(weaponID)
            weaponID = tonumber(weaponID) or 0
            if weaponID <= 0 then return nil end
            syncWeaponCacheFromLobby()
            local w = cache().weapons[weaponID]
            if w and w.resID and w.resID > 0 then return w.resID end
            return nil
        end

        local function getMatchWeaponSkin(weaponID)
            weaponID = tonumber(weaponID) or 0
            local fromCache = getCachedWeaponSkin(weaponID)
            if fromCache then return fromCache end
            if MATCH_CONFIG.weaponSkins then
                local fixed = tonumber(MATCH_CONFIG.weaponSkins[weaponID])
                if fixed and fixed > 0 then return fixed end
            end
            return nil
        end

        local _ticker
        pcall(function() _ticker = require("common.time_ticker") end)
        local function later(sec, fn)
            local guarded = function(...)
                if _G.__DuneSkinCtl and not _G.__DuneSkinCtl.enabled then return end
                return fn(...)
            end
            if _G.SetTimer then pcall(_G.SetTimer, sec, guarded) return end
            if _ticker and _ticker.AddTimer then pcall(_ticker.AddTimer, sec, guarded) end
        end

        local function getEntity()
            local ok, dc = pcall(require, "client.slua.logic.wardrobe.logic_wardrobe_data_center")
            if not ok or not dc then return nil end
            local ok2, e = pcall(dc.GetWardrobeData, EWardrobeDataSource and EWardrobeDataSource.Wardrobe or nil)
            if ok2 and e then return e end
            ok2, e = pcall(dc.GetWardrobeData)
            return ok2 and e or nil
        end

        local function alreadyHave(entity, resID)
            local arr = entity.ResIDToIndexArrayMap and entity.ResIDToIndexArrayMap[resID]
            if not arr then return false end
            for _, idx in pairs(arr) do
                local d = entity._data[idx]
                if d and d.count and d.count > 0 then return true end
            end
            return false
        end

        local function ensureDepotTabFields(entity, data, resID)
            if not data then return end
            pcall(function()
                if entity and entity.LoadConfigForData and CDataTable.GetTableData then
                    entity:LoadConfigForData(data, CDataTable.GetTableData)
                end
            end)
            local equipSlot = getEquipSkinSlot(resID)
            if equipSlot == "bag" then
                data.mainTabType = _K.WARDROBE_PAGE_AVATAR
                data.subTabType = _K.WARDROBE_TAB_BAG
            elseif equipSlot == "helmet" then
                data.mainTabType = _K.WARDROBE_PAGE_AVATAR
                data.subTabType = _K.WARDROBE_TAB_HELMET
            elseif equipSlot == "armor" then
                data.mainTabType = _K.WARDROBE_PAGE_AVATAR
                data.subTabType = _K.WARDROBE_TAB_ARMOR
            end
            local c = cfg(resID)
            if c then data.itemSubType = tonumber(c.ItemSubType or c.itemSubType) or data.itemSubType end
            if c then
                local wmTab = tonumber(c.WardrobeMainTab or c.wardrobeMainTab) or 0
                if wmTab == _K.WARDROBE_PAGE_VEHICLE then
                    data.mainTabType = _K.WARDROBE_PAGE_VEHICLE
                    data.subTabType = tonumber(c.WardrobeTab or c.wardrobeTab) or data.subTabType
                end
            end
        end

        local function depotResID(v)
            return v and tonumber(v.resID or v.res_id) or nil
        end

        local function injectedEquipAllowed(resID, mainTab, subTab)
            local slot = getEquipSkinSlot(resID)
            if slot == "bag" then
                return mainTab == _K.WARDROBE_PAGE_AVATAR and subTab == _K.WARDROBE_TAB_BAG
            end
            if slot == "helmet" then
                return mainTab == _K.WARDROBE_PAGE_AVATAR and subTab == _K.WARDROBE_TAB_HELMET
            end
            if slot == "armor" then
                return mainTab == _K.WARDROBE_PAGE_AVATAR and subTab == _K.WARDROBE_TAB_ARMOR
            end
            if slot == "parachute" then
                return mainTab == _K.WARDROBE_PAGE_PARACHUTE and subTab == _K.WARDROBE_TAB_PARACHUTE
            end
            if slot == "glider" then
                return mainTab == _K.WARDROBE_PAGE_PARACHUTE and subTab == _K.WARDROBE_TAB_GLIDER
            end
            return nil
        end

        local function injectOne(entity, resID, insID)
            if alreadyHave(entity, resID) then
                R.resToIns[resID] = R.resToIns[resID] or insID
                R.insToRes[insID] = resID
                pcall(function()
                    local data = entity.GetDataByInsID and entity:GetDataByInsID(R.resToIns[resID])
                    if data then ensureDepotTabFields(entity, data, resID) end
                end)
                return true
            end
            entity:AddData({
                instid = insID, res_id = resID, count = 1,
                lock_cnt = 0, isnew = 0, valid_hours = 0, expire_ts = 0,
            })
            pcall(function()
                local data = entity.GetDataByInsID and entity:GetDataByInsID(insID)
                if data then
                    ensureDepotTabFields(entity, data, resID)
                end
            end)
            R.insToRes[insID] = resID
            R.resToIns[resID] = insID
            return true
        end

        local function injectArmory(resID, insID)
            local wid = weaponIdFromSkin(resID)
            if not wid then return end
            local Arm = require("client.logic.armory.logic_armory")
            Arm.rsp_list = Arm.rsp_list or { skin_list = {}, install_list = {} }
            Arm.rsp_list.skin_list = Arm.rsp_list.skin_list or {}
            if not Arm.rsp_list.skin_list[wid] then Arm.rsp_list.skin_list[wid] = {} end
            Arm.rsp_list.skin_list[wid][resID] = { is_open = 1 }
            Arm.WardrobeInsList = Arm.WardrobeInsList or {}
            Arm.WardrobeInsList[resID] = insID
        end

        local function injectAll(entity)
            if _S.injectedDone then return true end
            refreshItems()
            entity = entity or getEntity()
            if not entity or not entity.bInit then return false end

            if next(_C.fullSuit) == nil then
                pcall(function()
                    for _, rid in ipairs(ITEMS) do
                        local c = cfg(rid)
                        if c then
                            local st = tonumber(c.ItemSubType or c.itemSubType) or 0
                            if st == _K.ST_TOP then
                                local tab = tonumber(c.WardrobeTab or c.wardrobeTab) or 0
                                if tab == _K.WARDROBE_TAB_SUIT then
                                    _C.fullSuit[rid] = true
                                else
                                    pcall(function()
                                        local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
                                        if LogicXSuit.IsXSuit(rid) then _C.fullSuit[rid] = true end
                                    end)
                                end
                            end
                            local wmTab = tonumber(c.WardrobeMainTab or c.wardrobeMainTab) or 0
                            if wmTab == _K.WARDROBE_PAGE_VEHICLE then
                                _C.vehicleItems[#_C.vehicleItems + 1] = rid
                            end
                        end
                        getEquipSkinSlot(rid)
                        weaponIdFromSkin(rid)
                    end
                    for _, rid in ipairs(ITEMS) do
                        getInjectedItemTab(rid)
                    end
                    local allTabs = {
                        {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_SUIT},
                        {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_CLOTHES},
                        {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_TROUSERS},
                        {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_SHOES},
                        {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_BAG},
                        {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_HELMET},
                        {_K.WARDROBE_PAGE_AVATAR, _K.WARDROBE_TAB_ARMOR},
                        {_K.WARDROBE_PAGE_WEAPON, _K.WARDROBE_TAB_GUN},
                        {_K.WARDROBE_PAGE_PARACHUTE, _K.WARDROBE_TAB_PARACHUTE},
                        {_K.WARDROBE_PAGE_PARACHUTE, _K.WARDROBE_TAB_GLIDER},
                        {_K.WARDROBE_PAGE_VEHICLE, 0},
                    }
                    for k in pairs(_C.pageMatch) do _C.pageMatch[k] = nil end
                end)
            end

            local n = 0
            for i, resID in ipairs(ITEMS) do
                local insID = _K.INS_BASE + i
                if injectOne(entity, resID, insID) then
                    n = n + 1
                    local c = cfg(resID)
                    if _K.GUN_SUB[subType(c)] or subType(c) == _K.MELEE_ID then
                        injectArmory(resID, insID)
                    end
                end
            end
            if n > 0 then
                _S.injectedDone = true
                _G.AddOutfit_R = R
                log("Injected", n, "items")
            end
            return n > 0
        end

        local function injectAllSources()
            return injectAll(getEntity())
        end

        local function refreshWardrobe()
            pcall(function()
                if EventSystem and EVENTTYPE_WARDROBE then
                    if EVENTID_WARDROBE_UPDATE_ITEM_LIST then
                        EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_ITEM_LIST)
                    end
                    if EVENTID_WARDROBE_UPDATE_AVATAR_LIST then
                        EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_AVATAR_LIST)
                    end
                    if EVENTID_WARDROBE_UPDATE_GUN_LIST then
                        EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_GUN_LIST, -1)
                    end
                end
            end)
        end

        local function findWornInsBySubType(st)
            st = tonumber(st)
            if not st then return nil end
            local wd = require("client.slua.logic.wardrobe.wardrobe_data")
            local AvatarData = require("client.logic.data.AvatarData")
            for _, ins in pairs(AvatarData.GetRoleWear()) do
                ins = tonumber(ins)
                if ins and ins > 0 then
                    local d = wd:GetHallDepotItemDataByInsID(ins)
                    if d and tonumber(d.itemSubType) == st then
                        return ins, d.resID
                    end
                end
            end
            return nil
        end

        local function removeRoleWearBySubTypes(stMap)
            if not stMap then return end
            local wd = require("client.slua.logic.wardrobe.wardrobe_data")
            local AvatarData = require("client.logic.data.AvatarData")
            for _, ins in pairs(AvatarData.GetRoleWear()) do
                ins = tonumber(ins)
                if ins and ins > 0 then
                    local d = wd:GetHallDepotItemDataByInsID(ins)
                    if d and stMap[tonumber(d.itemSubType)] then
                        AvatarData.RemoveRoleWearDataByValue(ins)
                    end
                end
            end
        end

        local function clearFashionBagSlots(stMap)
            if not stMap then return end
            pcall(function()
                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                local wfu = require("client.slua.logic.wardrobe.fashionbag.wardrobe_fashion_utils")
                local bag = fbd.GetCurrentFashionBag and fbd:GetCurrentFashionBag()
                if not bag or not bag.rolewear_list then return end
                for st, _ in pairs(stMap) do
                    local idx = wfu.GetRoleWearIndexBySubType and wfu:GetRoleWearIndexBySubType(st)
                    if idx then bag.rolewear_list[idx] = 0 end
                end
            end)
        end

        local function syncFashionBagRolewear()
            pcall(function()
                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                fbd:SaveRolewearToFashionBag(fbd:GetFashionBagUseIndex())
            end)
        end

        local function ensureKnapsackExtInfo()
            pcall(function()
                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                local idx = fbd:GetFashionBagUseIndex()
                if not fbd:GetKnapsackExtInfoByIndex(idx) then
                    fbd:SetKnapsackExtInfoByIndex(idx, {})
                end
            end)
        end

        local function getEquipSubType(resID, slot)
            local c = cfg(resID)
            if c then
                local st = tonumber(c.ItemSubType or c.itemSubType)
                if st then return st end
            end
            if slot == "bag" then return ENUM_ITEM_SUBTYPE.Backpack end
            if slot == "helmet" then return ENUM_ITEM_SUBTYPE.Helmet_NoLevel end
            return nil
        end

        local function softRemoveEquipVisual(oldResID, slot)
            oldResID = normalizeEquipCatalogRes(oldResID)
            if not oldResID or oldResID <= 0 or not slot then return end
            pcall(function()
                local TAM = require("client.logic.avatar.logic_team_avatar_manager")
                local AvatarData = require("client.logic.data.AvatarData")
                for lvl = 1, 3 do
                    local displayRes = mapEquipSkinRes(oldResID, lvl)
                    if displayRes > 0 then
                        TAM.ChangeAvatarEquipment(tostring(DataMgr.roleData.uid),
                            AvatarData.CreateAvatarCustom(displayRes), false)
                    end
                end
            end)
        end

        local function applyEquipVisual(resID, insID, slot)
            pcall(function()
                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                local HT = require("client.logic.lobby.hall_theme_utils")
                local TAM = require("client.logic.avatar.logic_team_avatar_manager")
                local AvatarData = require("client.logic.data.AvatarData")
                local lds = require("client.slua.logic.wardrobe.logic_display_setting")
                local lav = require("client.slua.logic.wardrobe.logic_wardrobe_avatar")
                syncEquipLevelFromRes(resID, slot)
                local level = getEquipDisplayLevel(resID, slot)
                local catalogRes = normalizeEquipCatalogRes(resID)
                local itemSt = getEquipSubType(catalogRes, slot)
                if itemSt then lav:AddToWearInfo(itemSt, insID, catalogRes, 0, 0) end
                lav:AvatarChange(catalogRes, true)
                local displayRes = mapEquipSkinRes(catalogRes, level)
                if displayRes > 0 then
                    TAM.ChangeAvatarEquipment(tostring(DataMgr.roleData.uid),
                        AvatarData.CreateAvatarCustom(displayRes), true)
                end
                if lds.data then
                    if slot == "bag" then lds.data.OpenBag = true end
                    if slot == "helmet" then lds.data.OpenHelmet = true end
                end
                if slot == "helmet" then
                    fbd:SetHeadShow(insID)
                    local WRH = require("client.network.Protocol.WardRobeHandler")
                    WRH.send_depot_set_head_show_req(insID)
                end
                if slot == "bag" then HT.PutOnBag(fbd:GetFashionBagUseIndex()) end
            end)
        end

        local takeOffEquipSkinVisual, takeOffClothVisual, takeOffWeaponSkinVisual

        local function takeOffItem(insID)
            insID = tonumber(insID)
            if not insID or insID <= 0 then return false end
            local resID = R.insToRes[insID]
            if not resID then return false end

            local cch = cache()
            local kind = getClothKind(resID)
            local slot = getEquipSkinSlot(resID)
            local wid  = weaponIdFromSkin(resID)
            local handled = false

            if slot then
                local oldRes = cch.equip[slot] or resID
                takeOffEquipSkinVisual(slot, oldRes, insID)
                cch.equip[slot]          = nil
                cch.equip[slot .. "Ins"] = nil
                if MATCH_CONFIG.equip then MATCH_CONFIG.equip[slot] = 0 end
                handled = true
            elseif kind then
                takeOffClothVisual(resID, insID, kind)
                if kind == "full_suit" then
                    cch.outfitRes, cch.outfitIns = nil, nil
                    _G.AddOutfitLastLobbyOutfitRes = nil
                else
                    cch.clothes[resID] = nil
                end
                handled = true
            elseif wid then
                takeOffWeaponSkinVisual(wid, resID, insID)
                cch.weapons[wid] = nil
                _G.AddOutfitLastAppliedSkin = {}
                _S.weaponApplied = false
                _S.weaponDiagDone = false
                _S.lastAppliedWeaponID = 0
                _S.lastAppliedSkinID = 0
                handled = true
            elseif isHallThemeRes(resID) then
                pcall(function()
                    local HT = require("client.logic.lobby.hall_theme_utils")
                    HT.homeThemeItemId = 0
                    HT.SetThemeInstId(0)
                    local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                    local idx = fbd:GetFashionBagUseIndex()
                    local bag = fbd:GetCurrentFashionBag()
                    if bag and bag.avatar_show then
                        bag.avatar_show[HT.knapsack_ext_background] = nil
                    end
                end)
                handled = true
            end

            if not handled then return false end

            _S.matchApplied = false
            _S.matchOutfitDone = false
            invalidateSocialWearCache()
            pcall(_AutoSaveOutfit)
            return true
        end

        takeOffEquipSkinVisual = function(slot, resID, insID)
            if not slot then return end
            resID, insID = tonumber(resID), tonumber(insID)
            if _S.equipSkinApplying then return end
            _S.equipSkinApplying = true
            pcall(function()
                if resID and resID > 0 then softRemoveEquipVisual(resID, slot) end
                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                local lds = require("client.slua.logic.wardrobe.logic_display_setting")
                local lav = require("client.slua.logic.wardrobe.logic_wardrobe_avatar")
                local HT = require("client.logic.lobby.hall_theme_utils")
                local itemSt = resID and getEquipSubType(resID, slot)
                if itemSt and insID and insID > 0 then
                    pcall(function() lav:SetCurrentWearPreview(itemSt, nil) end)
                end
                if slot == "bag" then
                    fbd:SetBagSkin(0)
                    if lds.data then lds.data.OpenBag = false end
                    HT.PutOnBag(fbd:GetFashionBagUseIndex())
                elseif slot == "helmet" then
                    fbd:SetHelmetSkin(0)
                    if lds.data then lds.data.OpenHelmet = false end
                    fbd:SetHeadShow(0)
                elseif slot == "armor" then
                    pcall(function()
                        local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                        wl:on_putdown_rsp(_K.NET_OK, { res_id = resID or 0, instid = insID or 0, count = 1 }, nil)
                    end)
                end
                if DataMgr and DataMgr.equipmentSkinInsIDTable then
                    local subKey = (slot == "bag") and 504 or (slot == "helmet") and 505 or (slot == "armor") and 506
                    if subKey then DataMgr.equipmentSkinInsIDTable[subKey] = 0 end
                end
                syncFashionBagRolewear()
            end)
            _S.equipSkinApplying = false
        end

        takeOffClothVisual = function(resID, insID, kind)
            resID, insID = tonumber(resID), tonumber(insID)
            if not resID or not insID then return end
            kind = kind or getClothKind(resID)
            local clearMap = subTypesToClearForKind(kind)
            if not clearMap then return end
            pcall(function()
                removeRoleWearBySubTypes(clearMap)
                clearFashionBagSlots(clearMap)
                local WRH = require("client.network.Protocol.WardRobeHandler")
                WRH.on_depot_put_down_rsp(_K.NET_OK, { res_id = resID, count = 1, instid = insID }, nil)
                local av = require("client.slua.logic.wardrobe.logic_wardrobe_avatar")
                local TAM = require("client.logic.avatar.logic_team_avatar_manager")
                local AvatarData = require("client.logic.data.AvatarData")
                local uid = tostring(DataMgr.roleData.uid)
                local itemSt = subType(cfg(resID)) or _K.ST_TOP
                if kind == "full_suit" then
                    itemSt = _K.ST_TOP
                    for st in pairs(clearMap) do
                        local oIns, oRes = findWornInsBySubType(st)
                        if oIns and oRes and oRes > 0 then
                            TAM.ChangeAvatarEquipment(uid, AvatarData.CreateAvatarCustom(oRes), false)
                        end
                    end
                end
                TAM.ChangeAvatarEquipment(uid, AvatarData.CreateAvatarCustom(resID), false)
                pcall(function() AvatarData.RemoveRoleWearDataByValue(insID) end)
                pcall(function() av:SetCurrentWearPreview(itemSt, nil) end)
                later(0.05, function()
                    pcall(function() av:ProcessTakeOff() end)
                    syncFashionBagRolewear()
                    pcall(function()
                        local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                        wl:on_putdown_rsp(_K.NET_OK, { res_id = resID, instid = insID, count = 1 }, nil)
                    end)
                    if av.InitCurrentWearPreviewMap then av:InitCurrentWearPreviewMap(true) end
                end)
            end)
        end

        takeOffWeaponSkinVisual = function(weaponID, resID, insID)
            weaponID, resID, insID = tonumber(weaponID), tonumber(resID), tonumber(insID)
            if not weaponID then return end
            pcall(function()
                local Arm = require("client.logic.armory.logic_armory")
                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                local HT = require("client.logic.lobby.hall_theme_utils")
                local wgl = require("client.slua.logic.wardrobe.logic_wardrobe_gun")
                if Arm.rsp_list and Arm.rsp_list.install_list then
                    Arm.rsp_list.install_list[weaponID] = nil
                end
                if fbd.UpdateCurrentFashionBagWeaponSkin then
                    fbd:UpdateCurrentFashionBagWeaponSkin(weaponID, 0)
                end
                local bag = fbd.GetCurrentFashionBag and fbd:GetCurrentFashionBag()
                if bag and bag.weapon_skin_list then
                    bag.weapon_skin_list[weaponID] = nil
                end
                local bagIdx = fbd:GetFashionBagUseIndex()
                HT.proc_skin_list_chg("weapon_skin", weaponID, 0, bagIdx, {})
                wgl:SetGunID(weaponID)
                if wgl.UpdateCurrentGunAvatar then
                    wgl:UpdateCurrentGunAvatar(weaponID, 0)
                end
                if EventSystem and EVENTTYPE_ARMORY and EVENTID_ARMORY_EQUIP_STAT_CHANGE then
                    EventSystem:postEvent(EVENTTYPE_ARMORY, EVENTID_ARMORY_EQUIP_STAT_CHANGE, 0)
                end
                if EventSystem and EVENTTYPE_WARDROBE and EVENTID_WARDROBE_UPDATE_CURRENT_PUT_ON_GUN then
                    EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_CURRENT_PUT_ON_GUN, 0)
                end
                if EventSystem and EVENTID_WARDROBE_UPDATE_GUN_LIST then
                    EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_GUN_LIST, weaponID)
                end
                log("Weapon skin removed", weaponID)
            end)
        end

        local function putOnThrowObject(insID)
            insID = tonumber(insID)
            if not insID or not isInjectedIns(insID) then return end
            local resID = R.insToRes[insID]
            if not resID then return end
            local st = isThrowObjectRes(resID)
            if not st then return end
            pcall(function()
                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                fbd:PutOnThrowObjectSkin(insID)
            end)
            saveThrowObject(resID, insID)
            pcall(_AutoSaveOutfit)
            log("Throwable equipped", st, resID)
        end

        local function putOnEquipSkin(insID)
            insID = tonumber(insID)
            local resID = R.insToRes[insID]
            if not resID then return end
            local slot = getEquipSkinSlot(resID)
            if not slot then return end
            if _S.equipSkinApplying then return end
            _S.equipSkinApplying = true
            pcall(function()
                local cch = cache()
                local oldResID = cch.equip[slot]
                local oldInsID = cch.equip[slot .. "Ins"]
                ensureKnapsackExtInfo()
                local item = { res_id = resID, instid = insID, count = 1, color = 0, pattern = 0 }
                local oldItem = nil
                if oldInsID and oldInsID > 0 and oldResID and oldResID > 0 then
                    oldItem = { res_id = oldResID, instid = oldInsID, count = 1, color = 0, pattern = 0 }
                end
                local HT = require("client.logic.lobby.hall_theme_utils")
                if slot == "helmet" then
                    HT.ProcPutOnHelmet(item, oldItem)
                elseif slot == "bag" then
                    HT.ProcPutOnBagSkin(item, oldItem)
                elseif slot == "parachute" then
                    local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                    local lav = require("client.slua.logic.wardrobe.logic_wardrobe_avatar")
                    local origAddToWearInfo = lav.AddToWearInfo
                    if _G.__DuneTrack then _G.__DuneTrack(lav, 'AddToWearInfo') end
                    lav.AddToWearInfo = function(self2, subType, ...)
                        if tonumber(subType) == 701 then return end
                        return origAddToWearInfo(self2, subType, ...)
                    end
                    pcall(function()
                        wl:on_puton_rsp(_K.NET_OK, item, oldItem, 1, insID, 0)
                    end)
                    lav.AddToWearInfo = origAddToWearInfo
                elseif slot == "glider" then
                    local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                    local lav = require("client.slua.logic.wardrobe.logic_wardrobe_avatar")
                    local origAddToWearInfo = lav.AddToWearInfo
                    if _G.__DuneTrack then _G.__DuneTrack(lav, 'AddToWearInfo') end
                    lav.AddToWearInfo = function(self2, subType, ...)
                        local st = tonumber(subType)
                        if st == 413 or st == 414 or st == 415 then return end
                        return origAddToWearInfo(self2, subType, ...)
                    end
                    pcall(function()
                        wl:on_puton_rsp(_K.NET_OK, item, oldItem, 1, insID, 0)
                    end)
                    lav.AddToWearInfo = origAddToWearInfo
                else
                    local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                    wl:on_puton_rsp(_K.NET_OK, item, oldItem, 1, insID, 0)
                end
                saveEquipSkin(resID, insID)
                if oldResID and oldResID > 0 and oldResID ~= resID then
                    softRemoveEquipVisual(oldResID, slot)
                end
                if slot ~= "parachute" and slot ~= "glider" then
                    applyEquipVisual(resID, insID, slot)
                end
                invalidateSocialWearCache()
                log("Equipment equipped", slot, resID)
            end)
            _S.equipSkinApplying = false
        end

        local function putOnCloth(insID)
            insID = tonumber(insID)
            local resID = R.insToRes[insID]
            if not resID then return end
            local wd = require("client.slua.logic.wardrobe.wardrobe_data")
            local d = wd:GetHallDepotItemDataByInsID(insID)
            if not d then return end

            local kind = getClothKind(resID, d)
            if not kind then return end

            local cch = cache()
            local switchingFromSuit = (kind ~= "full_suit") and cch.outfitRes and isFullSuitRes(cch.outfitRes)
            local switchingToSuit = (kind == "full_suit") and not cch.outfitRes and next(cch.clothes) ~= nil

            local clearMap
            if switchingFromSuit then
                clearMap = FULL_SUIT_CLEAR_ST
            else
                clearMap = subTypesToClearForKind(kind)
            end
            if not clearMap then return end

            local itemSt = subType(cfg(resID)) or _K.ST_TOP

            local function doPutOn()
                local oldIns, oldRes = findWornInsBySubType(itemSt)
                removeRoleWearBySubTypes(clearMap)
                clearFashionBagSlots(clearMap)
                saveEquip(resID, insID)

                local slot = _K.PKG_SLOT
                pcall(function()
                    local wfu = require("client.slua.logic.wardrobe.fashionbag.wardrobe_fashion_utils")
                    local idx = wfu.GetRoleWearIndexBySubType and wfu:GetRoleWearIndexBySubType(itemSt)
                    if idx then slot = idx end
                end)

                local olditem
                if oldIns and oldIns ~= insID then
                    olditem = { res_id = oldRes or R.insToRes[oldIns], count = 1, instid = oldIns }
                end

                local WRH = require("client.network.Protocol.WardRobeHandler")
                local item = { res_id = resID, count = 1, instid = insID }
                WRH.on_depot_put_on_rsp(_K.NET_OK, item, olditem, slot, insID, oldIns or 0)

                pcall(function()
                    local av = require("client.slua.logic.wardrobe.logic_wardrobe_avatar")
                    av:AddToWearInfo(itemSt, insID, resID, 0, 0)
                    local displayResID = resID
                    local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
                    if LogicXSuit.IsXSuit(displayResID) then
                        displayResID = LogicXSuit.GetItemShowID(insID) or displayResID
                    end
                    av:AvatarChange(displayResID, true, 0, 0)
                    later(0.05, function()
                        pcall(function() av:ProcessTakeOff() end)
                        syncFashionBagRolewear()
                    end)
                end)
                log("Cloth equipped", kind, resID)
            end

            if switchingFromSuit then
                local suitRes = cch.outfitRes
                local suitIns = cch.outfitIns
                cch.outfitRes, cch.outfitIns = nil, nil
                _G.AddOutfitLastLobbyOutfitRes = nil
                if suitRes and suitIns then
                    pcall(function() takeOffClothVisual(suitRes, suitIns, "full_suit") end)
                    later(0.15, doPutOn)
                else
                    doPutOn()
                end
            elseif switchingToSuit then
                local toTakeOff = {}
                for clothRes in pairs(cch.clothes) do
                    local clothIns = R.resToIns[clothRes]
                    local clothKind = getClothKind(clothRes)
                    if clothIns and clothKind then
                        toTakeOff[#toTakeOff + 1] = { resID = clothRes, insID = clothIns, kind = clothKind }
                    end
                end
                for _, c in ipairs(toTakeOff) do
                    cch.clothes[c.resID] = nil
                    pcall(function() takeOffClothVisual(c.resID, c.insID, c.kind) end)
                end
                later(0.15, doPutOn)
            else
                doPutOn()
            end
        end

        local function equipWeaponSkin(weaponID, insID)
            weaponID, insID = tonumber(weaponID), tonumber(insID)
            if not weaponID or not insID or not isInjectedIns(insID) then return end
            local resID = R.insToRes[insID]
            saveEquip(resID, insID)

            local Arm = require("client.logic.armory.logic_armory")
            local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
            local HT = require("client.logic.lobby.hall_theme_utils")
            local wgl = require("client.slua.logic.wardrobe.logic_wardrobe_gun")

            injectArmory(resID, insID)
            Arm.rsp_list.install_list = Arm.rsp_list.install_list or {}
            Arm.rsp_list.install_list[weaponID] = { skin_id = insID }
            if fbd.UpdateCurrentFashionBagWeaponSkin then
                fbd:UpdateCurrentFashionBagWeaponSkin(weaponID, insID)
            end

            local bagIdx = fbd:GetFashionBagUseIndex()
            HT.proc_skin_list_chg("weapon_skin", weaponID, insID, bagIdx, {})

            wgl:SetGunID(weaponID)
            wgl:UpdateCurrentGunAvatar(weaponID, insID)

            if EventSystem and EVENTTYPE_ARMORY and EVENTID_ARMORY_EQUIP_STAT_CHANGE then
                EventSystem:postEvent(EVENTTYPE_ARMORY, EVENTID_ARMORY_EQUIP_STAT_CHANGE, resID)
            end
            if EventSystem and EVENTTYPE_WARDROBE and EVENTID_WARDROBE_UPDATE_CURRENT_PUT_ON_GUN then
                EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_CURRENT_PUT_ON_GUN, resID)
            end
            log("Weapon skin equipped", weaponID, resID, insID)
        end

        local function putOnHallTheme(insID)
            insID = tonumber(insID)
            if not insID or not isInjectedIns(insID) then return end
            local resID = R.insToRes[insID]
            if not resID or not isHallThemeRes(resID) then return end
            local item = { res_id = resID, count = 1, instid = insID }
            pcall(function()
                local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                wl:on_puton_rsp(_K.NET_OK, item, nil, 1, insID, 0)
            end)
            pcall(_AutoSaveOutfit)
            log("Hall theme equipped", resID, insID)
        end

        local function restorePersistedHallTheme()
            if not _G._addOutfitPersistLoaded then return end
            local ins = tonumber(_G._savedHallThemeIns)
            if not ins or ins <= 0 then return end
            later(2.5, function()
                if isInjectedIns(ins) then putOnHallTheme(ins) end
            end)
        end

        local SOCIAL = _G.AddOutfitSocialState or {}
        _G.AddOutfitSocialState = SOCIAL
        SOCIAL.debGen = SOCIAL.debGen or 0

        local function socialDebounce(sec, fn)
            SOCIAL.debGen = (SOCIAL.debGen or 0) + 1
            local gen = SOCIAL.debGen
            later(sec, function()
                if gen ~= SOCIAL.debGen then return end
                pcall(fn)
            end)
        end

        local function getLobbyCurPage()
            local p = nil
            pcall(function()
                local LMC = require("client.slua.logic.lobby.Main.Lobby_Main_Control")
                if LMC.GetCurPage then p = LMC.GetCurPage() end
            end)
            return p
        end

        local function getWeaponSkinResFast()
            local cch = cache()
            local wid = tonumber(DataMgr.Weapon_ID) or 0
            local w = wid > 0 and cch.weapons[wid] or nil
            if w and w.resID and w.resID > 0 then return w.resID end
            for _, ww in pairs(cch.weapons) do
                if ww.resID and ww.resID > 0 then return ww.resID end
            end
            return nil
        end

        local function resolveLobbyWeaponSkinRes()
            local wid = tonumber(DataMgr.Weapon_ID) or 0
            local skin = getWeaponSkinResFast()
            if skin and skin > 0 then return skin end
            if wid > 0 then
                local fromMatch = getMatchWeaponSkin(wid)
                if fromMatch and fromMatch > 0 then return fromMatch end
            end
            return nil
        end

        local function rememberLobbyOutfitRes(resID)
            resID = tonumber(resID)
            if not resID or resID <= 0 or not isFullSuitRes(resID) then return end
            _G.AddOutfitLastLobbyOutfitRes = resID
            local cch = cache()
            if not cch.outfitRes or cch.outfitRes <= 0 then
                cch.outfitRes = resID
                if isInjectedRes(resID) then cch.outfitIns = R.resToIns[resID] end
            end
        end

        local function resolveLobbyOutfitRes()
            local cch = cache()
            if tonumber(cch.outfitRes) and cch.outfitRes > 0 then return cch.outfitRes end
            if tonumber(_G.AddOutfitLastLobbyOutfitRes) and _G.AddOutfitLastLobbyOutfitRes > 0 then
                return tonumber(_G.AddOutfitLastLobbyOutfitRes)
            end
            if MATCH_CONFIG.outfitRes and tonumber(MATCH_CONFIG.outfitRes) > 0 then
                return tonumber(MATCH_CONFIG.outfitRes)
            end
            for resID in pairs(cch.clothes) do
                if isFullSuitRes(resID) then return resID end
            end
            return nil
        end

        local function collectAllClothResIDs()
            local ids = {}
            local cch = cache()
            if tonumber(cch.outfitRes) and cch.outfitRes > 0 then
                ids[cch.outfitRes] = true
            end
            for resID in pairs(cch.clothes) do
                if not getEquipSkinSlot(resID) and not weaponIdFromSkin(resID) then
                    ids[resID] = true
                end
            end
            return ids
        end

        local function wearPatchKey()
            local outfit = resolveLobbyOutfitRes() or 0
            local skin = resolveLobbyWeaponSkinRes() or 0
            local cch = cache()
            local eq = (cch.equip.bag or 0) .. "_" .. (cch.equip.helmet or 0)
            return outfit .. "_" .. skin .. "_" .. eq
        end

        local function applyInjectedPspace(roleData)
            if not roleData then return end
            roleData.bshow = true
            roleData.pspace_wear_ext = roleData.pspace_wear_ext or {}
            local outfitRes = resolveLobbyOutfitRes()
            if outfitRes and outfitRes > 0 then
                roleData.pspace_wear_ext[ENUM_AVATAR_SHOW_TYPE.SHOW_POS_CLOTH] = { outfitRes, 0, 0 }
            end
            local skinRes = resolveLobbyWeaponSkinRes()
            if skinRes and skinRes > 0 then
                roleData.pspace_wear_ext[ENUM_AVATAR_SHOW_TYPE.SHOW_POS_WEAPON] = { 0, 0, 0 }
                roleData.pspace_wear_ext[ENUM_AVATAR_SHOW_TYPE.SHOW_POS_WEAPONSKIN] = { skinRes, 0, 0 }
                roleData.depot_show_info = roleData.depot_show_info or {}
                if roleData.depot_show_info.weapon == nil then roleData.depot_show_info.weapon = true end
            end
        end

        local function patchSelfWearCache(force)
            local key = wearPatchKey()
            if not force and SOCIAL.wearPatchKey == key then return false end
            SOCIAL.wearPatchKey = key
            local myUid = tonumber(DataMgr.roleData.uid)
            if not myUid then return false end
            pcall(function()
                local BD = ModuleManager.GetModule(ModuleManager.DataModuleConfig.BasicDataAvatarWearInfo)
                local d = BD:GetCacheData(myUid)
                if d then applyInjectedPspace(d) end
            end)
            return true
        end

        local function requestSocialAvatarRefresh()
            pcall(function()
                if EventSystem and EVENTTYPE_LOBBY_SOCIAL and EVENTID_SOCIAL_LOBBY_REFRESH_AVATAR then
                    EventSystem:postEvent(EVENTTYPE_LOBBY_SOCIAL, EVENTID_SOCIAL_LOBBY_REFRESH_AVATAR)
                end
            end)
        end

        local function onSocialWearDirty(forceRefresh)
            SOCIAL.lastHandSkin = nil
            if patchSelfWearCache(forceRefresh) then requestSocialAvatarRefresh() end
        end

        local _myUidCached
        local function isMyWearData(wearData)
            if not wearData then return false end
            if not _myUidCached then
                pcall(function() _myUidCached = tonumber(DataMgr.roleData.uid) end)
            end
            return _myUidCached and tonumber(wearData.uid) == _myUidCached
        end

        local function mergeInjectedWeaponIntoWearData(wearData)
            if not isMyWearData(wearData) then return end
            local cch = cache()
            local wKey = ""
            for wid, w in pairs(cch.weapons) do wKey = wKey .. wid .. ":" .. (w.resID or 0) .. "," end
            wKey = wKey .. "|" .. tostring(DataMgr.Weapon_ID or 0)
            local skinRes
            if _weaponSkinResMergeCache.key == wKey then
                skinRes = _weaponSkinResMergeCache.res
            else
                skinRes = resolveLobbyWeaponSkinRes()
                _weaponSkinResMergeCache.key = wKey
                _weaponSkinResMergeCache.res = skinRes
            end
            if not skinRes or skinRes <= 0 then return end
            wearData.mainWeaponInfo = wearData.mainWeaponInfo or {
                weaponResId = 0, weaponSkinId = 0,
                diyInfo = { diyWeaponId = 0, diyDefaultScheme = false, diyScheme = nil },
            }
            wearData.mainWeaponInfo.weaponSkinId = skinRes
            wearData.mainWeaponInfo.weaponResId = 0
        end

        local function getOutfitMergeItems()
            local cch = cache()
            local clothKey = ""
            for resID in pairs(cch.clothes) do clothKey = clothKey .. resID .. "," end
            local key = (cch.outfitRes or 0) .. "_" .. clothKey .. "_" .. (cch.equip.bag or 0) .. "_" .. (cch.equip.helmet or 0)
            if _outfitMergeCache.key == key and _outfitMergeCache.items then
                return _outfitMergeCache.items
            end
            local outfitRes = resolveLobbyOutfitRes()
            local AvatarData = require("client.logic.data.AvatarData")
            local items = {}
            if outfitRes and outfitRes > 0 and isFullSuitRes(outfitRes) then
                rememberLobbyOutfitRes(outfitRes)
                local converted = AvatarData.ConvertToAvatarCustom({ outfitRes, 0, 0 })
                if converted then items[#items + 1] = converted end
                for resID in pairs(collectAllClothResIDs()) do
                    if resID ~= outfitRes and not isFullSuitRes(resID)
                        and not isBodyClothSubType(subType(cfg(resID))) then
                        local cv = AvatarData.ConvertToAvatarCustom({ resID, 0, 0 })
                        if cv then items[#items + 1] = cv end
                    end
                end
            else
                for resID in pairs(collectAllClothResIDs()) do
                    if not isFullSuitRes(resID) then
                        local converted = AvatarData.ConvertToAvatarCustom({ resID, 0, 0 })
                        if converted then items[#items + 1] = converted end
                    end
                end
            end
            _outfitMergeCache.key = key
            _outfitMergeCache.items = items
            return items
        end

        local function mergeInjectedOutfitIntoWearData(wearData)
            if not isMyWearData(wearData) then return end
            local outfitRes = resolveLobbyOutfitRes()
            local items = getOutfitMergeItems()
            if #items == 0 then return end
            if outfitRes and outfitRes > 0 and isFullSuitRes(outfitRes) then
                local newList = {}
                for _, e in ipairs(wearData.WearInfoList or {}) do
                    if not (e and e.ItemID and isBodyClothSubType(subType(cfg(e.ItemID)))) then
                        newList[#newList + 1] = e
                    end
                end
                for _, item in ipairs(items) do
                    newList[#newList + 1] = item
                end
                wearData.WearInfoList = newList
            else
                wearData.WearInfoList = wearData.WearInfoList or {}
                for _, item in ipairs(items) do
                    wearData.WearInfoList[#wearData.WearInfoList + 1] = item
                end
            end
        end

        local function mergeInjectedEquipIntoWearData(wearData)
            if not isMyWearData(wearData) then return end
            local cch = cache()
            wearData.depot_show_info = wearData.depot_show_info or {}
            if cch.equip.bag and cch.equip.bag > 0 then
                local catalogBag = normalizeEquipCatalogRes(cch.equip.bag)
                local bagLevel = getEquipDisplayLevel(cch.equip.bag, "bag")
                wearData.depot_show_info.bag = true
                wearData.bagSkinInsId = mapEquipSkinRes(catalogBag, bagLevel)
                wearData.skin_info = wearData.skin_info or {}
                wearData.skin_info.bag_skin = cch.equip.bagIns or R.resToIns[cch.equip.bag] or cch.equip.bag
                wearData.skin_info.bag_level = bagLevel
            end
            if cch.equip.helmet and cch.equip.helmet > 0 then
                local catalogHelm = normalizeEquipCatalogRes(cch.equip.helmet)
                local helmLevel = getEquipDisplayLevel(cch.equip.helmet, "helmet")
                local helmDisplay = mapEquipSkinRes(catalogHelm, helmLevel)
                wearData.depot_show_info.helmet = true
                wearData.helmet_skin = helmDisplay
                wearData.headShow = helmDisplay
                wearData.skin_info = wearData.skin_info or {}
                wearData.skin_info.helmet_skin = cch.equip.helmetIns or R.resToIns[cch.equip.helmet] or cch.equip.helmet
                wearData.skin_info.head_show = wearData.skin_info.helmet_skin
                wearData.skin_info.helmet_level = helmLevel
            end
        end

        local function mergeInjectedIntoWearData(wearData)
            if not wearData then return end
            mergeInjectedWeaponIntoWearData(wearData)
            mergeInjectedOutfitIntoWearData(wearData)
            mergeInjectedEquipIntoWearData(wearData)
        end

        local function reapplyAccessoryIns(insID)
            insID = tonumber(insID)
            local resID = R.insToRes[insID]
            if not resID then return end
            local c = cfg(resID)
            local st = subType(c)
            saveClothPiece(resID)
            local itemSt = st
            local oldIns, oldRes
            if itemSt then
                oldIns, oldRes = findWornInsBySubType(itemSt)
                if oldIns == insID then oldIns, oldRes = nil, nil end
                removeRoleWearBySubTypes({ [itemSt] = true })
            end
            local WRH = require("client.network.Protocol.WardRobeHandler")
            local olditem
            if oldIns then
                olditem = { res_id = oldRes or R.insToRes[oldIns], count = 1, instid = oldIns }
            end
            WRH.on_depot_put_on_rsp(_K.NET_OK, { res_id = resID, count = 1, instid = insID }, olditem, 1, insID, oldIns or 0)
            pcall(function()
                local av = require("client.slua.logic.wardrobe.logic_wardrobe_avatar")
                if oldIns and itemSt then av:SetCurrentWearPreview(itemSt, nil) end
                if itemSt then av:AddToWearInfo(itemSt, insID, resID, 0, 0) end
                av:AvatarChange(resID, true, 0, 0)
                av:ProcessTakeOff()
                syncFashionBagRolewear()
            end)
        end

        local function reapplyInjectedIns(insID)
            insID = tonumber(insID)
            if not insID or not isInjectedIns(insID) then return end
            local resID = R.insToRes[insID]
            if not resID then return end
            if isHallThemeRes(resID) then
                putOnHallTheme(insID)
            elseif getEquipSkinSlot(resID) then
                putOnEquipSkin(insID)
            elseif getClothKind(resID) then
                putOnCloth(insID)
            elseif weaponIdFromSkin(resID) then
                equipWeaponSkin(weaponIdFromSkin(resID), insID)
            elseif _K.GUN_SUB[subType(cfg(resID))] then
                local cch = cache()
                local foundWid = nil
                for wid, w in pairs(cch.weapons or {}) do
                    if w.resID == resID then foundWid = wid; break end
                end
                if foundWid then equipWeaponSkin(foundWid, insID) end
            elseif subType(cfg(resID)) == _K.MELEE_ID then
                equipWeaponSkin(_K.MELEE_ID, insID)
            elseif isThrowObjectRes(resID) then
                putOnThrowObject(insID)
            else
                reapplyAccessoryIns(insID)
            end
        end

        local function reapplyLobbyEquipped()
            if not GameStatus or not GameStatus.IsInLobbyOrMainCity or not GameStatus.IsInLobbyOrMainCity() then
                return
            end
            if _S.lobbyApplied then return end
            _S.lobbyApplied = true
            later(2.0, function() _S.lobbyApplied = false end)

            restorePersistedVehicles()
            restorePersistedMotions()
            restorePersistedEquipIns()
            restorePersistedThrowObjects()
            restorePersistedHallTheme()
            syncMatchConfigFromCache()

            if not _G._addOutfitPersistLoaded then
                snapshotLobbyWear()
            end
            local cch = cache()
            if not _G._addOutfitPersistLoaded and _G._savedOutfitClothes then
                for resID in pairs(_G._savedOutfitClothes) do
                    cch.clothes[resID] = true
                end
            end
            if not _G._addOutfitPersistLoaded and _G._savedOutfitRes and (not cch.outfitRes or cch.outfitRes <= 0) then
                cch.outfitRes = _G._savedOutfitRes
                cch.outfitIns = _G._savedOutfitIns or R.resToIns[_G._savedOutfitRes]
            end
            syncMatchConfigFromCache()

            local applyStep = 0
            local function scheduleApply(fn)
                applyStep = applyStep + 1
                later(applyStep * 0.12, fn)
            end

            if not _G._addOutfitPersistLoaded and _G._savedRoleWearList and #_G._savedRoleWearList > 0 then
                for _, insID in ipairs(_G._savedRoleWearList) do
                    local id = insID
                    scheduleApply(function() reapplyInjectedIns(id) end)
                end
            elseif cch.outfitIns and isInjectedIns(cch.outfitIns) then
                scheduleApply(function() putOnCloth(cch.outfitIns) end)
            else
                for resID in pairs(cch.clothes) do
                    local ins = R.resToIns[resID]
                    local rid = resID
                    if ins and isInjectedIns(ins) then
                        scheduleApply(function()
                            if getClothKind(rid) then
                                putOnCloth(ins)
                            else
                                reapplyAccessoryIns(ins)
                            end
                        end)
                    end
                end
            end
            for wid, w in pairs(cch.weapons) do
                local weaponID, entry = wid, w
                scheduleApply(function()
                    if entry.insID and isInjectedIns(entry.insID) then
                        equipWeaponSkin(weaponID, entry.insID)
                    elseif entry.resID and R.resToIns[entry.resID] and isInjectedIns(R.resToIns[entry.resID]) then
                        equipWeaponSkin(weaponID, R.resToIns[entry.resID])
                    end
                end)
            end
            for _, slot in ipairs({ "bag", "helmet", "armor", "parachute", "glider" }) do
                local resID = cch.equip[slot]
                local insID = cch.equip[slot .. "Ins"]
                scheduleApply(function()
                    if insID and isInjectedIns(insID) then
                        putOnEquipSkin(insID)
                    elseif resID and R.resToIns[resID] then
                        putOnEquipSkin(R.resToIns[resID])
                    end
                end)
            end
            if cch.throwObjects then
                for st, info in pairs(cch.throwObjects) do
                    local tInfo = info
                    scheduleApply(function()
                        if tInfo.insID and isInjectedIns(tInfo.insID) then
                            putOnThrowObject(tInfo.insID)
                        elseif tInfo.resID and R.resToIns[tInfo.resID] and isInjectedIns(R.resToIns[tInfo.resID]) then
                            putOnThrowObject(R.resToIns[tInfo.resID])
                        end
                    end)
                end
            end
            later(math.max(applyStep * 0.12 + 0.3, 0.5), function()
                syncMatchConfigFromCache()
                pcall(_AutoSaveOutfit, true)
                log("Lobby reapplied (once)")
            end)

            pcall(function()
                if _G._addOutfitPersistLoaded then return end
                local GTS = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.GarageThemeSystem)
                if not GTS then return end
                local maxSlots = GTS:GetMaxPositionNum()
                GTS.GarageVehicleInfo = GTS.GarageVehicleInfo or {}
                local usedIns = {}
                for slot, info in pairs(GTS.GarageVehicleInfo) do
                    if info and info.inst_id then
                        usedIns[tonumber(info.inst_id)] = true
                    end
                end
                local changed = false
                for slot = 1, maxSlots do
                    if not GTS.GarageVehicleInfo[slot] then
                        for _, resID in ipairs(_C.vehicleItems) do
                            if isInjectedRes(resID) then
                                local insID = R.resToIns[resID]
                                if insID and not usedIns[insID] then
                                    GTS.GarageVehicleInfo[slot] = { inst_id = insID, res_id = resID }
                                    usedIns[insID] = true
                                    changed = true
                                    break
                                end
                            end
                        end
                    end
                end
                if changed then
                    if EventSystem and EVENTTYPE_LOBBY_THEME and EVENTID_GARAGE_VEHICLE_DATA_CHANGE then
                        EventSystem:postEvent(EVENTTYPE_LOBBY_THEME, EVENTID_GARAGE_VEHICLE_DATA_CHANGE)
                    end
                end
            end)
        end

        local function initHooks()
            local function hookLobbySwipePersistence()
                pcall(function()
                    local AC = require("client.slua.logic.avatar.avatar_common")
                    local oGetWear = AC.GetWearDataFromRoleData
                    if _G.__DuneTrack then _G.__DuneTrack(AC, 'GetWearDataFromRoleData') end
                    AC.GetWearDataFromRoleData = function(roleData)
                        local wearData = oGetWear(roleData)
                        if wearData and roleData and tonumber(roleData.uid) == tonumber(DataMgr.roleData.uid) then
                            mergeInjectedIntoWearData(wearData)
                        end
                        return wearData
                    end
                    local oUp = AC.UpdateAvatar
                    if _G.__DuneTrack then _G.__DuneTrack(AC, 'UpdateAvatar') end
                    AC.UpdateAvatar = function(avatar, wearData, isShowWeapon, isShowHelmet, isShowBag)
                        if isMyWearData(wearData) then mergeInjectedIntoWearData(wearData) end
                        return oUp(avatar, wearData, isShowWeapon, isShowHelmet, isShowBag)
                    end
                end)
                pcall(function()
                    if EventSystem and EventSystem.registEvent and EVENTTYPE_LOBBY and EVENTID_SWITCHTO_PAGE_END then
                        EventSystem:registEvent(EVENTTYPE_LOBBY, EVENTID_SWITCHTO_PAGE_END, function(_, _, _, toPage)
                            if ENUM_LobbyPageType and toPage == ENUM_LobbyPageType.Mid then
                                socialDebounce(0.5, reapplyLobbyEquipped)
                            end
                        end)
                    end
                end)
            end

            local function hookCDataTableCache()
                pcall(function()
                    if not CDataTable or CDataTable._lava_cached then return end
                    CDataTable._lava_cached = true
                    local origGetTableData = CDataTable.GetTableData
                    if _G.__DuneTrack then _G.__DuneTrack(CDataTable, 'GetTableData') end
                    CDataTable.GetTableData = function(tableName, resID, ...)
                        if tableName == "Item" then
                            resID = tonumber(resID)
                            if resID and _C.cfg[resID] ~= nil then
                                return _C.cfg[resID]
                            end
                            local result = origGetTableData(tableName, resID, ...)
                            if resID then
                                _C.cfg[resID] = result
                            end
                            return result
                        end
                        return origGetTableData(tableName, resID, ...)
                    end
                end)
            end

            local function hookDepotInit()
                pcall(function()
                    local WDE = require("client.slua.logic.wardrobe.WardrobeDataEntity")
                    local orig = WDE.InitData
                    if _G.__DuneTrack then _G.__DuneTrack(WDE, 'InitData') end
                    WDE.InitData = function(self, pkg)
                        orig(self, pkg)
                        injectAll(self)
                        refreshWardrobe()
                    end
                end)
            end

            local function hookWardrobeData()
                pcall(function()
                    local wd = require("client.slua.logic.wardrobe.wardrobe_data")
                    local function wrapGet(name)
                        local o = wd[name]
                        if not o then return end
                        if _G.__DuneTrack then _G.__DuneTrack(wd, name) end
                        wd[name] = function(self, insID, ...)
                            insID = tonumber(insID)
                            if isInjectedIns(insID) then
                                local e = getEntity()
                                if e then return e:GetDataByInsID(insID) end
                            end
                            return o(self, insID, ...)
                        end
                    end
                    wrapGet("GetHallDepotItemDataByInsID")
                    wrapGet("GetValidHallDepotItemDataByInsID")
                    local function wrapBool(name)
                        local o = wd[name]
                        if not o then return end
                        if _G.__DuneTrack then _G.__DuneTrack(wd, name) end
                        wd[name] = function(self, id, ...)
                            if isInjectedRes(tonumber(id)) or isInjectedIns(tonumber(id)) then return true end
                            return o(self, id, ...)
                        end
                    end
                    wrapBool("HasItem")
                    wrapBool("HasValidItem")
                    wrapBool("CheckHasPermanentItem")
                    if not wd._lava_global_equip then
                        wd._lava_global_equip = true
                        local origGetEquipped = wd.GetEquippedSkinIDByWeaponID
                        if _G.__DuneTrack then _G.__DuneTrack(wd, 'GetEquippedSkinIDByWeaponID') end
                        wd.GetEquippedSkinIDByWeaponID = function(self, weaponID)
                            local w = cache().weapons[tonumber(weaponID)]
                            if w and w.resID and w.resID > 0 then return w.resID end
                            return origGetEquipped(self, weaponID)
                        end
                    end
                    if not wd._lava_global_equip_ins then
                        wd._lava_global_equip_ins = true
                        if wd.GetEquippedSkinInsIDByWeaponID then
                            local origGetEquippedIns = wd.GetEquippedSkinInsIDByWeaponID
                            if _G.__DuneTrack then _G.__DuneTrack(wd, 'GetEquippedSkinInsIDByWeaponID') end
                            wd.GetEquippedSkinInsIDByWeaponID = function(self, weaponID)
                                local w = cache().weapons[tonumber(weaponID)]
                                if w and w.insID and w.insID > 0 and isInjectedIns(w.insID) then return w.insID end
                                return origGetEquippedIns(self, weaponID)
                            end
                        end
                        if wd.GetWeaponSkinInsID then
                            local origGetWSI = wd.GetWeaponSkinInsID
                            if _G.__DuneTrack then _G.__DuneTrack(wd, 'GetWeaponSkinInsID') end
                            wd.GetWeaponSkinInsID = function(self, weaponID)
                                local w = cache().weapons[tonumber(weaponID)]
                                if w and w.insID and w.insID > 0 and isInjectedIns(w.insID) then return w.insID end
                                return origGetWSI(self, weaponID)
                            end
                        end
                    end
                end)
                pcall(function()
                    local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                    local oPutDownReq = wl.wardrobe_put_down_req
                    if oPutDownReq then
                        if _G.__DuneTrack then _G.__DuneTrack(wl, 'wardrobe_put_down_req') end
                        wl.wardrobe_put_down_req = function(self, ins_id, unequip_by_server)
                            ins_id = tonumber(ins_id)
                            if isInjectedIns(ins_id) then
                                local resID = R.insToRes[ins_id]
                                takeOffItem(ins_id)
                                pcall(function()
                                    self:on_putdown_rsp(_K.NET_OK, {
                                        instid = ins_id,
                                        res_id = resID or 0,
                                    }, nil)
                                end)
                                pcall(function()
                                    if EventSystem and EVENTTYPE_WARDROBE and EVENTID_WARDROBE_UPDATE_PUT_DOWN_DATA then
                                        EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_PUT_DOWN_DATA, {
                                            instid = ins_id,
                                            res_id = resID or 0,
                                            count = 1,
                                        })
                                    end
                                end)
                                refreshWardrobe()
                                return
                            end
                            return oPutDownReq(self, ins_id, unequip_by_server)
                        end
                    end
                end)
            end

            local function hookPageFilter()
                pcall(function()
                    local SubTab = require("client.slua.umg.Wardrobe.subtab_item_list_base")
                    if SubTab._lava_prefilter then return end
                    SubTab._lava_prefilter = true
                    local origGet = SubTab.GetArrayHallDepotItemInfo
                    if _G.__DuneTrack then _G.__DuneTrack(SubTab, 'GetArrayHallDepotItemInfo') end
                    SubTab.GetArrayHallDepotItemInfo = function(self)
                        local allData = origGet(self)
                        if not allData or not next(allData) then return allData end
                        local pageId = self.subTabConfig and self.subTabConfig.pageId
                        local subTabId = self.subTabConfig and self.subTabConfig.subTabId
                        if not pageId or not subTabId then return allData end
                        local result = {}
                        for _, data in pairs(allData) do
                            local resID = depotResID(data)
                            if resID and isInjectedRes(resID) then
                                local itemMain, itemSub = getInjectedItemTab(resID, data)
                                if itemMain == pageId then
                                    if pageId == _K.WARDROBE_PAGE_AVATAR then
                                        if subTabId == _K.WARDROBE_TAB_SUIT or subTabId == _K.WARDROBE_TAB_CLOTHES then
                                            local st = data.itemSubType or subType(cfg(resID))
                                            if st == _K.ST_TOP then
                                                local full = isFullSuitRes(resID, data)
                                                if (subTabId == _K.WARDROBE_TAB_SUIT and full) or
                                                (subTabId == _K.WARDROBE_TAB_CLOTHES and not full) then
                                                    result[#result + 1] = data
                                                end
                                            end
                                        elseif itemSub == subTabId then
                                            result[#result + 1] = data
                                        end
                                    elseif itemSub == subTabId then
                                        result[#result + 1] = data
                                    end
                                end
                            else
                                result[#result + 1] = data
                            end
                        end
                        return result
                    end
                end)
                pcall(function()
                    local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                    local o1 = wl.IsValidCurrentPageItem
                    if _G.__DuneTrack then _G.__DuneTrack(wl, 'IsValidCurrentPageItem') end
                    wl.IsValidCurrentPageItem = function(self, mainTab, subTab, v, t)
                        local resID = depotResID(v)
                        if resID and isInjectedRes(resID) then
                            local cacheKey = resID .. "_" .. mainTab .. "_" .. subTab
                            if _C.pageMatch[cacheKey] ~= nil then
                                return _C.pageMatch[cacheKey]
                            end
                            local result
                            if not (v.expireTS == 0 or not t or t < v.expireTS) then
                                result = false
                            else
                                local equipOk = injectedEquipAllowed(resID, mainTab, subTab)
                                if equipOk ~= nil then
                                    result = equipOk
                                elseif weaponIdFromSkin(resID) then
                                    result = mainTab == _K.WARDROBE_PAGE_WEAPON and subTab == _K.WARDROBE_TAB_GUN
                                elseif mainTab == _K.WARDROBE_PAGE_VEHICLE then
                                    local c = cfg(resID)
                                    local wmTab = c and tonumber(c.WardrobeMainTab or c.wardrobeMainTab) or 0
                                    if wmTab ~= mainTab and v.mainTabType ~= mainTab then
                                        result = false
                                    else
                                        local wTab = c and tonumber(c.WardrobeTab or c.wardrobeTab) or nil
                                        local vTab = v.subTabType and tonumber(v.subTabType) or nil
                                        if wTab and wTab == subTab then result = true
                                        elseif vTab and vTab == subTab then result = true
                                        else result = o1(self, mainTab, subTab, v, t) end
                                    end
                                elseif mainTab == _K.WARDROBE_PAGE_AVATAR then
                                    local st = v.itemSubType or subType(cfg(resID))
                                    if st == _K.ST_TOP then
                                        local full = isFullSuitRes(resID, v)
                                        if subTab == _K.WARDROBE_TAB_SUIT and full then result = true
                                        elseif subTab == _K.WARDROBE_TAB_CLOTHES and not full then result = true
                                        else result = false end
                                    elseif st == _K.ST_PANTS and subTab == _K.WARDROBE_TAB_TROUSERS then
                                        result = true
                                    elseif st == _K.ST_SHOES and subTab == _K.WARDROBE_TAB_SHOES then
                                        result = true
                                    elseif v.subTabType == subTab then
                                        result = true
                                    else
                                        result = false
                                    end
                                else
                                    result = o1(self, mainTab, subTab, v, t)
                                end
                            end
                            _C.pageMatch[cacheKey] = result
                            return result
                        end
                        return o1(self, mainTab, subTab, v, t)
                    end
                    local o2 = wl.IsCanUse
                    if _G.__DuneTrack then _G.__DuneTrack(wl, 'IsCanUse') end
                    wl.IsCanUse = function(self, resId)
                        if isInjectedRes(resId) then return true end
                        return o2(self, resId)
                    end
                    local o4 = wl.GetWardrobeInsIdByResId
                    if _G.__DuneTrack then _G.__DuneTrack(wl, 'GetWardrobeInsIdByResId') end
                    wl.GetWardrobeInsIdByResId = function(self, resid)
                        resid = tonumber(resid)
                        if isInjectedRes(resid) then return R.resToIns[resid] end
                        return o4(self, resid)
                    end
                end)
            end

            local function hookArmory()
                pcall(function()
                    local Arm = require("client.logic.armory.logic_armory")
                    if not Arm._lava_global_own then
                        Arm._lava_global_own = true
                        local origIsOwn = Arm.IsSkinOwn
                        if _G.__DuneTrack then _G.__DuneTrack(Arm, 'IsSkinOwn') end
                        Arm.IsSkinOwn = function(weaponID, skinID)
                            if isInjectedRes(skinID) then return 1 end
                            return origIsOwn(weaponID, skinID)
                        end
                    end
                    if not Arm._lava_global_get_install then
                        Arm._lava_global_get_install = true
                        if Arm.get_install_skin then
                            local origGetInstall = Arm.get_install_skin
                            if _G.__DuneTrack then _G.__DuneTrack(Arm, 'get_install_skin') end
                            Arm.get_install_skin = function(weaponID)
                                local w = cache().weapons[tonumber(weaponID)]
                                if w and w.insID and w.insID > 0 and isInjectedIns(w.insID) then
                                    return { skin_id = w.insID }
                                end
                                return origGetInstall(weaponID)
                            end
                        end
                        if Arm.GetInstallSkinInsID then
                            local origGetInstall2 = Arm.GetInstallSkinInsID
                            if _G.__DuneTrack then _G.__DuneTrack(Arm, 'GetInstallSkinInsID') end
                            Arm.GetInstallSkinInsID = function(weaponID)
                                local w = cache().weapons[tonumber(weaponID)]
                                if w and w.insID and w.insID > 0 and isInjectedIns(w.insID) then
                                    return w.insID
                                end
                                return origGetInstall2(weaponID)
                            end
                        end
                    end
                    local oi = Arm.install_weapon_skin
                    if _G.__DuneTrack then _G.__DuneTrack(Arm, 'install_weapon_skin') end
                    Arm.install_weapon_skin = function(cd, wid, ins)
                        ins = tonumber(ins)
                        if isInjectedIns(ins) then
                            wid = tonumber(weaponIdFromSkin(R.insToRes[ins]) or wid)
                            equipWeaponSkin(wid, ins)
                            return
                        end
                        return oi(cd, wid, ins)
                    end
                    local function hookArmoryUninstall(fnName)
                        local orig = Arm[fnName]
                        if not orig then return end
                        if _G.__DuneTrack then _G.__DuneTrack(Arm, fnName) end
                        Arm[fnName] = function(cd, wid, ins, ...)
                            ins = tonumber(ins)
                            wid = tonumber(wid)
                            if ins and isInjectedIns(ins) then
                                local resID = R.insToRes[ins]
                                wid = weaponIdFromSkin(resID) or wid
                                if takeOffItem(ins) then
                                    refreshWardrobe()
                                    return
                                end
                            elseif wid and wid > 0 then
                                local cch = cache()
                                local w = cch.weapons[wid]
                                if w and w.insID and isInjectedIns(w.insID) then
                                    if takeOffItem(w.insID) then
                                        refreshWardrobe()
                                        return
                                    end
                                end
                            end
                            return orig(cd, wid, ins, ...)
                        end
                    end
                    hookArmoryUninstall("uninstall_weapon_skin")
                    hookArmoryUninstall("remove_weapon_skin")
                end)
            end

            local function hookLobbyTheme()
                pcall(function()
                    local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                    if wl._lava_hooked_hall_theme then return end
                    wl._lava_hooked_hall_theme = true
                    local origPutOn = wl.wardrobe_puton_req
                    if _G.__DuneTrack then _G.__DuneTrack(wl, 'wardrobe_puton_req') end
                    wl.wardrobe_puton_req = function(self, insID, extra)
                        insID = tonumber(insID)
                        if insID and isInjectedIns(insID) and isHallThemeRes(R.insToRes[insID]) then
                            putOnHallTheme(insID)
                            return
                        end
                        return origPutOn(self, insID, extra)
                    end
                end)
            end

            local function hookPutOn()
                pcall(function()
                    local WRH = require("client.network.Protocol.WardRobeHandler")
                    local o = WRH.send_depot_put_on_req
                    if _G.__DuneTrack then _G.__DuneTrack(WRH, 'send_depot_put_on_req') end
                    WRH.send_depot_put_on_req = function(insID, extra)
                        insID = tonumber(insID)
                        if isInjectedIns(insID) then
                            local resID = R.insToRes[insID]
                            local c = cfg(resID)
                            local st = subType(c)
                            if getEquipSkinSlot(resID) then
                                putOnEquipSkin(insID)
                                return
                            end
                            if getClothKind(resID) then
                                putOnCloth(insID)
                                return
                            end
                            if _K.GUN_SUB[st] then
                                local wid = weaponIdFromSkin(resID)
                                if not wid then
                                    pcall(function()
                                        local wgl = require("client.slua.logic.wardrobe.logic_wardrobe_gun")
                                        wid = wgl.GetCurGunID and wgl:GetCurGunID() or nil
                                        if not wid and wgl.GetCurrentGunID then
                                            wid = wgl:GetCurrentGunID()
                                        end
                                    end)
                                end
                                if wid then equipWeaponSkin(wid, insID) end
                                return
                            end
                            if st == _K.MELEE_ID then
                                equipWeaponSkin(_K.MELEE_ID, insID)
                                return
                            end
                            if isHallThemeRes(resID) then
                                putOnHallTheme(insID)
                                return
                            end
                            if isThrowObjectRes(resID) then
                                local st = isThrowObjectRes(resID)
                                local cch = cache()
                                local oldThrow = cch.throwObjects and cch.throwObjects[st]
                                local oldInsID = oldThrow and oldThrow.insID or 0
                                local oldResID = oldThrow and oldThrow.resID or 0
                                putOnThrowObject(insID)
                                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                                local bagIndex = fbd:GetFashionBagUseIndex()
                                local olditem
                                if oldInsID and oldInsID ~= insID and oldInsID ~= 0 then
                                    olditem = { res_id = oldResID, count = 1, instid = oldInsID }
                                end
                                WRH.on_depot_put_on_rsp(_K.NET_OK, { res_id = resID, count = 1, instid = insID }, olditem, bagIndex, insID, oldInsID, extra)
                                return
                            end
                            local mainTab = wardrobeMainTab(resID)
                            if mainTab == _K.WARDROBE_PAGE_VEHICLE then
                                local item = { res_id = resID, count = 1, instid = insID }
                                WRH.on_depot_put_on_rsp(_K.NET_OK, item, nil, 1, insID, 0, extra)
                                return
                            end
                            local wd = require("client.slua.logic.wardrobe.wardrobe_data")
                            if wd:GetHallDepotItemDataByInsID(insID) then
                                local itemSt = st or subType(cfg(resID))
                                local oldIns, oldRes
                                if itemSt then
                                    oldIns, oldRes = findWornInsBySubType(itemSt)
                                    if oldIns == insID then oldIns, oldRes = nil, nil end
                                    removeRoleWearBySubTypes({ [itemSt] = true })
                                end
                                saveClothPiece(resID)
                                local olditem
                                if oldIns then
                                    olditem = { res_id = oldRes or R.insToRes[oldIns], count = 1, instid = oldIns }
                                end
                                WRH.on_depot_put_on_rsp(_K.NET_OK, { res_id = resID, count = 1, instid = insID }, olditem, 1, insID, oldIns or 0, extra)
                                pcall(function()
                                    local av = require("client.slua.logic.wardrobe.logic_wardrobe_avatar")
                                    if oldIns and itemSt then av:SetCurrentWearPreview(itemSt, nil) end
                                    if itemSt then av:AddToWearInfo(itemSt, insID, resID, 0, 0) end
                                    av:AvatarChange(resID, true, 0, 0)
                                    av:ProcessTakeOff()
                                    syncFashionBagRolewear()
                                end)
                                pcall(_AutoSaveOutfit)
                            end
                            return
                        end
                        return o(insID, extra)
                    end
                end)

                pcall(function()
                    local WRH = require("client.network.Protocol.WardRobeHandler")
                    local oPutDown = WRH.send_depot_put_down_req
                    if _G.__DuneTrack then _G.__DuneTrack(WRH, 'send_depot_put_down_req') end
                    WRH.send_depot_put_down_req = function(insID, extra)
                        insID = tonumber(insID)
                        if isInjectedIns(insID) then
                            local resID = R.insToRes[insID]
                            local removed = takeOffItem(insID)
                            if removed then
                                local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                                pcall(function()
                                    wl:on_putdown_rsp(_K.NET_OK, {
                                        res_id = resID or 0,
                                        instid = insID,
                                        count  = 1,
                                    }, nil)
                                end)
                                pcall(function()
                                    if EventSystem and EVENTTYPE_WARDROBE and EVENTID_WARDROBE_UPDATE_PUT_DOWN_DATA then
                                        EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_PUT_DOWN_DATA, {
                                            instid = insID,
                                            res_id = resID or 0,
                                            count = 1,
                                        })
                                    end
                                end)
                                refreshWardrobe()
                                return
                            end
                        end
                        return oPutDown(insID, extra)
                    end
                end)

                pcall(function()
                    local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                    local oPutDownReq = wl.wardrobe_put_down_req
                    if oPutDownReq then
                        if _G.__DuneTrack then _G.__DuneTrack(wl, 'wardrobe_put_down_req') end
                        wl.wardrobe_put_down_req = function(self, ins_id, unequip_by_server)
                            ins_id = tonumber(ins_id)
                            if isInjectedIns(ins_id) then
                                local resID = R.insToRes[ins_id]
                                takeOffItem(ins_id)
                                pcall(function()
                                    self:on_putdown_rsp(_K.NET_OK, {
                                        instid = ins_id,
                                        res_id = resID or 0,
                                    }, nil)
                                end)
                                pcall(function()
                                    if EventSystem and EVENTTYPE_WARDROBE and EVENTID_WARDROBE_UPDATE_PUT_DOWN_DATA then
                                        EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_PUT_DOWN_DATA, {
                                            instid = ins_id,
                                            res_id = resID or 0,
                                            count = 1,
                                        })
                                    end
                                end)
                                refreshWardrobe()
                                return
                            end
                            return oPutDownReq(self, ins_id, unequip_by_server)
                        end
                    end
                end)

                pcall(function()
                    local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                    local oEquipSlot = wl.EquipSlotVehicle
                    if oEquipSlot and not wl._lava_hooked_equip_slot_vehicle then
                        wl._lava_hooked_equip_slot_vehicle = true
                        if _G.__DuneTrack then _G.__DuneTrack(wl, 'EquipSlotVehicle') end
                        wl.EquipSlotVehicle = function(self, resid, dragVehicleInsID, Index)
                            dragVehicleInsID = tonumber(dragVehicleInsID)
                            if dragVehicleInsID and isInjectedIns(dragVehicleInsID) then
                                local resID = R.insToRes[dragVehicleInsID]
                                local c = cfg(resID)
                                local itemSubType = c and tonumber(c.ItemSubType or c.itemSubType) or 0
                                if itemSubType and itemSubType > 0 then
                                    DataMgr.VehicleSlotList = DataMgr.VehicleSlotList or {}
                                    local slotList = DataMgr.VehicleSlotList[itemSubType] or {}
                                    local idx = Index or 1
                                    for i = #slotList, 1, -1 do
                                        if slotList[i] == dragVehicleInsID then
                                            table.remove(slotList, i)
                                        end
                                    end
                                    slotList[idx] = dragVehicleInsID
                                    DataMgr.VehicleSlotList[itemSubType] = slotList
                                    if DataMgr.vehicleSkinInsIDTable then
                                        DataMgr.vehicleSkinInsIDTable[resID] = DataMgr.vehicleSkinInsIDTable[resID] or dragVehicleInsID
                                    end
                                end
                                DataMgr.UpdateVehicleSkin(itemSubType, dragVehicleInsID)
                                pcall(function()
                                    local tabSurveillance = require("client.slua.logic.wardrobe.tab_surveillance")
                                    if tabSurveillance and tabSurveillance.VehicleChange then
                                        tabSurveillance.VehicleChange()
                                    end
                                end)
                                if EventSystem and EVENTTYPE_WARDROBE and EVENTID_WARDROBE_VEHICLE_SLOT_DATA_CHANGE then
                                    EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_VEHICLE_SLOT_DATA_CHANGE)
                                end
                                return
                            end
                            return oEquipSlot(self, resid, dragVehicleInsID, Index)
                        end
                    end
                end)

                pcall(function()
                    local GarageThemeSystem = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.GarageThemeSystem)
                    if GarageThemeSystem and not GarageThemeSystem._lava_hooked_equip_vehicle then
                        GarageThemeSystem._lava_hooked_equip_vehicle = true
                        local oEquip = GarageThemeSystem.EquipVehicle
                        if _G.__DuneTrack then _G.__DuneTrack(GarageThemeSystem, 'EquipVehicle') end
                        GarageThemeSystem.EquipVehicle = function(self, Position, InsID)
                            InsID = tonumber(InsID)
                            if InsID and isInjectedIns(InsID) then
                                self:OnEquipVehicle(Position, InsID)
                                return
                            end
                            return oEquip(self, Position, InsID)
                        end
                        local oBatch = GarageThemeSystem.BatchEquipVehicle
                        if _G.__DuneTrack then _G.__DuneTrack(GarageThemeSystem, 'BatchEquipVehicle') end
                        GarageThemeSystem.BatchEquipVehicle = function(self, InsIDList)
                            if InsIDList and type(InsIDList) == "table" then
                                local hasInjected = false
                                local filtered = {}
                                for slot, ins in pairs(InsIDList) do
                                    if isInjectedIns(tonumber(ins)) then
                                        hasInjected = true
                                        self:OnEquipVehicle(slot, tonumber(ins))
                                    else
                                        filtered[slot] = ins
                                    end
                                end
                                if hasInjected and not next(filtered) then
                                    return
                                end
                                InsIDList = filtered
                            end
                            return oBatch(self, InsIDList)
                        end

                        local oReceive = GarageThemeSystem.OnReceiveGarageData
                        if _G.__DuneTrack then _G.__DuneTrack(GarageThemeSystem, 'OnReceiveGarageData') end
                        GarageThemeSystem.OnReceiveGarageData = function(self, VehicleInfo)
                            local injectedSlots = {}
                            if self.GarageVehicleInfo then
                                for slot, info in pairs(self.GarageVehicleInfo) do
                                    if info and info.inst_id and isInjectedIns(tonumber(info.inst_id)) then
                                        injectedSlots[slot] = info
                                    end
                                end
                            end
                            oReceive(self, VehicleInfo)
                            for slot, info in pairs(injectedSlots) do
                                if not self.GarageVehicleInfo[slot] then
                                    self.GarageVehicleInfo[slot] = info
                                end
                            end
                        end

                        local oGetInfo = GarageThemeSystem.GetGarageVehicleInfo
                        if _G.__DuneTrack then _G.__DuneTrack(GarageThemeSystem, 'GetGarageVehicleInfo') end
                        GarageThemeSystem.GetGarageVehicleInfo = function(self)
                            if not self.bDataReceived and self.GarageVehicleInfo and next(self.GarageVehicleInfo) then
                                return self.GarageVehicleInfo
                            end
                            return oGetInfo(self)
                        end

                        local oGetShowList = GarageThemeSystem.GetGarageShowCarInsIDList
                        if oGetShowList then
                            if _G.__DuneTrack then _G.__DuneTrack(GarageThemeSystem, 'GetGarageShowCarInsIDList') end
                            GarageThemeSystem.GetGarageShowCarInsIDList = function(self, VehicleType)
                                local List = oGetShowList(self, VehicleType) or {}
                                for _, resID in ipairs(_C.vehicleItems) do
                                    if isInjectedRes(resID) and #List < self:GetMaxPositionNum() then
                                        local c = cfg(resID)
                                        if c then
                                            local itemSubType = tonumber(c.ItemSubType or c.itemSubType) or 0
                                            local taxonomy = CDataTable.GetTableDataByFilter("WardrobeVehiclesTaxonomy", "ItemSubType", itemSubType)
                                            if taxonomy and taxonomy.UseInGarage == 1 and taxonomy.CategoryID == VehicleType then
                                                local insID = R.resToIns[resID]
                                                if insID then
                                                    local alreadyIn = false
                                                    for _, existingIns in ipairs(List) do
                                                        if tonumber(existingIns) == tonumber(insID) then
                                                            alreadyIn = true
                                                            break
                                                        end
                                                    end
                                                    if not alreadyIn then
                                                        table.insert(List, insID)
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                                return List
                            end
                        end
                    end
                end)
            end

            local function hookMotionEquip()
                pcall(function()
                    local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                    if wl._lava_hooked_motion then return end
                    wl._lava_hooked_motion = true

                    local origEquip = wl.EquipMotion
                    if _G.__DuneTrack then _G.__DuneTrack(wl, 'EquipMotion') end
                    wl.EquipMotion = function(self, instid, dst_slot)
                        instid = tonumber(instid)
                        if instid and isInjectedIns(instid) then
                            local insSlot = 0
                            for i, v in ipairs(DataMgr.MotionSlotList) do
                                if v == instid then insSlot = i; break end
                            end
                            if insSlot > 0 then
                                local curIns = DataMgr.MotionSlotList[dst_slot]
                                if curIns == instid then return end
                                DataMgr.MotionSlotList[insSlot] = curIns or 0
                                DataMgr.MotionSlotList[dst_slot] = instid
                            else
                                while #DataMgr.MotionSlotList < dst_slot do
                                    table.insert(DataMgr.MotionSlotList, 0)
                                end
                                DataMgr.MotionSlotList[dst_slot] = instid
                            end
                            if EventSystem and EVENTTYPE_MOTION and EVENTID_MOTION_UPDATE_SLOT_LIST then
                                EventSystem:postEvent(EVENTTYPE_MOTION, EVENTID_MOTION_UPDATE_SLOT_LIST)
                            end
                            pcall(_AutoSaveOutfit)
                            return
                        end
                        return origEquip(self, instid, dst_slot)
                    end

                    local origUnequip = wl.unequip_motion_req
                    if _G.__DuneTrack then _G.__DuneTrack(wl, 'unequip_motion_req') end
                    wl.unequip_motion_req = function(self, instid, slot)
                        instid = tonumber(instid)
                        if instid and isInjectedIns(instid) then
                            for i, v in ipairs(DataMgr.MotionSlotList) do
                                if v == instid then
                                    table.remove(DataMgr.MotionSlotList, i)
                                    break
                                end
                            end
                            if EventSystem and EVENTTYPE_MOTION and EVENTID_MOTION_UPDATE_SLOT_LIST then
                                EventSystem:postEvent(EVENTTYPE_MOTION, EVENTID_MOTION_UPDATE_SLOT_LIST)
                            end
                            pcall(_AutoSaveOutfit)
                            return
                        end
                        return origUnequip(self, instid, slot)
                    end
                end)
            end

            local function hookIngameEmote()
                pcall(function()
                    local QEU = require("GameLua.Mod.BaseMod.Client.Emote.QuickExpressionUtils")
                    if QEU._lava_hooked then return end
                    QEU._lava_hooked = true

                    local _emoteSlotKey = nil
                    local _emoteSlotCache = {}
                    local function getInjectedEmotes()
                        local slotList = DataMgr and DataMgr.MotionSlotList or {}
                        local key = table.concat(slotList, ",")
                        if key == _emoteSlotKey then return _emoteSlotCache end
                        _emoteSlotKey = key
                        _emoteSlotCache = {}
                        for _, insID in ipairs(slotList) do
                            insID = tonumber(insID)
                            if insID and insID > 0 and isInjectedIns(insID) then
                                local resID = R.insToRes[insID]
                                if resID then
                                    local c = cfg(resID)
                                    if c and tonumber(c.ItemType) == 22 then
                                        _emoteSlotCache[#_emoteSlotCache + 1] = {
                                            resID = resID,
                                            name = c.ItemName or "",
                                            icon = c.ItemSmallIcon or c.ItemIcon or ""
                                        }
                                    end
                                end
                            end
                        end
                        return _emoteSlotCache
                    end

                    local origGetList = QEU.GetShowExpressionList
                    if _G.__DuneTrack then _G.__DuneTrack(QEU, 'GetShowExpressionList') end
                    QEU.GetShowExpressionList = function()
                        local tShowEmoteList, nWeaponEmoteId = origGetList()
                        tShowEmoteList = tShowEmoteList or {}
                        local emotes = getInjectedEmotes()
                        if #emotes > 0 then
                            local existingIDs = {}
                            for _, existing in pairs(tShowEmoteList) do
                                if existing.DefineID then
                                    existingIDs[tonumber(existing.DefineID.TypeSpecificID) or 0] = true
                                end
                            end
                            for _, em in ipairs(emotes) do
                                if not existingIDs[em.resID] then
                                    tShowEmoteList[#tShowEmoteList + 1] = {
                                        DefineID = {TypeSpecificID = em.resID},
                                        Name = em.name
                                    }
                                end
                            end
                        end
                        return tShowEmoteList, nWeaponEmoteId
                    end
                end)

                pcall(function()
                    local QE = require("GameLua.Mod.BaseMod.Client.Emote.QuickExpression")
                    if QE._lava_hooked_img then return end
                    QE._lava_hooked_img = true

                    local _emoteSlotKey = nil
                    local _emoteSlotCache = {}
                    local function getInjectedEmotes()
                        local slotList = DataMgr and DataMgr.MotionSlotList or {}
                        local key = table.concat(slotList, ",")
                        if key == _emoteSlotKey then return _emoteSlotCache end
                        _emoteSlotKey = key
                        _emoteSlotCache = {}
                        for _, insID in ipairs(slotList) do
                            insID = tonumber(insID)
                            if insID and insID > 0 and isInjectedIns(insID) then
                                local resID = R.insToRes[insID]
                                if resID then
                                    local c = cfg(resID)
                                    if c and tonumber(c.ItemType) == 22 then
                                        _emoteSlotCache[#_emoteSlotCache + 1] = {
                                            resID = resID,
                                            name = c.ItemName or "",
                                            icon = c.ItemSmallIcon or c.ItemIcon or ""
                                        }
                                    end
                                end
                            end
                        end
                        return _emoteSlotCache
                    end

                    local origGetImg = QE.GetEmoteImagePalthMap
                    if _G.__DuneTrack then _G.__DuneTrack(QE, 'GetEmoteImagePalthMap') end
                    QE.GetEmoteImagePalthMap = function(self, ...)
                        origGetImg(self, ...)
                        local emotes = getInjectedEmotes()
                        for _, em in ipairs(emotes) do
                            if em.icon ~= "" then
                                self.ItemIDToImagePathMap[em.resID] = em.icon
                            end
                        end
                    end
                end)

                pcall(function()
                    local le = require("GameLua.Mod.Library.GamePlay.Avatar.Emote.logic_emote")
                    if le._lava_hooked_exist then return end
                    le._lava_hooked_exist = true

                    local origExist = le.IsEmoteExist
                    if _G.__DuneTrack then _G.__DuneTrack(le, 'IsEmoteExist') end
                    le.IsEmoteExist = function(EmoteID)
                        if isInjectedRes(tonumber(EmoteID)) then return true end
                        return origExist(EmoteID)
                    end

                    local origDownloaded = le.CheckEmoteDownloaded
                    if origDownloaded then
                        if _G.__DuneTrack then _G.__DuneTrack(le, 'CheckEmoteDownloaded') end
                        le.CheckEmoteDownloaded = function(EmoteID, bUseCache, bLobby, bForeceLobby)
                            if isInjectedRes(tonumber(EmoteID)) then return true end
                            return origDownloaded(EmoteID, bUseCache, bLobby, bForeceLobby)
                        end
                    end
                end)
            end

            local function hookFashionBag()
                pcall(function()
                    local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                    if fbd._lava_hooked_bag then return end
                    fbd._lava_hooked_bag = true
                    local function onFashionBagSkinChanged(skin, slot)
                        skin = tonumber(skin)
                        if _S.equipSkinApplying or not skin or skin <= 0 or not isInjectedIns(skin) then return end
                        local rid = R.insToRes[skin]
                        if not rid or not isInjectedRes(rid) then return end
                        local cch = cache()
                        local oldRes = cch.equip[slot]
                        if oldRes and oldRes > 0 and oldRes ~= rid then
                            softRemoveEquipVisual(oldRes, slot)
                        end
                        saveEquipSkin(rid, skin)
                        if slot ~= "parachute" and slot ~= "glider" then
                            applyEquipVisual(rid, skin, slot)
                        end
                    end
                    local origBag = fbd.SetBagSkin
                    if _G.__DuneTrack then _G.__DuneTrack(fbd, 'SetBagSkin') end
                    fbd.SetBagSkin = function(self, skin)
                        local r = origBag(self, skin)
                        onFashionBagSkinChanged(skin, "bag")
                        return r
                    end
                    local origHelm = fbd.SetHelmetSkin
                    if _G.__DuneTrack then _G.__DuneTrack(fbd, 'SetHelmetSkin') end
                    fbd.SetHelmetSkin = function(self, skin)
                        local r = origHelm(self, skin)
                        onFashionBagSkinChanged(skin, "helmet")
                        return r
                    end
                    local function reInjectThrowObjects(bagIndex)
                        pcall(function()
                            local cch = cache()
                            if not cch.throwObjects then return end
                            local bags = fbd.GetFashionBags and fbd:GetFashionBags()
                            if not bags or not bags.bags then return end
                            local bag = bags.bags[bagIndex]
                            if not bag then return end
                            bag.throw_object_list = bag.throw_object_list or {}
                            for st, info in pairs(cch.throwObjects) do
                                if info.insID and info.insID > 0 and _K.THROW_SUB[st] then
                                    bag.throw_object_list[st] = info.insID
                                end
                            end
                        end)
                    end
                    local origUpdateAll = fbd.UpdateAllFashionBagExtraInfos
                    if origUpdateAll then
                        if _G.__DuneTrack then _G.__DuneTrack(fbd, 'UpdateAllFashionBagExtraInfos') end
                        fbd.UpdateAllFashionBagExtraInfos = function(self, all_knapsack_ext_info)
                            origUpdateAll(self, all_knapsack_ext_info)
                            if all_knapsack_ext_info then
                                for i, _ in pairs(all_knapsack_ext_info) do
                                    reInjectThrowObjects(i)
                                end
                            end
                        end
                    end
                    local origUpdateOne = fbd.UpdateFashionBagExtraInfoByIndex
                    if origUpdateOne then
                        if _G.__DuneTrack then _G.__DuneTrack(fbd, 'UpdateFashionBagExtraInfoByIndex') end
                        fbd.UpdateFashionBagExtraInfoByIndex = function(self, index, knapsack_ext_info)
                            origUpdateOne(self, index, knapsack_ext_info)
                            if index then reInjectThrowObjects(index) end
                        end
                    end
                end)
                pcall(function()
                    if not DataMgr or DataMgr._lava_hooked_equip_skin then return end
                    DataMgr._lava_hooked_equip_skin = true
                    local orig = DataMgr.UpdateEquipmentSkin
                    if _G.__DuneTrack then _G.__DuneTrack(DataMgr, 'UpdateEquipmentSkin') end
                    DataMgr.UpdateEquipmentSkin = function(itemSubType, putOnId)
                        putOnId = tonumber(putOnId)
                        if putOnId and putOnId > 0 and isInjectedIns(putOnId) and not _S.equipSkinApplying then
                            putOnEquipSkin(putOnId)
                        elseif putOnId == 0 then
                            local slot = (itemSubType == ENUM_ITEM_SUBTYPE.Backpack) and "bag"
                                or (itemSubType == ENUM_ITEM_SUBTYPE.Helmet_NoLevel) and "helmet" or nil
                            if slot then
                                local cch = cache()
                                takeOffEquipSkinVisual(slot, cch.equip[slot], cch.equip[slot .. "Ins"])
                                cch.equip[slot]          = nil
                                cch.equip[slot .. "Ins"] = nil
                                if MATCH_CONFIG.equip then MATCH_CONFIG.equip[slot] = 0 end
                                _S.matchApplied = false
                                invalidateSocialWearCache()
                                pcall(_AutoSaveOutfit)
                            end
                        end
                        return orig(itemSubType, putOnId)
                    end
                end)
            end

            local function hookBackpackValid()
                if _G.DEV_WARDROBE_BP_HOOKED then return end
                _G.DEV_WARDROBE_BP_HOOKED = true
                pcall(function()
                    local BU = import("BackpackUtils")
                    if BU and BU.GetBPIDByResID then
                        local orig = BU.GetBPIDByResID
                        if _G.__DuneTrack then _G.__DuneTrack(BU, 'GetBPIDByResID') end
                        BU.GetBPIDByResID = function(resID)
                            resID = tonumber(resID)
                            if resID and isInjectedRes(resID) then
                                local bp = orig(resID)
                                if bp and bp > 0 then return bp end
                                return resID
                            end
                            return orig(resID)
                        end
                    end
                end)
                pcall(function()
                    local AU = import("AvatarUtils")
                    if AU and AU.GetBPIDByResID then
                        local orig = AU.GetBPIDByResID
                        if _G.__DuneTrack then _G.__DuneTrack(AU, 'GetBPIDByResID') end
                        AU.GetBPIDByResID = function(resID, ...)
                            resID = tonumber(resID)
                            if resID and isInjectedRes(resID) then
                                local bp = orig(resID, ...)
                                if bp and bp > 0 then return bp end
                                return resID
                            end
                            return orig(resID, ...)
                        end
                    end
                end)
            end

            local function hookAvatarValid()
                pcall(function()
                    local CAC = require("GameLua.Mod.Library.GamePlay.Avatar.Component.CharacterAvatarComponent")
                    if not CAC._lava_hooked_check_valid then
                        CAC._lava_hooked_check_valid = true
                        local orig = CAC.CheckItemValid
                        if _G.__DuneTrack then _G.__DuneTrack(CAC, 'CheckItemValid') end
                        CAC.CheckItemValid = function(self, resID)
                            if isInjectedRes(resID) then return true end
                            return orig(self, resID)
                        end
                    end
                end)
            end

            local function hookLobbyWeaponCache()
                pcall(function()
                    local Arm = require("client.logic.armory.logic_armory")
                    local oRsp = Arm.install_weapon_skin_rsp
                    if _G.__DuneTrack then _G.__DuneTrack(Arm, 'install_weapon_skin_rsp') end
                    Arm.install_weapon_skin_rsp = function(client_data, errorCode, weapon_id, instanceID)
                        oRsp(client_data, errorCode, weapon_id, instanceID)
                        if errorCode == 0 or errorCode == _K.NET_OK then
                            cacheWeaponSkinFromIns(weapon_id, instanceID)
                        end
                    end
                end)
                pcall(function()
                    local wl = require("client.slua.logic.wardrobe.logic_wardrobe_new")
                    local o = wl.on_puton_rsp
                    if _G.__DuneTrack then _G.__DuneTrack(wl, 'on_puton_rsp') end
                    wl.on_puton_rsp = function(self, res, item, olditem, index, extra)
                        o(self, res, item, olditem, index, extra)
                        if item and item.instid and (res == 0 or res == _K.NET_OK) then
                            local resID, insID = tonumber(item.res_id), tonumber(item.instid)
                            local slot = getEquipSkinSlot(resID)
                            if isInjectedIns(insID) and slot and not _S.equipSkinApplying then
                                saveEquipSkin(resID, insID)
                                if slot ~= "parachute" and slot ~= "glider" then
                                    applyEquipVisual(resID, insID, slot)
                                end
                            elseif isInjectedIns(insID) then
                                local mt = wardrobeMainTab(resID)
                                if mt ~= _K.WARDROBE_PAGE_VEHICLE then
                                    if isThrowObjectRes(resID) then
                                        saveThrowObject(resID, insID)
                                    else
                                        saveEquip(resID, insID)
                                    end
                                end
                            end
                        end
                    end
                end)
            end

            local function hookGunWardrobe()
                pcall(function()
                    local wgl = require("client.slua.logic.wardrobe.logic_wardrobe_gun")
                    if wgl._lava_gun_hooked then return end
                    wgl._lava_gun_hooked = true

                    local origSetGunID = wgl.SetGunID
                    if _G.__DuneTrack then _G.__DuneTrack(wgl, 'SetGunID') end
                    wgl.SetGunID = function(self, weaponID, ...)
                        weaponID = tonumber(weaponID)
                        if not weaponID then return origSetGunID(self, weaponID, ...) end

                        local w = cache().weapons[weaponID]
                        local injected = w and w.insID and w.insID > 0 and isInjectedIns(w.insID)
                        local currentSkin = wgl.GetCurrentEquippedSkinInsID and wgl:GetCurrentEquippedSkinInsID(weaponID) or 0
                        if injected and currentSkin == w.insID then
                            return origSetGunID(self, weaponID, ...)
                        end

                        if injected then
                            pcall(function()
                                local Arm = require("client.logic.armory.logic_armory")
                                Arm.rsp_list = Arm.rsp_list or { skin_list = {}, install_list = {} }
                                Arm.rsp_list.install_list = Arm.rsp_list.install_list or {}
                                Arm.rsp_list.install_list[weaponID] = { skin_id = w.insID }
                                
                                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                                if fbd.UpdateCurrentFashionBagWeaponSkin then
                                    fbd:UpdateCurrentFashionBagWeaponSkin(weaponID, w.insID)
                                end
                                if fbd.SetFashionBagWeaponSkin then
                                    fbd:SetFashionBagWeaponSkin(weaponID, w.insID)
                                end
                            end)
                        else
                            pcall(function()
                                local Arm = require("client.logic.armory.logic_armory")
                                if Arm.rsp_list and Arm.rsp_list.install_list then
                                    Arm.rsp_list.install_list[weaponID] = nil
                                end
                                local fbd = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
                                if fbd.UpdateCurrentFashionBagWeaponSkin then
                                    fbd:UpdateCurrentFashionBagWeaponSkin(weaponID, 0)
                                end
                                local bag = fbd.GetCurrentFashionBag and fbd:GetCurrentFashionBag()
                                if bag and bag.weapon_skin_list then
                                    bag.weapon_skin_list[weaponID] = nil
                                end
                            end)
                        end

                        local result = origSetGunID(self, weaponID, ...)

                        if injected then
                            later(0.05, function()
                                pcall(function()
                                    local wgl2 = require("client.slua.logic.wardrobe.logic_wardrobe_gun")
                                    wgl2:UpdateCurrentGunAvatar(weaponID, w.insID)
                                    
                                    if EventSystem then
                                        if EVENTTYPE_WARDROBE and EVENTID_WARDROBE_UPDATE_CURRENT_PUT_ON_GUN then
                                            EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_CURRENT_PUT_ON_GUN, w.resID)
                                        end
                                        if EVENTTYPE_WARDROBE and EVENTID_WARDROBE_UPDATE_GUN_LIST then
                                            EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_GUN_LIST, -1)
                                        end
                                        if EVENTTYPE_ARMORY and EVENTID_ARMORY_EQUIP_STAT_CHANGE then
                                            EventSystem:postEvent(EVENTTYPE_ARMORY, EVENTID_ARMORY_EQUIP_STAT_CHANGE, w.resID)
                                        end
                                    end
                                end)
                            end)
                        else
                            later(0.05, function()
                                pcall(function()
                                    local wgl2 = require("client.slua.logic.wardrobe.logic_wardrobe_gun")
                                    wgl2:UpdateCurrentGunAvatar(weaponID, 0)
                                    if EventSystem and EVENTTYPE_WARDROBE and EVENTID_WARDROBE_UPDATE_CURRENT_PUT_ON_GUN then
                                        EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_CURRENT_PUT_ON_GUN, 0)
                                    end
                                    if EventSystem and EVENTID_WARDROBE_UPDATE_GUN_LIST then
                                        EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_UPDATE_GUN_LIST, weaponID)
                                    end
                                end)
                            end)
                            log("Weapon skin removed", weaponID)
                        end
                        
                        return result
                    end

                    local origUpdateGunAvatar = wgl.UpdateCurrentGunAvatar
                    if _G.__DuneTrack then _G.__DuneTrack(wgl, 'UpdateCurrentGunAvatar') end
                    wgl.UpdateCurrentGunAvatar = function(self, weaponID, insID, ...)
                        weaponID = tonumber(weaponID)
                        insID = tonumber(insID)
                        if weaponID and (not insID or insID <= 0) then
                            local w = cache().weapons[weaponID]
                            if w and w.insID and w.insID > 0 and isInjectedIns(w.insID) then
                                insID = w.insID
                                log("UpdateCurrentGunAvatar: using saved skin", weaponID, insID)
                            else
                                insID = 0
                            end
                        end
                        return origUpdateGunAvatar(self, weaponID, insID, ...)
                    end

                    if wgl.GetCurrentEquippedSkinInsID then
                        local origGetCurSkin = wgl.GetCurrentEquippedSkinInsID
                        if _G.__DuneTrack then _G.__DuneTrack(wgl, 'GetCurrentEquippedSkinInsID') end
                        wgl.GetCurrentEquippedSkinInsID = function(self, weaponID, ...)
                            weaponID = tonumber(weaponID)
                            if weaponID then
                                local w = cache().weapons[weaponID]
                                if w and w.insID and w.insID > 0 and isInjectedIns(w.insID) then
                                    return w.insID
                                end
                            end
                            return origGetCurSkin(self, weaponID, ...)
                        end
                    end

                    if wgl.GetGunSkinInsID then
                        local origGetGunSkin = wgl.GetGunSkinInsID
                        if _G.__DuneTrack then _G.__DuneTrack(wgl, 'GetGunSkinInsID') end
                        wgl.GetGunSkinInsID = function(self, weaponID, ...)
                            weaponID = tonumber(weaponID)
                            if weaponID then
                                local w = cache().weapons[weaponID]
                                if w and w.insID and w.insID > 0 and isInjectedIns(w.insID) then
                                    return w.insID
                                end
                            end
                            return origGetGunSkin(self, weaponID, ...)
                        end
                    end

                    log("hookGunWardrobe: done")
                end)
            end

            local function isInLobby()
                local ok, r = pcall(function()
                    return GameStatus and GameStatus.IsInLobbyOrMainCity and GameStatus.IsInLobbyOrMainCity() == true
                end)
                return ok and r == true
            end

            local function start()
                log("AddOutfit Lobby Only start")
                pcall(hookLobbyWeaponCache)
                pcall(hookGunWardrobe)
                pcall(hookLobbySwipePersistence)
                pcall(hookCDataTableCache)
                pcall(hookDepotInit)
                pcall(hookWardrobeData)
                pcall(hookPageFilter)
                pcall(hookArmory)
                pcall(hookPutOn)
                pcall(hookLobbyTheme)
                pcall(hookMotionEquip)
                pcall(hookIngameEmote)
                pcall(hookFashionBag)
                pcall(hookBackpackValid)
                pcall(hookAvatarValid)

                if injectAllSources() then
                    refreshWardrobe()
                    later(1.0, reapplyLobbyEquipped)
                else
                    local tries = 0
                    local function retry()
                        tries = tries + 1
                        if injectAllSources() then
                            refreshWardrobe()
                            later(1.0, reapplyLobbyEquipped)
                            return
                        end
                        if tries < 40 then later(1.5, retry) end
                    end
                    later(1.5, retry)
                end

                pcall(function()
                    if isInLobby() then
                        snapshotLobbyWear()
                    end
                end)
            end

            pcall(_loadEquippedCache)
            start()

            log("AddOutfit Lobby Only loaded")
        end

        local function prewarmModules()
            local mods = {
                "client.logic.armory.logic_armory",
                "client.slua.logic.wardrobe.fashionbag.fashionbag_data",
                "client.logic.lobby.hall_theme_utils",
                "client.slua.logic.wardrobe.logic_wardrobe_gun",
                "client.slua.logic.wardrobe.wardrobe_data",
                "client.network.Protocol.WardRobeHandler",
                "client.slua.logic.wardrobe.logic_wardrobe_avatar",
                "client.slua.logic.wardrobe.fashionbag.wardrobe_fashion_utils",
                "client.logic.data.AvatarData",
                "client.slua.logic.XSuit.logic_xsuit",
                "client.slua.logic.wardrobe.logic_wardrobe_new",
                "client.slua.logic.wardrobe.logic_display_setting",
                "client.logic.avatar.logic_team_avatar_manager",
                "client.slua.logic.wardrobe.logic_wardrobe_data_center",
                "client.slua.logic.wardrobe.WardrobeDataEntity",
                "client.slua.umg.Wardrobe.subtab_item_list_base",
                "client.slua.logic.wardrobe.tab_surveillance",
                "client.network.comm.NetManager",
                "client.slua.umg.Wardrobe.wardrobe_macro",
                "client.slua.logic.avatar.avatar_common",
                "client.slua.logic.lobby.Main.Lobby_Main_Control",
                "common.time_ticker",
                "GameLua.GameCore.Module.Subsystem.SubsystemMgr",
                "GameLua.Mod.BaseMod.GamePlay.Backpack.BackpackUtils",
                "GameLua.Mod.Library.GamePlay.Avatar.AvatarDataUtil",
                "GameLua.Activity.Commercialize.GamePlay.CommerAvatarDataUtil",
            }
            for _, m in ipairs(mods) do
                pcall(require, m)
            end
        end

        prewarmModules()
        initHooks()

        log("AddOutfit Lobby Only loaded")
    end)
    if not _ao_ok then
        print("[AddOutfit] LOAD ERROR:", tostring(_ao_err))
    end
